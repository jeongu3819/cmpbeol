import logging

from openai import OpenAI

from app.config import settings, env_first

logger = logging.getLogger(__name__)

# =========================
# OpenAI (외부 API 테스트용) Adapter
# - 회사 밖에서 GPT 모델로 AI 요약/정리 성능을 비교 테스트하기 위한 경로.
# - API_KEY / BASE_URL / MODEL 은 .env.local 또는 .env.production 에서만 읽는다.
#   (frontend / DB 저장 없음 — 민감정보 보호)
# - dsllm_adapter 와 동일한 chat / chat_stream 인터페이스를 제공해 router 가 분기만 한다.
# - 로그에 API Key / prompt / response 전체를 남기지 않는다.
# =========================

_DEFAULT_BASE_URL = "https://api.openai.com/v1"
_REQUEST_TIMEOUT = 60.0  # 초 — 외부 호출 timeout 필수


def is_configured() -> bool:
    """OPENAI_API_KEY 가 env 에 설정되어 있는지. (런타임 os.environ 실측 우선)"""
    return bool(env_first("OPENAI_API_KEY", settings.openai_api_key))


def _env_models() -> list[str]:
    """env 기반 OpenAI 모델 id 목록.

    OPENAI_MODELS(쉼표구분)가 있으면 그것을, 없으면 OPENAI_MODEL 하나를 노출한다.
    기본 모델(OPENAI_MODEL)은 항상 목록 맨 앞에 한 번만 포함한다.
    """
    raw = env_first("OPENAI_MODELS", settings.openai_models)
    models = [m.strip() for m in raw.split(",") if m.strip()] if raw else []

    default = env_first("OPENAI_MODEL", settings.openai_model)
    if default:
        # 중복 제거 후 기본 모델을 맨 앞으로
        models = [m for m in models if m != default]
        models = [default] + models
    return models


def get_available_models() -> list[dict]:
    """프론트 드롭다운에 노출할 OpenAI 모델 메타 목록(dsllm_adapter 와 동일 스키마)."""
    out: list[dict] = []
    for model_id in _env_models():
        out.append({
            "key": model_id,
            "model": model_id,
            "name": model_id,
            "description": "외부 OpenAI API 테스트용",
            "capability": "text-only",
            "vision_supported": False,
            "experimental": True,
        })
    return out


def list_model_keys() -> list[str]:
    return [m["key"] for m in get_available_models()]


def default_model_key() -> str:
    models = get_available_models()
    return models[0]["key"] if models else (settings.openai_model or "").strip()


def is_known_model(model_name: str | None) -> bool:
    name = (model_name or "").strip()
    if not name:
        return False
    return name in set(list_model_keys())


def _get_base_url() -> str:
    url = env_first("OPENAI_BASE_URL", settings.openai_base_url).rstrip("/")
    url = url or _DEFAULT_BASE_URL
    # ⚠️ OpenAI(외부 API)는 보안상 https 강제. http:// 차단. (DSLLM과 정책 분리)
    if not url.startswith("https://"):
        raise RuntimeError(
            f"OpenAI BASE_URL은 https://로 시작해야 합니다. Current value: {url}"
        )
    return url


def _get_api_key() -> str:
    api_key = env_first("OPENAI_API_KEY", settings.openai_api_key)
    if not api_key:
        raise RuntimeError(
            "OpenAI API Key가 설정되어 있지 않습니다. "
            "backend env 파일에 OPENAI_API_KEY를 설정한 뒤 다시 시도해주세요."
        )
    return api_key


def _resolve_model(model_name: str | None) -> str:
    name = (model_name or "").strip()
    if name:
        return name
    fallback = default_model_key()
    if not fallback:
        raise RuntimeError(
            "OpenAI model is missing. Set OPENAI_MODEL in .env.local/.env.production "
            "또는 요청에 model_name을 전달해야 합니다."
        )
    return fallback


def _get_client() -> OpenAI:
    return OpenAI(
        api_key=_get_api_key(),
        base_url=_get_base_url(),
        timeout=_REQUEST_TIMEOUT,
    )


# =========================
# 오류 분류 (status code 기반 사용자 친화 메시지)
# - API Key 원문은 메시지/로그에 절대 포함하지 않는다.
# - OpenAI 401 응답 body 의 message 에는 마스킹된 키가 섞일 수 있어, raw body 를 쓰지 않고
#   curated 메시지 + status_code + error code 만 노출한다.
# =========================
class OpenAIAdapterError(RuntimeError):
    def __init__(self, user_message: str, status_code=None, code=None, error_type=None):
        super().__init__(user_message)
        self.user_message = user_message
        self.status_code = status_code
        self.code = code
        self.error_type = error_type


def _error_code_from(exc) -> str | None:
    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            return err.get("code") or err.get("type")
    code = getattr(exc, "code", None)
    return code if isinstance(code, str) else None


def _classify(exc) -> OpenAIAdapterError:
    """OpenAI SDK 예외 → status code 별 사용자 친화 메시지로 변환."""
    status = getattr(exc, "status_code", None)
    code = _error_code_from(exc)
    name = type(exc).__name__

    if status == 401:
        msg = "OpenAI API Key 인증에 실패했습니다. Secret Key가 맞는지 확인해주세요."
    elif status == 403:
        msg = "OpenAI API 권한이 없거나 현재 Project/API Key에서 해당 모델 사용 권한이 없습니다."
    elif status == 404 or code == "model_not_found":
        msg = "선택한 OpenAI 모델을 사용할 수 없습니다. 모델명 또는 모델 접근 권한을 확인해주세요."
    elif status == 429:
        msg = "OpenAI API 사용량/크레딧/Rate Limit 문제일 수 있습니다."
    elif name in ("APITimeoutError", "APIConnectionError") or status is None:
        msg = "OpenAI API에 연결하지 못했습니다. 네트워크/프록시/방화벽을 확인해주세요."
    else:
        # 기타: code/status 만 노출 (raw body 미노출)
        detail = f" (code={code})" if code else ""
        msg = f"OpenAI 호출 실패 (status={status}){detail}."

    return OpenAIAdapterError(user_message=msg, status_code=status, code=code, error_type=name)


def _is_unsupported_param_error(exc) -> bool:
    """일부 최신 모델은 temperature/max_output_tokens 미지원 → 옵션 제거 후 재시도 판단."""
    if getattr(exc, "status_code", None) != 400:
        return False
    code = _error_code_from(exc)
    if code in ("unsupported_parameter", "unknown_parameter", "invalid_request_error"):
        return True
    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        err = body.get("error") or {}
        param = err.get("param") if isinstance(err, dict) else None
        if param in ("temperature", "max_output_tokens", "top_p"):
            return True
    return False


def list_model_ids() -> list[str]:
    """현재 API Key 로 접근 가능한 모델 id 목록(GET /v1/models)."""
    client = _get_client()
    logger.info("[OpenAI] list models: base_url=%s", _get_base_url())
    try:
        resp = client.models.list()
    except Exception as e:
        raise _classify(e) from e
    return [getattr(m, "id", "") for m in getattr(resp, "data", []) if getattr(m, "id", "")]


def _extract_responses_text(response) -> str:
    """Responses API 응답에서 text 추출 → 기존 AI Report/Query 문자열 형태로 정규화."""
    text = getattr(response, "output_text", None)
    if text:
        return text.strip()
    # fallback: output 항목 순회
    parts: list[str] = []
    for item in getattr(response, "output", []) or []:
        for c in getattr(item, "content", []) or []:
            t = getattr(c, "text", None)
            if t:
                parts.append(t)
    return "".join(parts).strip()


def _create_response(client: OpenAI, *, model: str, instructions: str, user_input: str,
                     temperature: float, max_tokens: int):
    """Responses API 호출. 옵션 미지원 모델은 옵션 제거 후 1회 재시도."""
    base = {"model": model, "input": user_input or ""}
    if instructions:
        base["instructions"] = instructions
    attempt = {**base, "temperature": temperature, "max_output_tokens": max_tokens}
    try:
        return client.responses.create(**attempt)
    except Exception as e:
        if _is_unsupported_param_error(e):
            logger.info("[OpenAI] retry /responses without optional params (model=%s)", model)
            try:
                return client.responses.create(**base)
            except Exception as e2:
                raise _classify(e2) from e2
        raise _classify(e) from e


def chat(
    base_url: str | None,
    model_name: str | None,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 4096,
) -> str:
    """OpenAI Responses API(/v1/responses) 우선 사용. system_prompt→instructions 매핑."""
    resolved_model = _resolve_model(model_name)
    client = _get_client()

    # ⚠️ API Key / prompt 본문은 로그에 남기지 않는다. 모델/base_url 메타만.
    logger.info("[OpenAI] responses request: model=%s, base_url=%s", resolved_model, _get_base_url())

    response = _create_response(
        client,
        model=resolved_model,
        instructions=system_prompt or "",
        user_input=user_prompt or "",
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return _extract_responses_text(response)


def chat_stream(
    base_url: str | None,
    model_name: str | None,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 4096,
):
    """Generator로 token 문자열을 yield. Responses API 스트리밍 사용."""
    resolved_model = _resolve_model(model_name)
    client = _get_client()

    logger.info("[OpenAI] responses stream: model=%s, base_url=%s", resolved_model, _get_base_url())

    base = {"model": resolved_model, "input": user_prompt or ""}
    if system_prompt:
        base["instructions"] = system_prompt
    attempt = {**base, "temperature": temperature, "max_output_tokens": max_tokens, "stream": True}

    def _iter(kwargs):
        stream = client.responses.create(**kwargs)
        for event in stream:
            if getattr(event, "type", "") == "response.output_text.delta":
                delta = getattr(event, "delta", None)
                if delta:
                    yield delta

    try:
        yield from _iter(attempt)
    except Exception as e:
        if _is_unsupported_param_error(e):
            try:
                yield from _iter({**base, "stream": True})
                return
            except Exception as e2:
                raise _classify(e2) from e2
        raise _classify(e) from e


# =========================
# Vision 호출 (super_admin Vision Report Test PoC 전용)
# - 멀티모달 입력(content = input_text + input_image data URL)을 Responses API 로 호출.
# - 기존 chat / chat_stream 은 절대 건드리지 않는다(텍스트 경로 무영향).
# - 이미지 binary/base64/prompt 본문은 로그에 남기지 않는다(모델/base_url 메타만).
# =========================
def _extract_usage(response) -> dict | None:
    """Responses API 응답에서 usage(token) 정보를 dict 로 정규화."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return None
    for attr in ("model_dump", "dict"):
        fn = getattr(usage, attr, None)
        if callable(fn):
            try:
                return fn()
            except Exception:
                pass
    out = {}
    for k in ("input_tokens", "output_tokens", "total_tokens"):
        v = getattr(usage, k, None)
        if v is not None:
            out[k] = v
    return out or None


def _extract_completion_meta(response, max_tokens: int | None) -> dict:
    """Responses API 응답에서 완료 상태/잘림(truncation) 여부를 정규화.

    Responses API:
      - response.status: "completed" / "incomplete" / "failed"
      - response.incomplete_details.reason: "max_output_tokens" / "content_filter" 등
    출력이 max_output_tokens 에 도달해 잘린 경우 truncated=True 로 표시한다.
    incomplete_details 가 없더라도 output_tokens >= max_tokens 면 휴리스틱으로 truncated 판정.
    """
    status = getattr(response, "status", None)
    reason = None
    details = getattr(response, "incomplete_details", None)
    if details is not None:
        reason = getattr(details, "reason", None)
        if reason is None and isinstance(details, dict):
            reason = details.get("reason")

    truncated = False
    if status == "incomplete":
        truncated = True
    if reason == "max_output_tokens":
        truncated = True
    # 휴리스틱: usage.output_tokens 가 한도에 도달
    if not truncated and max_tokens:
        usage = _extract_usage(response)
        out_tok = (usage or {}).get("output_tokens")
        if isinstance(out_tok, int) and out_tok >= max_tokens:
            truncated = True

    return {"status": status, "incomplete_reason": reason, "truncated": truncated}


def vision_chat(
    model_name: str | None,
    instructions: str,
    content: list,
    *,
    max_tokens: int | None = None,
    timeout: float | None = None,
) -> dict:
    """이미지 포함 멀티모달 호출. Responses API(/v1/responses) 사용.

    Args:
        model_name: 사용할 모델 id(UI 선택값). 비어 있으면 기본 모델로 복귀.
        instructions: system 역할 지시문(global rule + 출력 schema 유도).
        content: user 메시지 content 리스트
            예) [{"type": "input_text", "text": ...},
                 {"type": "input_image", "image_url": "data:image/png;base64,..."}]
        max_tokens: max_output_tokens. None 이면 settings.vision_report_max_output_tokens(기본 8000).

    Returns:
        {"raw_text": str, "usage": dict|None, "model": str,
         "status": str|None, "incomplete_reason": str|None, "truncated": bool,
         "max_output_tokens": int}

    Raises:
        OpenAIAdapterError: 호출 실패(status code 별 사용자 친화 메시지).
    """
    resolved_model = _resolve_model(model_name)
    client = _get_client()  # _REQUEST_TIMEOUT(60s) 적용
    # vision 은 이미지 batch 라 더 길 수 있어 호출자(Vision AI 설정)가 timeout 을 늘릴 수 있다.
    if timeout is not None and timeout > 0:
        client = client.with_options(timeout=float(timeout))

    effective_max = max_tokens
    if effective_max is None:
        effective_max = int(getattr(settings, "vision_report_max_output_tokens", 8000) or 8000)

    logger.info("[OpenAI] vision request: model=%s, base_url=%s, images=%d, max_output_tokens=%d",
                resolved_model, _get_base_url(),
                sum(1 for c in content if isinstance(c, dict) and c.get("type") == "input_image"),
                effective_max)

    base = {
        "model": resolved_model,
        "input": [{"role": "user", "content": content}],
    }
    if instructions:
        base["instructions"] = instructions
    attempt = {**base, "max_output_tokens": effective_max}

    no_limit = False
    try:
        response = client.responses.create(**attempt)
    except Exception as e:
        if _is_unsupported_param_error(e):
            logger.info("[OpenAI] retry vision without optional params (model=%s)", resolved_model)
            try:
                response = client.responses.create(**base)
                no_limit = True
            except Exception as e2:
                raise _classify(e2) from e2
        else:
            raise _classify(e) from e

    meta = _extract_completion_meta(response, None if no_limit else effective_max)
    return {
        "raw_text": _extract_responses_text(response),
        "usage": _extract_usage(response),
        "model": resolved_model,
        "status": meta["status"],
        "incomplete_reason": meta["incomplete_reason"],
        "truncated": meta["truncated"],
        "max_output_tokens": None if no_limit else effective_max,
    }


# =========================
# 연결 테스트 (super_admin AI Settings — 단계별 진단)
# 1. API Key env 존재  2. /v1/models 인증·네트워크  3. 선택 모델 접근 가능  4. /v1/responses 호출
# ⚠️ 프로젝트/Task/회사 내부 데이터는 절대 넣지 않는다. 비민감 고정 문구만 사용.
# =========================
_TEST_USER_PROMPT = "안녕하세요. 한 문장으로 응답해주세요."
_TEST_SYSTEM_PROMPT = "You are a helpful assistant. 한 문장으로만 응답하세요."


def run_connection_test(model_name: str | None) -> dict:
    base_url = _get_base_url()
    resolved_model = (model_name or "").strip() or default_model_key()

    # 1) API Key env 존재
    if not is_configured():
        return {
            "ok": False, "stage": "api_key", "model": resolved_model, "base_url": base_url,
            "message": "OPENAI_API_KEY가 backend env에 설정되어 있지 않습니다.",
        }

    # 2) /v1/models — 인증/네트워크 확인
    try:
        model_ids = list_model_ids()
    except OpenAIAdapterError as e:
        return {
            "ok": False, "stage": "models", "model": resolved_model, "base_url": base_url,
            "status_code": e.status_code, "code": e.code, "message": e.user_message,
        }

    # 3) 선택 모델 접근 가능 여부
    model_found = resolved_model in set(model_ids)
    if not model_found:
        return {
            "ok": False, "stage": "model_check", "model": resolved_model, "base_url": base_url,
            "model_found": False, "models_count": len(model_ids),
            "message": (
                f"현재 API Key에서 {resolved_model} 모델을 찾지 못했습니다. "
                f"OPENAI_MODELS 값을 접근 가능한 모델명으로 변경해주세요."
            ),
        }

    # 4) /v1/responses — 짧은 테스트 호출
    try:
        content = chat(
            base_url=None, model_name=resolved_model,
            system_prompt=_TEST_SYSTEM_PROMPT, user_prompt=_TEST_USER_PROMPT,
            temperature=0.2, max_tokens=64,
        )
    except OpenAIAdapterError as e:
        return {
            "ok": False, "stage": "responses", "model": resolved_model, "base_url": base_url,
            "model_found": True, "status_code": e.status_code, "code": e.code,
            "message": e.user_message,
        }

    answer = (content or "").strip()
    if len(answer) > 200:
        answer = answer[:200] + "…"
    return {
        "ok": True, "stage": "done", "model": resolved_model, "base_url": base_url,
        "model_found": True, "models_count": len(model_ids), "answer": answer,
    }
