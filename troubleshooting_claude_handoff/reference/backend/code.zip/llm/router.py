"""LLM Provider 라우터 — provider(dsllm/openai) 별 adapter 분기.

AI Report / AI Query / 요약 기능은 adapter 를 직접 호출하지 말고 이 router 를 거친다.

- provider == "dsllm" → 사내 DSLLM adapter (기존 동작 그대로)
- provider == "openai" → 외부 OpenAI adapter (env 에 OPENAI_API_KEY 가 있을 때만 호출 가능)

기본 Provider 는 env(AI_PROVIDER, 기본 dsllm). 사용자가 AI Settings 에서 고른 값이
DB(ai_settings.provider)에 저장되면 그 값이 우선한다.
"""

import logging

from app.config import settings, env_first
from app.llm import dsllm_adapter, openai_adapter

logger = logging.getLogger(__name__)

DSLLM = "dsllm"
OPENAI = "openai"

_PROVIDERS = {
    DSLLM: {"label": "DSLLM / 사내 모델", "adapter": dsllm_adapter},
    OPENAI: {"label": "OpenAI / 외부 API 테스트", "adapter": openai_adapter},
}

# OpenAI provider 선택 시 화면에 노출할 경고 문구.
OPENAI_WARNING = (
    "외부 OpenAI API 테스트 모드입니다. "
    "회사 내부 정보, 설비명, 공정 조건, 사람 이름, 내부 시스템 정보 등 민감한 데이터는 "
    "외부 API로 전송하지 마세요. 비식별 샘플 데이터 또는 테스트 프로젝트에서만 사용하세요."
)


def env_default_provider() -> str:
    p = (settings.ai_provider or DSLLM).strip().lower()
    return p if p in _PROVIDERS else DSLLM


def openai_enabled() -> bool:
    """OpenAI provider 를 *선택*할 수 있는지.

    - ENABLE_OPENAI_PROVIDER=true 이거나
    - OPENAI_API_KEY 가 설정되어 있으면 선택 가능.
    사내 운영 env 에는 둘 다 없으므로 자연히 비활성화된다.
    """
    return bool(settings.enable_openai_provider) or openai_adapter.is_configured()


def is_provider_available(provider: str) -> bool:
    p = (provider or "").strip().lower()
    if p == DSLLM:
        return True
    if p == OPENAI:
        return openai_enabled()
    return False


def resolve_active_provider(saved_provider: str | None) -> str:
    """실제로 사용할 provider 결정.

    저장값(DB) → 없으면 env 기본값. 알 수 없는 값이면 dsllm 로 안전 복귀.
    ⚠️ openai 가 key 미설정이어도 여기서 dsllm 로 강등하지 않는다.
        (호출부에서 '키 미설정' 명시적 에러를 띄우기 위함)
    """
    p = (saved_provider or "").strip().lower()
    if p not in _PROVIDERS:
        p = env_default_provider()
    return p if p in _PROVIDERS else DSLLM


def adapter_for(provider: str):
    return _PROVIDERS[resolve_active_provider(provider)]["adapter"]


def available_models(provider: str) -> list[dict]:
    return _PROVIDERS[resolve_active_provider(provider)]["adapter"].get_available_models()


def default_model_key(provider: str) -> str:
    return _PROVIDERS[resolve_active_provider(provider)]["adapter"].default_model_key()


def resolve_model(provider: str, selected_model: str | None) -> str:
    """active provider 기준으로 사용할 모델 key 확정.

    - 선택값이 비어 있으면 provider 기본 모델.
    - 선택값이 해당 provider 의 등록 모델이면 그대로 사용.
    - openai 는 사용자가 임의 모델명을 쓸 수 있으므로 비어있지 않으면 그대로 허용.
    - dsllm 인데 등록되지 않은 값(예: provider 전환 후 남은 openai 모델명)이면 기본 모델로 복귀.
    """
    prov = resolve_active_provider(provider)
    sel = (selected_model or "").strip()
    if not sel:
        return default_model_key(prov)
    ad = _PROVIDERS[prov]["adapter"]
    if ad.is_known_model(sel):
        return sel
    if prov == OPENAI:
        return sel  # custom 모델명 허용
    return default_model_key(prov)


def connection_state(provider: str) -> dict:
    """provider 별 연결 상태(설정 여부만). API Key 원문은 절대 포함하지 않는다.

    ⚠️ os.environ(런타임 실측) 우선으로 읽는다(env_first). pydantic Settings 스냅샷이
    비어 있어도 environment.py 가 채운 os.environ 값을 보므로, 'OPENAI_API_KEY 감지=확인됨'
    인데 'api_key_configured=false' 로 갈리던 모순을 원천 차단한다.
    """
    prov = resolve_active_provider(provider)
    if prov == OPENAI:
        base_url = env_first("OPENAI_BASE_URL", settings.openai_base_url)
        return {
            "base_url_configured": bool(base_url),
            "base_url_display": base_url,
            "api_key_configured": openai_adapter.is_configured(),
        }
    # DSLLM: DSLLM_* 우선 → 기존 BASE_URL/API_KEY fallback (dsllm_effective_* 와 동일 우선순위).
    base_url = env_first("DSLLM_BASE_URL") or env_first("BASE_URL", settings.dsllm_effective_base_url)
    api_key = env_first("DSLLM_API_KEY") or env_first("API_KEY", settings.dsllm_effective_api_key)
    return {
        "base_url_configured": bool(base_url),
        "base_url_display": base_url,
        "api_key_configured": bool(api_key),
    }


def list_providers() -> list[dict]:
    """AI Settings 화면용 provider 목록(선택 가능 여부 포함)."""
    return [
        {"key": DSLLM, "label": _PROVIDERS[DSLLM]["label"], "available": True},
        {"key": OPENAI, "label": _PROVIDERS[OPENAI]["label"], "available": openai_enabled()},
    ]


def _ensure_callable(provider: str) -> str:
    prov = resolve_active_provider(provider)
    if prov == OPENAI and not openai_adapter.is_configured():
        raise RuntimeError(
            "OpenAI API Key가 설정되어 있지 않습니다. "
            "backend env 파일에 OPENAI_API_KEY를 설정한 뒤 다시 시도해주세요."
        )
    return prov


def chat(
    provider: str,
    base_url: str | None,
    model_name: str | None,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 4096,
) -> str:
    prov = _ensure_callable(provider)
    return _PROVIDERS[prov]["adapter"].chat(
        base_url=base_url,
        model_name=model_name,
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        temperature=temperature,
        max_tokens=max_tokens,
    )


def chat_stream(
    provider: str,
    base_url: str | None,
    model_name: str | None,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 4096,
):
    prov = _ensure_callable(provider)
    return _PROVIDERS[prov]["adapter"].chat_stream(
        base_url=base_url,
        model_name=model_name,
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        temperature=temperature,
        max_tokens=max_tokens,
    )
