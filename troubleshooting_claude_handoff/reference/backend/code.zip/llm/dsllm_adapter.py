import logging

from openai import OpenAI

from app.config import settings

logger = logging.getLogger(__name__)

# =========================
# DSLLM Gateway (OpenAI SDK) Adapter
# - ipynb에서 검증된 OpenAI SDK 방식으로 호출.
# - BASE_URL/API_KEY는 .env.local 또는 .env.production에서만 읽는다.
# - 모델 목록은 env(LLM_MODEL_1~4) 기반.
# - 응답은 choices[0].message.content만 사용 (reasoning_content 등은 노출 X).
# =========================

# typo / legacy 호환 alias. key 입력 → 실제 model id로 변환.
_LEGACY_ALIAS: dict[str, str] = {
    "GuassO-Think": "GaussO-Think",
    "GuassO3.2":    "GaussO3.2",
    "GuassO4.1":    "GaussO4.1",
    "GuassO4-VL":   "GaussO4-VL",
}

# 모델별 설명 (env 기준 model_1~4 순서)
_MODEL_DESCRIPTIONS = [
    "tool call 가능, Reasoning 가능",
    "tool call 가능, Reasoning 가능",
    "tool call 가능, Reasoning 가능",
    "이미지 인식 가능",
]

# 모델별 capability 메타 (env 기준 model_1~4 순서).
# ⚠️ 메타데이터 전용 — 현재 이 값으로 실제 image call 을 수행하지 않는다.
# vision_supported=True 여도 현재는 image_manifest 만 준비하고 실제 이미지는 모델에 보내지 않는다.
#
# Future multimodal path:
# - chat() 는 지금도 text-only. 이 capability 는 UI/미래 확장(어떤 모델이 vision 가능한지)
#   판별용 메타데이터일 뿐이며, 호출 경로를 바꾸지 않는다.
# - 안정적인 vision 모델 확보 후, 별도 멀티모달 어댑터가
#   text_context + image_manifest + 인가된 이미지 파일을 소비한다.
_MODEL_CAPABILITIES = [
    {"capability": "text-only", "vision_supported": False, "experimental": False},
    {"capability": "text-only", "vision_supported": False, "experimental": False},
    {"capability": "text-only", "vision_supported": False, "experimental": False},
    {"capability": "vision-supported", "vision_supported": True, "experimental": True},
]


def _capability_for(idx: int) -> dict:
    if 0 <= idx < len(_MODEL_CAPABILITIES):
        return _MODEL_CAPABILITIES[idx]
    return {"capability": "text-only", "vision_supported": False, "experimental": False}


def _env_models() -> list[str]:
    """env 기반 모델 id 목록 (빈 값 제외, 순서 유지)."""
    raw = [
        (settings.model_1 or "").strip(),
        (settings.model_2 or "").strip(),
        (settings.model_3 or "").strip(),
        (settings.model_4 or "").strip(),
    ]
    return [m for m in raw if m]


def get_available_models() -> list[dict]:
    """프론트 드롭다운에 노출할 모델 메타 목록.

    기존 필드(key/model/name/description)는 그대로 유지하고, capability 메타
    (capability/vision_supported/experimental)를 **추가**한다(하위호환 유지).
    """
    out: list[dict] = []
    for idx, model_id in enumerate(_env_models()):
        cap = _capability_for(idx)
        out.append({
            "key": f"DS/{model_id}",
            "model": model_id,
            "name": f"DS/{model_id}",
            "description": _MODEL_DESCRIPTIONS[idx] if idx < len(_MODEL_DESCRIPTIONS) else "",
            # ── capability 메타 (additive, UI/미래 멀티모달용) ──
            "capability": cap["capability"],
            "vision_supported": cap["vision_supported"],
            "experimental": cap["experimental"],
        })
    return out


def get_model_capabilities() -> list[dict]:
    """모델별 capability 메타만 별도로 반환(향후 멀티모달 라우팅 기반).

    현재는 메타데이터 전용 — 이 값으로 실제 이미지 호출을 수행하지 않는다.
    """
    out: list[dict] = []
    for idx, model_id in enumerate(_env_models()):
        cap = _capability_for(idx)
        out.append({
            "model_key": f"DS/{model_id}",
            "model_name": model_id,
            "capability": cap["capability"],
            "vision_supported": cap["vision_supported"],
            "experimental": cap["experimental"],
        })
    return out


def list_model_keys() -> list[str]:
    """프론트 드롭다운용 key 목록 (env 기반)."""
    return [m["key"] for m in get_available_models()]


# =========================
# Vision(이미지 입력) — DS/Gemma4 multimodal chat/completions
# - 사내 DSLLM 게이트웨이의 /v1/chat/completions 에 text + image_url 을 함께 넣는
#   멀티모달 payload 로 호출한다(별도 image generation endpoint 를 쓰지 않는다).
# - text-only chat() 경로는 그대로 두고, vision_chat() 만 멀티모달 content 를 구성한다.
# - endpoint 는 OpenAI SDK 가 base_url + "/chat/completions" 로 조립한다
#   (_get_base_url 이 이미 trailing /chat/completions 를 정리 → 중복 path 없음).
# =========================

# vision 후보로 노출할 최소 안내 문구(Vision AI 설정 UI 에서 사용).
VISION_CANDIDATE_NOTE = (
    "DS/Gemma4는 사내 Vision 모델입니다. "
    "chat/completions 멀티모달(image_url) 입력으로 이미지 포함 AI Report에 사용할 수 있습니다. "
    "게이트웨이 버전에 따라 멀티모달 지원이 다를 수 있으니 'vision 입력 테스트'로 먼저 확인하세요."
)


class DsllmVisionError(RuntimeError):
    """DSLLM vision(멀티모달 chat/completions) 호출 실패.

    openai_adapter.OpenAIAdapterError 와 동일한 표면(user_message/status_code/code)을
    제공해 호출부(main.py)가 provider 무관하게 동일하게 처리할 수 있게 한다.
    payload_unsupported=True 는 "텍스트 연결은 되지만 image_url payload 처리 실패" 신호다.
    """

    def __init__(self, user_message: str, status_code=None, code=None, error_type=None,
                 payload_unsupported: bool = False):
        super().__init__(user_message)
        self.user_message = user_message
        self.status_code = status_code
        self.code = code
        self.error_type = error_type
        self.payload_unsupported = payload_unsupported


def vision_candidate_models() -> list[str]:
    """vision 후보로 노출할 DSLLM 모델 key 목록.

    capability 메타에서 vision_supported=True 로 표시된 모델(현재 DS/Gemma4)만 노출한다.
    """
    return [m["key"] for m in get_available_models() if m.get("vision_supported")]


def supports_vision_payload() -> bool:
    """실제 이미지(image payload) 입력 처리가 구현되었는지.

    DS/Gemma4 멀티모달 chat/completions(image_url) 경로가 구현되어 True.
    (게이트웨이가 실제로 멀티모달을 지원하는지는 vision-test 로 검증한다.)
    """
    return True


def _to_chat_content(content) -> tuple:
    """Responses 스타일 content(list) → Chat Completions 멀티모달 content 로 변환.

    입력 항목 매핑:
      {"type":"input_text","text": ...}               → {"type":"text","text": ...}
      {"type":"input_image","image_url":"data:..."}   → {"type":"image_url","image_url":{"url": ...}}
      {"type":"text"|"image_url", ...}                → 정규화 후 그대로

    이미지가 하나도 없으면 텍스트를 이어붙인 **일반 문자열**을 반환한다
    (검증된 text-only chat 경로와 동일한 형태 → 게이트웨이 호환성 최대화).

    Returns:
        (chat_content, image_count) — chat_content 는 str(텍스트 전용) 또는 content parts list.
    """
    if isinstance(content, str):
        return content, 0

    parts: list = []
    image_count = 0
    text_chunks: list[str] = []
    for c in content or []:
        if not isinstance(c, dict):
            continue
        ctype = c.get("type")
        if ctype in ("input_text", "text"):
            txt = c.get("text") or ""
            parts.append({"type": "text", "text": txt})
            text_chunks.append(txt)
        elif ctype in ("input_image", "image_url"):
            url = c.get("image_url")
            if isinstance(url, dict):
                url = url.get("url")
            if not url:
                continue
            parts.append({"type": "image_url", "image_url": {"url": url}})
            image_count += 1

    if image_count == 0:
        return "\n".join(t for t in text_chunks if t).strip(), 0
    return parts, image_count


def _normalize_usage(usage) -> dict | None:
    """chat/completions usage(prompt/completion/total) → merge_usage 호환 키로 정규화.

    openai_adapter(Responses) 는 input/output/total_tokens 를 쓰므로 동일 키로 맞춘다.
    """
    if usage is None:
        return None

    def _g(name):
        v = getattr(usage, name, None)
        if v is None and isinstance(usage, dict):
            v = usage.get(name)
        return v

    out: dict = {}
    prompt = _g("prompt_tokens")
    completion = _g("completion_tokens")
    total = _g("total_tokens")
    if prompt is not None:
        out["input_tokens"] = prompt
    if completion is not None:
        out["output_tokens"] = completion
    if total is not None:
        out["total_tokens"] = total
    return out or None


def _classify_vision_error(exc, image_count: int) -> DsllmVisionError:
    """DSLLM vision 호출 예외 → 세분화된 error_type + 사용자 친화 메시지로 변환.

    이전에는 timeout/connection 계열을 모두 "네트워크/프록시/방화벽" 하나로 뭉쳤다(§3).
    이제 HTTP status 와 (OpenAI SDK 를 감싼) 하위 httpx 예외 종류로 나눠 진단 가능하게 한다:
      connect_timeout / read_timeout / write_timeout / pool_timeout / connection_error /
      gateway_http_4xx / gateway_http_5xx / payload_too_large / unsupported_payload /
      malformed_response / unknown_transport_error.

    payload_unsupported=True 는 "텍스트 연결은 되지만 image_url payload 처리 실패" 신호로,
    이미지가 포함된 400/404/415/422/501 에서만 세운다(호출부 stage 구분에 사용).
    status_code / error_type / payload_unsupported 필드는 계속 유지한다.
    """
    status = getattr(exc, "status_code", None)
    name = type(exc).__name__
    code = None
    body = getattr(exc, "body", None)
    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            code = err.get("code") or err.get("type")

    # OpenAI SDK 예외는 원인(httpx.ConnectTimeout/ReadTimeout 등)을 __cause__ 로 감싼다.
    cause = getattr(exc, "__cause__", None) or getattr(exc, "__context__", None)
    cause_name = type(cause).__name__ if cause is not None else None

    payload_unsupported = False

    # ── 1) HTTP status 기반 분류(응답을 받은 경우) ──
    if status == 413:
        error_type = "payload_too_large"
        msg = "이미지 요청 크기가 DSLLM Gateway 제한을 초과했습니다."
    elif status in (400, 415, 422):
        error_type = "unsupported_payload"
        payload_unsupported = image_count > 0
        msg = "DSLLM 이미지 요청 형식 또는 모델 입력 제한을 확인해주세요."
    elif status in (404, 501):
        error_type = "unsupported_payload"
        payload_unsupported = image_count > 0
        msg = (
            "DS/Gemma4 텍스트 연결은 가능하지만, 이미지(image_url)를 포함한 요청 처리에 실패했습니다. "
            "DSLLM 게이트웨이가 chat/completions 멀티모달 content(image_url) 형식을 지원하는지 확인해주세요."
        )
    elif isinstance(status, int) and 500 <= status < 600:
        error_type = "gateway_http_5xx"
        msg = "DSLLM Gateway 또는 모델 서버가 요청을 처리하지 못했습니다."
    elif isinstance(status, int) and 400 <= status < 500:
        error_type = "gateway_http_4xx"
        detail = f" (code={code})" if code else ""
        msg = f"DSLLM 요청이 거부됐습니다 (status={status}){detail}."
    # ── 2) status 없음(응답 전 실패): timeout / connection 계열 세분화 ──
    elif name == "APITimeoutError" or (cause_name and "Timeout" in cause_name):
        if cause_name == "ConnectTimeout":
            error_type = "connect_timeout"
            msg = "DSLLM Gateway 연결 시간이 초과됐습니다."
        elif cause_name == "WriteTimeout":
            error_type = "write_timeout"
            msg = "이미지 요청 전송 시간이 초과됐습니다."
        elif cause_name == "PoolTimeout":
            error_type = "pool_timeout"
            msg = "DSLLM 연결 풀 대기 시간이 초과됐습니다."
        else:  # ReadTimeout 또는 일반 TimeoutException → 모델 응답 지연
            error_type = "read_timeout"
            msg = "DSLLM 모델 응답 시간이 초과됐습니다."
    elif name == "APIConnectionError" or cause_name in ("ConnectError", "ConnectTimeout"):
        error_type = "connection_error"
        msg = "DSLLM Gateway에 연결하지 못했습니다. 네트워크/프록시/방화벽을 확인해주세요."
    elif name in ("APIResponseValidationError",):
        error_type = "malformed_response"
        msg = "DSLLM 응답을 해석하지 못했습니다(형식 오류)."
    else:
        error_type = "unknown_transport_error"
        detail = f" (code={code})" if code else ""
        msg = f"DSLLM vision 호출 실패 (error={name}{detail})."

    return DsllmVisionError(
        msg, status_code=status, code=code, error_type=error_type,
        payload_unsupported=payload_unsupported,
    )


def vision_chat(
    model_name: str | None,
    instructions: str,
    content: list,
    *,
    max_tokens: int | None = None,
    timeout: float | None = None,
    temperature: float = 0.2,
) -> dict:
    """이미지 포함 멀티모달 호출. /v1/chat/completions(멀티모달 content) 사용.

    openai_adapter.vision_chat 와 **동일한 시그니처/반환 dict** 를 맞춰, 호출부가
    provider 분기만으로 연결할 수 있게 한다.

    Args:
        model_name: 사용할 모델 key(예: DS/Gemma4). 비어 있으면 env 기본 모델.
        instructions: system 역할 지시문.
        content: user content 리스트(Responses 스타일 input_text/input_image 또는
            chat 스타일 text/image_url). 내부에서 chat/completions 형식으로 변환한다.
        max_tokens: 응답 max_tokens. None 이면 settings.vision_report_max_output_tokens(기본 8000).
        timeout: 호출 timeout(초). None 이면 클라이언트 기본.

    Returns:
        {"raw_text", "usage", "model", "provider", "status", "incomplete_reason",
         "truncated", "max_output_tokens", "image_count", "fallback_source"}

    Raises:
        DsllmVisionError: 호출 실패(payload_unsupported 로 image_url 미지원 여부 구분).
    """
    resolved_model = _resolve_model(model_name)
    resolved_base = _get_base_url(None)
    client = _get_client(None)
    # vision(멀티모달)은 실패/timeout 시 OpenAI SDK 기본 재시도(max_retries=2)가 조용히
    # 최대 3회까지 호출을 늘려 전체 소요를 폭증시킨다(느린 게이트웨이에서 120s×3=360s).
    # vision 경로는 재시도를 끄고 실패를 즉시 표면화한다. text chat 경로에는 영향 없음.
    client_opts: dict = {"max_retries": 0}
    if timeout is not None and timeout > 0:
        client_opts["timeout"] = float(timeout)
    client = client.with_options(**client_opts)

    effective_max = max_tokens
    if effective_max is None:
        effective_max = int(getattr(settings, "vision_report_max_output_tokens", 8000) or 8000)

    chat_content, image_count = _to_chat_content(content)

    logger.info(
        "[DSLLM] vision request: model=%s, base_url=%s, images=%d, max_tokens=%d",
        resolved_model, resolved_base, image_count, effective_max,
    )

    messages: list = []
    if instructions:
        messages.append({"role": "system", "content": instructions})
    messages.append({"role": "user", "content": chat_content})

    try:
        response = client.chat.completions.create(
            model=resolved_model,
            messages=messages,
            temperature=temperature,
            max_tokens=effective_max,
        )
    except Exception as e:
        raise _classify_vision_error(e, image_count) from e

    choice = response.choices[0] if getattr(response, "choices", None) else None
    message = getattr(choice, "message", None) if choice is not None else None
    raw_text = ((getattr(message, "content", None) or "") if message is not None else "").strip()
    finish_reason = getattr(choice, "finish_reason", None) if choice is not None else None
    truncated = finish_reason == "length"

    return {
        "raw_text": raw_text,
        "usage": _normalize_usage(getattr(response, "usage", None)),
        "model": resolved_model,
        "provider": "dsllm",
        "status": finish_reason,
        "incomplete_reason": "max_tokens" if truncated else None,
        "truncated": truncated,
        "max_output_tokens": effective_max,
        "image_count": image_count,
        "fallback_source": None,
    }


def default_model_key() -> str:
    """env 기준 기본 모델 (model_1)."""
    models = get_available_models()
    return models[0]["key"] if models else ""


def _strip_ds_prefix(name: str) -> str:
    if name.startswith("DS/"):
        return name[len("DS/"):]
    return name


def _normalize_model_input(model_name: str | None) -> str:
    """입력값을 비교용으로 정규화: DS/ 제거 + legacy alias 변환."""
    name = (model_name or "").strip()
    if not name:
        return ""
    name = _strip_ds_prefix(name)
    return _LEGACY_ALIAS.get(name, name)


def is_known_model(model_name: str | None) -> bool:
    """env 등록 모델 또는 legacy alias 형태인지."""
    name = _normalize_model_input(model_name)
    if not name:
        return False
    return name in set(_env_models()) or name in _LEGACY_ALIAS.values()


def _resolve_model(model_name: str | None) -> str:
    """
    실제 Gateway 호출에 쓸 model id 반환.
    - 사용자가 선택한 값이 있으면 (DS/ 제거 + alias 적용 후) 그 값을 사용.
    - 비어 있을 때만 settings.model_1로 fallback.
    """
    normalized = _normalize_model_input(model_name)
    if normalized:
        return normalized

    fallback = (settings.model_1 or "").strip()
    if not fallback:
        raise RuntimeError(
            "DSLLM model is missing. Set LLM_MODEL_1 in .env.local/.env.production "
            "또는 요청에 model_name을 전달해야 합니다."
        )
    return fallback


def _get_base_url(base_url: str | None = None) -> str:
    # BASE_URL은 항상 env에서만 읽는다. 인자로 들어온 base_url은 무시.
    # (과거 DB/프론트에 저장된 잘못된 http URL이 호출 경로로 흘러들어오는 것을 차단)
    if base_url:
        logger.warning(
            "[DSLLM] ignoring caller-supplied base_url=%r — env BASE_URL이 우선합니다.",
            base_url,
        )

    url = (settings.dsllm_effective_base_url or "").strip()
    if not url:
        raise RuntimeError(
            "DSLLM BASE_URL이 설정되어 있지 않습니다. "
            ".env.local 또는 .env.production의 DSLLM_BASE_URL/BASE_URL을 확인해주세요."
        )

    url = url.rstrip("/")
    if url.endswith("/chat/completions"):
        url = url[: -len("/chat/completions")].rstrip("/")

    # ⚠️ 사내 DSLLM 게이트웨이는 http:// 사내 URL 로도 동작한다.
    #    OpenAI 처럼 https 강제하지 않는다. (http:// 또는 https:// 둘 다 허용)
    if not (url.startswith("http://") or url.startswith("https://")):
        raise RuntimeError(
            "DSLLM BASE_URL 형식이 올바르지 않습니다. "
            f"http:// 또는 https://로 시작해야 합니다. Current value: {url}"
        )

    return url


def _get_api_key() -> str:
    # DSLLM_API_KEY 우선, 없으면 기존 API_KEY fallback (backward compatible)
    api_key = (settings.dsllm_effective_api_key or "").strip()
    if not api_key:
        raise RuntimeError(
            "DSLLM API_KEY가 설정되어 있지 않습니다. "
            ".env.local 또는 .env.production의 DSLLM_API_KEY/API_KEY를 확인해주세요."
        )
    return api_key


def _mask_api_key(api_key: str) -> str:
    if not api_key:
        return "<empty>"
    if len(api_key) <= 6:
        return "*" * len(api_key)
    return f"{api_key[:4]}***{api_key[-2:]} (len={len(api_key)})"


def _log_startup_env_state() -> None:
    """모듈 로드 시 1회 — env가 어떻게 읽혔는지 가시화."""
    logger.info("[DSLLM] ENV_MODE=%s", settings.env_mode)
    logger.info("[DSLLM] BASE_URL=%s", settings.dsllm_effective_base_url or "<missing>")
    logger.info("[DSLLM] API_KEY=%s", _mask_api_key(settings.dsllm_effective_api_key))
    logger.info("[DSLLM] MODEL_1=%s", settings.model_1)
    logger.info("[DSLLM] MODEL_2=%s", settings.model_2)
    logger.info("[DSLLM] MODEL_3=%s", settings.model_3)
    logger.info("[DSLLM] MODEL_4=%s", settings.model_4)


_log_startup_env_state()


def _get_client(base_url: str | None = None) -> OpenAI:
    return OpenAI(
        api_key=_get_api_key(),
        base_url=_get_base_url(base_url),
    )


def chat(
    base_url: str | None,
    model_name: str | None,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 4096,
) -> str:
    resolved_model = _resolve_model(model_name)
    resolved_base = _get_base_url(base_url)
    client = _get_client(base_url)

    logger.info("[DSLLM] request: model=%s, base_url=%s", resolved_model, resolved_base)

    try:
        response = client.chat.completions.create(
            model=resolved_model,
            messages=[
                {"role": "system", "content": system_prompt or ""},
                {"role": "user", "content": user_prompt or ""},
            ],
            temperature=temperature,
            max_tokens=max_tokens,
        )
    except Exception as e:
        raise RuntimeError(
            f"DSLLM request failed: model={resolved_model}, "
            f"base_url={resolved_base}, error={type(e).__name__}: {e}"
        ) from e

    return (response.choices[0].message.content or "").strip()


def chat_stream(
    base_url: str | None,
    model_name: str | None,
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 4096,
):
    """Generator로 token 문자열을 yield. FastAPI StreamingResponse 호환."""
    resolved_model = _resolve_model(model_name)
    resolved_base = _get_base_url(base_url)
    client = _get_client(base_url)

    logger.info("[DSLLM] stream request: model=%s, base_url=%s", resolved_model, resolved_base)

    try:
        stream = client.chat.completions.create(
            model=resolved_model,
            messages=[
                {"role": "system", "content": system_prompt or ""},
                {"role": "user", "content": user_prompt or ""},
            ],
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
        )
        for chunk in stream:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            token = getattr(delta, "content", None)
            if token:
                yield token
    except Exception as e:
        raise RuntimeError(
            f"DSLLM stream request failed: model={resolved_model}, "
            f"base_url={resolved_base}, error={type(e).__name__}: {e}"
        ) from e
