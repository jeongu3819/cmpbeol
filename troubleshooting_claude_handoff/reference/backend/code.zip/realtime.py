"""Space 단위 realtime sync (SSE + MySQL event outbox).

설계 요지 (부하 제어형):
- emit_realtime_event(): create/update/delete API 의 기존 트랜잭션 안에서
  realtime_events row 한 줄을 추가한다. commit 이 실패하면 이벤트도 함께 rollback 된다.
- space 단위 broadcaster: SSE 클라이언트마다 DB 를 polling 하지 않는다.
  같은 space_id 의 클라이언트가 N 명이어도 DB polling 은 worker 당 1개(채널당 1 poller)다.
- GLOBAL_CHANNEL(0): 공간에 묶이지 않는 전역 이벤트(VOC 등). 모든 인증 클라이언트가 함께 구독한다.
- 인증: EventSource 는 커스텀 헤더를 못 넣으므로, 인증된 사용자가 먼저 단발성 ticket 을 발급받고
  EventSource 는 ?ticket= 로 접속한다. 세션 토큰 자체를 URL 에 노출하지 않는다.
- retention: 오래된 realtime_events 는 매일 1회 + 서버 시작 후 1회 정리한다(이벤트 로그만 정리).

민감정보(title/description/note/content)는 이벤트/payload 에 절대 넣지 않는다.
실제 화면 반영은 프론트의 React Query invalidate → 기존 API 재조회로 처리한다.
"""
import asyncio
import json
import logging
import secrets
import threading
import time
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import text

from app.db_connections.sqlalchemy import SessionLocal
from app.models import RealtimeEvent
from app.environment import (
    REALTIME_SYNC_ENABLED,
    REALTIME_POLL_INTERVAL_SECONDS,
    REALTIME_HEARTBEAT_SECONDS,
    REALTIME_MAX_EVENTS_PER_POLL,
    REALTIME_EVENT_RETENTION_DAYS,
    REALTIME_EVENT_CLEANUP_ENABLED,
    REALTIME_TICKET_TTL_SECONDS,
)

logger = logging.getLogger("realtime")

# 공간에 묶이지 않는 전역 이벤트(VOC 등)는 space_id=0 채널에 적재한다.
GLOBAL_CHANNEL = 0


# =========================================================
# 1) 이벤트 생성 helper (API 트랜잭션 내부에서 호출)
# =========================================================
def emit_realtime_event(
    db,
    *,
    space_id,
    event_type,
    entity_type,
    entity_id=None,
    project_id=None,
    task_id=None,
    actor_user_id=None,
    payload=None,
):
    """현재 DB 트랜잭션에 realtime_events row 를 추가한다 (commit 은 호출자 책임).

    - 호출자의 db.commit() 시점에 본 이벤트도 함께 영속화된다 → 원자적.
    - 호출자가 rollback 하면 이벤트도 함께 사라진다.
    - 이벤트 적재 자체가 본 기능(생성/수정/삭제)을 막지 않도록, row 구성 단계의 예외만 흡수한다.
    - 민감정보는 payload 에 넣지 않는다. payload 는 작은 비민감 JSON 만 허용한다.
    """
    if not REALTIME_SYNC_ENABLED:
        return None
    try:
        sid = int(space_id) if space_id is not None else GLOBAL_CHANNEL
    except (TypeError, ValueError):
        sid = GLOBAL_CHANNEL
    try:
        payload_json = None
        if payload:
            payload_json = json.dumps(payload, ensure_ascii=False)[:2000]
        ev = RealtimeEvent(
            space_id=sid,
            project_id=project_id,
            task_id=task_id,
            event_type=str(event_type)[:80],
            entity_type=str(entity_type)[:50],
            entity_id=entity_id,
            actor_user_id=actor_user_id,
            payload_json=payload_json,
            created_at=datetime.now(),
        )
        db.add(ev)
        return ev
    except Exception as e:  # pragma: no cover - 방어적
        logger.warning("emit_realtime_event 실패 (무시): %s", e)
        return None


# =========================================================
# 2) 단발성 ticket (EventSource 인증)
# =========================================================
_tickets = {}  # ticket -> (user_id, space_id, expires_at)
_tickets_lock = threading.Lock()


def issue_ticket(user_id: int, space_id: int):
    """인증된 사용자에게 단발성 ticket 발급. (ticket, ttl_seconds) 반환."""
    ticket = secrets.token_urlsafe(24)
    now = time.time()
    with _tickets_lock:
        _tickets[ticket] = (int(user_id), int(space_id), now + REALTIME_TICKET_TTL_SECONDS)
        # 기회적 만료 정리 (메모리 누수 방지)
        if len(_tickets) > 5000:
            for k in [k for k, v in _tickets.items() if v[2] < now]:
                _tickets.pop(k, None)
    return ticket, REALTIME_TICKET_TTL_SECONDS


def validate_ticket(ticket: str, space_id: int) -> Optional[int]:
    """ticket 유효성 검사. 일치하면 user_id 반환, 아니면 None.

    TTL 내 재사용을 허용한다(EventSource 자동 재연결 호환). 만료는 시간으로 통제한다.
    """
    if not ticket:
        return None
    with _tickets_lock:
        data = _tickets.get(ticket)
    if not data:
        return None
    uid, sid, exp = data
    if exp < time.time():
        with _tickets_lock:
            _tickets.pop(ticket, None)
        return None
    if int(sid) != int(space_id):
        return None
    return uid


# =========================================================
# 3) space 단위 broadcaster
# =========================================================
class _Channel:
    __slots__ = ("channel_id", "subscribers", "poller_task", "cursor")

    def __init__(self, channel_id: int):
        self.channel_id = channel_id
        self.subscribers = set()       # set[asyncio.Queue]
        self.poller_task = None        # asyncio.Task | None
        self.cursor = 0                # 마지막으로 broadcast 한 event id


_channels = {}                         # channel_id -> _Channel
_channels_lock = asyncio.Lock()
_client_count = 0


def client_count() -> int:
    return _client_count


def get_stats() -> dict:
    return {
        "enabled": REALTIME_SYNC_ENABLED,
        "client_count": _client_count,
        "channels": {cid: len(ch.subscribers) for cid, ch in _channels.items()},
        "poll_interval_seconds": REALTIME_POLL_INTERVAL_SECONDS,
        "heartbeat_seconds": REALTIME_HEARTBEAT_SECONDS,
        "retention_days": REALTIME_EVENT_RETENTION_DAYS,
        "cleanup_enabled": REALTIME_EVENT_CLEANUP_ENABLED,
    }


def _fetch_events_sync(channel_id: int, after_id: int, limit: int):
    """index (space_id, id) 를 타는 조회. 짧게 session 열고 닫는다(누수 방지)."""
    db = SessionLocal()
    try:
        rows = db.execute(
            text(
                "SELECT id, event_type, space_id, project_id, task_id, "
                "entity_type, entity_id, actor_user_id, created_at, payload_json "
                "FROM realtime_events "
                "WHERE space_id = :sid AND id > :after "
                "ORDER BY id ASC LIMIT :lim"
            ),
            {"sid": channel_id, "after": after_id, "lim": limit},
        ).mappings().all()
        return [dict(r) for r in rows]
    finally:
        db.close()


def _max_event_id_sync(channel_id: int) -> int:
    db = SessionLocal()
    try:
        r = db.execute(
            text("SELECT COALESCE(MAX(id), 0) FROM realtime_events WHERE space_id = :sid"),
            {"sid": channel_id},
        ).scalar()
        return int(r or 0)
    finally:
        db.close()


def _format_sse(ev: dict) -> str:
    created = ev.get("created_at")
    created_iso = created.isoformat() if hasattr(created, "isoformat") else str(created or "")
    data = {
        "type": ev.get("event_type"),
        "space_id": ev.get("space_id"),
        "project_id": ev.get("project_id"),
        "task_id": ev.get("task_id"),
        "entity_type": ev.get("entity_type"),
        "entity_id": ev.get("entity_id"),
        "actor_user_id": ev.get("actor_user_id"),
        "created_at": created_iso,
    }
    if ev.get("payload_json"):
        try:
            data["payload"] = json.loads(ev["payload_json"])
        except Exception:
            pass
    return (
        f"id: {ev['id']}\n"
        f"event: {ev.get('event_type')}\n"
        f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
    )


async def _poller_loop(channel: _Channel):
    """채널당 1개. 2~3초 간격으로 새 이벤트를 조회해 구독자 큐에 broadcast 한다."""
    loop = asyncio.get_event_loop()
    try:
        while True:
            await asyncio.sleep(REALTIME_POLL_INTERVAL_SECONDS)
            async with _channels_lock:
                if not channel.subscribers:
                    channel.poller_task = None
                    _channels.pop(channel.channel_id, None)
                    return
            try:
                rows = await loop.run_in_executor(
                    None, _fetch_events_sync, channel.channel_id, channel.cursor, REALTIME_MAX_EVENTS_PER_POLL
                )
            except Exception as e:
                logger.warning("realtime poller 조회 실패 (channel=%s): %s", channel.channel_id, e)
                continue
            if not rows:
                continue
            channel.cursor = rows[-1]["id"]
            for q in list(channel.subscribers):
                for ev in rows:
                    try:
                        q.put_nowait(ev)
                    except asyncio.QueueFull:
                        # 느린 클라이언트는 일부 이벤트를 흘려보낸다(이후 이벤트로 어차피 재조회됨).
                        pass
    except asyncio.CancelledError:
        return
    except Exception as e:  # pragma: no cover - 방어적
        logger.warning("realtime poller 비정상 종료 (channel=%s): %s", channel.channel_id, e)
        channel.poller_task = None


async def _register(channel_id: int, q: "asyncio.Queue"):
    loop = asyncio.get_event_loop()
    async with _channels_lock:
        ch = _channels.get(channel_id)
        if ch is None:
            ch = _Channel(channel_id)
            # 최초 cursor = 현재 최신 id (최초 연결 시 과거 이벤트 대량 전송 방지)
            ch.cursor = await loop.run_in_executor(None, _max_event_id_sync, channel_id)
            _channels[channel_id] = ch
        ch.subscribers.add(q)
        if ch.poller_task is None or ch.poller_task.done():
            ch.poller_task = asyncio.create_task(_poller_loop(ch))


async def _unregister(channel_id: int, q: "asyncio.Queue"):
    async with _channels_lock:
        ch = _channels.get(channel_id)
        if not ch:
            return
        ch.subscribers.discard(q)
        if not ch.subscribers and ch.poller_task is not None:
            ch.poller_task.cancel()
            ch.poller_task = None
            _channels.pop(channel_id, None)


async def event_stream(request, user_id: int, space_id: int, last_event_id: int = 0):
    """SSE generator. space 채널 + 전역 채널(0)을 하나의 큐로 멀티플렉싱한다.

    - 등록을 catch-up 보다 먼저 해서 그 사이 이벤트 누락을 방지한다.
    - 최초 연결(last_event_id 없음): 현재 시점 이후 이벤트만 받는다(과거 폭주 방지).
    - 재연결(Last-Event-ID): 누락분만 짧게 catch-up 후 실시간 이어받는다.
    - client disconnect 감지 시 generator 를 종료하고 큐를 해제한다(누수 방지).
    """
    global _client_count
    loop = asyncio.get_event_loop()
    q: "asyncio.Queue" = asyncio.Queue(maxsize=1000)

    channels = [space_id]
    if space_id != GLOBAL_CHANNEL:
        channels.append(GLOBAL_CHANNEL)

    for c in channels:
        await _register(c, q)
    _client_count += 1
    logger.info("SSE client connected: space_id=%s user_id=%s (clients=%s)", space_id, user_id, _client_count)

    last_sent = {}  # channel_id -> 마지막으로 보낸 event id (중복/역행 방지)
    try:
        for c in channels:
            if last_event_id and last_event_id > 0:
                last_sent[c] = last_event_id
                # 재연결: 누락분만 짧게 catch-up
                try:
                    rows = await loop.run_in_executor(
                        None, _fetch_events_sync, c, last_event_id, REALTIME_MAX_EVENTS_PER_POLL
                    )
                except Exception:
                    rows = []
                for ev in rows:
                    if ev["id"] > last_sent[c]:
                        last_sent[c] = ev["id"]
                        yield _format_sse(ev)
            else:
                # 최초 연결: 현재 최신 id 이후만 (과거 이벤트 전송 안 함)
                last_sent[c] = await loop.run_in_executor(None, _max_event_id_sync, c)

        # 초기 코멘트 (프록시 버퍼 flush 유도 + 연결 확인)
        yield ": connected\n\n"

        while True:
            if await request.is_disconnected():
                break
            try:
                ev = await asyncio.wait_for(q.get(), timeout=REALTIME_HEARTBEAT_SECONDS)
            except asyncio.TimeoutError:
                # heartbeat
                yield ": ping\n\n"
                continue
            c = ev.get("space_id")
            if c in last_sent and ev["id"] <= last_sent[c]:
                continue  # catch-up 과 broadcaster 중복 제거
            last_sent[c] = ev["id"]
            yield _format_sse(ev)
    except asyncio.CancelledError:
        pass
    except Exception as e:  # pragma: no cover - 방어적
        logger.warning("SSE stream 오류 (space_id=%s): %s", space_id, e)
    finally:
        for c in channels:
            try:
                await _unregister(c, q)
            except Exception:
                pass
        _client_count = max(0, _client_count - 1)
        logger.info("SSE client disconnected: space_id=%s user_id=%s (clients=%s)", space_id, user_id, _client_count)


# =========================================================
# 4) retention cleanup + 스케줄러
# =========================================================
def cleanup_old_events(retention_days: Optional[int] = None) -> dict:
    """오래된 realtime_events 정리. 운영 데이터가 아닌 이벤트 로그만 삭제한다."""
    if not REALTIME_EVENT_CLEANUP_ENABLED:
        return {"deleted": 0, "skipped": True}
    days = retention_days or REALTIME_EVENT_RETENTION_DAYS
    cutoff = datetime.now() - timedelta(days=days)
    db = SessionLocal()
    try:
        before = db.execute(text("SELECT COUNT(*) FROM realtime_events")).scalar() or 0
        result = db.execute(
            text("DELETE FROM realtime_events WHERE created_at < :cutoff"), {"cutoff": cutoff}
        )
        db.commit()
        deleted = result.rowcount or 0
        after = max(0, before - deleted)
        logger.info(
            "realtime_events cleanup: deleted=%s before=%s after=%s (retention=%sd)",
            deleted, before, after, days,
        )
        try:
            from app.services.system_log import log_event
            log_event(
                "INFO", "BACKUP",
                f"realtime_events 정리: {deleted}건 삭제 (보관 {days}일)",
                detail=f"before={before}, after={after}",
            )
        except Exception:
            pass
        return {"deleted": deleted, "before": before, "after": after}
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        logger.warning("realtime_events cleanup 실패: %s", e)
        return {"deleted": 0, "error": str(e)}
    finally:
        db.close()


_cleanup_thread = None
_cleanup_stop = threading.Event()


def _seconds_until_hour(hour: int) -> float:
    now = datetime.now()
    nxt = now.replace(hour=hour, minute=0, second=0, microsecond=0)
    if nxt <= now:
        nxt += timedelta(days=1)
    return max(60.0, (nxt - now).total_seconds())


def start_cleanup_scheduler():
    """서버 시작 후 1회 + 매일 새벽 4시 정리. 백그라운드 데몬 스레드."""
    global _cleanup_thread
    if not REALTIME_EVENT_CLEANUP_ENABLED:
        return
    if _cleanup_thread and _cleanup_thread.is_alive():
        return
    _cleanup_stop.clear()

    def loop():
        try:
            cleanup_old_events()  # 시작 후 1회
        except Exception:
            pass
        while not _cleanup_stop.is_set():
            wait_s = _seconds_until_hour(4)
            if _cleanup_stop.wait(wait_s):
                break
            try:
                cleanup_old_events()
            except Exception:
                pass

    _cleanup_thread = threading.Thread(target=loop, name="realtime-cleanup", daemon=True)
    _cleanup_thread.start()


def stop_cleanup_scheduler():
    _cleanup_stop.set()
