from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    Float,
    String,
    Boolean,
    DateTime,
    ForeignKey,
    Text,
    BigInteger,
    UniqueConstraint,
    Index,
)
from sqlalchemy.sql import func
from sqlalchemy.types import JSON

from app.db_connections.sqlalchemy import Base
from app.environment import KST

# =========================================================
# Core Tables (기존)
# =========================================================

# ── Space (workspace) ──
class Space(Base):
    __tablename__ = "spaces"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    slug = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, server_default=func.now())
    warned_at = Column(DateTime, nullable=True)  # 빈 공간 경고 발송 시점

    # ✅ 빈 공간 안전 관리(보관 lifecycle)
    archived_at = Column(DateTime, nullable=True)        # 자동/수동 보관 시각 (is_active=False 와 함께 "보관됨" 표현)
    last_activity_at = Column(DateTime, nullable=True)   # 마지막 활동일 (Phase 1: 집계 계산, 컬럼은 향후용)
    delete_scheduled_at = Column(DateTime, nullable=True)  # 삭제 예정일 (표시/연장용)
    cleanup_exempt = Column(Boolean, nullable=False, default=False)  # 자동 정리 제외

    # ✅ v3.0 공간 목적 프리셋
    purpose = Column(String(50), nullable=True, default="project_management")
    # project_management / equipment_ops / process_change / sw_dev / integrated_ops / custom


class SpaceMember(Base):
    __tablename__ = "space_members"

    id = Column(Integer, primary_key=True, index=True)
    space_id = Column(Integer, ForeignKey("spaces.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    role = Column(String(30), nullable=False, default="member")  # owner / admin / member
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("space_id", "user_id", name="uq_space_member"),
    )


class SpaceJoinRequest(Base):
    __tablename__ = "space_join_requests"

    id = Column(Integer, primary_key=True, index=True)
    space_id = Column(Integer, ForeignKey("spaces.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    status = Column(String(20), nullable=False, default="pending")  # pending / approved / rejected
    message = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(Integer, ForeignKey("users.id"), nullable=True)

    __table_args__ = (
        UniqueConstraint("space_id", "user_id", "status", name="uq_space_join_request"),
    )


class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)

    # ✅ 새 사이트 기능용 확장 컬럼 (DB에 추가해두었다면 사용)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    visibility = Column(String(20), nullable=False, default="private")   # private / public
    require_approval = Column(Boolean, nullable=False, default=False)
    permissions = Column(JSON, nullable=True)  # {"post_write":"all", ...}

    # ✅ v1.2 조직 기반 확장
    part_id = Column(Integer, ForeignKey("groups.id"), nullable=True, index=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)

    # ✅ v2.0 Space 소속
    space_id = Column(Integer, ForeignKey("spaces.id"), nullable=True, index=True)

    created_at = Column(DateTime, server_default=func.now())
    archived_at = Column(DateTime, nullable=True)
    # 삭제(보관) 주체. Trash Page에서 "내가 삭제한 항목"만 보여주기 위함.
    deleted_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)

    # ✅ 프로젝트별 워크플로우 컬럼 커스텀 (Slice 1)
    # DEFAULT = 기존 status 기반 Board 렌더 / CUSTOM = project_task_columns 기반 렌더
    workflow_mode = Column(String(20), nullable=False, default="DEFAULT")
    # 작업노트 체크율 기반 자동 status 이동 여부. 기존 프로젝트=True, CUSTOM 전환 시 False.
    auto_progress_from_notes = Column(Boolean, nullable=False, default=True)


class CalendarEvent(Base):
    """공간 단위 단발/단순 일정. Task 보다 가벼우며, 필요 시 단발 업무 task 로 전환할 수 있다.
    전환 시 linked_task_id / linked_project_id 로 연결된다. (Phase 2)"""
    __tablename__ = "calendar_events"

    id = Column(Integer, primary_key=True, index=True)
    space_id = Column(Integer, ForeignKey("spaces.id"), nullable=False, index=True)

    title = Column(String(300), nullable=False)
    description = Column(Text, nullable=True)

    start_date = Column(String(20), nullable=True)  # YYYY-MM-DD 문자열 (Task 와 동일 패턴)
    end_date = Column(String(20), nullable=True)
    all_day = Column(Boolean, nullable=False, default=True)

    status = Column(String(30), nullable=False, default="planned")   # planned / done / canceled
    event_type = Column(String(40), nullable=False, default="general")

    owner_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    assignee_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)

    # Task 전환 연결
    linked_task_id = Column(Integer, ForeignKey("tasks.id"), nullable=True, index=True)
    linked_project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    archived_at = Column(DateTime, nullable=True)


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    loginid = Column(String(128), unique=True, nullable=False, index=True)
    username = Column(String(120), nullable=False)
    deptname = Column(String(120), nullable=True)
    mail = Column(String(255), nullable=True)

    role = Column(String(50), nullable=False, default="member")  # member / admin
    avatar_color = Column(String(20), nullable=False, default="#2955FF")

    # ✅ 실제 DB 컬럼명이 is_active면 그대로 사용
    is_active = Column(Boolean, nullable=False, default=True)

    # ✅ 그룹 기능(관리자 그룹 적용)에서 사용할 수 있음
    group_name = Column(String(120), nullable=True, index=True)

    # ✅ v1.2 조직 기반 확장
    primary_team_id = Column(Integer, ForeignKey("groups.id"), nullable=True, index=True)
    primary_part_id = Column(Integer, ForeignKey("groups.id"), nullable=True, index=True)

    created_at = Column(DateTime, server_default=func.now())
    last_login_at = Column(DateTime, nullable=True)


class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)

    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)

    title = Column(String(300), nullable=False)
    description = Column(Text, nullable=True)

    status = Column(String(30), nullable=False, default="todo")      # todo / in_progress / done / hold
    priority = Column(String(30), nullable=False, default="medium")  # low / medium / high

    # ✅ 단발 일정 구분: normal(일반 task) / one_off(캘린더 단발 일정)
    task_type = Column(String(20), nullable=False, default="normal")

    start_date = Column(String(20), nullable=True)  # YYYY-MM-DD 문자열 유지
    due_date = Column(String(20), nullable=True)

    # ✅ 일정 "미정(TBD)" 상태: 날짜가 단순 누락(NULL)인 경우와,
    # 사용자가 의도적으로 "미정"으로 설정한 경우를 구분한다.
    # tbd=True 이면 대응 날짜(start_date/due_date)는 NULL 로 저장한다.
    start_date_tbd = Column(Boolean, nullable=False, default=False)
    due_date_tbd = Column(Boolean, nullable=False, default=False)

    assignee_ids = Column(JSON, nullable=False, default=list)
    tags = Column(JSON, nullable=False, default=list)

    # ✅ 새 사이트 기능용 확장 컬럼
    sub_project_id = Column(Integer, ForeignKey("sub_projects.id"), nullable=True, index=True)
    progress = Column(Integer, nullable=False, default=0)  # 0~100

    # ✅ Task 상하 관계 (Parent / Child). NULL = 최상위 Task.
    # 단일 레벨만 허용(자식은 다시 부모가 될 수 없음) — 순환/다단계 방지는 API 레이어에서 강제.
    parent_task_id = Column(Integer, ForeignKey("tasks.id"), nullable=True, index=True)

    # ✅ 프로젝트별 워크플로우 컬럼 커스텀 (Slice 1)
    # CUSTOM 모드에서 사용자가 보는 Board 컬럼. NULL이면 status 기준 fallback.
    # status(canonical)는 그대로 유지하고, 이 값이 표시용 컬럼을 담당한다.
    workflow_column_id = Column(Integer, ForeignKey("project_task_columns.id"), nullable=True, index=True)

    remarks = Column(Text, nullable=True)  # 비고

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    archived_at = Column(DateTime, nullable=True)
    # 삭제(보관) 주체. Trash Page에서 "내가 삭제한 항목"만 보여주기 위함.
    deleted_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)


from sqlalchemy.dialects.mysql import LONGTEXT

class TaskActivity(Base):
    __tablename__ = "task_activities"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    block_type = Column(String(20), nullable=False, default="checkbox")  # checkbox / text
    order_index = Column(Integer, nullable=False, default=0)
    content = Column(LONGTEXT().with_variant(Text, "sqlite").with_variant(Text, "postgresql"), nullable=False, default="")
    checked = Column(Boolean, nullable=False, default=False)
    checked_at = Column(DateTime, nullable=True)  # 체크 완료 시각
    style = Column(JSON, nullable=True)  # {"bold": true, "color": "#EF4444"}

    # 단계 완료 체크포인트(stage completion checkpoint) 메타 — 자동 이동 판단에 사용.
    #   is_stage_checkpoint = 이 체크박스를 '단계 완료 조건'으로 사용할지 여부
    #   checkpoint_stage_id = 완료 조건이 적용될 workflow 단계(컬럼) id. 보통 지정 시점의 Task 현재 단계.
    #   checkpoint_required = 필수 체크포인트 여부(자동 이동 판단은 required 항목만 대상)
    is_stage_checkpoint = Column(Boolean, nullable=False, default=False)
    checkpoint_stage_id = Column(Integer, ForeignKey("project_task_columns.id"), nullable=True, index=True)
    checkpoint_required = Column(Boolean, nullable=False, default=False)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class ProjectTaskColumn(Base):
    """프로젝트별 커스텀 워크플로우 컬럼 (사용자가 보는 업무 단계).

    컬럼명 = 사용자가 보는 단계, sort_order = 업무 흐름.
    mapped_status = 통계/대시보드/AI 계산용 canonical status 로의 매핑.
      - 첫 컬럼 = todo / 중간 = in_progress / 마지막 = done (저장 시 순서로 자동 계산)
      - hold 컬럼은 별도로 mapped_status=hold 유지 가능
    is_final_done = 해당 프로젝트 기준 "완료" 컬럼 여부 (기본은 마지막 컬럼).
    active = False 면 보관(soft delete). CUSTOM→DEFAULT 전환해도 hard delete 하지 않는다.
    """
    __tablename__ = "project_task_columns"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)

    key = Column(String(40), nullable=True)   # 안정 식별용 슬러그 (선택)
    label = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)  # 단계 세부 설명 (Board 헤더 제목 아래 표시, plain text)
    mapped_status = Column(String(20), nullable=False, default="in_progress")  # todo/in_progress/done/hold

    sort_order = Column(Integer, nullable=False, default=0)
    color = Column(String(20), nullable=True)
    is_final_done = Column(Boolean, nullable=False, default=False)
    active = Column(Boolean, nullable=False, default=True)

    # 중간 완료 체크포인트 (보조 지표). 최종 완료(is_final_done)/Completion 계산과 무관하며,
    # "Task가 이 단계 이상(sort_order >=)에 도달했는지"를 보여주기 위한 표시용 메타데이터.
    is_checkpoint = Column(Boolean, nullable=False, default=False)
    checkpoint_label = Column(String(120), nullable=True)        # 화면 표시 이름 (비면 '{label} 완료')
    checkpoint_description = Column(Text, nullable=True)         # 체크포인트 설명

    # 진행률 기준 자동 이동 (CUSTOM 전용, 단계별 설정). 기본 OFF — 사용자가 켠 경우에만 동작.
    # 이 단계에 있는 Task progress 가 threshold 이상이 되면 다음(flow) 단계로 자동 이동한다.
    # 상위 Task 는 모든 활성 하위 Task 도 threshold 이상일 때만 이동하며, 한 번에 1단계만 이동한다.
    auto_advance_enabled = Column(Boolean, nullable=False, default=False)
    auto_advance_threshold = Column(Integer, nullable=True)      # 1~100, NULL=미설정

    # 단계 완료 조건(stage completion rule) — (레거시) 자동 이동 판단 기준. 4차부터는
    # auto_move_on_complete 로 단순화됨. 컬럼은 back-compat 위해 유지.
    completion_rule_type = Column(String(40), nullable=False, default="all_required_checkpoints")

    # 4차: '단계 완료 선언' 시 다음 단계로 자동 이동할지 여부(사용자 완료 선언 기반).
    #   True  = 사용자가 이 단계 완료를 체크하면 다음 단계로 자동 이동
    #   False = 완료를 체크해도 현재 단계 유지(수동 이동)
    # 마지막 단계는 다음 단계가 없어 자동 이동 대상에서 제외된다.
    auto_move_on_complete = Column(Boolean, nullable=False, default=True)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_project_task_columns_project_sort", "project_id", "sort_order"),
        Index("ix_project_task_columns_project_active", "project_id", "active"),
    )


class TaskStageCompletion(Base):
    """Task 의 '단계 완료 선언' 상태 (사용자 완료 선언 기반 자동 이동의 근거 데이터).

    - (task_id, stage_id) 당 1행. completed=True 는 사용자가 그 단계 완료를 선언했음을 의미.
    - 자동 이동 여부는 stage 의 auto_move_on_complete 가 결정한다(이 테이블은 '선언' 기록).
    - workflow DB / event log 활용을 위해 actor/시각을 함께 보관한다.
    """
    __tablename__ = "task_stage_completions"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    stage_id = Column(Integer, ForeignKey("project_task_columns.id"), nullable=False, index=True)
    completed = Column(Boolean, nullable=False, default=True)
    completed_at = Column(DateTime, nullable=True)
    actor_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ux_task_stage_completion", "task_id", "stage_id", unique=True),
    )


class ProjectWorkflowSnapshot(Base):
    """워크플로우 모드 변경 직전 상태 백업 (되돌리기/복구용).

    snapshot_json = 변경 직전의 {workflow_mode, auto_progress_from_notes, columns:[...]}.
    1차는 컬럼 설정 복구까지만 지원. Task별 위치 복구는 2차.
    """
    __tablename__ = "project_workflow_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)

    previous_mode = Column(String(20), nullable=True)
    next_mode = Column(String(20), nullable=True)
    snapshot_json = Column(JSON, nullable=True)

    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        Index("ix_project_workflow_snapshots_project_created", "project_id", "created_at"),
    )


class UserPreference(Base):
    __tablename__ = "user_preferences"

    user_id = Column(Integer, ForeignKey("users.id"), primary_key=True)
    layout = Column(JSON, nullable=True)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class VisitLog(Base):
    __tablename__ = "visit_log"

    id = Column(Integer, primary_key=True, index=True)
    ip_address = Column(String(50), nullable=False)
    deptname = Column(String(100), nullable=True)
    username = Column(String(100), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    visit_date = Column(String(10), nullable=True, index=True)  # YYYY-MM-DD
    timestamp = Column(DateTime, default=lambda: datetime.now(KST))


class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)

    action = Column(String(100), nullable=False)        # ex) CREATE_TASK
    entity_type = Column(String(50), nullable=False)    # ex) task / project
    entity_id = Column(Integer, nullable=True, index=True)

    message = Column(Text, nullable=True)
    meta = Column(JSON, nullable=True)

    created_at = Column(DateTime, server_default=func.now())


# =========================================================
# New Site Features (data.json -> DB 전환용)
# =========================================================

class SubProject(Base):
    __tablename__ = "sub_projects"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)

    name = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)

    # 서브프로젝트 트리 구조를 원하면 사용 (없어도 됨)
    parent_id = Column(Integer, ForeignKey("sub_projects.id"), nullable=True, index=True)

    created_at = Column(DateTime, server_default=func.now())


class Note(Base):
    __tablename__ = "notes"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)

    content = Column(Text, nullable=False)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class NoteMention(Base):
    __tablename__ = "note_mentions"

    id = Column(Integer, primary_key=True, index=True)
    note_id = Column(Integer, ForeignKey("notes.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("note_id", "user_id", name="uq_note_mention"),
    )


class TaskActivityMention(Base):
    __tablename__ = "task_activity_mentions"

    id = Column(Integer, primary_key=True, index=True)
    activity_id = Column(Integer, ForeignKey("task_activities.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("activity_id", "user_id", name="uq_activity_mention"),
    )


class Attachment(Base):
    __tablename__ = "attachments"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=False, index=True)

    # URL 첨부 / 외부 링크 첨부
    url = Column(Text, nullable=True)
    filename = Column(String(255), nullable=True)
    type = Column(String(30), nullable=False, default="url")  # url / file / etc

    created_at = Column(DateTime, server_default=func.now())


class ProjectMember(Base):
    __tablename__ = "project_members"

    # 복합 PK: 한 프로젝트에 같은 유저 중복 방지
    project_id = Column(Integer, ForeignKey("projects.id"), primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), primary_key=True)

    role = Column(String(30), nullable=False, default="member")  # owner / admin / member
    loginid = Column(String(128), nullable=True)
    deptname = Column(String(120), nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("project_id", "user_id", name="uq_project_member"),
    )


class JoinRequest(Base):
    __tablename__ = "join_requests"

    id = Column(Integer, primary_key=True, index=True)

    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    role = Column(String(30), nullable=False, default="member")
    status = Column(String(30), nullable=False, default="pending")  # pending/approved/rejected

    created_at = Column(DateTime, server_default=func.now())


class ProjectFile(Base):
    __tablename__ = "project_files"

    id = Column(Integer, primary_key=True, index=True)

    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    uploader_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)

    filename = Column(String(255), nullable=False)      # 원본 파일명
    stored_name = Column(String(255), nullable=False)   # 서버 저장 파일명(uuid)
    size = Column(BigInteger, nullable=False, default=0)

    created_at = Column(DateTime, server_default=func.now())


class Group(Base):
    __tablename__ = "groups"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False, unique=True, index=True)

    # 이전/향후 관리자 그룹 기능 호환용
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)

    # ✅ v1.2 조직 계층 확장
    parent_id = Column(Integer, ForeignKey("groups.id"), nullable=True, index=True)
    group_type = Column(String(20), nullable=True, default="TEAM")  # CENTER / TEAM / GROUP / PART
    sort_order = Column(Integer, nullable=True, default=0)

    created_at = Column(DateTime, server_default=func.now())


class GroupMembership(Base):
    """v1.2 조직 내 사용자 역할 매핑"""
    __tablename__ = "group_memberships"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    group_id = Column(Integer, ForeignKey("groups.id"), nullable=False, index=True)

    org_role = Column(String(30), nullable=False, default="MEMBER")  # CENTER_HEAD / TEAM_HEAD / GROUP_HEAD / PART_HEAD / MEMBER
    detail_level = Column(String(20), nullable=False, default="FULL_DETAIL")  # SUMMARY_ONLY / FULL_DETAIL
    is_primary = Column(Boolean, nullable=False, default=False)

    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("user_id", "group_id", name="uq_group_membership"),
    )


class Shortcut(Base):
    __tablename__ = "shortcuts"

    id = Column(Integer, primary_key=True, index=True)

    name = Column(String(100), nullable=False)
    url = Column(Text, nullable=False)

    icon_text = Column(String(20), nullable=True)
    icon_color = Column(String(20), nullable=False, default="#2955FF")

    order = Column(Integer, nullable=False, default=0)
    open_new_tab = Column(Boolean, nullable=False, default=True)
    active = Column(Boolean, nullable=False, default=True)

    created_at = Column(DateTime, server_default=func.now())


class UserShortcut(Base):
    __tablename__ = "user_shortcuts"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    name = Column(String(100), nullable=False)
    url = Column(Text, nullable=False)
    icon_text = Column(String(20), nullable=True)
    icon_color = Column(String(20), nullable=False, default="#2955FF")
    order = Column(Integer, nullable=False, default=0)
    open_new_tab = Column(Boolean, nullable=False, default=True)
    active = Column(Boolean, nullable=False, default=True)
    # 공유 모델 — PRIVATE / PUBLIC / SHARED_USERS / SHARED_GROUPS. 기본 PRIVATE.
    # shared_*_ids 는 JSON 직렬화된 정수 리스트("[1,2,3]").
    visibility = Column(String(20), nullable=False, default="PRIVATE")
    shared_user_ids = Column(Text, nullable=True)
    shared_group_ids = Column(Text, nullable=True)
    created_at = Column(DateTime, server_default=func.now())


class MemberGroup(Base):
    __tablename__ = "member_groups"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    description = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, server_default=func.now())


class MemberGroupUser(Base):
    __tablename__ = "member_group_users"

    id = Column(Integer, primary_key=True, index=True)
    group_id = Column(Integer, ForeignKey("member_groups.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("group_id", "user_id", name="uq_member_group_user"),
    )


class AiSetting(Base):
    __tablename__ = "ai_settings"

    # 단일 row로 써도 되고, 환경별 row로 확장해도 됨
    id = Column(Integer, primary_key=True, index=True)

    api_url = Column(Text, nullable=False)
    model_name = Column(String(255), nullable=False)
    api_key = Column(Text, nullable=True)
    # AI Provider 선택값 (dsllm / openai). 비어있으면 env AI_PROVIDER fallback.
    provider = Column(String(20), nullable=True)

    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class VisionAiSetting(Base):
    """이미지 포함 AI Report(Vision Report) 전용 설정 — Text AI(ai_settings)와 완전 분리.

    단일 row 사용(get_or_create). 접속정보(API Key/BASE URL)는 env 전용이라 저장하지 않고,
    선택값(provider/model)과 실행 파라미터(enabled/max_output_tokens/batch/timeout)만 저장한다.
    값이 비어 있으면 호출부가 VISION_AI_* env → OPENAI_VISION_* env → Text env fallback 순으로 보강.
    """
    __tablename__ = "vision_ai_settings"

    id = Column(Integer, primary_key=True, index=True)

    # Primary Vision Model (DS/Gemma4 등). 저장은 하되 호출부에서 provider 로 검증.
    provider = Column(String(20), nullable=True)
    model_name = Column(String(255), nullable=True)
    enabled = Column(Boolean, nullable=True)
    max_output_tokens = Column(Integer, nullable=True)
    batch_size = Column(Integer, nullable=True)
    timeout_seconds = Column(Integer, nullable=True)

    # ── Fallback Text Model (Gemma4 vision 지연/실패 시 텍스트 전용 보고서용) ──
    # Primary(Gemma4)와 별개 저장값. fallback 실행은 **일회성 옵션**이라 이 값을 덮어쓰지 않는다.
    # soft_timeout_seconds: 이 시간 초과 시 FE 가 사용자 선택 modal 을 띄운다(자동 전환 아님).
    fallback_text_provider = Column(String(20), nullable=True)
    fallback_text_model = Column(String(255), nullable=True)
    fallback_text_enabled = Column(Boolean, nullable=True)
    fallback_policy = Column(String(40), nullable=True)  # ask_user_on_timeout
    soft_timeout_seconds = Column(Integer, nullable=True)

    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class VisionImageObservation(Base):
    """이미지 자체에서 객관적으로 확인되는 관찰 결과(문맥 독립).

    같은 이미지(원본 SHA-256)라면 Task/작업노트 텍스트가 바뀌어도 재사용할 수 있는
    "이미지가 무엇을 보여주는가"만 저장한다. evidence_type/task_relevance 같은
    **문맥 의존 값은 절대 저장하지 않는다**(그것은 VisionImageContextLink 담당).

    캐시 유효성은 image_sha256 뿐 아니라 provider/model/파이프라인·프롬프트·전처리 버전과
    detail_policy 까지 일치해야 성립한다(모델/프롬프트/전처리가 바뀌면 재분석해야 하므로).
    """
    __tablename__ = "vision_image_observations"

    id = Column(Integer, primary_key=True, index=True)

    image_sha256 = Column(String(64), nullable=False, index=True)

    provider = Column(String(30), nullable=False)
    model_name = Column(String(255), nullable=False)

    pipeline_version = Column(String(50), nullable=False)
    prompt_version = Column(String(50), nullable=False)
    preprocessing_version = Column(String(50), nullable=False)
    detail_policy = Column(String(30), nullable=False)

    image_type = Column(String(50), nullable=True)

    observation_json = Column(JSON, nullable=False)

    overall_confidence = Column(Float, nullable=True)
    needs_raw_review = Column(Boolean, nullable=False, default=False)

    original_width = Column(Integer, nullable=True)
    original_height = Column(Integer, nullable=True)
    original_bytes = Column(Integer, nullable=True)

    processed_width = Column(Integer, nullable=True)
    processed_height = Column(Integer, nullable=True)
    processed_bytes = Column(Integer, nullable=True)

    input_tokens = Column(Integer, nullable=True)
    output_tokens = Column(Integer, nullable=True)
    latency_ms = Column(Integer, nullable=True)

    status = Column(String(20), nullable=False, default="completed")
    error_message = Column(Text, nullable=True)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint(
            "image_sha256", "provider", "model_name", "pipeline_version",
            "prompt_version", "preprocessing_version", "detail_policy",
            name="uq_vision_image_observation_key",
        ),
    )


class VisionImageContextLink(Base):
    """이미지(관찰 결과)가 특정 Task/작업노트 문맥에서 갖는 의미(문맥 의존).

    ImageObservation 은 유지한 채, Task 설명/작업노트 텍스트가 바뀌면 이 링크만 재생성한다.
    evidence_type/task_relevance/supports/context_summary 처럼 문맥에 따라 달라지는 값을 담는다.
    (동일 이미지가 Task A=direct, Task B=reference 가 될 수 있으므로 Task별로 별도 row.)
    """
    __tablename__ = "vision_image_context_links"

    id = Column(Integer, primary_key=True, index=True)

    observation_id = Column(
        Integer, ForeignKey("vision_image_observations.id"), nullable=False, index=True
    )

    project_id = Column(Integer, nullable=False, index=True)
    task_id = Column(Integer, nullable=False, index=True)
    note_id = Column(Integer, nullable=True, index=True)

    # authoritative image_id(backend 주입). 모델이 반환한 값이 아니다.
    canonical_image_id = Column(String(500), nullable=False)

    # Task/작업노트/인접 텍스트/caption 기반 hash. 텍스트 변경 감지 → 링크 재생성 판단.
    source_text_hash = Column(String(64), nullable=False)

    relation_type = Column(String(30), nullable=True)

    evidence_type = Column(String(20), nullable=False)
    task_relevance = Column(String(20), nullable=True)

    supports_json = Column(JSON, nullable=True)
    contradictions_json = Column(JSON, nullable=True)

    context_summary = Column(Text, nullable=True)
    confidence = Column(Float, nullable=True)

    model_name = Column(String(255), nullable=True)
    prompt_version = Column(String(50), nullable=False)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_vision_ctx_link_obs_task", "observation_id", "task_id"),
    )


class ProjectAiReport(Base):
    __tablename__ = "project_ai_reports"

    id = Column(Integer, primary_key=True, index=True)

    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)

    overview = Column(Text, nullable=True)
    task_analysis = Column(Text, nullable=True)
    status_analysis = Column(Text, nullable=True)
    next_steps = Column(Text, nullable=True)

    raw_response = Column(Text, nullable=True)
    structured_snapshot = Column(JSON, nullable=True)

    model = Column(String(255), nullable=True)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_project_ai_reports_project_created", "project_id", "created_at"),
    )


class ProjectAiQuery(Base):
    __tablename__ = "project_ai_queries"

    id = Column(Integer, primary_key=True, index=True)

    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    query = Column(Text, nullable=False)

    one_liner = Column(Text, nullable=True)
    details = Column(Text, nullable=True)
    key_schedule = Column(Text, nullable=True)
    next_actions = Column(Text, nullable=True)

    # (선택) 사용자에게 보여줄 최종 텍스트
    response = Column(Text, nullable=True)

    # LLM 원문(디버깅/파싱 실패 대비)
    raw_response = Column(Text, nullable=True)

    context_snapshot = Column(JSON, nullable=True)

    model = Column(String(255), nullable=True)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_project_ai_queries_project_created", "project_id", "created_at"),
        Index("ix_project_ai_queries_user_created", "user_id", "created_at"),
    )


# =========================================================
# v3.0 Sheet 운영 기능 (Excel 기반 Check Sheet / 운영 Sheet)
# =========================================================

class SheetTemplate(Base):
    """업로드된 Excel 원본 구조 (템플릿)"""
    __tablename__ = "sheet_templates"

    id = Column(Integer, primary_key=True, index=True)
    space_id = Column(Integer, ForeignKey("spaces.id"), nullable=False, index=True)

    name = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    category = Column(String(50), nullable=True, default="general")
    # check_sheet / chemical_mgmt / equipment_inspect / work_log / standard_form / general

    original_filename = Column(String(255), nullable=True)
    sheet_name = Column(String(100), nullable=True)  # 엑셀 시트 이름

    sheet_type = Column(String(50), nullable=False, default="inspection")
    # inspection / assignment_mapping

    # 파싱된 구조 (셀 데이터 + 병합/색상/수식 정보)
    structure = Column(JSON, nullable=False, default=dict)
    # {
    #   "rows": [...], "cols": [...],
    #   "merges": [...], "col_widths": [...], "row_heights": [...],
    #   "header_rows": [...], "checkable_cells": [...]
    # }

    row_count = Column(Integer, nullable=False, default=0)
    col_count = Column(Integer, nullable=False, default=0)
    checkable_count = Column(Integer, nullable=False, default=0)  # 체크 가능 항목 수

    # v3.1: 자동 인식된 컬럼 역할 매핑 (사용자 확인 후 저장)
    column_role_mapping = Column(JSON, nullable=True)
    structure_hash = Column(String(32), nullable=True, index=True)  # 같은 양식 인식용 해시

    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_sheet_templates_space", "space_id", "created_at"),
    )


class SheetExecution(Base):
    """시트 실행본 (누가, 언제, 어떤 프로젝트에서 실행했는지)"""
    __tablename__ = "sheet_executions"

    id = Column(Integer, primary_key=True, index=True)
    template_id = Column(Integer, ForeignKey("sheet_templates.id"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=True, index=True)
    space_id = Column(Integer, ForeignKey("spaces.id"), nullable=False, index=True)

    title = Column(String(300), nullable=True)  # 실행 제목 (예: "2026-04-17 PM Check")
    equipment_name = Column(String(200), nullable=True)  # 관련 설비명 (선택)

    sheet_type = Column(String(50), nullable=False, default="inspection")

    status = Column(String(30), nullable=False, default="in_progress")
    # in_progress / completed / cancelled

    total_items = Column(Integer, nullable=False, default=0)
    checked_items = Column(Integer, nullable=False, default=0)
    progress = Column(Integer, nullable=False, default=0)  # 0~100

    started_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    started_at = Column(DateTime, server_default=func.now())
    completed_at = Column(DateTime, nullable=True)
    completed_by = Column(Integer, ForeignKey("users.id"), nullable=True)

    # 사용자가 실행본에서 숨긴 컬럼 인덱스 배열 (template.structure는 그대로 유지)
    hidden_cols = Column(JSON, nullable=True)
    # 사용자가 실행본에서 숨긴 행 인덱스 배열 (template.structure는 그대로 유지)
    hidden_rows = Column(JSON, nullable=True)
    # 실행본 단위 구조 오버레이.
    # 모양: { "added_columns": [{col_idx, header}, ...],
    #         "added_rows": [{row_idx}, ...],
    #         "renamed_headers": {col_idx: header_text} }
    # 이번 라운드는 added_columns만 사용. 나머지는 슬롯만 유지.
    structure_overlay = Column(JSON, nullable=True)

    __table_args__ = (
        Index("ix_sheet_exec_template", "template_id", "started_at"),
        Index("ix_sheet_exec_project", "project_id", "started_at"),
        Index("ix_sheet_exec_task", "task_id", "started_at"),
        Index("ix_sheet_exec_space", "space_id", "started_at"),
    )


class SheetExecutionItem(Base):
    """실행본의 항목별 체크 상태/메모"""
    __tablename__ = "sheet_execution_items"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(Integer, ForeignKey("sheet_executions.id", ondelete="CASCADE"), nullable=False, index=True)

    cell_ref = Column(String(20), nullable=False)  # 셀 좌표 (예: "C5", "D12")
    row_idx = Column(Integer, nullable=False, default=0)
    col_idx = Column(Integer, nullable=False, default=0)

    label = Column(Text, nullable=True)  # 항목 라벨 (인접 셀 텍스트)
    checked = Column(Boolean, nullable=False, default=False)
    value = Column(String(100), nullable=True)  # O / X / 수치 등 체크값
    memo = Column(Text, nullable=True)  # 특이사항/메모

    checked_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    checked_at = Column(DateTime, nullable=True)

    __table_args__ = (
        Index("ix_sheet_exec_item_exec", "execution_id", "row_idx", "col_idx"),
    )


class SheetExecutionLog(Base):
    """항목별 체크/변경 이력 (감사 로그)"""
    __tablename__ = "sheet_execution_logs"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(Integer, ForeignKey("sheet_executions.id", ondelete="CASCADE"), nullable=False, index=True)
    item_id = Column(Integer, ForeignKey("sheet_execution_items.id", ondelete="CASCADE"), nullable=True, index=True)

    action = Column(String(50), nullable=False)  # check / uncheck / memo / complete / start
    old_value = Column(String(200), nullable=True)
    new_value = Column(String(200), nullable=True)
    memo = Column(Text, nullable=True)

    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        Index("ix_sheet_exec_log_exec", "execution_id", "created_at"),
    )

class SheetExecutionMapping(Base):
    """assignment_mapping 유형 시트의 매핑 관계 저장"""
    __tablename__ = "sheet_execution_mappings"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(Integer, ForeignKey("sheet_executions.id", ondelete="CASCADE"), nullable=False, index=True)

    master_name = Column(String(200), nullable=False)  # 예: 약품명, 마스터 항목
    master_code = Column(String(100), nullable=True)   # 예: 약품코드
    assigned_entity = Column(String(200), nullable=False)  # 예: 설비명, 연결될 항목

    manager = Column(String(100), nullable=True)
    last_checked_at = Column(DateTime, nullable=True)
    note = Column(Text, nullable=True)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_sheet_exec_mapping_exec", "execution_id", "master_name"),
    )


# =========================================================
# Notification System (Knox Messenger 등 외부 채널 추상화)
# =========================================================
# 실제 발송은 services.notification_service 가 수행한다.
# 본 테이블은:
#   - 발송 이력 영구 보관 (분석/감사용)
#   - 중복 발송 방지 키(dedup_key) 조회
# 용도이다. 이벤트 정의는 notification_service.EventType 참고.
class NotificationLog(Base):
    __tablename__ = "notification_logs"

    id = Column(Integer, primary_key=True, index=True)
    event_type = Column(String(40), nullable=False, index=True)
    target_user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id", ondelete="SET NULL"), nullable=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id", ondelete="SET NULL"), nullable=True, index=True)
    actor_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    # 중복 발송 방지용 키 (예: "task_assigned:7:42", "due_soon:7:42:2026-06-08")
    dedup_key = Column(String(255), nullable=False, index=True)
    provider = Column(String(40), nullable=False, default="knox")  # knox|email|web|...
    status = Column(String(20), nullable=False, default="sent")    # sent|failed|skipped
    message = Column(Text, nullable=True)
    link = Column(String(500), nullable=True)
    sent_at = Column(DateTime, server_default=func.now(), nullable=False, index=True)

    __table_args__ = (
        # dedup_key 단독으로도 빠르게 lookup 가능하도록 unique 보다는 일반 index 사용
        # (동일 키 재시도 시 status='failed'→'sent' 갱신 시나리오를 위해 unique 회피)
        Index("ix_notification_logs_event_user", "event_type", "target_user_id"),
        Index("ix_notification_logs_dedup", "dedup_key", "sent_at"),
    )


# =========================================================
# VOC / 개선 요청 (전역 피드백)
# =========================================================

class VocItem(Base):
    """사이트 전체 피드백/개선 요청. 특정 공간/프로젝트에 묶이지 않는 전역 데이터."""
    __tablename__ = "voc_items"

    id = Column(Integer, primary_key=True, index=True)
    author_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    title = Column(String(200), nullable=False)
    category = Column(String(40), nullable=False)
    # bug | improvement | feature | ux | design | etc
    content = Column(Text, nullable=False)

    related_screen = Column(String(40), nullable=True)
    # dashboard | space | project | settings | sheet | messenger | ai_report | etc

    priority = Column(String(20), nullable=False, default="normal")
    # low | normal | high | urgent

    status = Column(String(20), nullable=False, default="received")
    # received | reviewing | in_progress | completed | on_hold

    # 공개 범위. 신규 작성분은 public 이 기본, 기존 데이터는 마이그레이션에서 private 로 유지.
    visibility = Column(String(20), nullable=False, default="public")
    # public | private

    admin_note = Column(Text, nullable=True)
    resolved_by = Column(Integer, ForeignKey("users.id"), nullable=True)

    # 최소 수정 이력 메타 (전체 스냅샷은 저장하지 않음)
    edited_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    edited_at = Column(DateTime, nullable=True)
    change_summary = Column(String(255), nullable=True)

    created_at = Column(DateTime, server_default=func.now(), nullable=False, index=True)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_voc_items_status_created", "status", "created_at"),
        Index("ix_voc_items_visibility_created", "visibility", "created_at"),
    )


class SystemEventLog(Base):
    """운영 확인용 요약 시스템 이벤트 로그.

    모든 요청을 저장하지 않는다. 장애/오류/백업 등 운영자가 "뭐가 언제 터졌는지"를
    확인하기 위한 요약 이벤트만 저장한다.
    민감정보(토큰/비밀번호/쿠키/request body 전문/DSLLM 프롬프트/파일 내용)는 절대 저장하지 않는다.
    상세 원문은 서버 콘솔/nginx 로그에 남기고, 여기에는 요약만 남긴다.
    """
    __tablename__ = "system_event_logs"

    id = Column(Integer, primary_key=True, index=True)

    level = Column(String(20), nullable=False, default="ERROR")     # INFO / WARNING / ERROR / CRITICAL
    category = Column(String(20), nullable=False, default="API")    # API / DB / S3 / KNOX / DSLLM / BACKUP / AUTH / FRONTEND

    message = Column(String(500), nullable=False)                   # 짧은 요약 메시지
    detail = Column(Text, nullable=True)                            # 상세(민감정보 제외, 요약 stack trace 등)
    detail_json = Column(Text, nullable=True)                       # 구조화 진단 JSON 문자열(비민감 지표만; VISION_AI 등)

    endpoint = Column(String(300), nullable=True)                   # API endpoint
    method = Column(String(10), nullable=True)                      # GET/POST/PATCH/DELETE
    status_code = Column(Integer, nullable=True)                    # HTTP status code

    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    login_id = Column(String(128), nullable=True)
    request_id = Column(String(40), nullable=True, index=True)      # 요청 추적용 ID (REQ-YYYYMMDD-XXXXXXXX)

    resolved = Column(Boolean, nullable=False, default=False)       # 운영자 처리 완료 여부
    resolved_at = Column(DateTime, nullable=True)                   # 처리 완료 시각
    resolved_by = Column(Integer, ForeignKey("users.id"), nullable=True)  # 처리한 운영자
    resolution_note = Column(Text, nullable=True)                   # 처리 사유 메모
    created_at = Column(DateTime, server_default=func.now(), nullable=False, index=True)

    __table_args__ = (
        Index("ix_system_event_logs_category_created", "category", "created_at"),
        Index("ix_system_event_logs_level_resolved", "level", "resolved", "created_at"),
    )


class VocAttachment(Base):
    """개선요청 첨부 이미지. 원본은 보관하지 않고 리사이즈+webp 최적화본만 저장."""
    __tablename__ = "voc_attachments"

    id = Column(Integer, primary_key=True, index=True)
    voc_id = Column(Integer, ForeignKey("voc_items.id", ondelete="CASCADE"), nullable=False, index=True)

    filename = Column(String(255), nullable=False)      # 사용자가 올린 원본 파일명
    stored_name = Column(String(255), nullable=False)   # 디스크/S3에 저장된 실제 파일명 (uuid + ext)
    content_type = Column(String(80), nullable=True)    # image/webp 등
    file_size = Column(Integer, nullable=True)          # 최적화 후 byte 크기
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    s3_key = Column(String(500), nullable=True)         # S3 저장 시 키, 로컬이면 빈 문자열
    # True 면 VOC 본문이 아니라 댓글/추가 문의에 붙은 이미지.
    # 본문 첨부 목록/수정 diff 와 분리해 댓글 이미지가 본문 편집 시 삭제되지 않도록 구분한다.
    comment_scoped = Column(Boolean, nullable=False, default=False)

    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    __table_args__ = (
        Index("ix_voc_attachments_voc", "voc_id", "created_at"),
    )


class VocVote(Base):
    """VOC 공감('나도 필요해요'). 사용자당 VOC 1건에 한 번만 가능."""
    __tablename__ = "voc_votes"

    id = Column(Integer, primary_key=True, index=True)
    voc_id = Column(Integer, ForeignKey("voc_items.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    __table_args__ = (
        UniqueConstraint("voc_id", "user_id", name="uq_voc_votes_voc_user"),
    )


class VocComment(Base):
    """VOC 댓글 / 관리자 답변. 조회 가능한 VOC(공개글/본인/관리자)에 작성."""
    __tablename__ = "voc_comments"

    id = Column(Integer, primary_key=True, index=True)
    voc_id = Column(Integer, ForeignKey("voc_items.id", ondelete="CASCADE"), nullable=False, index=True)
    author_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    content = Column(Text, nullable=False)
    # 작성 시점에 작성자가 관리자였는지 — UI에서 '운영자 답변' 배지 표시용
    is_admin_reply = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, server_default=func.now(), nullable=False, index=True)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index("ix_voc_comments_voc_created", "voc_id", "created_at"),
    )


class RealtimeEvent(Base):
    """Realtime sync 용 event outbox (SSE 전파).

    같은 공간 사용자 간 변경사항(Project/Task/Calendar/VOC)을 새로고침 없이
    2~5초 내 반영하기 위한 경량 이벤트 로그. 민감정보(title/description/note/content)는
    절대 저장하지 않는다. 실제 화면 데이터는 기존 API 재조회로 가져온다.
    space_id = 0 은 공간에 묶이지 않는 전역 이벤트(VOC 등) 채널.
    retention 정책으로 오래된 row 는 주기적으로 삭제한다(운영 데이터 아님, 이벤트 로그만 정리).
    """
    __tablename__ = "realtime_events"

    # MySQL 에서는 BIGINT, SQLite(dev) 에서는 INTEGER 로 동작
    id = Column(BigInteger().with_variant(Integer, "sqlite"), primary_key=True, autoincrement=True)
    space_id = Column(Integer, nullable=False, default=0, server_default="0")
    project_id = Column(Integer, nullable=True)
    task_id = Column(Integer, nullable=True)
    event_type = Column(String(80), nullable=False)
    entity_type = Column(String(50), nullable=False)
    entity_id = Column(Integer, nullable=True)
    actor_user_id = Column(Integer, nullable=True)
    # 작은 비민감 JSON 만 저장 (예: {"voc_id": 12}). 큰 텍스트/본문 금지.
    payload_json = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.now)

    __table_args__ = (
        Index("idx_realtime_events_space_id_id", "space_id", "id"),
        Index("idx_realtime_events_created_at", "created_at"),
        Index("idx_realtime_events_space_created", "space_id", "created_at"),
    )


# =========================================================
# Task Comments (담당자 외 인원 의견 제시 / 논의 기록)
# =========================================================
class TaskComment(Base):
    """Task 에 달리는 댓글. 담당자 외 인원의 의견 제시 / 논의 기록 용도.

    soft delete(deleted_at) 정책 — 삭제해도 row 는 남기고 화면에서만 "삭제된 댓글"로 표시.
    parent_comment_id 는 향후 대댓글 확장을 위한 예약 컬럼(1차 UI 는 단순 댓글만).
    """
    __tablename__ = "task_comments"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    author_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)

    content = Column(Text, nullable=False)

    # 향후 대댓글 확장용(예약). 1차에서는 항상 NULL.
    parent_comment_id = Column(Integer, ForeignKey("task_comments.id"), nullable=True, index=True)

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    edited_at = Column(DateTime, nullable=True)      # 본문이 실제 수정된 시각
    deleted_at = Column(DateTime, nullable=True)     # soft delete

    __table_args__ = (
        Index("ix_task_comments_task_created", "task_id", "created_at"),
    )


class TaskCommentMention(Base):
    """댓글 내 @멘션 대상 사용자. notification event 생성/중복방지 기준으로 사용."""
    __tablename__ = "task_comment_mentions"

    id = Column(Integer, primary_key=True, index=True)
    comment_id = Column(Integer, ForeignKey("task_comments.id", ondelete="CASCADE"), nullable=False, index=True)
    mentioned_user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("comment_id", "mentioned_user_id", name="uq_comment_mention"),
    )


class TaskCommentAttachment(Base):
    """Task 댓글에 붙는 이미지. 원본은 보관하지 않고 리사이즈+webp 최적화본만 저장(VOC 첨부와 동일 정책).

    comment_id 는 붙여넣기-먼저-업로드 흐름을 위해 nullable — 업로드 시점엔 NULL(task 스코프 pending)로
    저장되고, 댓글 등록 시 해당 comment 에 링크된다. base64 DB 저장은 하지 않는다(S3/로컬 파일 저장).
    """
    __tablename__ = "task_comment_attachments"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id", ondelete="CASCADE"), nullable=False, index=True)
    comment_id = Column(Integer, ForeignKey("task_comments.id", ondelete="CASCADE"), nullable=True, index=True)
    uploader_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    filename = Column(String(255), nullable=False)      # 사용자가 올린 원본 파일명
    stored_name = Column(String(255), nullable=False)   # 저장 파일명 (uuid + ext)
    content_type = Column(String(80), nullable=True)    # image/webp 등
    file_size = Column(Integer, nullable=True)          # 최적화 후 byte 크기
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    s3_key = Column(String(500), nullable=True)         # S3 저장 시 키, 로컬이면 빈 문자열/NULL

    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    __table_args__ = (
        Index("ix_task_comment_attachments_comment", "comment_id", "created_at"),
        Index("ix_task_comment_attachments_task", "task_id", "created_at"),
    )


# =========================================================
# Notification events (알림 outbox — Knox 메일/메신저 연동 기반)
#   실제 발송 worker 는 미구현. 이벤트 row 만 남겨 추후 sender adapter 를 붙인다.
#   (docs/NOTIFICATION_KNOX_MAIL_TODO.md 참고)
# =========================================================
class NotificationEvent(Base):
    __tablename__ = "notification_events"

    id = Column(Integer, primary_key=True, index=True)
    # ex) task_comment_created / task_comment_mentioned
    event_type = Column(String(60), nullable=False, index=True)

    task_id = Column(Integer, nullable=True, index=True)
    project_id = Column(Integer, nullable=True)
    space_id = Column(Integer, nullable=True)

    actor_user_id = Column(Integer, nullable=True)     # 이벤트를 유발한 사용자
    target_user_id = Column(Integer, nullable=True, index=True)  # 알림 받을 대상

    # 작은 비민감 JSON 만. (예: {"comment_id": 12})
    payload_json = Column(JSON, nullable=True)

    # pending / processing / skipped / sent / failed
    status = Column(String(20), nullable=False, default="pending", index=True)
    # skipped/failed 사유 (예: provider_disabled, no_mail, pref_off, no_access, sender_optout, smtp_not_configured, SMTP 오류 등)
    error_message = Column(Text, nullable=True)

    created_at = Column(DateTime, server_default=func.now())
    processed_at = Column(DateTime, nullable=True)

    __table_args__ = (
        Index("ix_notification_events_status_created", "status", "created_at"),
    )


class UserNotificationPreference(Base):
    """사용자별 알림 on/off 설정 (Knox 메일 연동 시 사용). 1차는 구조만 준비."""
    __tablename__ = "user_notification_preferences"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, unique=True, index=True)

    # master 스위치 — 이게 false면 어떤 멘션 메일도 보내지 않는다.
    mention_email_enabled = Column(Boolean, nullable=False, default=True)
    # 세부 스위치 (master 가 true 일 때만 의미 있음)
    task_comment_email_enabled = Column(Boolean, nullable=False, default=True)   # (예약) 담당자 댓글 알림
    task_mention_email_enabled = Column(Boolean, nullable=False, default=True)   # Comment 멘션 메일
    work_note_mention_email_enabled = Column(Boolean, nullable=False, default=True)  # 작업노트 멘션 메일

    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())