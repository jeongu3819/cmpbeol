"""
DB 백업 retention 분류 로직 (순수 함수 — S3 접근 없음).

S3 cleanup은 실수하면 운영 데이터 손실로 이어질 수 있으므로,
"어떤 key를 삭제/보관/스킵할지" 결정하는 부분만 이 모듈에 분리했습니다.
- s3fs / boto3 의존성이 전혀 없어 단위 테스트가 가능합니다.
  (scripts/test_backup_retention_logic.py 참고)
- 실제 S3 list/delete 는 s3_utils.cleanup_old_db_backups() 가 담당합니다.

핵심 안전 규칙:
  1. db-backups/ prefix 밖의 key 는 절대 삭제 후보가 되지 않는다.
  2. .sql / .sql.gz 파일만 삭제 후보가 된다.
  3. 날짜 폴더(YYYY-MM-DD)만 처리한다. 파싱 실패 시 보관(skip).
  4. cutoff_date = today - retention_days. object_date < cutoff 인 경우만 삭제.
"""

import re
from datetime import date, datetime, timedelta
from typing import List, Tuple

# 정리 대상 하위 prefix (BASE_S3_PATH 기준). 절대 이 밖을 건드리지 않는다.
DB_BACKUP_SUB_PREFIX = "db-backups/"

# 날짜 폴더 형식: YYYY-MM-DD 만 허용
_DATE_DIR_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

# 삭제 허용 확장자 (DB dump 만)
ALLOWED_SUFFIXES = (".sql", ".sql.gz")


def extract_backup_date(key: str) -> Tuple[date, str]:
    """
    key 에서 날짜 폴더(YYYY-MM-DD)를 추출한다.

    key 예: 'FDC/plan-a/db-backups/2026-06-16/schedule_2026-06-16_030002.sql'
            → 마지막 디렉토리 세그먼트('2026-06-16')를 날짜 폴더로 본다.

    Returns:
        (date, "") 성공 시
        (None, reason) 실패 시 — 호출부는 reason 으로 skip 처리
    """
    parts = key.rstrip("/").split("/")
    if len(parts) < 2:
        return None, "no-date-folder"
    date_folder = parts[-2]  # 파일명 바로 위 폴더
    if not _DATE_DIR_RE.match(date_folder):
        return None, "bad-date-format"
    try:
        return datetime.strptime(date_folder, "%Y-%m-%d").date(), ""
    except ValueError:
        return None, "date-parse-failed"


def classify_db_backup_keys(
    keys: List[str],
    full_prefix: str,
    retention_days: int,
    today: date,
) -> dict:
    """
    DB 백업 key 목록을 삭제 / 보관 / 스킵으로 분류한다 (순수 함수).

    Args:
        keys: S3 key 목록 (boto3 호환 key, 예: 'FDC/plan-a/db-backups/.../x.sql')
        full_prefix: 삭제가 허용되는 전체 prefix. 반드시 'db-backups/' 로 끝나야 한다.
        retention_days: 보관 일수. cutoff = today - retention_days.
        today: 기준 날짜(KST date).

    Returns:
        {
          "delete": [key, ...],          # 삭제 후보 (cutoff 이전)
          "keep":   [key, ...],          # 보관 (cutoff 이상)
          "skip":   [(key, reason), ...] # 처리 제외 (prefix/확장자/날짜 문제)
          "cutoff": "YYYY-MM-DD",
        }

    Raises:
        ValueError: full_prefix 가 db-backups/ 로 끝나지 않으면 (안전장치).
    """
    # 안전장치: 잘못된 prefix 로 호출되면 아무것도 분류하지 않고 즉시 예외.
    if not full_prefix.endswith(DB_BACKUP_SUB_PREFIX):
        raise ValueError(
            f"안전장치: full_prefix 는 반드시 '{DB_BACKUP_SUB_PREFIX}' 로 끝나야 합니다. "
            f"받은 값: '{full_prefix}'"
        )

    if retention_days < 0:
        raise ValueError(f"retention_days 는 0 이상이어야 합니다. 받은 값: {retention_days}")

    cutoff = today - timedelta(days=retention_days)

    to_delete: List[str] = []
    to_keep: List[str] = []
    to_skip: List[Tuple[str, str]] = []

    for key in keys:
        # 안전장치 1: db-backups prefix 밖이면 절대 손대지 않음 (files/images 등)
        if not key.startswith(full_prefix):
            to_skip.append((key, "prefix-mismatch"))
            continue
        # 안전장치 2: .sql / .sql.gz 만 삭제 후보
        if not key.endswith(ALLOWED_SUFFIXES):
            to_skip.append((key, "not-sql"))
            continue
        # 안전장치 3·4: 날짜 폴더 추출 (실패 시 보관)
        obj_date, reason = extract_backup_date(key)
        if obj_date is None:
            to_skip.append((key, reason))
            continue

        if obj_date < cutoff:
            to_delete.append(key)
        else:
            to_keep.append(key)

    return {
        "delete": to_delete,
        "keep": to_keep,
        "skip": to_skip,
        "cutoff": cutoff.isoformat(),
    }
