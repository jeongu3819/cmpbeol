"""공통 파일 업로드 정책.

모든 업로드 경로(Task 첨부 / Project 파일 / VOC 첨부 / 인라인 이미지)가 동일한
검증 로직을 공유하도록 정책 객체 + validator 를 한 곳에서 관리한다. 각 endpoint 가
제한 로직을 중복 구현하지 않게 하는 것이 목적이다.

정책 종류
- GENERAL_ATTACHMENT_POLICY : 일반 첨부(문서+이미지). Task/Project 파일 업로드.
- INLINE_IMAGE_POLICY       : Description/작업노트/단발일정 인라인 이미지(이미지 전용, 작은 용량).
- VOC_IMAGE_POLICY          : 개선요청(VOC) 첨부 이미지(스크린샷). 이미지 전용 + 자체 장수 제한.

운영 중 한도 조정은 .env 값만 바꾸면 된다 (코드 수정 불필요):
    MAX_UPLOAD_FILE_MB=30                  # 일반 첨부 1개당 (최대 50까지 권장)
    MAX_UPLOAD_FILE_COUNT_PER_ENTITY=10    # Task/Project 1개당 파일 수
    MAX_UPLOAD_TOTAL_MB_PER_ENTITY=200     # Task/Project 1개당 총 용량
    MAX_INLINE_IMAGE_UPLOAD_MB=10          # 인라인 이미지 1개당
    MAX_VOC_ATTACHMENT_COUNT=5             # VOC 1개당 첨부 장수
    ALLOW_HWP_UPLOAD=true                  # 일반 첨부에 hwp/hwpx 허용

구 환경변수(MAX_TASK_FILE_COUNT / MAX_TASK_TOTAL_UPLOAD_MB)도 alias 로 계속 인식한다.
"""
import os
from dataclasses import dataclass
from typing import Optional, Set

# .env 가 먼저 로드되도록 environment 를 import (load_dotenv 트리거)
from app import environment  # noqa: F401

MB = 1024 * 1024


def _int_env(names, default: int) -> int:
    """names 중 처음 발견되는 환경변수를 사용 (구→신 alias 지원)."""
    for n in names:
        v = os.getenv(n)
        if v is not None:
            try:
                return max(1, int(v))
            except (TypeError, ValueError):
                continue
    return default


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


# ── 한도 (환경변수) ──
MAX_UPLOAD_FILE_MB = _int_env(["MAX_UPLOAD_FILE_MB"], 30)
MAX_FILE_COUNT_PER_ENTITY = _int_env(
    ["MAX_UPLOAD_FILE_COUNT_PER_ENTITY", "MAX_TASK_FILE_COUNT"], 10
)
MAX_TOTAL_MB_PER_ENTITY = _int_env(
    ["MAX_UPLOAD_TOTAL_MB_PER_ENTITY", "MAX_TASK_TOTAL_UPLOAD_MB"], 200
)
MAX_INLINE_IMAGE_MB = _int_env(["MAX_INLINE_IMAGE_UPLOAD_MB"], 10)
MAX_VOC_ATTACHMENT_COUNT = _int_env(["MAX_VOC_ATTACHMENT_COUNT"], 5)
ALLOW_HWP_UPLOAD = _bool_env("ALLOW_HWP_UPLOAD", False)

# ── 확장자 집합 ──
_DOC_EXTS = {
    ".pdf", ".ppt", ".pptx", ".doc", ".docx",
    ".xls", ".xlsx", ".csv", ".txt",
}
_IMAGE_DOC_EXTS = {".png", ".jpg", ".jpeg"}
_HWP_EXTS = {".hwp", ".hwpx"}
_INLINE_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
_VOC_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}

_GENERAL_ALLOWED = set(_DOC_EXTS) | set(_IMAGE_DOC_EXTS)
if ALLOW_HWP_UPLOAD:
    _GENERAL_ALLOWED |= _HWP_EXTS

# ── 명시적 차단 확장자 (일반 첨부에서 카테고리별 구체 메시지용) ──
_BLOCKED_VIDEO = {".mp4", ".avi", ".mov", ".mkv", ".webm"}
_BLOCKED_ARCHIVE = {".zip", ".rar", ".7z", ".alz", ".egg", ".tar", ".gz"}
_BLOCKED_EXEC = {
    ".exe", ".msi", ".bat", ".cmd", ".ps1", ".sh",
    ".js", ".vbs", ".dll", ".jar",
}
_BLOCKED_RISKY = {".html", ".htm", ".php"}
BLOCKED_EXTENSIONS = _BLOCKED_VIDEO | _BLOCKED_ARCHIVE | _BLOCKED_EXEC | _BLOCKED_RISKY

# 클라이언트 MIME 은 신뢰도가 낮지만 명백히 위험한 카테고리는 추가로 거른다.
_BLOCKED_MIME_PREFIXES = ("video/",)
_BLOCKED_MIME_EXACT = {
    "application/x-msdownload", "application/x-msdos-program",
    "application/x-sh", "application/x-bat",
    "application/zip", "application/x-zip-compressed",
    "application/x-rar-compressed", "application/x-7z-compressed",
    "application/x-tar", "application/gzip",
}

GENERAL_LABEL = "PDF, PPT, Word, Excel, 이미지"
INLINE_IMAGE_LABEL = "PNG, JPG, JPEG, WEBP"


class UploadValidationError(Exception):
    """업로드 정책 위반. detail 메시지는 사용자에게 그대로 노출 가능."""


def file_ext(filename: str) -> str:
    return os.path.splitext(filename or "")[1].lower()


@dataclass
class UploadPolicy:
    name: str
    max_file_bytes: int
    allowed_extensions: Set[str]
    allowed_label: str
    too_large_message: str
    bad_type_message: str
    max_file_count: Optional[int] = None
    max_total_bytes: Optional[int] = None
    enforce_blocked_categories: bool = False  # True 면 영상/압축/실행 카테고리별 구체 메시지
    count_message: Optional[str] = None
    total_message: Optional[str] = None

    def validate_type(self, filename: str, content_type: str = "") -> None:
        """확장자/MIME 검증 (파일을 읽기 전에 호출 가능)."""
        ext = file_ext(filename)
        if self.enforce_blocked_categories and ext in BLOCKED_EXTENSIONS:
            if ext in _BLOCKED_VIDEO:
                raise UploadValidationError(
                    "동영상 파일은 업로드할 수 없습니다. 용량이 큰 영상은 별도 저장소를 이용해 주세요."
                )
            if ext in _BLOCKED_ARCHIVE:
                raise UploadValidationError(
                    "압축 파일은 업로드할 수 없습니다. 내부 파일을 직접 첨부해 주세요."
                )
            raise UploadValidationError(
                "실행/스크립트 파일은 보안상 업로드할 수 없습니다."
            )
        if ext not in self.allowed_extensions:
            raise UploadValidationError(self.bad_type_message)
        if self.enforce_blocked_categories:
            ct = (content_type or "").lower().strip()
            if ct and (any(ct.startswith(p) for p in _BLOCKED_MIME_PREFIXES) or ct in _BLOCKED_MIME_EXACT):
                raise UploadValidationError(self.bad_type_message)

    def validate(
        self,
        filename: str,
        size_bytes: int,
        content_type: str = "",
        existing_count: Optional[int] = None,
        existing_total_bytes: Optional[int] = None,
    ) -> None:
        """전체 검증: 확장자/MIME → 파일 크기 → (개수) → (총 용량).

        위반 시 UploadValidationError(detail) 발생. detail 은 사용자 노출 가능.
        """
        self.validate_type(filename, content_type)

        if size_bytes > self.max_file_bytes:
            raise UploadValidationError(self.too_large_message)

        if self.max_file_count is not None and existing_count is not None:
            if existing_count + 1 > self.max_file_count:
                raise UploadValidationError(
                    self.count_message
                    or f"첨부는 최대 {self.max_file_count}개까지 업로드할 수 있습니다."
                )
        if self.max_total_bytes is not None and existing_total_bytes is not None:
            if existing_total_bytes + size_bytes > self.max_total_bytes:
                raise UploadValidationError(
                    self.total_message
                    or f"전체 첨부 용량은 최대 {self.max_total_bytes // MB}MB까지 허용됩니다."
                )

    def as_dict(self) -> dict:
        d = {
            "max_file_mb": self.max_file_bytes // MB,
            "max_file_bytes": self.max_file_bytes,
            "allowed_extensions": sorted(self.allowed_extensions),
            "allowed_label": self.allowed_label,
        }
        if self.max_file_count is not None:
            d["max_file_count"] = self.max_file_count
        if self.max_total_bytes is not None:
            d["max_total_mb"] = self.max_total_bytes // MB
            d["max_total_bytes"] = self.max_total_bytes
        return d


# ── 정책 인스턴스 ──
GENERAL_ATTACHMENT_POLICY = UploadPolicy(
    name="general_attachment",
    max_file_bytes=MAX_UPLOAD_FILE_MB * MB,
    allowed_extensions=_GENERAL_ALLOWED,
    allowed_label=GENERAL_LABEL,
    too_large_message=f"파일 1개당 최대 {MAX_UPLOAD_FILE_MB}MB까지만 업로드할 수 있습니다.",
    bad_type_message=f"업로드할 수 없는 파일 형식입니다. {GENERAL_LABEL} 파일만 첨부할 수 있습니다.",
    max_file_count=MAX_FILE_COUNT_PER_ENTITY,
    max_total_bytes=MAX_TOTAL_MB_PER_ENTITY * MB,
    enforce_blocked_categories=True,
    count_message=f"첨부파일은 최대 {MAX_FILE_COUNT_PER_ENTITY}개까지 업로드할 수 있습니다.",
    total_message=f"전체 첨부 용량은 최대 {MAX_TOTAL_MB_PER_ENTITY}MB까지 허용됩니다.",
)

INLINE_IMAGE_POLICY = UploadPolicy(
    name="inline_image",
    max_file_bytes=MAX_INLINE_IMAGE_MB * MB,
    allowed_extensions=set(_INLINE_IMAGE_EXTS),
    allowed_label=INLINE_IMAGE_LABEL,
    too_large_message=f"이미지 1개당 최대 {MAX_INLINE_IMAGE_MB}MB까지만 업로드할 수 있습니다.",
    bad_type_message=f"이미지는 {INLINE_IMAGE_LABEL} 형식만 첨부할 수 있습니다.",
)

VOC_IMAGE_POLICY = UploadPolicy(
    name="voc_image",
    max_file_bytes=MAX_INLINE_IMAGE_MB * MB,
    allowed_extensions=set(_VOC_IMAGE_EXTS),
    allowed_label="PNG, JPG, JPEG, WEBP, GIF",
    too_large_message=f"이미지 1개당 최대 {MAX_INLINE_IMAGE_MB}MB까지만 업로드할 수 있습니다.",
    bad_type_message="이미지(png/jpg/jpeg/webp/gif)만 업로드할 수 있습니다.",
    max_file_count=MAX_VOC_ATTACHMENT_COUNT,
    count_message=f"첨부는 최대 {MAX_VOC_ATTACHMENT_COUNT}장까지 가능합니다.",
)


def get_upload_policies() -> dict:
    """프론트가 즉시 검증에 사용할 정책 묶음 (일반 첨부 + 인라인 이미지)."""
    return {
        "general": {**GENERAL_ATTACHMENT_POLICY.as_dict(),
                    "blocked_extensions": sorted(BLOCKED_EXTENSIONS),
                    "allow_hwp": ALLOW_HWP_UPLOAD},
        "inline_image": INLINE_IMAGE_POLICY.as_dict(),
    }
