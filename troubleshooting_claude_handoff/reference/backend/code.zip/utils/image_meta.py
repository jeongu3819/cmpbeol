"""업로드 시점 이미지 메타 추출 헬퍼.

프로젝트 내부 이미지가 저장될 때 ``width/height/sha256/format`` 을 함께 기록해
나중에 AI(vision) 입력 품질 판단(image readiness)과 중복/캐시 식별을 가능하게 한다.

- LLM/vision 호출 없음. 바이트만 분석.
- Pillow(PIL) 가 없거나 비이미지면 dimension 은 None 으로 두고 sha256 만 남긴다(예외 비전파).
- 이미지 바이트 자체는 저장하지 않으며, 본 함수는 메타(dict)만 반환한다.
"""

from __future__ import annotations

import hashlib
import io
from typing import Any, Dict, Optional


def compute_sha256(contents: bytes) -> str:
    return hashlib.sha256(contents).hexdigest()


def compute_image_meta(
    contents: bytes,
    content_type: Optional[str] = None,
    filename: Optional[str] = None,
) -> Dict[str, Any]:
    """바이트에서 이미지 메타를 추출한다.

    Returns:
        {"sha256", "width", "height", "format"}
        - 비이미지/PIL 실패 시 width/height/format 은 None, sha256 은 항상 채움.
    """
    meta: Dict[str, Any] = {
        "sha256": None,
        "width": None,
        "height": None,
        "format": None,
    }
    try:
        meta["sha256"] = compute_sha256(contents or b"")
    except Exception:
        pass

    # 이미지일 가능성이 있을 때만 PIL 시도 (PDF 등 비이미지는 빠르게 실패하고 넘어감)
    try:
        from PIL import Image  # 지연 import — 미설치여도 업로드는 계속

        with Image.open(io.BytesIO(contents)) as im:
            meta["width"] = int(im.width)
            meta["height"] = int(im.height)
            fmt = (im.format or "").lower()
            meta["format"] = fmt or None
    except Exception:
        # 비이미지이거나 Pillow 미설치/손상 — dimension 은 알 수 없음으로 둔다.
        pass

    return meta
