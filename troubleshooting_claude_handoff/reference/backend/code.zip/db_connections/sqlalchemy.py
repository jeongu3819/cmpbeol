import os

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from app.environment import DATABASE_URL

connect_args = {}
engine_kwargs = {
    "pool_pre_ping": True,  # 끊긴 커넥션 자동 감지 (MySQL wait_timeout 대비)
    "echo": False,
}

if DATABASE_URL.startswith("sqlite"):
    # SQLite(개발)는 단일 파일 기반이라 커넥션 풀 옵션을 적용하지 않는다.
    connect_args = {"check_same_thread": False}
else:
    # 운영 DB(MySQL 등): 동시 접속 증가 시 커넥션 고갈을 막기 위한 풀 설정.
    # 값은 환경변수로 조정 가능하며, 미설정 시 안정 기본값을 사용한다.
    engine_kwargs.update(
        pool_size=int(os.getenv("DB_POOL_SIZE", "10")),
        max_overflow=int(os.getenv("DB_MAX_OVERFLOW", "20")),
        pool_timeout=int(os.getenv("DB_POOL_TIMEOUT", "30")),
        pool_recycle=int(os.getenv("DB_POOL_RECYCLE", "1800")),  # MySQL idle 끊김 전 재활용
    )

engine = create_engine(
    DATABASE_URL,
    connect_args=connect_args,
    **engine_kwargs,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
