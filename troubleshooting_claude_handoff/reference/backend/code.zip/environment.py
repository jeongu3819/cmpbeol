# app/environment.py
import os
from dotenv import load_dotenv
from datetime import timedelta, timezone

BASE_DIR = os.path.dirname(__file__)

def env_path(name: str) -> str:
    return os.path.join(BASE_DIR, name)

ENV_MODE = os.getenv("ENV_MODE", "development").lower()

if ENV_MODE == "development":
    if os.path.isfile(env_path(".env.local")):
        print("🔧 [ENV] Loading app/.env.local (development)")
        load_dotenv(env_path(".env.local"), override=True)
    else:
        print("🔧 [ENV] Loading app/.env (development fallback)")
        load_dotenv(env_path(".env"), override=True)
else:
    env_file = f".env.{ENV_MODE}"
    if os.path.isfile(env_path(env_file)):
        print(f"🔧 [ENV] Loading app/{env_file} (ENV_MODE={ENV_MODE})")
        load_dotenv(env_path(env_file), override=True)
    elif os.path.isfile(env_path(".env.production")):
        print("🔧 [ENV] Loading app/.env.production (fallback)")
        load_dotenv(env_path(".env.production"), override=True)
    else:
        print("⚠️ [ENV] .env 파일을 찾지 못했습니다. OS 환경변수만 사용합니다.")

# ===== SSO / OAuth =====
ADFS_TOKEN_URL = os.getenv("ADFS_TOKEN_URL")
ADFS_AUTH_URL = os.getenv("ADFS_AUTH_URL", "https://stsds.secsso.net/adfs/oauth2/authorize/")

CLIENT_ID = os.getenv("CLIENT_ID") or os.getenv("SSO_CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET") or os.getenv("SSO_CLIENT_SECRET")
REDIRECT_URI = os.getenv("REDIRECT_URI", "http://localhost:8085/api/auth/callback")


# ===== DB 설정 =====
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "mysql+pymysql://~~@localhost:3306/schedule" 
)

# ===== Timezone =====
KST = timezone(timedelta(hours=9))

# ===== BYPASS =====
BYPASS_SSO = os.getenv("BYPASS_SSO", "False").lower() == "true"
BYPASS_USER_INFO = {
    "loginid": os.getenv("BYPASS_LOGINID") or os.getenv("LOGIN_ID", "local.dev"),
    "username": os.getenv("BYPASS_USERNAME") or os.getenv("USER_NAME", "Local DEV"),
    "deptname": os.getenv("BYPASS_DEPTNAME") or os.getenv("USER_DEPARTMENT", "데분 파트"),
    "mail": os.getenv("BYPASS_MAIL") or os.getenv("USER_MAIL", "local.dev@example.com"),
}

# ===== Super Admin =====
def _parse_list(v: str):
    return [x.strip() for x in (v or "").split(",") if x.strip()]

SUPER_ADMIN_LOGINIDS = _parse_list(
    os.getenv("SUPER_ADMIN_LOGINIDS", "jimi.lee,juhui07.kim,zoltas.roh")
)

# ===== Front redirect =====
FRONTEND_REDIRECT_URI = (
    os.getenv("FRONTEND_REDIRECT_URI")
    or os.getenv("REDIRECT_URI_LOCAL")
    or "http://localhost:5173"
)

# ===== CORS =====
def _parse_origins(val: str) -> list[str]:
    return [x.strip() for x in val.split(",") if x.strip()]

CORS_ORIGINS = _parse_origins(
    os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000,http://127.0.0.1:3000")
)

# ===== S3 / Backup =====
# S3 호환 스토리지 (MinIO 등)
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID", "")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "")
S3_ENDPOINT_URL = os.getenv("S3_ENDPOINT_URL", "")
S3_REGION_NAME = os.getenv("S3_REGION_NAME", "us-east-1")
BUCKET_NAME = os.getenv("BUCKET_NAME", "fdc-portal")
BASE_S3_PATH = os.getenv("BASE_S3_PATH", "s3://fdc-portal/FDC/plan-a")

# 자동 백업 스케줄 (KST 기준)
BACKUP_HOUR = int(os.getenv("BACKUP_HOUR", "3"))
BACKUP_MINUTE = int(os.getenv("BACKUP_MINUTE", "0"))

# ===== 시스템 이벤트 로그 보관 기간 =====
# 이 일수보다 오래된 system_event_logs 는 백업 스케줄러에서 하루 1회 정리한다.
try:
    SYSTEM_EVENT_LOG_RETENTION_DAYS = max(0, int(os.getenv("SYSTEM_EVENT_LOG_RETENTION_DAYS", "30")))
except (TypeError, ValueError):
    SYSTEM_EVENT_LOG_RETENTION_DAYS = 30

# ===== Knox Messenger (선택적 외부 연동) =====
def _bool_env(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _int_env(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default


# ===== 공간 생성 제한 / 빈 공간 정리 정책 =====
# 사용자가 "직접 생성/소유"한 active 공간 기준 (초대받은 공간/보관 공간 제외).
MAX_ACTIVE_SPACES_PER_USER = _int_env("MAX_ACTIVE_SPACES_PER_USER", 10)
MAX_ACTIVE_SPACES_PER_ADMIN = _int_env("MAX_ACTIVE_SPACES_PER_ADMIN", 20)
# 하루 공간 생성 스팸 방지 (일반 사용자 대상)
MAX_SPACE_CREATE_PER_DAY = _int_env("MAX_SPACE_CREATE_PER_DAY", 3)
# 빈 공간 lifecycle (일 단위)
SPACE_EMPTY_WARNING_DAYS = _int_env("SPACE_EMPTY_WARNING_DAYS", 7)
SPACE_EMPTY_AUTO_ARCHIVE_DAYS = _int_env("SPACE_EMPTY_AUTO_ARCHIVE_DAYS", 14)
SPACE_EMPTY_DELETE_AFTER_DAYS = _int_env("SPACE_EMPTY_DELETE_AFTER_DAYS", 30)
# 자동 hard-delete 는 기본 비활성 (관리자 수동 삭제만 허용). 운영 검증 후에만 켠다.
SPACE_EMPTY_AUTO_DELETE_ENABLED = _bool_env("SPACE_EMPTY_AUTO_DELETE_ENABLED", False)

# ===== Realtime sync (SSE event outbox) =====
# 같은 공간 사용자 간 Project/Task/Calendar/VOC 변경을 2~5초 내 자동 반영.
# 부하가 생기면 REALTIME_SYNC_ENABLED=false 로 끄거나 POLL_INTERVAL 을 늘린다.
REALTIME_SYNC_ENABLED = _bool_env("REALTIME_SYNC_ENABLED", True)
REALTIME_POLL_INTERVAL_SECONDS = max(1, _int_env("REALTIME_POLL_INTERVAL_SECONDS", 3))
REALTIME_HEARTBEAT_SECONDS = max(5, _int_env("REALTIME_HEARTBEAT_SECONDS", 25))
REALTIME_MAX_EVENTS_PER_POLL = max(1, _int_env("REALTIME_MAX_EVENTS_PER_POLL", 100))
REALTIME_MAX_CLIENTS_PER_WORKER = max(1, _int_env("REALTIME_MAX_CLIENTS_PER_WORKER", 300))
# realtime_events 보관 기간(일). 이보다 오래된 이벤트 로그는 매일 1회 정리한다(운영 데이터 아님).
REALTIME_EVENT_RETENTION_DAYS = max(1, _int_env("REALTIME_EVENT_RETENTION_DAYS", 3))
REALTIME_EVENT_CLEANUP_ENABLED = _bool_env("REALTIME_EVENT_CLEANUP_ENABLED", True)
# EventSource 인증용 단발성 ticket TTL(초). 세션 토큰을 URL 에 노출하지 않기 위함.
REALTIME_TICKET_TTL_SECONDS = max(10, _int_env("REALTIME_TICKET_TTL_SECONDS", 30))

# ===== 멘션 메일 알림 (notification_events outbox → mail_sender) =====
# 실제 발송 여부는 MAIL_PROVIDER 로 결정. 운영 실수 방지를 위해 기본값은 disabled.
#   disabled(기본): 발송 없음(event=skipped)  |  mock: 발송 없이 성공 처리(검증용)
#   smtp: SMTP_* 가 모두 있을 때만 실제 발송
#   knox_api: 사내 Knox Mail API(/mail/api/v2.0/mails/send?userId=…) 로 실제 발송.
#             KNOX_MAIL_API_BASE_URL/USER_ID/SENDER_EMAIL 이 모두 있을 때만 호출.
# ⚠️ 값 자체는 mail_sender / notification_processor 가 os.getenv 로 '호출 시점'에 읽는다.
#    여기서는 문서화 + 프론트 딥링크 base url 노출용으로만 정리한다.
MAIL_PROVIDER = (os.getenv("MAIL_PROVIDER") or "disabled").strip().lower()
FRONTEND_BASE_URL = (
    os.getenv("FRONTEND_BASE_URL")
    or FRONTEND_REDIRECT_URI
).rstrip("/")
NOTIFICATION_PROCESSOR_ENABLED = _bool_env("NOTIFICATION_PROCESSOR_ENABLED", True)
NOTIFICATION_PROCESSOR_INTERVAL_SECONDS = max(10, _int_env("NOTIFICATION_PROCESSOR_INTERVAL_SECONDS", 60))
# 자기 자신 멘션도 알림 이벤트 생성/발송할지. 기본 False(운영 정책). Knox Mail 연동 테스트용 true.
# 실제 판정은 app.services.notifications.allow_self_mention() 이 env 를 호출 시점에 읽어서 한다(이 상수는 문서/기본값용).
NOTIFICATION_ALLOW_SELF_MENTION = _bool_env("NOTIFICATION_ALLOW_SELF_MENTION", False)

# ===== Knox Gateway 공통 (임직원 정보 API + Mail API 공유) =====
# 같은 Knox Gateway / 같은 연계계정(KNOX_SYSTEM_ID) / 같은 토큰(KNOX_AUTH_TOKEN) 을 쓰고 endpoint path 만 다르다.
#   KNOX_API_URL           공통 Gateway base URL   (예: https://knox-gw.company.com)
#   KNOX_SYSTEM_ID         연계계정 loginid/userId (예: KCC~~) — 실제 메일주소 아님(혼동 금지)
#   KNOX_AUTH_TOKEN        Bearer 토큰
#   KNOX_EMPLOYEE_API_PATH 임직원 API path → {KNOX_API_URL}{path}. 없으면 KNOX_API_URL 을 full endpoint 로(하위호환).
#   KNOX_MAIL_API_PATH     메일 API path   → {KNOX_API_URL}{path}?userId={KNOX_SYSTEM_ID}
# ⚠️ 값은 knox_client / mail_sender 가 os.getenv 로 '호출 시점'에 읽는다. 아래 상수는 문서/진단용.
KNOX_EMPLOYEE_API_PATH = (os.getenv("KNOX_EMPLOYEE_API_PATH") or "").strip()

# Knox Mail API (MAIL_PROVIDER=knox_api). base url/token/sender/userId 는 코드에 하드코딩 금지 — env 전용.
# mail 전용 env 가 없으면 위 Knox 공통 env 를 fallback 재사용(base=KNOX_API_URL, userId=KNOX_SYSTEM_ID,
# token=KNOX_AUTH_TOKEN). 인증 헤더도 knox_client(임직원 API)와 동일(Bearer + System-ID).
KNOX_MAIL_API_BASE_URL = (os.getenv("KNOX_MAIL_API_BASE_URL") or os.getenv("KNOX_API_URL") or "").strip().rstrip("/")
KNOX_MAIL_API_PATH = (os.getenv("KNOX_MAIL_API_PATH") or "/mail/api/v2.0/mails/send").strip()
KNOX_MAIL_USER_ID = (os.getenv("KNOX_MAIL_USER_ID") or os.getenv("KNOX_SYSTEM_ID") or "").strip()
KNOX_MAIL_SENDER_EMAIL = (os.getenv("KNOX_MAIL_SENDER_EMAIL") or "").strip()
KNOX_MAIL_CONTENT_TYPE = (os.getenv("KNOX_MAIL_CONTENT_TYPE") or "TEXT").strip().upper()
KNOX_MAIL_DOC_SECU_TYPE = (os.getenv("KNOX_MAIL_DOC_SECU_TYPE") or "PERSONAL").strip().upper()
KNOX_MAIL_TIMEOUT_SECONDS = max(1, _int_env("KNOX_MAIL_TIMEOUT_SECONDS", 10))

KNOX_MESSENGER_ENABLED = _bool_env("KNOX_MESSENGER_ENABLED", False)
KNOX_MESSENGER_API_BASE_URL = (os.getenv("KNOX_MESSENGER_API_BASE_URL") or "").strip()
KNOX_MESSENGER_API_TOKEN = (os.getenv("KNOX_MESSENGER_API_TOKEN") or "").strip()
try:
    KNOX_MESSENGER_TIMEOUT_SECONDS = float(os.getenv("KNOX_MESSENGER_TIMEOUT_SECONDS") or 5)
except ValueError:
    KNOX_MESSENGER_TIMEOUT_SECONDS = 5.0
KNOX_MESSENGER_VERIFY_SSL = _bool_env("KNOX_MESSENGER_VERIFY_SSL", True)
KNOX_MESSENGER_DRY_RUN = _bool_env("KNOX_MESSENGER_DRY_RUN", False)
