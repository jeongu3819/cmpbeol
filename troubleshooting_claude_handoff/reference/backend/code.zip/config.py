import os
from urllib.parse import urlparse

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

ENV_MODE = os.getenv("ENV_MODE", "development").lower()

# ⚠️ env_file 은 반드시 절대경로로 고정한다.
#   pydantic BaseSettings 의 상대 env_file 은 "실행 CWD" 기준이라, uvicorn 을 backend/ 가
#   아닌 다른 위치(repo 루트 등)에서 실행하면 .env.local 을 못 찾아 OPENAI_API_KEY 등이
#   "미설정"으로 잡히는 footgun 이 있었다. app/environment.py 와 동일하게 이 파일이 있는
#   app/ 디렉터리 기준으로 해석해 CWD 에 의존하지 않게 한다.
_APP_DIR = os.path.dirname(os.path.abspath(__file__))          # backend/app
_BACKEND_DIR = os.path.dirname(_APP_DIR)                         # backend


def _env_file_candidates() -> list[str]:
    if ENV_MODE in ("production", "prod"):
        names = [".env.production", ".env"]
    else:
        names = [".env.local", ".env"]
    # 여러 위치를 모두 뒤진다: app/(environment.py 기준) → backend/ → 실행 CWD.
    # 어디에 두더라도 찾히도록 하고, 존재하는 파일을 우선순위 낮은→높은 순으로 pydantic 에
    # 넘긴다(뒤 파일이 앞 파일을 override). CWD 의존 footgun 을 제거한다.
    base_dirs = [os.getcwd(), _BACKEND_DIR, _APP_DIR]
    found: list[str] = []
    for base in base_dirs:
        for name in names:
            p = os.path.abspath(os.path.join(base, name))
            if os.path.isfile(p) and p not in found:
                found.append(p)
    return found


_ENV_FILE_CANDIDATES = _env_file_candidates()
# pydantic 에 넘길 값(존재하는 파일 목록). 없으면 app/ 기준 기본 경로 하나(진단 표시용).
ENV_FILE = _ENV_FILE_CANDIDATES or [
    os.path.join(_APP_DIR, ".env.production" if ENV_MODE in ("production", "prod") else ".env.local")
]
# 진단용: AI Settings 상태 조회에서 "실제로 어떤 env 파일을 읽었는지" 노출할 때 사용.
ENV_FILE_DISPLAY = ", ".join(ENV_FILE)
ENV_FILE_EXISTS = bool(_ENV_FILE_CANDIDATES)


class Settings(BaseSettings):
    env_mode: str = Field(default=ENV_MODE, alias="ENV_MODE")

    # 사내 DSLLM 접속정보 (기존 변수명 유지 — backward compatible)
    api_key: str = Field(default="", alias="API_KEY")
    base_url: str = Field(default="", alias="BASE_URL")

    # DSLLM 전용 변수(우선) — 없으면 기존 BASE_URL/API_KEY 로 fallback.
    # OpenAI 변수(OPENAI_*)와 절대 섞이지 않게 분리한다.
    dsllm_base_url: str = Field(default="", alias="DSLLM_BASE_URL")
    dsllm_api_key: str = Field(default="", alias="DSLLM_API_KEY")

    model_1: str = Field(default="GPT-OSS", alias="LLM_MODEL_1")
    model_2: str = Field(default="GaussO3.2", alias="LLM_MODEL_2")
    model_3: str = Field(default="GaussO4.1", alias="LLM_MODEL_3")
    model_4: str = Field(default="Gemma4", alias="LLM_MODEL_4")

    # ── AI Provider 선택 (dsllm: 사내 모델 / openai: 외부 API 테스트) ──
    # 기본값은 항상 dsllm. 운영/사내 환경에서는 OpenAI key가 없으므로 자연히 비활성.
    ai_provider: str = Field(default="dsllm", alias="AI_PROVIDER")

    # OpenAI 외부 API 테스트용 (회사 밖 비식별 테스트 전용). API_KEY는 env에서만 관리.
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")
    openai_base_url: str = Field(default="https://api.openai.com/v1", alias="OPENAI_BASE_URL")
    openai_model: str = Field(default="gpt-4.1-mini", alias="OPENAI_MODEL")
    # 쉼표구분 모델 목록(확장용). 비우면 OPENAI_MODEL 하나만 노출.
    openai_models: str = Field(default="", alias="OPENAI_MODELS")
    # super_admin Vision Report Test(이미지 포함 PoC)용 모델 목록(쉼표구분).
    # 우선순위: OPENAI_VISION_MODELS → OPENAI_MODELS → 기본값(gpt-5.4-mini,gpt-5.4).
    openai_vision_models: str = Field(default="", alias="OPENAI_VISION_MODELS")
    # Vision Report Test 기본 선택 모델. 우선순위: OPENAI_VISION_MODEL → OPENAI_MODEL → 목록 첫 번째.
    openai_vision_model: str = Field(default="", alias="OPENAI_VISION_MODEL")
    # Vision Report Test 응답 max_output_tokens. 한 번에 이미지 해석+보고서를 모두 생성하므로
    # 출력이 길다 → truncation 방지를 위해 기본 8000. env 로 조정 가능.
    vision_report_max_output_tokens: int = Field(
        default=8000, alias="VISION_REPORT_MAX_OUTPUT_TOKENS"
    )
    # Vision Report Test 2단계 중 Stage1(이미지 evidence 추출) 배치당 이미지 수.
    # 한 번에 너무 많은 이미지를 넣으면 출력이 길어져 truncation 위험 → 기본 5.
    vision_report_stage1_batch_size: int = Field(
        default=5, alias="VISION_REPORT_STAGE1_BATCH_SIZE"
    )

    # ── Vision AI 전용 설정 (Text AI와 완전 분리) ──
    # 이미지 포함 AI Report(Vision Report)는 vision 지원 모델이 필요하므로 Text AI 설정과
    # 절대 값을 공유하지 않는다. DB(vision_ai_settings)에 저장값이 없을 때의 env 기본값.
    # 후보/기본 모델 우선순위:
    #   목록: VISION_AI_MODELS → OPENAI_VISION_MODELS → (fallback) OPENAI_MODELS → 기본값
    #   기본: DB → VISION_AI_MODEL → OPENAI_VISION_MODEL → 목록 첫 번째 → (fallback) OPENAI_MODEL
    vision_ai_provider: str = Field(default="openai", alias="VISION_AI_PROVIDER")
    vision_ai_model: str = Field(default="", alias="VISION_AI_MODEL")
    vision_ai_models: str = Field(default="", alias="VISION_AI_MODELS")
    vision_ai_enabled: bool = Field(default=True, alias="VISION_AI_ENABLED")
    vision_ai_max_output_tokens: int = Field(
        default=8000, alias="VISION_AI_MAX_OUTPUT_TOKENS"
    )
    vision_ai_batch_size: int = Field(default=6, alias="VISION_AI_BATCH_SIZE")
    vision_ai_timeout_seconds: int = Field(default=120, alias="VISION_AI_TIMEOUT_SECONDS")
    # ── Vision Report 지연 시 텍스트 전용 fallback (Gemma4 느림/실패 → 사용자 선택) ──
    # soft timeout: 이 시간(초)을 넘으면 FE가 "계속 기다리기/텍스트 전용 생성/취소" modal 표시.
    # hard timeout(vision_ai_timeout_seconds): Gemma4 vision 요청 자체의 실패 처리 기준.
    # fallback 은 **일회성 실행 옵션** — 선택해도 Vision/Text AI 설정 저장값을 바꾸지 않는다.
    vision_ai_soft_timeout_seconds: int = Field(default=60, alias="VISION_AI_SOFT_TIMEOUT_SECONDS")
    vision_ai_fallback_text_enabled: bool = Field(default=True, alias="VISION_AI_FALLBACK_TEXT_ENABLED")
    vision_ai_fallback_text_provider: str = Field(default="dsllm", alias="VISION_AI_FALLBACK_TEXT_PROVIDER")
    vision_ai_fallback_text_model: str = Field(default="", alias="VISION_AI_FALLBACK_TEXT_MODEL")
    # 정책: ask_user_on_timeout(기본, 자동전환 금지) — 자동 전환은 지원하지 않는다.
    vision_ai_fallback_policy: str = Field(default="ask_user_on_timeout", alias="VISION_AI_FALLBACK_POLICY")
    # OpenAI provider 명시적 활성화 스위치. key가 설정되면 자동으로도 활성화된다.
    enable_openai_provider: bool = Field(default=False, alias="ENABLE_OPENAI_PROVIDER")

    # ── 이미지 관찰 캐시(2b) — 기능 플래그로 단계 제어 ──
    # ENABLED: 전체 기능 on/off. SHADOW_MODE: 기존 결과를 쓰면서 신규 구조에도 저장(읽지 않음).
    # CACHE_READ_ENABLED: cache hit 시 Vision 호출 생략(2b-2). false면 기존 경로와 완전히 동일.
    vision_image_observation_enabled: bool = Field(default=True, alias="VISION_IMAGE_OBSERVATION_ENABLED")
    vision_image_observation_shadow_mode: bool = Field(default=True, alias="VISION_IMAGE_OBSERVATION_SHADOW_MODE")
    vision_image_observation_cache_read_enabled: bool = Field(
        default=False, alias="VISION_IMAGE_OBSERVATION_CACHE_READ_ENABLED"
    )
    vision_image_context_link_enabled: bool = Field(default=True, alias="VISION_IMAGE_CONTEXT_LINK_ENABLED")
    # rollout mode: off(전체 비활성) / canary(지정 project만) / all(전체). 미설정·잘못된 값 → off(안전).
    vision_image_cache_rollout_mode: str = Field(default="off", alias="VISION_IMAGE_CACHE_ROLLOUT_MODE")
    # canary: rollout_mode=canary 일 때 활성화할 project_id(콤마구분).
    vision_image_cache_canary_project_ids: str = Field(default="", alias="VISION_IMAGE_CACHE_CANARY_PROJECT_IDS")
    # 2b-2b: stale ContextLink 를 원본 이미지 없이 Text 모델 batch 로 재생성. 기본 off(=2b-2a Vision fallback 유지).
    vision_image_context_link_regen_enabled: bool = Field(
        default=False, alias="VISION_IMAGE_CONTEXT_LINK_REGEN_ENABLED"
    )
    vision_image_context_link_regen_batch_size: int = Field(
        default=12, alias="VISION_IMAGE_CONTEXT_LINK_REGEN_BATCH_SIZE"
    )

    # KNOX 사내검색 (knox_client는 os.getenv로 직접 읽지만, 기동 로그/디버그 용도로 노출)
    knox_api_url: str = Field(default="", alias="KNOX_API_URL")
    knox_auth_token: str = Field(default="", alias="KNOX_AUTH_TOKEN")
    knox_system_id: str = Field(default="", alias="KNOX_SYSTEM_ID")

    # DSLLM 게이트웨이 프록시 우회 대상(쉼표구분). 비우면 BASE_URL 호스트만 자동 우회.
    dsllm_no_proxy: str = Field(default="", alias="DSLLM_NO_PROXY")

    model_config = SettingsConfigDict(
        env_file=ENV_FILE,
        populate_by_name=True,
        protected_namespaces=(),
        extra="ignore",
    )

    # ── DSLLM 실효 접속정보 (DSLLM_* 우선 → 기존 BASE_URL/API_KEY fallback) ──
    @property
    def dsllm_effective_base_url(self) -> str:
        return (self.dsllm_base_url or self.base_url or "").strip()

    @property
    def dsllm_effective_api_key(self) -> str:
        return (self.dsllm_api_key or self.api_key or "").strip()


settings = Settings()


def env_first(name: str, settings_value: str = "") -> str:
    """런타임 os.environ(실측값) 우선, 없으면 Settings 스냅샷 값으로 fallback.

    environment.py 가 load_dotenv(override=True) 로 os.environ 를 채우므로,
    pydantic Settings 스냅샷 타이밍/파싱 차이와 무관하게 항상 "실제로 설정된 값"을 본다.
    (AI Settings 의 'OPENAI_API_KEY 감지=확인됨' 인데 'api_key=미설정' 으로 갈리던 모순 방지.)
    """
    v = os.environ.get(name)
    if v is not None and v.strip():
        return v.strip()
    return (settings_value or "").strip()


def _configure_dsllm_no_proxy() -> None:
    """
    DSLLM 게이트웨이(사내망)만 프록시를 우회하도록 no_proxy 범위를 좁힌다.

    기존에는 no_proxy="*" 를 전역 강제했는데, 이는 trust_env=True 를 쓰는
    모든 클라이언트(SSO requests, boto3 등)의 프록시 경로까지 바꿔버리는 footgun이다.
    (KNOX 클라이언트는 trust_env=False 라 애초에 영향을 받지 않는다.)

    여기서는 DSLLM_NO_PROXY 가 있으면 그 값을, 없으면 BASE_URL 호스트만 no_proxy에 추가한다.
    기존 no_proxy 값은 보존하되 위험한 "*" 항목만 제거한다.
    """
    explicit = (settings.dsllm_no_proxy or "").strip()
    if explicit:
        hosts = [h.strip() for h in explicit.split(",") if h.strip()]
    else:
        host = urlparse(settings.dsllm_effective_base_url or "").hostname
        hosts = [host] if host else []

    if not hosts:
        # 우회 대상이 없으면 전역 프록시 설정을 건드리지 않는다.
        return

    existing = os.getenv("no_proxy") or os.getenv("NO_PROXY") or ""
    merged: list[str] = []
    for part in existing.split(","):
        p = part.strip()
        if p and p != "*" and p not in merged:
            merged.append(p)
    for h in hosts:
        if h not in merged:
            merged.append(h)

    value = ",".join(merged)
    os.environ["no_proxy"] = value
    os.environ["NO_PROXY"] = value


_configure_dsllm_no_proxy()
