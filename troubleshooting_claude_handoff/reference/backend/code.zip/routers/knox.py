# app/routers/knox.py
import logging
import re
from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from app.services.knox_client import knox_search_employees, KnoxError, log_knox_env_state

logger = logging.getLogger("uvicorn.error")
router = APIRouter(prefix="/api", tags=["KNOX"])

# 모듈 import(라우터 등록) 시점에 1회 KNOX env/프록시 상태 로깅.
log_knox_env_state()

# 프론트에 노출할 사용자 친화적 메시지 (raw 에러 대신)
_FRIENDLY_KNOX_MESSAGE = {
    "ConnectTimeout": "Knox 검색 서버에 연결하지 못했습니다. 잠시 후 다시 시도하거나 관리자에게 문의하세요.",
    "ConnectError": "Knox 검색 서버에 연결하지 못했습니다. 잠시 후 다시 시도하거나 관리자에게 문의하세요.",
    "RequestError": "Knox 검색 서버에 연결하지 못했습니다. 잠시 후 다시 시도하거나 관리자에게 문의하세요.",
    "ReadTimeout": "Knox 응답이 지연되고 있습니다. 잠시 후 다시 시도해 주세요.",
    "Unauthorized": "Knox 인증에 실패했습니다. 관리자에게 문의하세요.",
    "NotFound": "Knox 검색 경로를 찾을 수 없습니다. 관리자에게 문의하세요.",
    "ConfigMissing": "Knox 검색 설정이 누락되었습니다. 관리자에게 문의하세요.",
}

@router.get("/employees")
async def get_employees(
    fullName: Optional[str] = Query(default=None),
    userIds: Optional[str] = Query(default=None),
    query: Optional[str] = Query(default=None),
    companyCode: str = Query(default="C10"),
):
    if not fullName and not userIds and not query:
        raise HTTPException(status_code=400, detail="fullName, userIds, 또는 query 중 하나는 입력해야 합니다.")

    try:
        if query:
            q = query.strip()
            # ID 패턴: 공백 없고 영숫자 위주 (한글 없음)
            is_id_like = bool(re.match(r'^[a-zA-Z0-9._\-]+$', q))

            if is_id_like:
                # ID로 먼저 시도
                employees = await knox_search_employees(userIds=q, companyCode=companyCode)
                if not employees:
                    # fallback: 이름 검색
                    employees = await knox_search_employees(fullName=q, companyCode=companyCode)
            else:
                # 이름으로 먼저 시도
                employees = await knox_search_employees(fullName=q, companyCode=companyCode)
                if not employees:
                    # fallback: ID 검색
                    employees = await knox_search_employees(userIds=q, companyCode=companyCode)

            # userId 기준 dedupe
            seen = set()
            deduped = []
            for e in employees:
                uid = e.get("userId")
                if uid not in seen:
                    seen.add(uid)
                    deduped.append(e)
            employees = deduped
        else:
            employees = await knox_search_employees(fullName=fullName, userIds=userIds, companyCode=companyCode)

        return {"result": "ok", "employees": employees}

    except KnoxError as e:
        # 서버 로그에는 원인(error_type) + 원문, 프론트에는 친화적 메시지만.
        logger.warning("KNOX error [%s]: %s", e.error_type, str(e))
        detail = _FRIENDLY_KNOX_MESSAGE.get(
            e.error_type, "Knox 검색 중 오류가 발생했습니다. 관리자에게 문의하세요."
        )
        raise HTTPException(status_code=502, detail=detail)

    except RuntimeError as e:
        logger.warning("KNOX runtime error: %s", str(e))
        raise HTTPException(status_code=502, detail=str(e))

    except Exception as e:
        logger.exception("Unknown /employees error")
        raise HTTPException(status_code=500, detail="Unknown server error")
