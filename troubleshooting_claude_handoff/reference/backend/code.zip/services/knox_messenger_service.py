# app/services/knox_messenger_service.py
"""
Knox Messenger 연동 서비스 (선택적 외부 연동).

- 멘션 발생 시 Knox Messenger API로 알림 메시지를 전송한다.
- 외부 의존성 실패가 본 서비스(노트/Activity 저장)에 영향을 주지 않도록
  모든 예외는 내부에서 흡수하여 로깅만 남긴다.
- 환경 변수 KNOX_MESSENGER_ENABLED=false 인 경우 즉시 no-op.
- KNOX_MESSENGER_DRY_RUN=true 인 경우 실제 전송 대신 payload를 로깅한다.

호출자는 fastapi.BackgroundTasks 로 fire-and-forget 형태로 사용한다.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable, Optional

import httpx

from app import environment as env

logger = logging.getLogger(__name__)


def _resolve_receiver(user: Any) -> Optional[str]:
    """
    Knox Messenger 수신자 식별자를 결정한다.
    fallback chain: knox_id (있으면) → loginid → mail → username.
    None/빈 문자열은 건너뛴다.
    """
    if user is None:
        return None
    # 미래 확장 필드 (현재 User 모델에는 없음)
    knox_id = getattr(user, "knox_id", None)
    candidates = [knox_id, getattr(user, "loginid", None), getattr(user, "mail", None), getattr(user, "username", None)]
    for c in candidates:
        if c is None:
            continue
        s = str(c).strip()
        if s:
            return s
    return None


def _build_payload(
    *,
    receiver: str,
    message: str,
    link: Optional[str],
    source: str,
    msg_type: str,
    metadata: Optional[dict[str, Any]],
) -> dict[str, Any]:
    """
    Knox Messenger API 전송용 payload (placeholder).
    실제 스펙이 확정되면 본 함수만 수정하면 된다.
    """
    payload: dict[str, Any] = {
        "receiver": receiver,
        "message": message,
        "source": source,
        "type": msg_type,
    }
    if link:
        payload["link"] = link
    if metadata:
        payload["metadata"] = metadata
    return payload


def send_mention_message(
    *,
    receiver: str,
    message: str,
    link: Optional[str] = None,
    source: str = "plan",
    msg_type: str = "mention",
    metadata: Optional[dict[str, Any]] = None,
) -> bool:
    """
    Knox Messenger로 단일 메시지 전송.
    반환값:
      True  → 전송 성공 / dry-run / 비활성화 (정상 종료)
      False → 전송 시도 후 실패 (로깅됨)
    예외는 발생시키지 않는다.
    """
    if not env.KNOX_MESSENGER_ENABLED:
        return True

    if not receiver or not (receiver or "").strip():
        logger.warning("[knox_messenger] empty receiver, skip")
        return True

    base_url = (env.KNOX_MESSENGER_API_BASE_URL or "").strip()
    if not base_url:
        logger.warning("[knox_messenger] KNOX_MESSENGER_API_BASE_URL not configured, skip")
        return True

    payload = _build_payload(
        receiver=receiver,
        message=message,
        link=link,
        source=source,
        msg_type=msg_type,
        metadata=metadata,
    )

    if env.KNOX_MESSENGER_DRY_RUN:
        logger.info("[knox_messenger][DRY_RUN] would POST %s payload=%s", base_url, payload)
        return True

    headers = {
        "accept": "*/*",
        "Content-Type": "application/json",
    }
    token = (env.KNOX_MESSENGER_API_TOKEN or "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"

    timeout = float(env.KNOX_MESSENGER_TIMEOUT_SECONDS or 5)
    verify = bool(env.KNOX_MESSENGER_VERIFY_SSL)

    try:
        with httpx.Client(trust_env=False, verify=verify, timeout=timeout) as client:
            resp = client.post(base_url, headers=headers, json=payload)
        if resp.status_code >= 400:
            logger.warning(
                "[knox_messenger] send failed status=%s body=%s receiver=%s",
                resp.status_code,
                (resp.text or "")[:300],
                receiver,
            )
            _log_knox_event(f"Knox Messenger 발송 실패 (status={resp.status_code})", status_code=resp.status_code)
            return False
        logger.info("[knox_messenger] sent receiver=%s status=%s", receiver, resp.status_code)
        return True
    except Exception as e:  # noqa: BLE001 — never raise to caller
        logger.warning("[knox_messenger] send exception receiver=%s err=%s", receiver, e)
        _log_knox_event(f"Knox Messenger 발송 예외: {type(e).__name__}", detail=str(e)[:500])
        return False


def _log_knox_event(message: str, *, detail=None, status_code=None):
    """system_event_logs 에 Knox 실패 요약 기록 (수신자/토큰 등 민감정보는 저장하지 않음)."""
    try:
        from app.services.system_log import log_event
        log_event("ERROR", "KNOX", message, detail=detail, status_code=status_code)
    except Exception:
        pass


def send_mention_messages_for_users(
    users: Iterable[Any],
    *,
    message: str,
    link: Optional[str] = None,
    source: str = "plan",
    msg_type: str = "mention",
    metadata: Optional[dict[str, Any]] = None,
    exclude_user_id: Optional[int] = None,
) -> None:
    """
    여러 User ORM 객체에 대해 멘션 알림을 일괄 발송한다.
    BackgroundTasks 에서 호출되므로 예외를 발생시키지 않는다.
    self-mention 제외: exclude_user_id 와 동일한 user.id 는 건너뛴다.
    """
    if not env.KNOX_MESSENGER_ENABLED:
        return
    if not users:
        return
    for u in users:
        try:
            uid = getattr(u, "id", None)
            if exclude_user_id is not None and uid == exclude_user_id:
                continue
            receiver = _resolve_receiver(u)
            if not receiver:
                logger.warning("[knox_messenger] no receiver resolved for user_id=%s, skip", uid)
                continue
            send_mention_message(
                receiver=receiver,
                message=message,
                link=link,
                source=source,
                msg_type=msg_type,
                metadata=metadata,
            )
        except Exception as e:  # noqa: BLE001
            logger.warning("[knox_messenger] per-user dispatch error: %s", e)
