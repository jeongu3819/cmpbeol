"""Project AI Context Builder.

프로젝트 단위 AI 요약을 위한 **컨텍스트 구조화** 모듈.

목적
----
이 모듈은 LLM 을 호출하지 않는다. 프로젝트 내부의 텍스트(Project / Sub Project /
Task / Task 설명 / 작업노트(TaskActivity) / Project Note)와, 그 안에서 참조되는
**프로젝트 내부 이미지**가 서로 어떤 맥락으로 연결돼 있는지를 구조화한다.

- ``text_context`` : 현재 text-only LLM 요약이 사용할 수 있는 텍스트 컨텍스트.
- ``image_manifest`` : 이미지가 어떤 Project/SubProject/Task/작업노트/설명/첨부에
  연결되는지를 표현하는 메타데이터(이미지 **바이트는 포함하지 않는다**).

# Future multimodal path:
# - Current LLM summary uses text_context only.
# - image_manifest is prepared to preserve project/task/note/image relationships.
# - When a stable vision model is available, a separate multimodal adapter should consume:
#   text_context + image_manifest + authorized image files.
# - Do not merge image analysis into the text summary path directly.

VOC 정책
--------
VOC / 개선요청 / 공개 VOC / VOC 댓글 / VOC 첨부 이미지는 **AI 요약 대상에서 제외**한다.
본 모듈은 ``voc_*`` 테이블을 일절 조회하지 않는다. (AI 요약 대상은 프로젝트 단위로 한정)

데이터 출처(실제 코드 기준)
---------------------------
- Project / SubProject / Task / TaskActivity / Note : DB (SQLAlchemy)
- task 첨부(attachments) / project_files / space_images : sidecar ``data.json`` state
  (이 레코드만 stored_name / s3_key / content_type 메타를 보유)
- 인라인 이미지 : Task.description / TaskActivity.content / Note.content 안의
  ``<img src="/api/spaces/{id}/images/{stored}/download">`` (또는 tasks/{id}/files/...) 태그
"""

from __future__ import annotations

import html as _html
import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from app.models import (
    Project,
    SubProject,
    Task,
    TaskActivity,
    Note,
)
from app.services.project_ai_image_readiness import (
    enrich_manifest_item,
    summarize_readiness,
    readiness_counts,
)
from app.services.project_ai_analysis_policy import (
    attach_analysis_metadata,
    summarize_analysis_policy,
    project_context_hash as _project_context_hash,
    PROJECT_AI_CONTEXT_SCHEMA_VERSION as CONTEXT_SCHEMA_VERSION,
    IMAGE_MANIFEST_VERSION,
    IMAGE_READINESS_VERSION as READINESS_VERSION,
    FUTURE_IMAGE_ANALYSIS_PROMPT_VERSION,
)
from app.services.project_ai_evidence import (
    attach_evidence_card,
    EVIDENCE_CARD_VERSION,
)

# nearby_text 는 너무 길지 않게 truncate (민감정보/프롬프트 비대화 방지)
NEARBY_TEXT_MAX = 400
TEXT_CONTEXT_DESC_MAX = 600
DEFAULT_MAX_IMAGES = 30

# 스키마 버전은 project_ai_analysis_policy 가 단일 출처 — 위 import 에서 alias 로 가져온다.
# (CONTEXT_SCHEMA_VERSION / IMAGE_MANIFEST_VERSION / READINESS_VERSION /
#  FUTURE_IMAGE_ANALYSIS_PROMPT_VERSION). 캐시/재분석 조건과 동일 값을 공유한다.

_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg"}
_EXT_MIME = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
    ".svg": "image/svg+xml",
}

# 인라인 이미지 src 에서 (context, stored_name) 추출.
#   /api/spaces/{id}/images/{stored}/download
#   /api/tasks/{id}/files/{stored}/download
_INLINE_SRC_RE = re.compile(
    r"/api/(spaces|tasks)/\d+/(?:images|files)/([^/\"'?]+)/download",
    re.IGNORECASE,
)
_IMG_TAG_RE = re.compile(r"<img\b[^>]*>", re.IGNORECASE)
_IMG_SRC_RE = re.compile(r"src\s*=\s*['\"]([^'\"]+)['\"]", re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]+>")


@dataclass
class ProjectAiContext:
    """build_project_ai_context 반환 구조."""

    project_id: int
    project_name: str
    project_context: Dict[str, Any]
    text_context: str
    image_manifest: List[Dict[str, Any]]
    warnings: List[str]
    counts: Dict[str, int] = field(default_factory=dict)
    # Image Readability / AI-Ready Image Layer 요약 (image_manifest 전체의 AI 입력 준비도)
    image_readiness_summary: Dict[str, Any] = field(default_factory=dict)
    # 이미지 분석 결과 재사용 정책 요약 (메타 캐시 가능 / 의미 분석 정답 캐시 금지)
    analysis_policy_summary: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "project_context": self.project_context,
            "text_context": self.text_context,
            "image_manifest": self.image_manifest,
            "warnings": self.warnings,
            "counts": self.counts,
            "image_readiness_summary": self.image_readiness_summary,
            "analysis_policy_summary": self.analysis_policy_summary,
        }


# =========================================================
# Text helpers
# =========================================================

def _strip_html(value: Optional[str]) -> str:
    """HTML / TipTap / Markdown 혼합 텍스트에서 표시 텍스트만 추출."""
    if not value:
        return ""
    text = _IMG_TAG_RE.sub(" ", value)         # 이미지 태그는 통째로 제거
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</(p|div|li|h[1-6])>", "\n", text, flags=re.IGNORECASE)
    text = _TAG_RE.sub(" ", text)              # 나머지 태그 제거
    text = _html.unescape(text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _truncate(text: str, limit: int) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return text[:limit].rstrip() + "…"


def _fallback_context_text(*candidates) -> str:
    """nearby_text 가 비었을 때 쓸 대체 맥락 텍스트(우선순위 첫 비-공백 값)."""
    for c in candidates:
        if c and str(c).strip():
            return str(c).strip()
    return ""


def _content_type_for(filename: str, stored_name: str, explicit: Optional[str]) -> Optional[str]:
    if explicit and explicit.startswith("image/"):
        return explicit
    ext = os.path.splitext(stored_name or filename or "")[1].lower()
    return _EXT_MIME.get(ext)


def _is_image_record(rec: Dict[str, Any]) -> bool:
    ct = (rec.get("content_type") or "").lower()
    if ct.startswith("image/"):
        return True
    name = rec.get("stored_name") or rec.get("filename") or ""
    return os.path.splitext(name)[1].lower() in _IMAGE_EXTS


# =========================================================
# Sidecar lookup (stored_name → 저장 메타)
# =========================================================

def _index_sidecar(state: Optional[Dict[str, Any]]):
    """stored_name → record 인덱스. 인라인 이미지 src 를 저장 메타로 해석하기 위함."""
    by_stored: Dict[str, Dict[str, Any]] = {}
    if not state:
        return by_stored
    for key in ("space_images", "attachments", "project_files"):
        for rec in state.get(key, []) or []:
            sn = rec.get("stored_name")
            if sn and sn not in by_stored:
                by_stored[sn] = rec
    return by_stored


def _storage_ref(*, attachment_id=None, stored_name=None, s3_key=None) -> Dict[str, Any]:
    # 보안: local_path 등 서버 경로/raw URL 은 노출하지 않는다(백엔드 내부 식별자 중심).
    return {
        "attachment_id": attachment_id,
        "stored_name": stored_name,
        "s3_key": s3_key or None,
        "local_path": None,
    }


# =========================================================
# Inline image extraction
# =========================================================

def _extract_inline_images(
    html_content: Optional[str],
    *,
    sidecar_by_stored: Dict[str, Dict[str, Any]],
    base: Dict[str, Any],
    source_entity_type: str,
    source_entity_id: int,
    relation_type: str,
    image_id_prefix: str,
    warnings: List[str],
) -> List[Dict[str, Any]]:
    """HTML 본문에서 <img> 를 찾아 manifest item 리스트로 변환."""
    if not html_content:
        return []

    # 같은 source entity(동일 TaskActivity / Task 설명 / Project Note) 본문에서 이미지 태그를
    # 제거하고 남은 텍스트. nearby_text 가 비었을 때의 fallback "2순위"로만 사용한다.
    # (다른 작업노트(sibling TaskActivity) 텍스트는 절대 끌어오지 않는다.)
    own_content_text = _truncate(_strip_html(html_content), NEARBY_TEXT_MAX)

    items: List[Dict[str, Any]] = []
    order = 0
    for m in _IMG_TAG_RE.finditer(html_content):
        tag = m.group(0)
        src_m = _IMG_SRC_RE.search(tag)
        if not src_m:
            continue
        src = src_m.group(1)

        # base64 data URI 는 구조화 대상에서 제외(바이트 인라인 — 우리 정책상 미사용)
        if src.strip().lower().startswith("data:"):
            warnings.append(
                f"{source_entity_type}:{source_entity_id} 의 인라인 이미지가 data URI 라 "
                f"저장 메타를 식별할 수 없어 image_manifest 에서 제외됨"
            )
            continue

        ref_m = _INLINE_SRC_RE.search(src)
        stored_name = ref_m.group(2) if ref_m else None
        rec = sidecar_by_stored.get(stored_name) if stored_name else None

        # 앞/뒤 주변 텍스트 (truncate)
        before = _truncate(_strip_html(html_content[: m.start()])[-NEARBY_TEXT_MAX:], NEARBY_TEXT_MAX)
        after = _truncate(_strip_html(html_content[m.end():])[:NEARBY_TEXT_MAX], NEARBY_TEXT_MAX)
        nearby = _truncate((before + " " + after).strip(), NEARBY_TEXT_MAX)

        if rec:
            filename = rec.get("filename") or stored_name
            content_type = _content_type_for(filename, stored_name, rec.get("content_type"))
            file_size = rec.get("size") or rec.get("size_bytes")
            s3_key = rec.get("s3_key")
            created_by = rec.get("uploader_id") or rec.get("uploaded_by")
            created_at = rec.get("created_at")
            content_hash = rec.get("sha256")
            img_format = rec.get("format")
            notes_list: List[str] = []
        else:
            filename = os.path.basename(src.split("?")[0]) or (stored_name or "inline-image")
            content_type = _content_type_for(filename, stored_name or filename, None)
            file_size = None
            s3_key = None
            created_by = None
            created_at = None
            content_hash = None
            img_format = None
            notes_list = ["저장 메타(sidecar)에서 일치하는 stored_name 을 찾지 못함 — URL 기반 추정"]

        item = dict(base)
        item.update({
            "image_id": f"{image_id_prefix}:image:{order}",
            "source_entity_type": source_entity_type,
            "source_entity_id": source_entity_id,
            "relation_type": relation_type,
            "nearby_text": nearby,
            "nearby_text_before": before,
            "nearby_text_after": after,
            # 같은 entity 본문(이미지 제거 후) — fallback 2순위. 사용 후 manifest 에서 제거.
            "own_content_text": own_content_text,
            "user_caption": None,
            "filename": filename,
            "content_type": content_type,
            "content_hash": content_hash,
            "format": img_format,
            "file_size": file_size,
            "width": (rec or {}).get("width"),
            "height": (rec or {}).get("height"),
            "storage_ref": _storage_ref(stored_name=stored_name, s3_key=s3_key),
            "order_index": order,
            "created_by": created_by,
            "created_at": created_at,
            "ai_eligible": True,
            "sensitivity_level": "internal",
            "notes": notes_list,
        })
        items.append(item)
        order += 1

    return items


# =========================================================
# Main builder
# =========================================================

def build_project_ai_context(
    db: Session,
    project_id: int,
    *,
    state: Optional[Dict[str, Any]] = None,
    include_images: bool = False,
    max_images: int = DEFAULT_MAX_IMAGES,
) -> ProjectAiContext:
    """프로젝트 AI 요약용 컨텍스트를 구조화한다. **LLM 을 호출하지 않는다.**

    Args:
        db: SQLAlchemy 세션.
        project_id: 대상 프로젝트.
        state: sidecar(data.json) state. 이미지(attachments/project_files/space_images)
            메타는 여기에만 존재하므로, 호출자가 ``load_state()`` 결과를 넘겨준다.
            None 이면 인라인 이미지의 저장 메타 식별이 제한되고 warnings 에 기록된다.
        include_images: False(기본)면 image_manifest 를 수집하지 않는다.
            현재 text-only LLM 흐름은 ``text_context`` 만 사용하므로 기본 False.
        max_images: image_manifest 최대 개수.

    Returns:
        ProjectAiContext
    """
    warnings: List[str] = []
    sidecar_by_stored = _index_sidecar(state)
    if state is None and include_images:
        warnings.append("sidecar state 가 전달되지 않아 인라인 이미지 저장 메타 식별이 제한됨")

    try:
        max_images = int(max_images)
    except (TypeError, ValueError):
        max_images = DEFAULT_MAX_IMAGES
    max_images = max(0, min(max_images, 200))

    p = db.query(Project).filter(
        Project.id == project_id,
        Project.archived_at.is_(None),
    ).first()
    if not p:
        # 호출자(엔드포인트)가 이미 존재/권한을 검증하지만, 직접 호출 대비 방어.
        raise ValueError(f"Project not found: {project_id}")

    project_name = p.name or ""

    # ── Sub Projects ──
    sub_rows = db.query(SubProject).filter(SubProject.project_id == project_id).all()
    sub_by_id = {sp.id: sp for sp in sub_rows}
    sub_projects_ctx = [
        {"id": sp.id, "name": sp.name or "", "description": _strip_html(sp.description)}
        for sp in sub_rows
    ]

    # ── Tasks (archived 제외) ──
    task_rows = (
        db.query(Task)
        .filter(Task.project_id == project_id, Task.archived_at.is_(None))
        .order_by(Task.id)
        .all()
    )

    tasks_ctx: List[Dict[str, Any]] = []
    work_notes_ctx: List[Dict[str, Any]] = []
    image_manifest: List[Dict[str, Any]] = []
    work_note_total = 0

    def _can_add_image() -> bool:
        return include_images and len(image_manifest) < max_images

    for t in task_rows:
        sp = sub_by_id.get(t.sub_project_id) if t.sub_project_id else None
        sp_name = sp.name if sp else None
        desc_text = _strip_html(t.description)

        tasks_ctx.append({
            "id": t.id,
            "title": t.title or "",
            "status": t.status,
            "priority": t.priority,
            "progress": getattr(t, "progress", 0) or 0,
            "due_date": t.due_date,
            "sub_project_id": t.sub_project_id,
            "sub_project_name": sp_name,
            "description": _truncate(desc_text, TEXT_CONTEXT_DESC_MAX),
        })

        # task base (manifest 공통 필드)
        task_base = {
            "project_id": project_id,
            "project_name": project_name,
            "sub_project_id": t.sub_project_id,
            "sub_project_name": sp_name,
            "task_id": t.id,
            "task_title": t.title or "",
            "task_status": t.status,
            "task_priority": t.priority,
        }

        # Task DESCRIPTION inline images
        if _can_add_image():
            desc_imgs = _extract_inline_images(
                t.description,
                sidecar_by_stored=sidecar_by_stored,
                base=task_base,
                source_entity_type="task_description",
                source_entity_id=t.id,
                relation_type="inline_image",
                image_id_prefix=f"task_description:{t.id}",
                warnings=warnings,
            )
            for it in desc_imgs:
                if not _can_add_image():
                    break
                image_manifest.append(it)

        # 작업노트 / Task Activity
        activities = (
            db.query(TaskActivity)
            .filter(TaskActivity.task_id == t.id)
            .order_by(TaskActivity.order_index, TaskActivity.id)
            .all()
        )
        for act in activities:
            work_note_total += 1
            block_type = act.block_type or "checkbox"
            note_text = _strip_html(act.content)
            if note_text:
                work_notes_ctx.append({
                    "task_id": t.id,
                    "activity_id": act.id,
                    "block_type": block_type,
                    "checked": bool(act.checked),
                    "text": _truncate(note_text, TEXT_CONTEXT_DESC_MAX),
                })

            if _can_add_image():
                act_imgs = _extract_inline_images(
                    act.content,
                    sidecar_by_stored=sidecar_by_stored,
                    base=task_base,
                    source_entity_type="task_activity",
                    source_entity_id=act.id,
                    relation_type="work_note_evidence",
                    image_id_prefix=f"task_activity:{act.id}",
                    warnings=warnings,
                )
                for it in act_imgs:
                    if not _can_add_image():
                        break
                    image_manifest.append(it)

        # Task 첨부 이미지 (sidecar attachments / type=file)
        if include_images and state is not None:
            task_atts = [
                a for a in state.get("attachments", []) or []
                if int(a.get("task_id") or 0) == t.id
                and (a.get("type") == "file")
                and _is_image_record(a)
            ]
            for a in task_atts:
                if not _can_add_image():
                    break
                filename = a.get("filename") or a.get("stored_name") or "image"
                item = dict(task_base)
                item.update({
                    "image_id": f"task_attachment:{a.get('id')}",
                    # task_file 와 task_attachment 는 동일 저장소(attachments)를 사용한다.
                    "source_entity_type": "task_attachment",
                    "source_entity_id": a.get("id"),
                    "relation_type": "attached_image",
                    "nearby_text": _truncate(desc_text, NEARBY_TEXT_MAX),
                    "nearby_text_before": None,
                    "nearby_text_after": None,
                    "user_caption": None,
                    "filename": filename,
                    "content_type": _content_type_for(filename, a.get("stored_name", ""), a.get("content_type")),
                    "content_hash": a.get("sha256"),
                    "format": a.get("format"),
                    "file_size": a.get("size") or a.get("size_bytes"),
                    "width": a.get("width"),
                    "height": a.get("height"),
                    "storage_ref": _storage_ref(
                        attachment_id=a.get("id"),
                        stored_name=a.get("stored_name"),
                        s3_key=a.get("s3_key"),
                    ),
                    "order_index": 0,
                    "created_by": a.get("uploaded_by") or a.get("uploader_id"),
                    "created_at": a.get("created_at"),
                    "ai_eligible": True,
                    "sensitivity_level": "internal",
                    "notes": [],
                })
                image_manifest.append(item)

    # ── Project Notes (DB) ──
    note_rows = (
        db.query(Note)
        .filter(Note.project_id == project_id)
        .order_by(Note.created_at.desc())
        .all()
    )
    project_notes_ctx = []
    for n in note_rows:
        note_text = _strip_html(n.content)
        if note_text:
            project_notes_ctx.append({
                "id": n.id,
                "author_id": n.author_id,
                "text": _truncate(note_text, TEXT_CONTEXT_DESC_MAX),
            })
        if _can_add_image():
            note_base = {
                "project_id": project_id,
                "project_name": project_name,
                "sub_project_id": None,
                "sub_project_name": None,
                "task_id": None,
                "task_title": None,
                "task_status": None,
                "task_priority": None,
            }
            note_imgs = _extract_inline_images(
                n.content,
                sidecar_by_stored=sidecar_by_stored,
                base=note_base,
                source_entity_type="project_note",
                source_entity_id=n.id,
                relation_type="inline_image",
                image_id_prefix=f"project_note:{n.id}",
                warnings=warnings,
            )
            for it in note_imgs:
                if not _can_add_image():
                    break
                image_manifest.append(it)

    # ── Project Files (sidecar, image content type) ──
    if include_images and state is not None:
        project_files = [
            f for f in state.get("project_files", []) or []
            if int(f.get("project_id") or 0) == project_id and _is_image_record(f)
        ]
        proj_desc_text = _strip_html(p.description)
        for f in project_files:
            if not _can_add_image():
                break
            filename = f.get("filename") or f.get("stored_name") or "image"
            item = {
                "image_id": f"project_file:{f.get('id')}",
                "project_id": project_id,
                "project_name": project_name,
                "sub_project_id": None,
                "sub_project_name": None,
                "task_id": None,
                "task_title": None,
                "task_status": None,
                "task_priority": None,
                "source_entity_type": "project_file",
                "source_entity_id": f.get("id"),
                "relation_type": "project_file_reference",
                "nearby_text": _truncate(proj_desc_text, NEARBY_TEXT_MAX),
                "nearby_text_before": None,
                "nearby_text_after": None,
                "user_caption": None,
                "filename": filename,
                "content_type": _content_type_for(filename, f.get("stored_name", ""), f.get("content_type")),
                "content_hash": f.get("sha256"),
                "format": f.get("format"),
                "file_size": f.get("size") or f.get("size_bytes"),
                "width": f.get("width"),
                "height": f.get("height"),
                "storage_ref": _storage_ref(
                    attachment_id=f.get("id"),
                    stored_name=f.get("stored_name"),
                    s3_key=f.get("s3_key"),
                ),
                "order_index": 0,
                "created_by": f.get("uploader_id") or f.get("uploaded_by"),
                "created_at": f.get("created_at"),
                "ai_eligible": True,
                "sensitivity_level": "internal",
                "notes": [],
            }
            image_manifest.append(item)

    if include_images and state is None:
        warnings.append(
            "task 첨부/project_files 이미지는 sidecar(data.json) state 가 필요하며, "
            "state 미전달로 수집에서 제외됨"
        )

    # max_images cap 도달 시 일부 이미지가 누락됐을 수 있음을 알린다.
    if include_images and max_images > 0 and len(image_manifest) >= max_images:
        warnings.append(
            f"image_manifest 이 max_images({max_images}) 로 제한됨 — 일부 이미지가 누락되었을 수 있음"
        )

    # ── nearby_text 가 빈 이미지의 대체 맥락 텍스트 ──
    # 우선순위(중요): 같은 entity 본문 → Task title → Sub Project name → Project name →
    #               source_entity. **다른 작업노트(sibling TaskActivity) 텍스트는 쓰지 않는다.**
    #   같은 Task 안에도 서로 다른 이미지/작업노트가 섞일 수 있어, sibling 작업노트를
    #   현재 이미지의 설명으로 보면 오분류(예: 무관한 "차트" 키워드 유입)가 발생한다.
    #   → 이미지 자신의 source entity(동일 TaskActivity / Task 설명 / Project Note) 본문만 신뢰.
    # context_text_source: nearby_text / same_entity_text / task_title / sub_project_name /
    #                      project_name / source_entity / none
    for it in image_manifest:
        # own_content_text 는 fallback 계산에만 쓰고 manifest 에는 남기지 않는다.
        own_text = it.pop("own_content_text", None)
        if (it.get("nearby_text") or "").strip():
            it["fallback_context_text"] = ""
            it["context_text_source"] = "nearby_text"
            continue
        # 우선순위대로 첫 비-공백 후보를 고르고, 어떤 출처에서 채웠는지 함께 기록한다.
        candidates = [
            (own_text, "same_entity_text"),
            (it.get("task_title"), "task_title"),
            (it.get("sub_project_name"), "sub_project_name"),
            (project_name, "project_name"),
        ]
        fallback_value = ""
        source = "none"
        for value, src in candidates:
            if value and str(value).strip():
                fallback_value = str(value).strip()
                source = src
                break
        if not fallback_value:
            # 최종 fallback: source_entity_type + source_entity_id
            set_type = it.get("source_entity_type")
            sid = it.get("source_entity_id")
            if set_type is not None:
                fallback_value = f"{set_type}:{sid}" if sid is not None else str(set_type)
                source = "source_entity"
        it["fallback_context_text"] = fallback_value
        it["context_text_source"] = source

    # ── Image Readability / AI-Ready Image Layer 부여 ──
    # 각 이미지에 image_quality + ai_image_variants 메타를 붙이고, 대표 warning 을 수집.
    # (실제 이미지 파일을 열지 않고 수집된 메타만으로 1차 판단)
    readiness_warn_cap = 15
    readiness_warns: List[str] = []
    for it in image_manifest:
        for w in enrich_manifest_item(it):
            readiness_warns.append(w)
    if readiness_warns:
        warnings.extend(readiness_warns[:readiness_warn_cap])
        extra = len(readiness_warns) - readiness_warn_cap
        if extra > 0:
            warnings.append(f"...외 {extra}건의 이미지 가독성 경고 생략(요약은 image_readiness_summary 참조)")

    image_readiness_summary = summarize_readiness(image_manifest)

    # ── 이미지 분석 결과 재사용 정책 / 재분석 식별자 부여 ──
    # 메타는 캐시 가능, 의미 분석은 정답 캐시 금지 → versioned attempt 로 관리.
    proj_ctx_hash = _project_context_hash(project_name, _strip_html(p.description))
    for it in image_manifest:
        attach_analysis_metadata(it, project_ctx_hash=proj_ctx_hash)
    analysis_policy_summary = summarize_analysis_policy(image_manifest)

    # ── Image Evidence Card 부여 ──
    # 낮은 성능 모델도 덜 헷갈리도록 image_role/context_strength/extraction_target/
    # model_instruction_key 를 묶은 카드를 생성(모델/OCR 미호출, 안전 메타만).
    for it in image_manifest:
        attach_evidence_card(it)

    # ── text_context 조립 (현재 text-only LLM 이 사용하는 텍스트) ──
    text_context = _render_text_context(
        project_name=project_name,
        project_description=_strip_html(p.description),
        sub_projects=sub_projects_ctx,
        tasks=tasks_ctx,
        work_notes=work_notes_ctx,
        project_notes=project_notes_ctx,
    )

    project_context = {
        "project": {
            "id": p.id,
            "name": project_name,
            "description": _strip_html(p.description),
            "workflow_mode": getattr(p, "workflow_mode", "DEFAULT") or "DEFAULT",
        },
        "sub_projects": sub_projects_ctx,
        "tasks": tasks_ctx,
        "work_notes": work_notes_ctx,
        "project_notes": project_notes_ctx,
    }

    counts = {
        "sub_projects": len(sub_projects_ctx),
        "tasks": len(tasks_ctx),
        "work_notes": work_note_total,
        "project_notes": len(project_notes_ctx),
        "image_manifest": len(image_manifest),
        # Image Readability 보조 카운트
        **readiness_counts(image_readiness_summary),
    }

    return ProjectAiContext(
        project_id=p.id,
        project_name=project_name,
        project_context=project_context,
        text_context=text_context,
        image_manifest=image_manifest,
        warnings=warnings,
        counts=counts,
        image_readiness_summary=image_readiness_summary,
        analysis_policy_summary=analysis_policy_summary,
    )


def _render_text_context(
    *,
    project_name: str,
    project_description: str,
    sub_projects: List[Dict[str, Any]],
    tasks: List[Dict[str, Any]],
    work_notes: List[Dict[str, Any]],
    project_notes: List[Dict[str, Any]],
) -> str:
    """프로젝트 텍스트 컨텍스트를 사람이 읽을 수 있는 형태로 조립.

    기존 ``/api/report/generate`` 프롬프트를 대체하지 않는다 — 본 모듈의 검증/미래
    멀티모달 어댑터용 컨텍스트 표현이다.
    """
    notes_by_task: Dict[int, List[Dict[str, Any]]] = {}
    for wn in work_notes:
        notes_by_task.setdefault(wn["task_id"], []).append(wn)

    lines: List[str] = []
    lines.append(f"[프로젝트] {project_name}")
    if project_description:
        lines.append(f"설명: {project_description}")

    if sub_projects:
        lines.append("")
        lines.append("[서브프로젝트]")
        for sp in sub_projects:
            desc = f" — {sp['description']}" if sp.get("description") else ""
            lines.append(f"- {sp['name']}{desc}")

    lines.append("")
    lines.append(f"[Task 목록] (총 {len(tasks)}개)")
    for t in tasks:
        sp = f" | 단계: {t['sub_project_name']}" if t.get("sub_project_name") else ""
        lines.append(
            f"- {t['title']} | 상태: {t['status']} | 우선순위: {t['priority']} "
            f"| 진행률: {t['progress']}% | 마감: {t['due_date'] or '미정'}{sp}"
        )
        if t.get("description"):
            lines.append(f"  설명: {t['description']}")
        for wn in notes_by_task.get(t["id"], []):
            mark = "[v]" if wn.get("checked") else "[ ]"
            prefix = mark if wn.get("block_type") == "checkbox" else "·"
            lines.append(f"  작업노트 {prefix} {wn['text']}")

    if project_notes:
        lines.append("")
        lines.append("[프로젝트 노트]")
        for pn in project_notes:
            lines.append(f"- {pn['text']}")

    return "\n".join(lines).strip()
