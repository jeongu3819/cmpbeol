# app/services/notification_service.py
"""
PLAN-AI 알림 이벤트 시스템 (1차 기반 구조).

설계 의도
─────────
* Task/프로젝트 등에서 발생한 이벤트를 받아 "어떤 사용자에게 어떤 채널로 보낼지"를
  결정하고, 채널별 어댑터(`knox_messenger_service` 등)에 위임한다.
* 즉시 실행 가능한 이벤트(task_assigned, mention)는 본 단계에서 함수 시그니처와
  중복 방지/로그 기록 흐름까지 갖춘다.
* 스케줄러 의존 이벤트(due_soon, overdue)는 함수 구조만 만들어 두고 실제 호출
  지점은 TODO 로 남긴다 — 운영 정책(시간/빈도/완료 제외 여부 등)이 확정된 후
  daily cron / APScheduler / Celery 등에서 본 함수만 호출하면 된다.
* 외부 채널 실패가 호출자(API 핸들러)에 영향을 주지 않도록 모든 함수는 예외를
  내부 흡수하고, fastapi.BackgroundTasks 의 fire-and-forget 호출을 가정한다.

확장 포인트
───────────
* 새 채널 추가: `CHANNELS` dict 에 어댑터 함수 등록.
* 새 이벤트 추가: `EventType` 에 상수 + dispatcher 헬퍼 추가.
* 사용자/프로젝트별 ON/OFF 정책은 추후 NotificationPreference 테이블 도입 후
  `_should_send(...)` 에서 분기.
"""

from __future__ import annotations

import logging
from datetime import datetime, date
from typing import Any, Iterable, Optional

from sqlalchemy.orm import Session

from app.models import NotificationLog, Task, User
from app.services import knox_messenger_service

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────
# Event types (문자열 상수 — DB 저장값으로도 사용)
# ──────────────────────────────────────────────────────────
class EventType:
    TASK_ASSIGNED = "task_assigned"
    TASK_DUE_SOON = "task_due_soon"
    TASK_OVERDUE = "task_overdue"
    MENTION = "mention"


# ──────────────────────────────────────────────────────────
# Channels — 채널별 어댑터 (현재는 Knox 1종)
# ──────────────────────────────────────────────────────────
def _send_via_knox(
    *,
    user: User,
    message: str,
    link: Optional[str],
    msg_type: str,
    metadata: Optional[dict[str, Any]],
) -> bool:
    receiver = knox_messenger_service._resolve_receiver(user)
    if not receiver:
        logger.info("[notification] no knox receiver for user_id=%s, skip", user.id)
        return False
    return knox_messenger_service.send_mention_message(
        receiver=receiver,
        message=message,
        link=link,
        source="plan",
        msg_type=msg_type,
        metadata=metadata,
    )


# provider key -> sender callable.
# 새 채널(email/web/...) 은 이 dict 에 함수만 추가하면 된다.
CHANNELS: dict[str, Any] = {
    "knox": _send_via_knox,
}


# ──────────────────────────────────────────────────────────
# 중복 방지 / 로깅
# ──────────────────────────────────────────────────────────
def _today_str() -> str:
    return date.today().isoformat()


def _make_dedup_key(
    event_type: str,
    target_user_id: int,
    *,
    task_id: Optional[int] = None,
    project_id: Optional[int] = None,
    extra: Optional[str] = None,
) -> str:
    """
    이벤트별 중복 방지 키 규칙.
    - task_assigned: 같은 (user, task) 조합은 최초 1회만
    - due_soon / overdue: 같은 (user, task) 조합 하루 1회 (날짜 포함)
    - mention: extra=mention_id 등 호출자가 정한 식별자로 1회 한정
    """
    parts: list[str] = [event_type, f"u{target_user_id}"]
    if task_id is not None:
        parts.append(f"t{task_id}")
    if project_id is not None:
        parts.append(f"p{project_id}")
    if event_type in (EventType.TASK_DUE_SOON, EventType.TASK_OVERDUE):
        parts.append(_today_str())
    if extra:
        parts.append(str(extra))
    return ":".join(parts)


def _already_sent(db: Session, dedup_key: str) -> bool:
    """동일 dedup_key 의 'sent' 로그가 이미 존재하는지 검사."""
    try:
        row = (
            db.query(NotificationLog.id)
            .filter(
                NotificationLog.dedup_key == dedup_key,
                NotificationLog.status == "sent",
            )
            .first()
        )
        return row is not None
    except Exception as e:  # noqa: BLE001
        logger.warning("[notification] dedup lookup failed key=%s err=%s", dedup_key, e)
        return False


def _log(
    db: Session,
    *,
    event_type: str,
    target_user_id: int,
    project_id: Optional[int],
    task_id: Optional[int],
    actor_user_id: Optional[int],
    dedup_key: str,
    provider: str,
    status: str,
    message: Optional[str],
    link: Optional[str],
) -> None:
    try:
        entry = NotificationLog(
            event_type=event_type,
            target_user_id=target_user_id,
            project_id=project_id,
            task_id=task_id,
            actor_user_id=actor_user_id,
            dedup_key=dedup_key,
            provider=provider,
            status=status,
            message=(message or "")[:5000] if message else None,
            link=(link or "")[:500] if link else None,
            sent_at=datetime.utcnow(),
        )
        db.add(entry)
        db.commit()
    except Exception as e:  # noqa: BLE001
        logger.warning("[notification] log write failed key=%s err=%s", dedup_key, e)
        try:
            db.rollback()
        except Exception:
            pass


# ──────────────────────────────────────────────────────────
# 공통 dispatch — 단일 사용자 + 단일 채널 1회 처리
# ──────────────────────────────────────────────────────────
def _dispatch(
    db: Session,
    *,
    event_type: str,
    target_user: User,
    actor_user_id: Optional[int],
    project_id: Optional[int],
    task_id: Optional[int],
    dedup_extra: Optional[str],
    message: str,
    link: Optional[str],
    msg_type: str,
    metadata: Optional[dict[str, Any]] = None,
    provider: str = "knox",
) -> None:
    """단일 수신자 + 단일 채널 디스패치. 예외는 내부 흡수."""
    try:
        if not target_user or not getattr(target_user, "id", None):
            return

        # 자기 자신에게는 보내지 않음 (mention 의 self-mention 등)
        if actor_user_id is not None and target_user.id == actor_user_id:
            return

        dedup_key = _make_dedup_key(
            event_type,
            target_user.id,
            task_id=task_id,
            project_id=project_id,
            extra=dedup_extra,
        )
        if _already_sent(db, dedup_key):
            logger.debug("[notification] dedup hit key=%s", dedup_key)
            return

        sender = CHANNELS.get(provider)
        if sender is None:
            logger.warning("[notification] unknown provider=%s, skip", provider)
            return

        ok = sender(
            user=target_user,
            message=message,
            link=link,
            msg_type=msg_type,
            metadata=metadata,
        )

        _log(
            db,
            event_type=event_type,
            target_user_id=target_user.id,
            project_id=project_id,
            task_id=task_id,
            actor_user_id=actor_user_id,
            dedup_key=dedup_key,
            provider=provider,
            status="sent" if ok else "failed",
            message=message,
            link=link,
        )
    except Exception as e:  # noqa: BLE001
        logger.warning("[notification] dispatch error event=%s err=%s", event_type, e)


# ──────────────────────────────────────────────────────────
# Public API — 이벤트별 알림 발송 함수
#
# 모든 함수는 호출자에서 fastapi.BackgroundTasks.add_task(...) 로 부르는 것을
# 가정한다. 예외 전파하지 않으므로 응답 흐름에 영향 없음.
# ──────────────────────────────────────────────────────────
def _resolve_task_and_user(db: Session, task_id: int, user_id: int) -> tuple[Optional[Task], Optional[User]]:
    task = db.query(Task).filter(Task.id == task_id).first() if task_id else None
    user = db.query(User).filter(User.id == user_id).first() if user_id else None
    return task, user


def _build_task_link(task: Optional[Task]) -> Optional[str]:
    """
    Task 링크 생성.
    실제 라우팅 규칙(/projects/{pid}/tasks/{tid} 등) 은 프론트와 합의 후 조정.
    TODO: 프론트 라우팅 확정되면 정확한 path 로 교체.
    """
    if not task:
        return None
    if not getattr(task, "project_id", None):
        return None
    return f"/projects/{task.project_id}/tasks/{task.id}"


def notify_task_assigned(
    db: Session,
    *,
    task_id: int,
    assignee_id: int,
    actor_id: Optional[int] = None,
) -> None:
    """
    Task 가 새 담당자에게 할당되었을 때 알림.
    중복 방지: 같은 (assignee, task) 조합은 최초 1회만.
    """
    task, user = _resolve_task_and_user(db, task_id, assignee_id)
    if not task or not user:
        return

    title = task.title or "(제목 없음)"
    message = f"[PLAN-AI] 새 Task가 할당되었습니다.\n• {title}"
    if task.due_date:
        message += f"\n• 마감: {task.due_date}"

    _dispatch(
        db,
        event_type=EventType.TASK_ASSIGNED,
        target_user=user,
        actor_user_id=actor_id,
        project_id=task.project_id,
        task_id=task.id,
        dedup_extra=None,
        message=message,
        link=_build_task_link(task),
        msg_type="task_assigned",
        metadata={"task_id": task.id, "project_id": task.project_id},
    )


def notify_task_due_soon(
    db: Session,
    *,
    task_id: int,
    assignee_id: int,
) -> None:
    """
    Task 마감 임박 알림.

    TODO(scheduler-wiring):
      - daily cron / APScheduler 등에서 마감일 임박 Task 목록을 추출 후 본 함수 호출.
      - "며칠 전 알림" / "당일 알림" 등 임박 정의는 운영 정책 확정 후 결정.
      - 완료(status='done') Task 는 호출자(스케줄러) 단계에서 제외 권장.
    중복 방지: 동일 사용자/Task 는 하루 1회.
    """
    task, user = _resolve_task_and_user(db, task_id, assignee_id)
    if not task or not user:
        return

    title = task.title or "(제목 없음)"
    message = f"[PLAN-AI] 마감 임박 Task가 있습니다.\n• {title}"
    if task.due_date:
        message += f"\n• 마감: {task.due_date}"

    _dispatch(
        db,
        event_type=EventType.TASK_DUE_SOON,
        target_user=user,
        actor_user_id=None,
        project_id=task.project_id,
        task_id=task.id,
        dedup_extra=None,
        message=message,
        link=_build_task_link(task),
        msg_type="task_due_soon",
        metadata={"task_id": task.id},
    )


def notify_task_overdue(
    db: Session,
    *,
    task_id: int,
    assignee_id: int,
) -> None:
    """
    Task 지연 알림.

    TODO(scheduler-wiring):
      - daily cron 등에서 due_date < today 이고 미완료인 Task 추출 후 본 함수 호출.
      - 발송 빈도(매일 vs 1회만), 완료된 Task 제외 여부 등은 운영 정책 확정 후 결정.
    중복 방지: 동일 사용자/Task 는 하루 1회.
    """
    task, user = _resolve_task_and_user(db, task_id, assignee_id)
    if not task or not user:
        return

    title = task.title or "(제목 없음)"
    message = f"[PLAN-AI] 지연된 Task가 있습니다.\n• {title}"
    if task.due_date:
        message += f"\n• 마감: {task.due_date}"

    _dispatch(
        db,
        event_type=EventType.TASK_OVERDUE,
        target_user=user,
        actor_user_id=None,
        project_id=task.project_id,
        task_id=task.id,
        dedup_extra=None,
        message=message,
        link=_build_task_link(task),
        msg_type="task_overdue",
        metadata={"task_id": task.id},
    )


def notify_mention(
    db: Session,
    *,
    target_user_ids: Iterable[int],
    actor_id: Optional[int],
    project_id: Optional[int] = None,
    task_id: Optional[int] = None,
    message_text: str = "",
    source_key: Optional[str] = None,
) -> None:
    """
    댓글/노트/Activity 등에서 사용자를 @멘션했을 때 알림.

    중복 방지: 같은 멘션 원본(source_key, 예: 'comment:123') + 수신자 조합은 1회.
    `source_key` 가 비면 task_id 단위 1회로 폴백.

    NOTE: 기존 knox_messenger_service.send_mention_messages_for_users 와는 별도 경로.
    추후 기존 호출지점을 본 함수로 옮길 수 있으나, 1차에서는 호환을 위해 두 경로를
    공존시킨다.
    """
    if not target_user_ids:
        return

    actor_user_id = actor_id
    link = None
    if task_id and project_id:
        link = f"/projects/{project_id}/tasks/{task_id}"

    users = (
        db.query(User)
        .filter(User.id.in_(list(target_user_ids)))
        .all()
    )
    for u in users:
        message = f"[PLAN-AI] 회원님이 언급되었습니다.\n{(message_text or '').strip()[:200]}"
        _dispatch(
            db,
            event_type=EventType.MENTION,
            target_user=u,
            actor_user_id=actor_user_id,
            project_id=project_id,
            task_id=task_id,
            dedup_extra=source_key,
            message=message,
            link=link,
            msg_type="mention",
            metadata={"source": source_key, "task_id": task_id, "project_id": project_id},
        )
