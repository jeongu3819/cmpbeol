"""
메일 발송 adapter.

provider 별로 갈아끼울 수 있는 구조. 실제 발송 여부는 MAIL_PROVIDER 환경변수로 결정한다.

  MAIL_PROVIDER=disabled  (기본)  실제 발송 없음. status="disabled".
  MAIL_PROVIDER=mock              실제 발송 없음. 발송 성공처럼 status="sent"(+[MOCK] 로그). 검증용.
  MAIL_PROVIDER=smtp              SMTP_HOST/PORT/USER/PASSWORD/FROM 이 모두 있을 때만 smtplib 발송.
                                  하나라도 없으면 status="failed"(smtp_not_configured) — 실제 발송 안 함.
  MAIL_PROVIDER=knox_api          사내 Knox Mail API(/mail/api/v2.0/mails/send?userId=…) 로 실제 발송.
                                  base_url/userId 는 mail 전용 env 없으면 기존 Knox 공통 env(KNOX_API_URL/
                                  KNOX_SYSTEM_ID) fallback. base_url·userId·KNOX_MAIL_SENDER_EMAIL 이 모두
                                  있어야 호출. 하나라도 없으면 status="failed"(knox_not_configured).

Knox Mail API (MAIL_PROVIDER=knox_api) 관련 env (전부 .env.local / .env.production 에서만):
  ── mail 전용 env 가 없으면 기존 Knox 공통 env 를 fallback 으로 재사용한다 ──
  base_url : KNOX_MAIL_API_BASE_URL  → (없으면) KNOX_API_URL        예: https://knox-api.company.com
  userId   : KNOX_MAIL_USER_ID       → (없으면) KNOX_SYSTEM_ID       URI ?userId= + System-ID 헤더
  token    : KNOX_MAIL_API_TOKEN     → (없으면) KNOX_AUTH_TOKEN      Authorization: Bearer
  KNOX_MAIL_SENDER_EMAIL    sender.emailAddress (예: planner@company.com). 필수 · 별도 env(공통 없음).
                            ⚠️ KNOX_SYSTEM_ID(=loginid/userId) 와 혼동 금지 — sender 는 실제 메일주소.
  KNOX_MAIL_API_PATH        기본 /mail/api/v2.0/mails/send
  KNOX_MAIL_TIMEOUT_SECONDS 기본 10
  KNOX_MAIL_CONTENT_TYPE    TEXT(기본) | HTML — HTML 이면 html_body 사용
  KNOX_MAIL_DOC_SECU_TYPE   기본 PERSONAL

인증 헤더는 knox_client.py(임직원 API)와 동일 방식을 재사용한다: Authorization: Bearer {token} + System-ID: {userId}.
전송도 knox_client 와 동일하게 trust_env=False(프록시 env 무시, 사내망 직접) + verify=False.

⚠️ 환경변수는 **호출 시점**에 읽는다 (import 시점에 읽으면 environment.py 로드 전이라 값이 굳을 수 있음 —
   backup_scheduler.py 주석 참고).
⚠️ SMTP 비밀번호 / Knox 토큰·base url·sender·userId 를 코드에 하드코딩하지 않는다. 전부 .env.local / .env.production.
⚠️ 멘션 알림 메일에는 첨부파일을 직접 첨부하지 않는다(multipart 는 mail part 만). 본문엔 PLAN-AI 링크만.
"""

from __future__ import annotations

import json
import logging
import os
import smtplib
from dataclasses import dataclass
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formataddr
from typing import Optional

logger = logging.getLogger("mail")


@dataclass
class MailSendResult:
    status: str            # "sent" | "disabled" | "skipped" | "failed"
    provider: str
    error: Optional[str] = None
    # provider 가 발송 성공 시 돌려준 메시지 식별자(knox_api → response.mailId). 실패 시 None.
    provider_message_id: Optional[str] = None


# ── env 읽기 (호출 시점) ──────────────────────────────────
def get_mail_provider() -> str:
    return (os.getenv("MAIL_PROVIDER") or "disabled").strip().lower()


def _smtp_config() -> dict:
    return {
        "host": (os.getenv("SMTP_HOST") or "").strip(),
        "port": (os.getenv("SMTP_PORT") or "").strip(),
        "user": (os.getenv("SMTP_USER") or "").strip(),
        "password": os.getenv("SMTP_PASSWORD") or "",
        "from_addr": (os.getenv("SMTP_FROM") or "").strip(),
        "use_tls": (os.getenv("SMTP_USE_TLS") or "true").strip().lower() in ("1", "true", "yes", "on"),
        "from_name": (os.getenv("SMTP_FROM_NAME") or "PLAN-AI").strip(),
    }


def _knox_config() -> dict:
    """Knox Mail 설정. mail 전용 env 가 없으면 기존 Knox 공통 env 를 fallback 으로 재사용한다.
      base_url   : KNOX_MAIL_API_BASE_URL → KNOX_API_URL                (URI base)
      user_id    : KNOX_MAIL_USER_ID      → KNOX_SYSTEM_ID              (URI ?userId= query)
      system_id  : KNOX_SYSTEM_ID         → KNOX_MAIL_USER_ID           (System-ID 헤더)
      token      : KNOX_MAIL_API_TOKEN    → KNOX_AUTH_TOKEN             (Authorization: Bearer)

    ⚠️ user_id(query ?userId=) 와 system_id(System-ID 헤더) 는 **서로 다른 값**이다.
       - query userId    = 메일 발송 계정 loginid (예: ji)  → KNOX_MAIL_USER_ID
       - header System-ID = 연계 시스템 ID              → KNOX_SYSTEM_ID
       예전엔 둘 다 user_id 로 채워서 System-ID 가 loginid(ji)로 나가 Knox 가 거부했다.
    인증 헤더는 knox_client.py(임직원 API)와 동일: Bearer 토큰 + System-ID 헤더.
    """
    base_url = (os.getenv("KNOX_MAIL_API_BASE_URL") or os.getenv("KNOX_API_URL") or "").strip().rstrip("/")
    user_id = (os.getenv("KNOX_MAIL_USER_ID") or os.getenv("KNOX_SYSTEM_ID") or "").strip()
    system_id = (os.getenv("KNOX_SYSTEM_ID") or os.getenv("KNOX_MAIL_USER_ID") or "").strip()
    token = (os.getenv("KNOX_MAIL_API_TOKEN") or os.getenv("KNOX_AUTH_TOKEN") or "").strip()
    return {
        "base_url": base_url,
        "path": (os.getenv("KNOX_MAIL_API_PATH") or "/mail/api/v2.0/mails/send").strip(),
        "user_id": user_id,
        "system_id": system_id,
        "sender_email": (os.getenv("KNOX_MAIL_SENDER_EMAIL") or "").strip(),
        "content_type": (os.getenv("KNOX_MAIL_CONTENT_TYPE") or "TEXT").strip().upper(),
        "doc_secu_type": (os.getenv("KNOX_MAIL_DOC_SECU_TYPE") or "PERSONAL").strip().upper(),
        "token": token,
        "timeout": _knox_timeout(),
    }


def _make_bearer_token(token: str) -> str:
    """Authorization 헤더 값. env 에 이미 'Bearer ' 가 붙어 있어도 중복(Bearer Bearer …)되지 않게 방어."""
    token = (token or "").strip()
    if not token:
        return ""
    if token.lower().startswith("bearer "):
        return token
    return f"Bearer {token}"


def _knox_timeout() -> int:
    try:
        return max(1, int(os.getenv("KNOX_MAIL_TIMEOUT_SECONDS", "10")))
    except (TypeError, ValueError):
        return 10


def is_mail_enabled() -> bool:
    """provider 가 실제/모의 발송을 하는 상태인지(=disabled 아님)."""
    return get_mail_provider() != "disabled"


# ── provider 구현 ────────────────────────────────────────
def _send_smtp(to: str, subject: str, text_body: str, html_body: Optional[str]) -> MailSendResult:
    cfg = _smtp_config()
    missing = [k for k in ("host", "port", "user", "password", "from_addr") if not cfg[k]]
    if missing:
        return MailSendResult(
            status="failed",
            provider="smtp",
            error=f"smtp_not_configured (missing: {','.join(missing)})",
        )
    try:
        port = int(cfg["port"])
    except (TypeError, ValueError):
        return MailSendResult(status="failed", provider="smtp", error="smtp_not_configured (bad SMTP_PORT)")

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = formataddr((cfg["from_name"], cfg["from_addr"]))
    msg["To"] = to
    msg.attach(MIMEText(text_body or "", "plain", "utf-8"))
    if html_body:
        msg.attach(MIMEText(html_body, "html", "utf-8"))

    try:
        if cfg["use_tls"]:
            server = smtplib.SMTP(cfg["host"], port, timeout=15)
            server.ehlo()
            server.starttls()
            server.ehlo()
        else:
            server = smtplib.SMTP(cfg["host"], port, timeout=15)
        try:
            if cfg["user"] and cfg["password"]:
                server.login(cfg["user"], cfg["password"])
            server.sendmail(cfg["from_addr"], [to], msg.as_string())
        finally:
            try:
                server.quit()
            except Exception:
                pass
        return MailSendResult(status="sent", provider="smtp")
    except Exception as e:  # noqa: BLE001
        return MailSendResult(status="failed", provider="smtp", error=f"smtp_error: {e}")


def _send_knox_api(to: str, subject: str, text_body: str, html_body: Optional[str]) -> MailSendResult:
    """사내 Knox Mail API 로 발송.

    URI: {base}/mail/api/v2.0/mails/send?userId={loginid}
    Method: POST, Content-Type: multipart/form-data (mail part 만 — 첨부 없음)

    성공 판단: HTTP 2xx AND response.result == "success". mailId 를 provider_message_id 로 저장.
    userId / sender 는 개인 계정이 아니라 시스템 연계계정(env)으로 고정 — 감사/발신저장 정책 단순화.
    실제 작성자명은 본문(text/html)에 이미 표시되어 있다.
    """
    cfg = _knox_config()
    missing = [k for k in ("base_url", "user_id", "sender_email") if not cfg[k]]
    if missing:
        return MailSendResult(
            status="failed",
            provider="knox_api",
            error=f"knox_not_configured (missing: {','.join(missing)})",
        )

    try:
        import requests  # 지연 import — provider=knox_api 일 때만 필요
    except Exception as e:  # noqa: BLE001
        return MailSendResult(status="failed", provider="knox_api", error=f"knox_requests_missing: {e}")

    url = f"{cfg['base_url']}{cfg['path']}"
    params = {"userId": cfg["user_id"]}  # VM 검증 스크립트와 동일하게 query 는 params 로 전달

    # contentType 이 HTML 이고 html_body 가 있을 때만 HTML, 그 외에는 TEXT 본문.
    if cfg["content_type"] == "HTML" and html_body:
        contents = html_body
        content_type = "HTML"
    else:
        contents = text_body or ""
        content_type = "TEXT"

    mail_payload = {
        "subject": subject,
        "contents": contents,
        "contentType": content_type,
        "docSecuType": cfg["doc_secu_type"],
        "sender": {"emailAddress": cfg["sender_email"]},
        "recipients": [{"emailAddress": to, "recipientType": "TO"}],
    }

    # 인증 헤더는 knox_client.py(임직원 API)와 동일 방식: Bearer 토큰 + System-ID 헤더.
    # ⚠️ System-ID 는 KNOX_SYSTEM_ID(연계 시스템 ID)이지 query userId(loginid) 가 아니다.
    # Content-Type 은 지정하지 않는다(requests 가 multipart boundary 를 자동 설정).
    headers = {"Accept": "application/json"}
    bearer = _make_bearer_token(cfg["token"])
    if bearer:
        headers["Authorization"] = bearer
    if cfg["system_id"]:
        headers["System-ID"] = cfg["system_id"]

    # multipart/form-data — form-data name 은 반드시 "mail" (첨부 시 "attachments", 이번엔 미사용).
    files = {
        "mail": (None, json.dumps(mail_payload, ensure_ascii=False), "application/json"),
    }

    # 발송 직전 상태 로그 (민감정보 제외: 토큰/Authorization 전체·본문은 남기지 않는다).
    logger.info(
        "[MAIL][knox_api] POST host=%s path=%s userId=%s system_id_set=%s token_set=%s to=%s",
        cfg["base_url"], cfg["path"], cfg["user_id"], bool(cfg["system_id"]), bool(cfg["token"]), to,
    )

    try:
        # knox_client 와 동일: trust_env=False(프록시 env 무시, 사내망 직접 연결) + verify=False.
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception:  # noqa: BLE001
            pass
        session = requests.Session()
        session.trust_env = False
        resp = session.post(url, params=params, files=files, headers=headers, timeout=cfg["timeout"], verify=False)
    except Exception as e:  # noqa: BLE001 — 네트워크/SSL/프록시/DNS/timeout
        return MailSendResult(status="failed", provider="knox_api", error=f"knox_exception: {e}")

    if resp.status_code < 200 or resp.status_code >= 300:
        logger.warning("[MAIL][knox_api] http_%s to=%s body=%s", resp.status_code, to, resp.text[:300])
        return MailSendResult(
            status="failed",
            provider="knox_api",
            error=f"knox_http_{resp.status_code}: {resp.text[:500]}",
        )

    try:
        data = resp.json()
    except Exception:  # noqa: BLE001 — 2xx 인데 JSON 이 아님
        logger.warning("[MAIL][knox_api] bad_response to=%s body=%s", to, resp.text[:300])
        return MailSendResult(
            status="failed",
            provider="knox_api",
            error=f"knox_bad_response: {resp.text[:500]}",
        )

    if isinstance(data, dict) and data.get("result") == "success":
        mail_id = data.get("mailId")
        logger.info("[MAIL][knox_api] sent to=%s status=%s result=success mailId=%s", to, resp.status_code, mail_id)
        return MailSendResult(status="sent", provider="knox_api", provider_message_id=mail_id)

    # 실패 응답: result/errorCode/errorMessage 를 남겨 디버깅 가능하게 (토큰·본문은 로그 안 함).
    err_code = data.get("errorCode") if isinstance(data, dict) else None
    err_msg = data.get("errorMessage") if isinstance(data, dict) else None
    logger.warning(
        "[MAIL][knox_api] not_success to=%s status=%s result=%s errorCode=%s errorMessage=%s",
        to, resp.status_code,
        (data.get("result") if isinstance(data, dict) else None), err_code, err_msg,
    )
    return MailSendResult(
        status="failed",
        provider="knox_api",
        error=f"knox_result_not_success: {str(data)[:500]}",
    )


def send_mail(
    to: str,
    subject: str,
    text_body: str,
    html_body: Optional[str] = None,
) -> MailSendResult:
    """provider 에 따라 메일을 발송(하거나 하지 않)는다. 예외를 밖으로 던지지 않는다."""
    provider = get_mail_provider()

    if not to:
        return MailSendResult(status="skipped", provider=provider, error="no_recipient")

    if provider == "disabled":
        return MailSendResult(status="disabled", provider="disabled", error="provider_disabled")

    if provider == "mock":
        logger.info("[MAIL][MOCK] to=%s subject=%s (실제 발송 없음)", to, subject)
        return MailSendResult(status="sent", provider="mock")

    if provider == "smtp":
        return _send_smtp(to, subject, text_body, html_body)

    if provider == "knox_api":
        return _send_knox_api(to, subject, text_body, html_body)

    return MailSendResult(status="skipped", provider=provider, error=f"unknown_provider:{provider}")
