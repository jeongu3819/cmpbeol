"""AI 이미지 variant 저장 정책 (경로 규칙 상수화).

⚠️ 이번 단계에서 **실제 파일을 생성하지 않는다.** 나중에 전처리 잡(preview/ai_readable/
tile 생성)을 붙일 때 일관된 경로를 쓰도록 **규칙만** 정의한다.

variant 정의
------------
- original   : 사용자가 업로드한 원본. **절대 임의 리사이즈하지 않는다.**
- preview    : 화면 표시용(작고 가벼움).
- ai_readable: 모델 전달용(글자/표/차트가 잘 보이도록 보정된 버전).
- tile       : 큰 이미지/전체 캡처를 영역별로 나눈 이미지.

식별 키
------
가능하면 ``content_hash``(sha256)를 variant 키로 쓴다 → 같은 원본에서 파생된
preview/ai_readable/tile 을 hash 로 추적 가능. hash 가 없으면 image_id 를
파일시스템 안전 문자열로 변환해 fallback 한다.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Optional

# {key} = content_hash(sha256) 우선, 없으면 sanitized image_id
ORIGINAL_PATH_TMPL = "projects/{project_id}/images/original/{key}"
PREVIEW_PATH_TMPL = "projects/{project_id}/images/preview/{key}.webp"
AI_READABLE_PATH_TMPL = "projects/{project_id}/images/ai_readable/{key}.png"
TILES_DIR_TMPL = "projects/{project_id}/images/tiles/{key}/"

POLICY_VERSION = "ai-image-storage-policy-v1"

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def _safe_key(image_id: Optional[str]) -> str:
    return _UNSAFE.sub("_", str(image_id or "unknown"))


def variant_storage_plan(
    project_id: Optional[int],
    image_id: Optional[str],
    content_hash: Optional[str] = None,
) -> Dict[str, Any]:
    """variant 별 (미래) 저장 경로 계획을 반환한다. 파일은 만들지 않는다."""
    key = content_hash or _safe_key(image_id)
    pid = project_id if project_id is not None else "unknown"
    return {
        "policy_version": POLICY_VERSION,
        "key": key,
        "key_source": "content_hash" if content_hash else "image_id",
        "original": ORIGINAL_PATH_TMPL.format(project_id=pid, key=key),
        "preview": PREVIEW_PATH_TMPL.format(project_id=pid, key=key),
        "ai_readable": AI_READABLE_PATH_TMPL.format(project_id=pid, key=key),
        "tiles": TILES_DIR_TMPL.format(project_id=pid, key=key),
    }


def policy_descriptor() -> Dict[str, Any]:
    """ai-context-preview 응답에 한 번 실어줄 정책 설명(경로 템플릿)."""
    return {
        "policy_version": POLICY_VERSION,
        "files_generated": False,  # 현재는 규칙만 — 실제 variant 파일 미생성
        "templates": {
            "original": ORIGINAL_PATH_TMPL,
            "preview": PREVIEW_PATH_TMPL,
            "ai_readable": AI_READABLE_PATH_TMPL,
            "tiles": TILES_DIR_TMPL,
        },
        "notes": [
            "original 은 임의 리사이즈 금지(원본 보존).",
            "key 는 content_hash(sha256) 우선, 없으면 image_id 기반.",
            "preview/ai_readable/tile 은 향후 전처리 잡이 생성.",
        ],
    }
