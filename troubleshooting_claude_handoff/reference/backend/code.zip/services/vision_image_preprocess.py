"""AI 전송용 이미지 전처리 (provider 무관).

원본 이미지는 그대로 두고(Task 카드/인수인계 상세 화면 표시용), **모델에 보낼 때만**
긴 변을 축소해 payload 를 줄인다. 재인코딩 포맷은 **role 로 분기**한다.

- 표/문서/UI/코드/로그/터미널 등 **텍스트·구조 판독이 중요한 role** → 무손실 PNG 유지.
  JPEG 압축 노이즈로 작은 글자·숫자·표 헤더 판독률이 떨어지는 것을 막는다(축소만 하고
  손실 재압축은 하지 않는다). 긴 변 한도 2000px.
- 그 외 일반/사진 계열 → JPEG(quality 85) 재인코딩. 긴 변 한도 1600px.

특징:
- OpenAI / DSLLM 등 provider 에 독립적이다(호출부는 바이트만 넘긴다).
- 실패(비이미지/손상/PIL 없음)하면 원본을 그대로 반환해 파이프라인을 막지 않는다.
- 축소/재인코딩 전·후 byte 크기를 meta 로 돌려줘 호출부가 로그로 남길 수 있게 한다.
"""

from __future__ import annotations

import io
import logging
from typing import Optional, Tuple

logger = logging.getLogger("main")

# 텍스트/구조 판독이 중요한 role — JPEG 압축 노이즈를 피해 **무손실(PNG)** 로 유지한다.
# (축소는 하되 재압축 손실은 주지 않는다. 작은 글자/숫자/표 헤더 선명도 우선.)
_LOSSLESS_TEXT_ROLES = {
    "table",
    "document_table",
    "document_crop",
    "text_crop",
    "error_screen",
    "config_capture",
    "terminal_capture",
    "log_capture",
    "code_snippet",
    "command_snippet",
    "equipment_screen",
    "partial_screen_capture",
    "process_flow",
    "meeting_slide",
    "chart",
    "result_capture",
}

# 전처리 정책 버전. 정책(포맷 분기/한도/품질)이 바뀌면 올린다 → 이미지 관찰 캐시 무효화 키에 사용.
PREPROCESS_VERSION = "preprocess-v1"

DEFAULT_MAX_EDGE = 1600      # 일반/사진 캡처
TEXT_HEAVY_MAX_EDGE = 2000   # 텍스트/구조 캡처(글자 판독 우선)
JPEG_QUALITY = 85            # 사진 계열만 사용(권장 82~88)


def is_text_heavy_role(role: Optional[str]) -> bool:
    """텍스트/구조 판독이 중요한 role 인지(→ 무손실 PNG 유지 대상)."""
    return (role or "") in _LOSSLESS_TEXT_ROLES


def max_edge_for_role(role: Optional[str]) -> int:
    """role 에 따른 긴 변 최대 px. 텍스트/구조 캡처는 글자 판독 위해 더 크게."""
    return TEXT_HEAVY_MAX_EDGE if is_text_heavy_role(role) else DEFAULT_MAX_EDGE


def preprocess_image_for_ai(
    data: bytes,
    media_type: str,
    *,
    role: Optional[str] = None,
) -> Tuple[bytes, str, dict]:
    """모델 전송용 이미지 바이트를 축소한다. 실패하면 원본을 그대로 반환한다.

    텍스트/구조 role 은 무손실(PNG), 그 외는 JPEG 로 재인코딩한다. 어느 경우든
    축소로 이득이 없으면(이미 작음/오히려 커짐) 원본을 유지한다.

    Args:
        data: 원본 이미지 바이트.
        media_type: 원본 media type(예: image/png).
        role: image_role(표/문서/화면 등은 무손실 + 더 큰 한도).

    Returns:
        (out_bytes, out_media_type, meta)
        meta = {original_bytes, processed_bytes, max_edge, text_heavy, format,
                width, height, out_width, out_height, resized, recompressed, skipped_reason}
    """
    text_heavy = is_text_heavy_role(role)
    meta: dict = {
        "original_bytes": len(data or b""),
        "processed_bytes": len(data or b""),
        "max_edge": max_edge_for_role(role),
        "text_heavy": text_heavy,
        "format": "original",
        "width": None,
        "height": None,
        "out_width": None,
        "out_height": None,
        "resized": False,
        "recompressed": False,
        "skipped_reason": None,
    }
    if not data:
        meta["skipped_reason"] = "empty"
        return data, media_type, meta

    try:
        from PIL import Image
    except Exception:
        meta["skipped_reason"] = "pillow_unavailable"
        return data, media_type, meta

    try:
        with Image.open(io.BytesIO(data)) as im:
            im.load()
            w, h = im.size
            meta["width"], meta["height"] = w, h

            # 애니메이션/멀티프레임(GIF 등)은 첫 프레임만 남으면 의미가 깨질 수 있어 건드리지 않는다.
            if getattr(im, "is_animated", False):
                meta["skipped_reason"] = "animated"
                return data, media_type, meta

            max_edge = meta["max_edge"]
            long_edge = max(w, h)
            work = im
            if long_edge > max_edge:
                scale = max_edge / float(long_edge)
                new_size = (max(1, int(round(w * scale))), max(1, int(round(h * scale))))
                work = im.resize(new_size, Image.LANCZOS)
                meta["resized"] = True

            if text_heavy:
                # 무손실 유지: 축소했을 때만 PNG 재인코딩(픽셀 수 감소분이 payload 이득).
                # 축소가 없으면 재인코딩해도 손실만 없을 뿐 이득이 없으므로 원본을 그대로 둔다.
                if not meta["resized"]:
                    meta["skipped_reason"] = "text_lossless_no_resize"
                    return data, media_type, meta
                save_img = work
                if save_img.mode not in ("RGB", "RGBA", "L", "LA", "P"):
                    save_img = save_img.convert("RGB")
                buf = io.BytesIO()
                save_img.save(buf, format="PNG", optimize=True)
                out = buf.getvalue()
                out_media = "image/png"
                out_fmt = "png"
            else:
                # 사진 계열: JPEG 재인코딩(투명 배경은 흰색으로 합성해 검게 뭉치는 것 방지).
                if work.mode in ("RGBA", "LA", "P"):
                    rgba = work.convert("RGBA")
                    bg = Image.new("RGB", rgba.size, (255, 255, 255))
                    bg.paste(rgba, mask=rgba.split()[-1])
                    work = bg
                elif work.mode != "RGB":
                    work = work.convert("RGB")
                buf = io.BytesIO()
                work.save(buf, format="JPEG", quality=JPEG_QUALITY, optimize=True)
                out = buf.getvalue()
                out_media = "image/jpeg"
                out_fmt = "jpeg"
                save_img = work

            meta["out_width"], meta["out_height"] = save_img.size

            # 축소 없이 재인코딩만 했는데 오히려 더 커지면(이미 작은/최적 이미지) 원본을 유지한다.
            if len(out) >= len(data) and not meta["resized"]:
                meta["skipped_reason"] = "no_gain"
                return data, media_type, meta

            meta["recompressed"] = True
            meta["processed_bytes"] = len(out)
            meta["format"] = out_fmt
            return out, out_media, meta
    except Exception as e:  # 손상/비이미지 등 → 원본 유지(파이프라인 무중단)
        logger.warning("[VisionPreprocess] 전처리 실패, 원본 사용: %s", e)
        meta["skipped_reason"] = "error"
        return data, media_type, meta
