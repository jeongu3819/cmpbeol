"""
Notification event outbox helper.

이 모듈은 "알림 이벤트"를 DB(notification_events)에 남기는 역할만 한다.
실제 Knox 메일/메신저 발송은 아직 사내 API 연동 방식 확인 전이므로 구현하지 않는다.
추후 발송 worker/sender adapter 를 이 outbox 를 소비하도록 붙이면 된다.

TODO: Knox mail/messenger sender adapter 연결 (docs/NOTIFICATION_KNOX_MAIL_TODO.md 참고)
"""

import logging
import os
from typing import Optional, Dict, Any

from app.models import NotificationEvent

logger = logging.getLogger("notifications")


def allow_self_mention() -> bool:
    """자기 자신 멘션도 알림 이벤트를 생성/발송할지 (기본 False).

    운영 정책상 self-mention 은 제외하지만, Knox Mail 연동 테스트 등에서
    NOTIFICATION_ALLOW_SELF_MENTION=true 로 두면 self-mention 도 통과시킨다.
    ⚠️ env 는 호출 시점에 읽는다(다른 mail/processor env 와 동일 규칙).
    """
    return (os.getenv("NOTIFICATION_ALLOW_SELF_MENTION") or "false").strip().lower() in ("1", "true", "yes", "on")


def create_notification_event(
    db,
    *,
    event_type: str,
    task_id: Optional[int] = None,
    project_id: Optional[int] = None,
    space_id: Optional[int] = None,
    actor_user_id: Optional[int] = None,
    target_user_id: Optional[int] = None,
    payload: Optional[Dict[str, Any]] = None,
) -> Optional[NotificationEvent]:
    """notification_events 에 이벤트 row 한 줄을 추가한다 (commit 은 호출자 책임).

    - actor 와 target 이 같으면(본인이 본인에게) 이벤트를 만들지 않는다.
    - 이벤트 적재 실패가 본 기능(댓글 작성 등)을 막지 않도록 예외는 흡수한다.
    - 실제 발송은 하지 않는다. status='pending' 으로만 남긴다.
    """
    try:
        if target_user_id is not None and actor_user_id is not None:
            if int(target_user_id) == int(actor_user_id) and not allow_self_mention():
                return None
        ev = NotificationEvent(
            event_type=str(event_type)[:60],
            task_id=task_id,
            project_id=project_id,
            space_id=space_id,
            actor_user_id=actor_user_id,
            target_user_id=target_user_id,
            payload_json=payload or None,
            status="pending",
        )
        db.add(ev)
        return ev
    except Exception as e:  # pragma: no cover - 방어적
        logger.warning("create_notification_event 실패 (무시): %s", e)
        return None
