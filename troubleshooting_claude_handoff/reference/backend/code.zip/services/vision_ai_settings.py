"""Vision AI 전용 설정 해석 — Text AI(ai_settings)와 완전 분리.

이미지 포함 AI Report(Vision Report)는 vision 지원 모델이 필요하다. 이 모듈은
DB(`vision_ai_settings`) 저장값과 env(VISION_AI_* → OPENAI_VISION_* → Text fallback)를
우선순위대로 합성해 **effective config**를 만든다.

분리 보장
---------
- 이 모듈은 Text 설정(`ai_settings`)을 **읽지도 쓰지도 않는다**.
- 마지막 fallback 으로만 env `OPENAI_MODEL(S)`(Text 공용 env)을 참조하며, 이때 `using_text_fallback`
  플래그를 세워 UI 가 "Vision 전용 설정 없음 → Text 모델 fallback" 경고를 띄울 수 있게 한다.
- DB row 변경은 Vision 전용이므로 Text AI 동작에 영향이 없다.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.models import VisionAiSetting

# vision 입력(이미지)을 지원하는 것으로 알려진 모델. True=지원, False=미지원, None=알수없음.
VISION_SUPPORTED_MODELS: Dict[str, bool] = {
    "gpt-5.5": True,
    "gpt-5.4": True,
    "gpt-5.4-mini": True,
    "gpt-4.1": True,
    "gpt-4.1-mini": True,
    "gpt-4o": True,
    "gpt-4o-mini": True,
    "gpt-oss": False,
}

# vision 미지원이 명확한 모델(이름 휴리스틱). capability 미등록 모델 보조 판정.
_NON_VISION_HINTS = ("gpt-oss", "text-", "embedding", "whisper", "tts")

# 후보/기본 모델 env 미설정 시 fallback 기본값.
DEFAULT_VISION_MODELS = ["gpt-5.4-mini", "gpt-5.4", "gpt-5.5"]


def get_or_create_vision_ai_setting(db: Session) -> VisionAiSetting:
    """단일 Vision AI 설정 row 를 가져오거나 생성. (get_or_create_ai_setting 패턴)"""
    row = db.query(VisionAiSetting).order_by(VisionAiSetting.id.asc()).first()
    if not row:
        row = VisionAiSetting()
        db.add(row)
        db.commit()
        db.refresh(row)
    return row


def _split_models(raw: Optional[str]) -> List[str]:
    return [m.strip() for m in (raw or "").split(",") if m.strip()]


def vision_supported(model: Optional[str]) -> Optional[bool]:
    """모델의 vision 지원 여부. True/False/None(알수없음)."""
    key = (model or "").strip()
    if not key:
        return None
    if key in VISION_SUPPORTED_MODELS:
        return VISION_SUPPORTED_MODELS[key]
    low = key.lower()
    if any(h in low for h in _NON_VISION_HINTS):
        return False
    return None


def vision_ai_models() -> Dict[str, Any]:
    """vision 후보 모델 목록과 출처.

    우선순위: VISION_AI_MODELS → OPENAI_VISION_MODELS → (fallback) OPENAI_MODELS → 기본값.
    OPENAI_MODELS(Text 공용)로 떨어지면 using_text_fallback=True.

    Returns:
        {"models": [...], "source": str, "using_text_fallback": bool}
    """
    models = _split_models(getattr(settings, "vision_ai_models", ""))
    if models:
        return {"models": models, "source": "VISION_AI_MODELS", "using_text_fallback": False}

    models = _split_models(getattr(settings, "openai_vision_models", ""))
    if models:
        return {"models": models, "source": "OPENAI_VISION_MODELS", "using_text_fallback": False}

    models = _split_models(getattr(settings, "openai_models", ""))
    if models:
        return {"models": models, "source": "OPENAI_MODELS", "using_text_fallback": True}

    return {"models": list(DEFAULT_VISION_MODELS), "source": "default", "using_text_fallback": False}


def vision_ai_default_model(row: Optional[VisionAiSetting], model_list: List[str]) -> Dict[str, Any]:
    """기본 선택 모델과 출처.

    우선순위: DB row.model_name → VISION_AI_MODEL → OPENAI_VISION_MODEL → 목록 첫 번째 →
              (fallback) OPENAI_MODEL.

    Returns:
        {"model": str, "source": str, "using_text_fallback": bool}
    """
    db_model = (getattr(row, "model_name", "") or "").strip() if row is not None else ""
    if db_model:
        return {"model": db_model, "source": "db", "using_text_fallback": False}

    v_model = (getattr(settings, "vision_ai_model", "") or "").strip()
    if v_model:
        return {"model": v_model, "source": "VISION_AI_MODEL", "using_text_fallback": False}

    ov_model = (getattr(settings, "openai_vision_model", "") or "").strip()
    if ov_model:
        return {"model": ov_model, "source": "OPENAI_VISION_MODEL", "using_text_fallback": False}

    if model_list:
        return {"model": model_list[0], "source": "model_list", "using_text_fallback": False}

    o_model = (getattr(settings, "openai_model", "") or "").strip()
    if o_model:
        return {"model": o_model, "source": "OPENAI_MODEL", "using_text_fallback": True}

    return {"model": "", "source": "none", "using_text_fallback": False}


def capability_label(vision_supported: Any) -> str:
    """capability 값 → 사람이 읽는 라벨."""
    if vision_supported is True:
        return "vision 지원"
    if vision_supported == "candidate":
        return "vision 후보 / 사내 모델"
    if vision_supported is False:
        return "vision 미지원"
    return "vision 미상"


def _openai_provider_block(row: Optional[VisionAiSetting]) -> Dict[str, Any]:
    """OpenAI vision provider 블록(모델 목록/기본값/capability). 기존 로직 유지."""
    models_info = vision_ai_models()
    models = models_info["models"]
    default_info = vision_ai_default_model(row, models)

    model = default_info["model"]
    display_models = list(models)
    if model and model not in display_models:
        display_models = [model] + display_models

    capabilities = []
    for m in display_models:
        vs = vision_supported(m)
        capabilities.append({
            "key": m,
            "provider": "openai",
            "vision_supported": vs,
            "label": capability_label(vs),
        })

    using_text_fallback = bool(
        models_info["using_text_fallback"] or default_info["using_text_fallback"]
    )
    return {
        "key": "openai",
        "label": "OpenAI / 외부 API",
        "models": display_models,
        "model_capabilities": capabilities,
        "default_model": model,
        "models_source": models_info["source"],
        "default_model_source": default_info["source"],
        "using_text_fallback": using_text_fallback,
    }


def _dsllm_provider_block(row: Optional[VisionAiSetting]) -> Dict[str, Any]:
    """DSLLM(사내) vision provider 블록.

    현재는 DS/Gemma4 만 vision '후보'(candidate) 로 노출한다. 실제 image 처리는 미구현이므로
    vision_supported="candidate" 로 표시하고, 안내 note 를 포함한다.
    """
    from app.llm import dsllm_adapter

    candidate_keys = dsllm_adapter.vision_candidate_models()

    capabilities = []
    for m in candidate_keys:
        capabilities.append({
            "key": m,
            "provider": "dsllm",
            "vision_supported": "candidate",
            "label": "vision 후보 / 사내 모델",
            "note": dsllm_adapter.VISION_CANDIDATE_NOTE,
        })

    # 기본 모델: DB 저장값이 후보 목록에 있으면 그것, 아니면 첫 후보.
    db_model = (getattr(row, "model_name", "") or "").strip() if row is not None else ""
    default_model = db_model if db_model in candidate_keys else (candidate_keys[0] if candidate_keys else "")

    return {
        "key": "dsllm",
        "label": "DSLLM / 사내 모델",
        "models": list(candidate_keys),
        "model_capabilities": capabilities,
        "default_model": default_model,
        "models_source": "dsllm_candidate",
        "default_model_source": "dsllm_candidate",
        "using_text_fallback": False,
        # 실제 image payload 처리 구현 여부(미구현이면 vision-test 시 안내).
        "vision_payload_implemented": dsllm_adapter.supports_vision_payload(),
    }


def _resolve_int(db_value: Any, env_value: Any, default: int) -> int:
    """DB 우선 → env → default 순으로 양의 정수 해석."""
    for v in (db_value, env_value):
        try:
            iv = int(v)
            if iv > 0:
                return iv
        except (TypeError, ValueError):
            continue
    return default


def _dsllm_gpt_oss_default() -> str:
    """dsllm 후보 모델 중 GPT-OSS(텍스트 전용 fallback)로 보이는 key 를 추정.

    env VISION_AI_FALLBACK_TEXT_MODEL 미설정 시의 편의 기본값. 이름에 oss/gpt 가 들어간
    모델을 우선하고, 없으면 dsllm 기본 모델 key 를 쓴다. (실패해도 빈 문자열 반환)
    """
    try:
        from app.llm import dsllm_adapter
        keys = [m.get("key", "") for m in dsllm_adapter.get_available_models()]
    except Exception:
        return ""
    for k in keys:
        low = k.lower()
        if "oss" in low or "gpt" in low:
            return k
    return keys[0] if keys else ""


def resolve_fallback_config(row: Optional[VisionAiSetting]) -> Dict[str, Any]:
    """Vision Report 지연 시 텍스트 전용 fallback 설정(DB → env → 기본값).

    Returns:
        {enabled, provider, model, policy, model_source}
    fallback 은 일회성 실행 옵션이라, 이 값은 "선택지 제공용" 이지 Primary Vision 모델을 바꾸지 않는다.
    """
    db_enabled = getattr(row, "fallback_text_enabled", None) if row is not None else None
    enabled = (
        bool(getattr(settings, "vision_ai_fallback_text_enabled", True))
        if db_enabled is None else bool(db_enabled)
    )

    provider = (
        (getattr(row, "fallback_text_provider", "") or "").strip().lower() if row is not None else ""
    ) or (getattr(settings, "vision_ai_fallback_text_provider", "") or "").strip().lower() or "dsllm"
    if provider not in ("openai", "dsllm"):
        provider = "dsllm"

    db_model = (getattr(row, "fallback_text_model", "") or "").strip() if row is not None else ""
    env_model = (getattr(settings, "vision_ai_fallback_text_model", "") or "").strip()
    if db_model:
        model, source = db_model, "db"
    elif env_model:
        model, source = env_model, "VISION_AI_FALLBACK_TEXT_MODEL"
    elif provider == "dsllm":
        model, source = _dsllm_gpt_oss_default(), "dsllm_default"
    else:
        model, source = "", "none"

    policy = (
        (getattr(row, "fallback_policy", "") or "").strip() if row is not None else ""
    ) or (getattr(settings, "vision_ai_fallback_policy", "") or "").strip() or "ask_user_on_timeout"

    return {
        "enabled": enabled,
        "provider": provider,
        "model": model,
        "policy": policy,
        "model_source": source,
    }


def resolve_vision_ai_config(db: Session) -> Dict[str, Any]:
    """Vision AI effective config 합성(DB + env). 실제 모델 호출 없음.

    Returns dict with: provider, model, models, model_capabilities, enabled,
    max_output_tokens, batch_size, timeout_seconds, using_text_fallback, fallback_reason.
    """
    row = get_or_create_vision_ai_setting(db)

    # provider: DB → VISION_AI_PROVIDER(기본 openai). openai / dsllm 만 허용.
    provider = (
        (getattr(row, "provider", "") or "").strip()
        or (getattr(settings, "vision_ai_provider", "") or "").strip()
        or "openai"
    ).lower()
    if provider not in ("openai", "dsllm"):
        provider = "openai"

    # 두 provider 블록을 모두 만들어 UI 가 provider 전환 시 서버 왕복 없이 모델을 바꿀 수 있게 한다.
    openai_block = _openai_provider_block(row)
    dsllm_block = _dsllm_provider_block(row)
    blocks = {"openai": openai_block, "dsllm": dsllm_block}
    selected = blocks.get(provider, openai_block)

    # DSLLM 은 내부 모델이라 항상 선택 가능. openai 는 key/enable 여부에 따름.
    from app.llm import openai_adapter

    provider_available = {
        "openai": bool(getattr(settings, "enable_openai_provider", False)) or openai_adapter.is_configured(),
        "dsllm": True,
    }

    providers = []
    for key in ("openai", "dsllm"):
        b = blocks[key]
        providers.append({
            "key": b["key"],
            "label": b["label"],
            "available": provider_available[key],
            "models": b["models"],
            "model_capabilities": b["model_capabilities"],
            "default_model": b["default_model"],
        })

    # 선택 provider 의 유효 모델 = DB 저장값이 목록에 있으면 그것, 아니면 provider 기본.
    db_model = (getattr(row, "model_name", "") or "").strip()
    if db_model and db_model in selected["models"]:
        model = db_model
    else:
        model = selected["default_model"]

    # openai 만 Text fallback 개념이 있다(Vision 전용 설정 없음 → Text 모델 차용).
    using_text_fallback = bool(selected.get("using_text_fallback")) if provider == "openai" else False
    fallback_reason = None
    if using_text_fallback:
        fallback_reason = (
            "Vision 전용 모델 설정이 없어 Text AI 모델을 fallback으로 사용 중입니다. "
            "이미지 인식이 실패할 수 있습니다."
        )

    # enabled: DB(명시값) 우선, 없으면 env.
    db_enabled = getattr(row, "enabled", None)
    enabled = bool(getattr(settings, "vision_ai_enabled", True)) if db_enabled is None else bool(db_enabled)

    max_output_tokens = _resolve_int(
        getattr(row, "max_output_tokens", None),
        getattr(settings, "vision_ai_max_output_tokens", None),
        8000,
    )
    batch_size = _resolve_int(
        getattr(row, "batch_size", None),
        getattr(settings, "vision_ai_batch_size", None),
        6,
    )
    timeout_seconds = _resolve_int(
        getattr(row, "timeout_seconds", None),
        getattr(settings, "vision_ai_timeout_seconds", None),
        120,
    )
    # soft timeout: 이 시간 초과 시 FE 가 사용자 선택 modal(계속/텍스트전용/취소)을 띄운다.
    # hard(timeout_seconds) 보다 작아야 의미가 있으므로 hard-1 로 clamp.
    soft_timeout_seconds = _resolve_int(
        getattr(row, "soft_timeout_seconds", None),
        getattr(settings, "vision_ai_soft_timeout_seconds", None),
        60,
    )
    if soft_timeout_seconds >= timeout_seconds:
        soft_timeout_seconds = max(1, timeout_seconds - 1)

    fallback = resolve_fallback_config(row)

    return {
        "provider": provider,
        "provider_available": provider_available.get(provider, False),
        "providers": providers,
        "model": model,
        "models": selected["models"],
        "model_capabilities": selected["model_capabilities"],
        "enabled": enabled,
        "max_output_tokens": max_output_tokens,
        "batch_size": batch_size,
        "timeout_seconds": timeout_seconds,
        "soft_timeout_seconds": soft_timeout_seconds,
        # ── Fallback Text Model (Gemma4 지연/실패 시 텍스트 전용 보고서) ──
        "fallback_text_enabled": fallback["enabled"],
        "fallback_text_provider": fallback["provider"],
        "fallback_text_model": fallback["model"],
        "fallback_policy": fallback["policy"],
        "fallback_text_model_source": fallback["model_source"],
        "using_text_fallback": using_text_fallback,
        "fallback_reason": fallback_reason,
        "models_source": selected["models_source"],
        "default_model_source": selected["default_model_source"],
        # dsllm 선택 시 실제 image payload 처리 구현 여부(미구현이면 vision-test 안내).
        "vision_payload_implemented": (
            dsllm_block.get("vision_payload_implemented", False) if provider == "dsllm" else True
        ),
    }
