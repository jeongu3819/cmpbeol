"""Vision Image Observation / Context Link repository (provider 무관).

이미지의 **객관적 관찰 결과(ImageObservation)** 는 원본 SHA-256 + 모델/파이프라인/프롬프트/
전처리 버전 + detail_policy 로 캐시하고, **문맥 의존 해석(ImageContextLink)** 은 Task/작업노트
텍스트 hash 로 관리한다. 이 모듈은 DB 접근/해시만 담당하고, OpenAI/DSLLM adapter 에 의존하지
않는다(향후 Gemma4/GPT-OSS 에도 그대로 재사용).

읽기(read-through) 흐름은 호출부(Stage 1)가 담당한다. 여기서는 조회/저장 원자만 제공한다.
"""

from __future__ import annotations

import hashlib
import logging
from enum import Enum
from typing import Any, Dict, Iterable, List, Optional

from sqlalchemy.orm import Session

from app.models import VisionImageObservation, VisionImageContextLink

logger = logging.getLogger("main")

# ── 캐시 유효성 버전 ──────────────────────────────────────────────
# 파이프라인/프롬프트가 바뀌어 기존 관찰 결과를 재사용하면 안 될 때 올린다.
# (전처리 버전은 vision_image_preprocess.PREPROCESS_VERSION 를 그대로 쓴다.)
IMAGE_PIPELINE_VERSION = "img-pipeline-v1"
IMAGE_OBSERVATION_PROMPT_VERSION = "img-observation-prompt-v1"

# detail_policy: 관찰 상세도 정책(예: standard / high_text). 현재 단일 기본값.
DEFAULT_DETAIL_POLICY = "standard"

# cache read rollout 모드.
CACHE_ROLLOUT_MODES = ("off", "canary", "all")


def is_cache_read_active(
    *,
    enabled: bool,
    cache_read_enabled: bool,
    rollout_mode: Optional[str],
    canary_ids,
    project_id: int,
) -> bool:
    """이 프로젝트에서 cache read 를 켤지 판정한다(rollout mode 반영).

    - enabled/cache_read_enabled 둘 중 하나라도 false → 항상 off.
    - mode=all → 모든 프로젝트 on(canary_ids 무시).
    - mode=canary → project_id 가 canary_ids 에 있으면 on.
    - mode=off / 미설정 / 잘못된 값 → off(안전).
    """
    if not (enabled and cache_read_enabled):
        return False
    mode = (rollout_mode or "off").strip().lower()
    if mode == "all":
        return True
    if mode == "canary":
        return project_id in (canary_ids or set())
    return False


def compute_image_sha256(data: bytes) -> str:
    """원본 이미지 바이트의 SHA-256(hex). 캐시 키의 이미지 식별자."""
    return hashlib.sha256(data or b"").hexdigest()


def compute_source_text_hash(*parts: Optional[str]) -> str:
    """Task/작업노트/인접 텍스트/caption 등을 합쳐 SHA-256(hex).

    이 값이 바뀌면(=문맥 텍스트 변경) ImageObservation 은 유지하되 ContextLink 만 재생성한다.
    None/공백은 무시하고, 순서를 보존해 결합한다.
    """
    h = hashlib.sha256()
    for p in parts:
        if p is None:
            continue
        h.update(str(p).strip().encode("utf-8", "ignore"))
        h.update(b"\x1f")  # 구분자(필드 경계 충돌 방지)
    return h.hexdigest()


# ── ImageObservation ─────────────────────────────────────────────
def find_valid_observation(
    db: Session,
    *,
    image_sha256: str,
    provider: str,
    model_name: str,
    pipeline_version: str,
    prompt_version: str,
    preprocessing_version: str,
    detail_policy: str,
    statuses: Iterable[str] = ("completed",),
) -> Optional[VisionImageObservation]:
    """캐시 유효 조건이 모두 일치하는 관찰 결과를 반환(없으면 None).

    이미지 hash 만이 아니라 provider/model/버전/detail_policy 까지 일치해야 재사용한다.
    기본적으로 status='completed' 만 hit 으로 본다(실패 row 는 재분석되도록 miss 처리).
    """
    q = (
        db.query(VisionImageObservation)
        .filter(
            VisionImageObservation.image_sha256 == image_sha256,
            VisionImageObservation.provider == provider,
            VisionImageObservation.model_name == model_name,
            VisionImageObservation.pipeline_version == pipeline_version,
            VisionImageObservation.prompt_version == prompt_version,
            VisionImageObservation.preprocessing_version == preprocessing_version,
            VisionImageObservation.detail_policy == detail_policy,
        )
    )
    status_list = list(statuses or [])
    if status_list:
        q = q.filter(VisionImageObservation.status.in_(status_list))
    return q.order_by(VisionImageObservation.id.desc()).first()


def upsert_observation(
    db: Session,
    *,
    image_sha256: str,
    provider: str,
    model_name: str,
    pipeline_version: str,
    prompt_version: str,
    preprocessing_version: str,
    detail_policy: str,
    observation_json: Any,
    image_type: Optional[str] = None,
    overall_confidence: Optional[float] = None,
    needs_raw_review: bool = False,
    original_width: Optional[int] = None,
    original_height: Optional[int] = None,
    original_bytes: Optional[int] = None,
    processed_width: Optional[int] = None,
    processed_height: Optional[int] = None,
    processed_bytes: Optional[int] = None,
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
    latency_ms: Optional[int] = None,
    status: str = "completed",
    error_message: Optional[str] = None,
    commit: bool = True,
) -> VisionImageObservation:
    """관찰 결과를 저장한다. 동일 캐시 키 row 가 있으면 갱신(구버전은 버전이 달라 공존).

    Returns 저장된 VisionImageObservation.
    """
    row = find_valid_observation(
        db,
        image_sha256=image_sha256,
        provider=provider,
        model_name=model_name,
        pipeline_version=pipeline_version,
        prompt_version=prompt_version,
        preprocessing_version=preprocessing_version,
        detail_policy=detail_policy,
        statuses=(),  # 상태 무관하게 동일 키 row 를 찾아 갱신
    )
    if row is None:
        row = VisionImageObservation(
            image_sha256=image_sha256,
            provider=provider,
            model_name=model_name,
            pipeline_version=pipeline_version,
            prompt_version=prompt_version,
            preprocessing_version=preprocessing_version,
            detail_policy=detail_policy,
        )
        db.add(row)

    row.observation_json = observation_json
    row.image_type = image_type
    row.overall_confidence = overall_confidence
    row.needs_raw_review = bool(needs_raw_review)
    row.original_width = original_width
    row.original_height = original_height
    row.original_bytes = original_bytes
    row.processed_width = processed_width
    row.processed_height = processed_height
    row.processed_bytes = processed_bytes
    row.input_tokens = input_tokens
    row.output_tokens = output_tokens
    row.latency_ms = latency_ms
    row.status = status
    row.error_message = error_message

    if commit:
        db.commit()
        db.refresh(row)
    else:
        db.flush()
    return row


# ── ImageContextLink ─────────────────────────────────────────────
def find_context_link(
    db: Session,
    *,
    observation_id: int,
    task_id: int,
    source_text_hash: str,
    prompt_version: str,
) -> Optional[VisionImageContextLink]:
    """관찰 결과 + Task + 텍스트 hash + 프롬프트 버전이 일치하는 문맥 링크 반환(없으면 None)."""
    return (
        db.query(VisionImageContextLink)
        .filter(
            VisionImageContextLink.observation_id == observation_id,
            VisionImageContextLink.task_id == task_id,
            VisionImageContextLink.source_text_hash == source_text_hash,
            VisionImageContextLink.prompt_version == prompt_version,
        )
        .order_by(VisionImageContextLink.id.desc())
        .first()
    )


def diagnose_context_link_miss(
    db: Session,
    *,
    observation_id: int,
    task_id: int,
    source_text_hash: str,
    prompt_version: str,
) -> str:
    """exact ContextLink 이 없을 때 miss 원인을 분류한다(진단/집계용).

    반환: source_text_hash_mismatch / prompt_version_mismatch / identity_mismatch.
    """
    rows = (
        db.query(VisionImageContextLink)
        .filter(
            VisionImageContextLink.observation_id == observation_id,
            VisionImageContextLink.task_id == task_id,
        )
        .all()
    )
    if not rows:
        return "identity_mismatch"  # 이 관찰/Task 조합의 링크 자체가 없음
    # 같은 prompt_version 링크가 있는데 exact 가 아니면 텍스트(hash) 변경으로 본다.
    if any((r.prompt_version == prompt_version) for r in rows):
        return "source_text_hash_mismatch"
    return "prompt_version_mismatch"


def upsert_context_link(
    db: Session,
    *,
    observation_id: int,
    project_id: int,
    task_id: int,
    canonical_image_id: str,
    source_text_hash: str,
    evidence_type: str,
    prompt_version: str,
    note_id: Optional[int] = None,
    relation_type: Optional[str] = None,
    task_relevance: Optional[str] = None,
    supports_json: Any = None,
    contradictions_json: Any = None,
    context_summary: Optional[str] = None,
    confidence: Optional[float] = None,
    model_name: Optional[str] = None,
    commit: bool = True,
) -> VisionImageContextLink:
    """문맥 링크를 저장한다. (observation_id, task_id, source_text_hash, prompt_version)
    동일 조합이 있으면 갱신, 없으면 생성."""
    row = find_context_link(
        db,
        observation_id=observation_id,
        task_id=task_id,
        source_text_hash=source_text_hash,
        prompt_version=prompt_version,
    )
    if row is None:
        row = VisionImageContextLink(
            observation_id=observation_id,
            task_id=task_id,
            source_text_hash=source_text_hash,
            prompt_version=prompt_version,
        )
        db.add(row)

    row.project_id = project_id
    row.note_id = note_id
    row.canonical_image_id = canonical_image_id
    row.relation_type = relation_type
    row.evidence_type = evidence_type
    row.task_relevance = task_relevance
    row.supports_json = supports_json
    row.contradictions_json = contradictions_json
    row.context_summary = context_summary
    row.confidence = confidence
    row.model_name = model_name

    if commit:
        db.commit()
        db.refresh(row)
    else:
        db.flush()
    return row


# ── Shadow Write (2b-1) ──────────────────────────────────────────
# 기존 Stage 1 evidence 를 그대로 두고(=source of truth 불변), 같은 정보를 신규 캐시 구조에도
# 저장한다. **추가 LLM 호출 없이** 기존 evidence 필드만 재구성한다(이미지별 Text LLM 호출 금지).

# ── task_relevance 정규화 (enum 계약) ────────────────────────────
# task_relevance 컬럼은 짧은 등급값(VARCHAR(20))이다. 모델이 등급 대신 설명 문장을 반환해도
# 여기서 high/medium/low/unknown 으로 정규화한 뒤 저장한다(원본 설명은 context_summary 로 보존).
TASK_RELEVANCE_VALUES = ("high", "medium", "low", "unknown")
_EVIDENCE_TYPE_RELEVANCE = {
    "direct": "high",
    "supporting": "medium",
    "reference": "low",
    "unrelated": "low",
    "unreadable": "unknown",
}
# 모델이 등급 대신 설명 문장을 준 경우 보조로 검사할 키워드(순서=우선순위).
_RELEVANCE_KEYWORDS = (
    ("high", ("직접 관련", "직접적", "직접 근거", "핵심 근거", "강한 관련", "매우 관련")),
    ("medium", ("보조", "부분적", "어느 정도", "간접", "참고 겸")),
    ("low", ("관련성 낮", "관련성이 낮", "약한 관련", "참고자료", "참고 자료", "참고 근거", "단순 참고", "낮음")),
)


def normalize_task_relevance(raw_value: object, *, evidence_type: Optional[str] = None) -> str:
    """task_relevance 를 high/medium/low/unknown 중 하나로 정규화한다.

    우선순위: (1) 모델이 정확한 등급을 주면 그대로 → (2) evidence_type 매핑 →
    (3) raw 문구 키워드 보조 검사 → (4) 판단 불가 시 unknown.
    """
    # 1) 정확한 등급값
    if raw_value is not None:
        v = str(raw_value).strip().lower()
        if v in TASK_RELEVANCE_VALUES:
            return v
    # 2) evidence_type 기준 매핑
    if evidence_type:
        et = str(evidence_type).strip().lower()
        if et in _EVIDENCE_TYPE_RELEVANCE:
            return _EVIDENCE_TYPE_RELEVANCE[et]
    # 3) raw 설명 문구의 키워드 보조 검사
    if raw_value is not None:
        text = str(raw_value)
        for level, kws in _RELEVANCE_KEYWORDS:
            if any(k in text for k in kws):
                return level
    # 4) 판단 불가
    return "unknown"


def build_context_summary(interpretation: Optional[str], relevance_reason: Optional[str]) -> Optional[str]:
    """interpretation 과 원본 task_relevance 설명을 중복 없이 합쳐 context_summary 를 만든다."""
    a = (interpretation or "").strip()
    b = (relevance_reason or "").strip()
    if a and b:
        if a == b or b in a:
            return a
        if a in b:
            return b
        return a + " " + b
    return a or b or None


def _clip(value: Optional[str], limit: int) -> Optional[str]:
    """VARCHAR 컬럼 방어용 길이 제한(정규화 대상 외 필드가 예기치 않게 길어지는 것 방지)."""
    if value is None:
        return None
    s = str(value)
    return s[:limit] if len(s) > limit else s


def build_observation_json(ev: Dict[str, Any], image_type: Optional[str] = None) -> Dict[str, Any]:
    """Stage 1 evidence → ImageObservation(문맥 독립) JSON. evidence_type/task_relevance 는 넣지 않는다."""
    uncertainty = (ev.get("uncertainty") or "").strip()
    return {
        "image_id": ev.get("image_id"),
        "image_type": image_type or ev.get("image_role_hint"),
        "visible_facts": ev.get("visible_facts") or [],
        "visible_text": ev.get("visible_text") or [],
        # shadow 단계에서는 interpretation 을 그대로 보관한다(객관/문맥 정제는 read 단계에서).
        "interpretation": (ev.get("interpretation") or "").strip() or None,
        "warnings": [uncertainty] if uncertainty else [],
    }


def _new_shadow_stats() -> Dict[str, Any]:
    return {
        "images_attempted": 0,
        "observations_inserted": 0,
        "observations_updated": 0,   # reuse 정책이라 항상 0(스키마 호환용)
        "observations_reused": 0,
        "context_links_inserted": 0,
        "context_links_updated": 0,  # reuse 정책이라 항상 0
        "context_links_reused": 0,
        "observation_failures": 0,
        "context_link_failures": 0,
        "shadow_mapped": 0,
        "first_error_stage": None,
        "first_error_type": None,
        "first_error_message": None,
        "shadow_write_elapsed_ms": 0,
    }


def shadow_write_from_evidence(
    db: Session,
    *,
    evidence_items: List[Dict[str, Any]],
    image_meta_by_id: Dict[str, Dict[str, Any]],
    provider: str,
    model_name: str,
    project_id: int,
    context_link_enabled: bool = True,
) -> Dict[str, Any]:
    """기존 evidence 를 ImageObservation/ContextLink 로 저장(best-effort, 격리 세션 권장).

    2b-1R 수정:
    - **이미지 단위 트랜잭션**(commit/rollback) — 한 이미지 실패가 세션을 오염시켜 나머지가
      연쇄 실패하던 문제 해결(첫 flush 오류 후 rollback 없이 계속 진행하던 버그).
    - **reuse 정책**: 동일 캐시키의 completed Observation 이 있으면 재사용(덮어쓰지 않음) →
      재실행 시 row 증가 없음.
    - Observation/ContextLink 실패를 분리 집계, 첫 예외는 stage/type/message + exc_info 로 기록
      (원본 SHA 전체·연결정보는 남기지 않고 hash 앞 8자리만).
    - 추가 LLM 호출 없음. 예외는 전파하지 않는다.
    """
    import time

    stats = _new_shadow_stats()
    t0 = time.perf_counter()
    pre_ver = _preprocess_version()

    # image_id 단위로 evidence 묶기(대개 1:1, 같은 이미지가 여러 Task면 여러 링크).
    by_image: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []
    for ev in evidence_items or []:
        if not isinstance(ev, dict):
            continue
        iid = str(ev.get("image_id")) if ev.get("image_id") is not None else None
        if not iid:
            continue
        meta = image_meta_by_id.get(iid)
        if not (meta or {}).get("sha256"):
            continue
        if iid not in by_image:
            by_image[iid] = {"meta": meta, "evs": []}
            order.append(iid)
        by_image[iid]["evs"].append(ev)

    def _record_first_error(stage: str, exc: Exception, iid: str, sha: str) -> None:
        if stats["first_error_stage"] is None:
            stats["first_error_stage"] = stage
            stats["first_error_type"] = type(exc).__name__
            stats["first_error_message"] = str(exc)[:300]
            # 첫 예외만 full stack. 원본 SHA/연결문자열은 남기지 않는다(hash 앞 8자리만).
            logger.exception(
                "[VisionReport] shadow persistence failed: stage=%s image_id=%s hash_prefix=%s "
                "exception_type=%s table=%s",
                stage, iid, (sha or "")[:8], type(exc).__name__,
                "vision_image_observations" if stage == "observation_upsert"
                else "vision_image_context_links",
            )

    for iid in order:
        stats["images_attempted"] += 1
        meta = by_image[iid]["meta"] or {}
        evs = by_image[iid]["evs"]
        sha = meta.get("sha256")
        rep_ev = evs[0]
        # image_type 은 짧은 role 이지만, 모델의 image_role_hint 로 fallback 시 길 수 있어 방어 clip.
        image_type = _clip(meta.get("image_role") or rep_ev.get("image_role_hint"), 50)
        stage = "observation_upsert"
        # 이미지 단위 임시 카운트 — commit 성공 후에만 stats 에 반영한다(rollback 된 쓰기는 세지 않음).
        d_obs_ins = d_obs_reuse = d_ctx_ins = d_ctx_reuse = 0
        try:
            # ── Observation: 있으면 재사용(reuse), 없으면 insert ──
            obs = find_valid_observation(
                db, image_sha256=sha, provider=provider, model_name=model_name,
                pipeline_version=IMAGE_PIPELINE_VERSION,
                prompt_version=IMAGE_OBSERVATION_PROMPT_VERSION,
                preprocessing_version=pre_ver, detail_policy=DEFAULT_DETAIL_POLICY,
                statuses=("completed",),
            )
            if obs is not None:
                d_obs_reuse = 1
            else:
                obs = VisionImageObservation(
                    image_sha256=sha, provider=provider, model_name=model_name,
                    pipeline_version=IMAGE_PIPELINE_VERSION,
                    prompt_version=IMAGE_OBSERVATION_PROMPT_VERSION,
                    preprocessing_version=pre_ver, detail_policy=DEFAULT_DETAIL_POLICY,
                    observation_json=build_observation_json(rep_ev, image_type),
                    image_type=image_type,
                    overall_confidence=None,
                    needs_raw_review=(rep_ev.get("evidence_type") == "unreadable"),
                    status="completed",
                    original_width=meta.get("original_width"),
                    original_height=meta.get("original_height"),
                    original_bytes=meta.get("original_bytes"),
                    processed_width=meta.get("processed_width"),
                    processed_height=meta.get("processed_height"),
                    processed_bytes=meta.get("processed_bytes"),
                )
                db.add(obs)
                db.flush()  # obs.id 확보
                d_obs_ins = 1

            # ── ContextLink: Task별로 있으면 reuse, 없으면 insert ──
            if context_link_enabled:
                stage = "context_link_upsert"
                seen_tasks: set = set()
                for ev in evs:
                    tid = ev.get("task_id")
                    if tid is None or tid in seen_tasks:
                        continue
                    seen_tasks.add(tid)
                    # source_text_hash 는 endpoint 가 manifest(task_title/description/nearby note)로
                    # 계산해 meta 로 넘긴 값을 우선 사용(read 와 정확히 동일 입력). 없으면 title 기반 fallback.
                    sth = meta.get("source_text_hash") or compute_source_text_hash(
                        ev.get("task_title"), str(tid)
                    )
                    existing = find_context_link(
                        db, observation_id=obs.id, task_id=int(tid),
                        source_text_hash=sth, prompt_version=IMAGE_OBSERVATION_PROMPT_VERSION,
                    )
                    if existing is not None:
                        d_ctx_reuse += 1
                        continue
                    db.add(VisionImageContextLink(
                        observation_id=obs.id, project_id=project_id, task_id=int(tid),
                        canonical_image_id=_clip(iid, 500), source_text_hash=sth,
                        evidence_type=_clip(ev.get("evidence_type") or "reference", 20),
                        prompt_version=IMAGE_OBSERVATION_PROMPT_VERSION,
                        # 모델이 등급 대신 설명 문장을 반환해도 enum 으로 정규화(원본 설명은 아래 summary 로 보존).
                        task_relevance=normalize_task_relevance(
                            ev.get("task_relevance"), evidence_type=ev.get("evidence_type")
                        ),
                        context_summary=build_context_summary(
                            ev.get("interpretation"), ev.get("task_relevance")
                        ),
                        model_name=model_name,
                    ))
                    d_ctx_ins += 1

            db.commit()  # 이미지 1장 = 1 트랜잭션. 여기까지 오면 성공.
            # commit 성공 후에만 반영(정확한 통계).
            stats["observations_inserted"] += d_obs_ins
            stats["observations_reused"] += d_obs_reuse
            stats["context_links_inserted"] += d_ctx_ins
            stats["context_links_reused"] += d_ctx_reuse
            stats["shadow_mapped"] += 1
        except Exception as exc:
            db.rollback()  # ★ 핵심: 실패 시 세션을 정리해 다음 이미지가 연쇄 실패하지 않게 한다.
            if stage == "observation_upsert":
                stats["observation_failures"] += 1
            else:
                stats["context_link_failures"] += 1
            _record_first_error(stage, exc, iid, sha)
            continue

    stats["shadow_write_elapsed_ms"] = int((time.perf_counter() - t0) * 1000)
    return stats


def _preprocess_version() -> str:
    """전처리 버전(캐시 무효화 키). import 순환을 피해 지연 import."""
    try:
        from app.services.vision_image_preprocess import PREPROCESS_VERSION
        return PREPROCESS_VERSION
    except Exception:
        return "preprocess-unknown"


# ── 2b-1Q Cache Quality Gate ─────────────────────────────────────
# 캐시를 "읽어도 되는지" 판정만 한다(이번 단계는 read 하지 않음, CACHE_READ=false 유지).
# 판정 결과만 반환하고 자동 재분석은 하지 않는다(실제 fallback 은 2b-2a).

class ObservationUsability(str, Enum):
    USABLE = "usable"                          # 그대로 캐시 재사용
    USABLE_WITH_WARNING = "usable_with_warning"  # 재사용하되 warnings/limitations 전달
    RAW_REVIEW_REQUIRED = "raw_review_required"  # 원본 Vision 재분석 대상(판정만)
    INVALID = "invalid"                        # 캐시 hit 로 사용 금지


# observation_json 에 있으면 안 되는 문맥 의존 키(있으면 계약 위반 → invalid).
_CONTEXT_LEAK_KEYS = ("evidence_type", "task_relevance", "supports", "context_summary")
# 저신뢰로 보아 경고 처리하는 confidence 기준(이 미만이면 usable_with_warning).
_LOW_CONFIDENCE_THRESHOLD = 0.75

_ALLOWED_EVIDENCE_TYPES = ("direct", "supporting", "reference", "unrelated", "unreadable")


def evaluate_observation_usability(
    observation: Any,
    *,
    expected_provider: str,
    expected_model: str,
    expected_pipeline_version: str,
    expected_prompt_version: str,
    expected_preprocessing_version: str,
    expected_detail_policy: str,
) -> ObservationUsability:
    """저장된 Observation 이 캐시로 재사용 가능한 상태인지 4단계로 판정한다."""
    o = observation
    if o is None:
        return ObservationUsability.INVALID

    # ── invalid: 하드 실패(캐시 hit 금지) ──
    if (getattr(o, "status", None) or "") != "completed":
        return ObservationUsability.INVALID
    if (
        getattr(o, "provider", None) != expected_provider
        or getattr(o, "model_name", None) != expected_model
        or getattr(o, "pipeline_version", None) != expected_pipeline_version
        or getattr(o, "prompt_version", None) != expected_prompt_version
        or getattr(o, "preprocessing_version", None) != expected_preprocessing_version
        or getattr(o, "detail_policy", None) != expected_detail_policy
    ):
        return ObservationUsability.INVALID
    oj = getattr(o, "observation_json", None)
    if not isinstance(oj, dict):
        return ObservationUsability.INVALID
    # 이미지 관찰값에 Task 문맥 판단이 섞이면 계약 위반.
    if any(k in oj for k in _CONTEXT_LEAK_KEYS):
        return ObservationUsability.INVALID
    vf = oj.get("visible_facts")
    if vf is not None and not isinstance(vf, list):
        return ObservationUsability.INVALID
    image_type = (getattr(o, "image_type", None) or oj.get("image_type") or "").strip()
    if not image_type:
        return ObservationUsability.INVALID

    visible_facts = vf or []
    interpretation = (oj.get("interpretation") or "").strip()

    # ── raw_review_required: 판정만(자동 재분석 없음) ──
    if bool(getattr(o, "needs_raw_review", False)):
        return ObservationUsability.RAW_REVIEW_REQUIRED
    if image_type.lower() == "unreadable":
        return ObservationUsability.RAW_REVIEW_REQUIRED
    if not visible_facts and not interpretation:
        return ObservationUsability.RAW_REVIEW_REQUIRED

    # ── usable_with_warning: 재사용하되 경고 전달 ──
    warnings = oj.get("warnings") or []
    conf = getattr(o, "overall_confidence", None)
    if warnings or (conf is not None and conf < _LOW_CONFIDENCE_THRESHOLD):
        return ObservationUsability.USABLE_WITH_WARNING

    return ObservationUsability.USABLE


def is_usable_observation(observation: Any, **expected: str) -> bool:
    """usable / usable_with_warning 이면 True(캐시 재사용 가능). raw_review/invalid 는 False."""
    u = evaluate_observation_usability(observation, **expected)
    return u in (ObservationUsability.USABLE, ObservationUsability.USABLE_WITH_WARNING)


# ── 2b-2a Read-through: 캐시 → legacy evidence 변환 / 병합 ────────
def build_uncertainty_from_observation(observation: Any) -> Optional[str]:
    """Observation 의 warnings 를 legacy evidence 의 uncertainty 문자열로 합친다."""
    oj = getattr(observation, "observation_json", None) or {}
    warnings = oj.get("warnings") or []
    if isinstance(warnings, list):
        parts = [str(w).strip() for w in warnings if str(w).strip()]
        return "; ".join(parts) or None
    s = str(warnings).strip()
    return s or None


def build_legacy_evidence_from_cache(
    *,
    image_id: Any,
    task_id: Any,
    task_title: Any,
    image_role: Any,
    observation: Any,
    context_link: Any,
) -> Dict[str, Any]:
    """캐시된 Observation + ContextLink → 기존 Stage 1 evidence schema.

    image_id/task_id/task_title/image_role 은 **현재 manifest 값**을 쓴다(캐시의 옛 Task 값으로
    덮어쓰지 않는다). 관찰값(visible_facts/interpretation)은 Observation, 문맥값
    (evidence_type/task_relevance)은 ContextLink 에서 가져온다.
    """
    oj = getattr(observation, "observation_json", None) or {}
    return {
        "image_id": image_id,
        "task_id": task_id,
        "task_title": task_title,
        "image_role_hint": image_role or oj.get("image_type"),
        "visible_facts": oj.get("visible_facts") or [],
        "visible_text": oj.get("visible_text") or [],
        "interpretation": (oj.get("interpretation") or ""),
        "task_relevance": getattr(context_link, "task_relevance", None),
        "evidence_type": getattr(context_link, "evidence_type", None),
        "uncertainty": build_uncertainty_from_observation(observation),
        "_from_cache": True,
    }


def build_legacy_evidence_from_regen(
    *,
    image_id: Any,
    task_id: Any,
    task_title: Any,
    image_role: Any,
    observation: Any,
    regen_result: Dict[str, Any],
) -> Dict[str, Any]:
    """캐시 Observation(객관) + Text 재생성 문맥(regen_result) → 기존 evidence schema (2b-2b).

    이미지 원본을 다시 보내지 않고, evidence_type/task_relevance/interpretation(=context_summary)만
    새 문맥으로 채운다. identity(image_id/task_id/...)는 manifest 값 사용.
    """
    oj = getattr(observation, "observation_json", None) or {}
    return {
        "image_id": image_id,
        "task_id": task_id,
        "task_title": task_title,
        "image_role_hint": image_role or oj.get("image_type"),
        "visible_facts": oj.get("visible_facts") or [],
        "visible_text": oj.get("visible_text") or [],
        "interpretation": (regen_result.get("context_summary") or oj.get("interpretation") or ""),
        "task_relevance": regen_result.get("task_relevance"),
        "evidence_type": regen_result.get("evidence_type"),
        "uncertainty": build_uncertainty_from_observation(observation),
        "_from_cache": True,
        "_context_regenerated": True,
    }


def merge_evidence_by_manifest_order(
    image_id_order: List[Any],
    cached_evidence: List[Dict[str, Any]],
    fresh_evidence: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """cached + fresh evidence 를 manifest 순서로 정렬(image_id 중복 제거, cached 우선).

    - 같은 image_id 는 한 번만(먼저 온 것=cached 우선). 실제로는 hit/miss 가 배타적이라 충돌 없음.
    - image_id 없는 orphan evidence 는 뒤에 붙인다(순서 안정).
    """
    order_index = {str(iid): i for i, iid in enumerate(image_id_order)}
    seen: set = set()
    merged: List[Dict[str, Any]] = []
    for ev in list(cached_evidence or []) + list(fresh_evidence or []):
        if not isinstance(ev, dict):
            continue
        iid = ev.get("image_id")
        key = str(iid) if iid is not None else None
        if key is not None:
            if key in seen:
                continue
            seen.add(key)
        merged.append(ev)
    merged.sort(key=lambda ev: order_index.get(str(ev.get("image_id")), len(order_index)))
    return merged


def is_usable_context_link(
    context_link: Any,
    *,
    observation_id: int,
    project_id: int,
    task_id: int,
    canonical_image_id: str,
    source_text_hash: str,
    prompt_version: str,
) -> bool:
    """ContextLink 가 현재 문맥과 정확히 일치하고 스키마가 정상이면 True(exact match)."""
    c = context_link
    if c is None:
        return False
    if getattr(c, "observation_id", None) != observation_id:
        return False
    if getattr(c, "project_id", None) != project_id:
        return False
    if getattr(c, "task_id", None) != task_id:
        return False
    if str(getattr(c, "canonical_image_id", None)) != str(canonical_image_id):
        return False
    if getattr(c, "source_text_hash", None) != source_text_hash:
        return False
    if getattr(c, "prompt_version", None) != prompt_version:
        return False
    if (getattr(c, "evidence_type", None) or "") not in _ALLOWED_EVIDENCE_TYPES:
        return False
    if (getattr(c, "task_relevance", None) or "") not in TASK_RELEVANCE_VALUES:
        return False
    cs = getattr(c, "context_summary", None)
    if cs is not None and not isinstance(cs, str):
        return False
    return True
