"""
운영 확인용 시스템 이벤트 로그 헬퍼.

설계 원칙
- 모든 요청을 저장하지 않는다. 장애/오류/백업 등 "요약 이벤트"만 저장한다.
- 민감정보(토큰/비밀번호/쿠키/Authorization 헤더/request body 전문/DSLLM 프롬프트/파일 내용)는
  애초에 인자로 받지 않는다. 호출부에서 요약 message/detail만 넘긴다.
- 절대 호출부로 예외를 던지지 않는다. (로깅 실패가 서비스에 영향 주지 않도록)
- 자체 SessionLocal 세션을 열어 사용한다. → 요청 핸들러의 트랜잭션/롤백, 미들웨어,
  스케줄러 어디에서 호출해도 안전하다.

request_id
- 미들웨어가 요청마다 new_request_id()를 생성해 ContextVar에 set 한다.
- log_event() 호출 시 request_id 인자를 생략하면 ContextVar의 현재 값을 사용한다.
"""

import uuid
import logging
from contextvars import ContextVar
from datetime import datetime, timedelta, timezone

logger = logging.getLogger("system_log")

KST = timezone(timedelta(hours=9))

# 요청 단위 추적 ID. 미들웨어 밖(스케줄러 등)에서는 빈 문자열.
request_id_ctx: ContextVar[str] = ContextVar("request_id", default="")

# 컬럼 길이 보호용 상한
_MSG_MAX = 500
_DETAIL_MAX = 4000
_DETAIL_JSON_MAX = 8000  # 구조화 진단 JSON(비민감 지표만) 저장 상한
_ENDPOINT_MAX = 300
_LOGIN_MAX = 128
_REQID_MAX = 40

VALID_LEVELS = {"INFO", "WARNING", "ERROR", "CRITICAL"}
# VISION_AI = Vision Report / DSLLM vision / ContextLink 재생성 진단(세부는 detail_json.failure_stage).
VALID_CATEGORIES = {
    "API", "DB", "S3", "KNOX", "DSLLM", "BACKUP", "AUTH", "FRONTEND", "ADMIN", "SPACE", "VISION_AI",
}

# §11 중복 저장 방지: 한 요청에서 같은 (request_id, dedupe_key) 는 1건만 저장한다.
# 워커 로컬 bounded set(같은 예외를 여러 계층에서 잡아도 한 건만). request_id 가 유일하므로 충돌 없음.
from collections import OrderedDict as _OrderedDict

_DEDUPE_MAX = 1024
_recent_dedupe: "_OrderedDict[str, bool]" = _OrderedDict()


def _dedupe_seen(key: str) -> bool:
    """key 가 최근에 저장됐으면 True(중복). 아니면 등록 후 False."""
    if not key:
        return False
    if key in _recent_dedupe:
        return True
    _recent_dedupe[key] = True
    if len(_recent_dedupe) > _DEDUPE_MAX:
        _recent_dedupe.popitem(last=False)
    return False


def new_request_id() -> str:
    """REQ-YYYYMMDD-XXXXXXXX 형식의 요청 추적 ID 생성."""
    date_str = datetime.now(KST).strftime("%Y%m%d")
    rand = uuid.uuid4().hex[:8].upper()
    return f"REQ-{date_str}-{rand}"


def current_request_id() -> str:
    """현재 요청의 request_id (없으면 빈 문자열)."""
    try:
        return request_id_ctx.get()
    except Exception:
        return ""


def _trunc(value, limit):
    if value is None:
        return None
    try:
        s = str(value)
    except Exception:
        return None
    return s[:limit]


def log_event(
    level: str,
    category: str,
    message: str,
    *,
    detail=None,
    detail_json=None,
    endpoint=None,
    method=None,
    status_code=None,
    user_id=None,
    login_id=None,
    request_id=None,
    resolved=None,
    dedupe_key=None,
):
    """system_event_logs 에 요약 이벤트 1건 적재. 절대 예외를 던지지 않는다.

    민감정보(토큰/헤더/바디 전문 등)는 인자에 넘기지 말 것. 요약 텍스트/비민감 지표만 전달한다.

    Args:
        detail_json: 구조화 진단 JSON **문자열**(비민감 지표만). detail_json 컬럼에 저장.
        resolved: 명시하면 그 값으로, None 이면 level 기준(ERROR/CRITICAL=False, 그 외=True).
        dedupe_key: 있으면 (request_id, dedupe_key) 기준으로 한 요청당 1건만 저장(§11).
    """
    try:
        # 지연 import (순환 import 및 환경 로드 순서 안전)
        from app.db_connections.sqlalchemy import SessionLocal
        from app.models import SystemEventLog

        lvl = (level or "ERROR").upper()
        if lvl not in VALID_LEVELS:
            lvl = "ERROR"
        cat = (category or "API").upper()
        if cat not in VALID_CATEGORIES:
            cat = "API"

        rid = request_id if request_id is not None else current_request_id()

        if dedupe_key and _dedupe_seen(f"{rid}|{dedupe_key}"):
            return

        # §7 처리 여부 기본 정책: ERROR/CRITICAL=미처리(False), INFO/WARNING=처리됨(True).
        if resolved is None:
            resolved_val = lvl in ("ERROR", "CRITICAL")
            resolved_val = not resolved_val  # ERROR/CRITICAL → False, 그 외 → True
        else:
            resolved_val = bool(resolved)

        row = SystemEventLog(
            level=lvl,
            category=cat,
            message=_trunc(message, _MSG_MAX) or "",
            detail=_trunc(detail, _DETAIL_MAX),
            detail_json=_trunc(detail_json, _DETAIL_JSON_MAX),
            endpoint=_trunc(endpoint, _ENDPOINT_MAX),
            method=_trunc(method, 10),
            status_code=int(status_code) if status_code is not None else None,
            user_id=int(user_id) if user_id else None,
            login_id=_trunc(login_id, _LOGIN_MAX),
            request_id=_trunc(rid, _REQID_MAX) or None,
            resolved=resolved_val,
        )

        db = SessionLocal()
        try:
            db.add(row)
            db.commit()
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001 — 로깅 실패는 절대 전파하지 않음
        try:
            logger.warning("[system_log] log_event 실패(무시): %s", e)
        except Exception:
            pass


def log_error(category: str, message: str, **kwargs):
    return log_event("ERROR", category, message, **kwargs)


def log_warning(category: str, message: str, **kwargs):
    return log_event("WARNING", category, message, **kwargs)


def log_info(category: str, message: str, **kwargs):
    return log_event("INFO", category, message, **kwargs)


def log_critical(category: str, message: str, **kwargs):
    return log_event("CRITICAL", category, message, **kwargs)


def cleanup_old_events(retention_days: int = 30) -> dict:
    """retention_days 보다 오래된 system_event_logs 를 안전 정책으로 정리. 결과 dict 반환.

    안전 정책 (운영 이력 보호):
    - 미해결(resolved=False) ERROR/CRITICAL 로그는 자동 삭제하지 않는다.
    - 그 외(INFO/WARNING, 또는 resolved=True 인 모든 로그)는 retention_days 경과 시 삭제.

    예외를 던지지 않고 {"deleted": n, "cutoff": iso, "error": None|str} 형태로 반환.
    """
    try:
        from sqlalchemy import or_
        from app.db_connections.sqlalchemy import SessionLocal
        from app.models import SystemEventLog

        days = max(0, int(retention_days))
        cutoff = datetime.now(KST) - timedelta(days=days)
        # naive 비교 대비: created_at은 DB now() 기준(서버 로컬). KST 기준 cutoff의 naive 값 사용.
        cutoff_naive = cutoff.replace(tzinfo=None)

        db = SessionLocal()
        try:
            deleted = (
                db.query(SystemEventLog)
                .filter(
                    SystemEventLog.created_at < cutoff_naive,
                    or_(
                        # 미해결 ERROR/CRITICAL 은 보호 → 그 외만 삭제 대상
                        SystemEventLog.resolved == True,  # noqa: E712
                        SystemEventLog.level.notin_(["ERROR", "CRITICAL"]),
                    ),
                )
                .delete(synchronize_session=False)
            )
            db.commit()
            return {"deleted": int(deleted or 0), "cutoff": cutoff_naive.isoformat(), "error": None}
        finally:
            db.close()
    except Exception as e:  # noqa: BLE001
        logger.warning("[system_log] cleanup_old_events 실패: %s", e)
        return {"deleted": 0, "cutoff": None, "error": str(e)}
