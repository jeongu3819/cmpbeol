"""아이템(프로젝트 / Task / 일정)별 변경 이력 기록 헬퍼.

VOC: "item별 history 관리". 기존 ActivityLog(activity_logs) 모델을 그대로 재사용한다.
새 테이블/컬럼을 만들지 않고, 누가(actor) / 언제(created_at) / 무엇을(message, meta) 바꿨는지만
요약해서 1건씩 남긴다.

설계 원칙
- 절대 호출부로 예외를 던지지 않는다. (이력 기록 실패가 본 기능을 깨뜨리면 안 됨)
- 호출부의 db 세션에 add 만 한다. commit 은 호출부의 트랜잭션과 함께 일어난다.
  → 본 작업이 롤백되면 이력도 함께 롤백되어 "실제로 일어나지 않은 변경"이 남지 않는다.
- 민감정보(토큰/비밀번호 등)는 넘기지 않는다. 요약 텍스트/식별자만 저장한다.
"""

import logging

logger = logging.getLogger("activity_log")

# entity_type 상수 (프론트와 약속한 값)
ENTITY_PROJECT = "project"
ENTITY_TASK = "task"
ENTITY_CALENDAR_EVENT = "calendar_event"

# action 상수
ACTION_CREATED = "created"
ACTION_UPDATED = "updated"
ACTION_DELETED = "deleted"
ACTION_RESTORED = "restored"
ACTION_STATUS_CHANGED = "status_changed"
ACTION_ASSIGNEE_CHANGED = "assignee_changed"
ACTION_MOVED = "moved"

# 사람이 읽는 필드 라벨
FIELD_LABELS = {
    "title": "제목",
    "name": "이름",
    "description": "설명",
    "status": "상태",
    "priority": "우선순위",
    "start_date": "시작일",
    "due_date": "마감일",
    "end_date": "종료일",
    "assignee_ids": "담당자",
    "assignee_id": "담당자",
    "owner_id": "소유자",
    "space_id": "공간",
    "event_type": "일정 유형",
    "all_day": "종일 여부",
    "visibility": "공개 범위",
    "tags": "태그",
    "remarks": "비고",
}

# 코드값 → 한글 라벨 (상태/우선순위). 매핑에 없으면 원문 그대로 노출.
STATUS_LABELS = {
    "todo": "할 일",
    "in_progress": "진행 중",
    "doing": "진행 중",
    "review": "검토",
    "done": "완료",
    "completed": "완료",
    "planned": "예정",
    "canceled": "취소",
    "cancelled": "취소",
    "hold": "보류",
    "on_hold": "보류",
    "blocked": "지연",
}

PRIORITY_LABELS = {
    "low": "낮음",
    "medium": "보통",
    "high": "높음",
    "urgent": "긴급",
}


def _json_safe(value):
    """meta(JSON 컬럼) 저장 가능한 형태로 변환. date/datetime 등은 문자열로."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    return str(value)


def _label_value(field, value):
    """필드별로 코드값을 한글로 바꿔 표시. 매핑 없으면 원문."""
    if value is None or value == "":
        return "없음"
    if field == "status":
        return STATUS_LABELS.get(str(value), str(value))
    if field == "priority":
        return PRIORITY_LABELS.get(str(value), str(value))
    if field == "all_day":
        return "예" if value else "아니오"
    return str(value)


def log_activity(db, *, user_id, action, entity_type, entity_id, message, meta=None):
    """activity_logs 에 이력 1건 add. 절대 예외를 던지지 않는다."""
    try:
        from app.models import ActivityLog

        row = ActivityLog(
            user_id=int(user_id) if user_id else None,
            action=str(action)[:100],
            entity_type=str(entity_type)[:50],
            entity_id=int(entity_id) if entity_id is not None else None,
            message=(str(message)[:1000] if message else None),
            meta=meta if isinstance(meta, (dict, list)) else None,
        )
        db.add(row)
    except Exception as e:  # noqa: BLE001 — 이력 실패는 절대 전파하지 않음
        try:
            logger.warning("[activity_log] 기록 실패(무시): %s", e)
        except Exception:
            pass


def diff_changes(old: dict, new: dict, fields):
    """old/new dict 에서 fields 중 실제로 바뀐 항목만 추려 변경 목록을 만든다.

    반환: (changes, action, message)
      - changes: [{field, label, before, after}] (meta 저장용 구조)
      - action: status 변경 우선 > 담당자 변경 > 일반 수정
      - message: "상태 변경: 진행 중 → 완료, 담당자 변경" 형태 한글 요약
    """
    changes = []
    for f in fields:
        if f not in new:
            continue
        before = old.get(f)
        after = new.get(f)
        # 리스트(담당자/태그)는 집합 비교가 아닌 순서 무시 비교
        if isinstance(before, list) or isinstance(after, list):
            if sorted(map(str, before or [])) == sorted(map(str, after or [])):
                continue
        # 스칼라: 값 또는 문자열 표현이 같으면 변경 없음으로 본다.
        # (date 객체 vs "YYYY-MM-DD" 문자열처럼 타입만 다른 동일값의 헛이력 방지)
        elif before == after or str(before) == str(after):
            continue
        changes.append({
            "field": f,
            "label": FIELD_LABELS.get(f, f),
            "before": _json_safe(before),
            "after": _json_safe(after),
        })

    if not changes:
        return [], None, None

    changed_fields = {c["field"] for c in changes}
    if "status" in changed_fields:
        action = ACTION_STATUS_CHANGED
    elif changed_fields & {"assignee_ids", "assignee_id"}:
        action = ACTION_ASSIGNEE_CHANGED
    else:
        action = ACTION_UPDATED

    parts = []
    for c in changes:
        f = c["field"]
        if f in ("status", "priority"):
            parts.append(f"{c['label']} 변경: {_label_value(f, c['before'])} → {_label_value(f, c['after'])}")
        elif f in ("assignee_ids", "assignee_id"):
            parts.append("담당자 변경")
        else:
            parts.append(f"{c['label']} 수정")
    message = ", ".join(parts)
    return changes, action, message
