"""Image Readability / AI-Ready Image Layer.

`image_manifest` 의 각 이미지에 대해 "AI(vision) 모델이 잘 읽을 수 있는 상태인가"를
판단하는 메타를 부여한다. **실제 이미지 파일을 열지 않는다** — 이미 수집된
width/height/file_size/content_type 메타만으로 1차 판단한다.

목적
----
미래에 성능 좋은 vision/multimodal 모델 API 를 붙였을 때, 단순히 이미지를 던지는 게
아니라 "이 이미지가 충분한 해상도인지 / 원본이 보존돼 있는지 / preview·thumbnail 인지 /
나중에 AI-readable variant·tile 을 만들 구조인지"를 함께 판단/전달하기 위함.

이번 범위에서 하지 않는 것
--------------------------
- 실제 업스케일링 / tile 이미지 파일 생성 (구조만 준비, ``planned=True``)
- blur/선명도 측정 (구조만 준비, ``blur_status="not_checked"``)
- 이미지 바이트 분석 / OCR / vision 모델 호출

# Future:
# - blur_score 는 Pillow/OpenCV 로 Laplacian variance 를 계산해 채울 수 있다(현재 None).
# - ai_readable / tiles 는 별도 전처리 잡이 실제 파일을 생성한 뒤 available=True 로 갱신.
# - width/height 가 없는 이미지는 업로드 시 dimension 캡처를 추가하면 판단 정확도가 올라간다.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from app.services.ai_image_storage_policy import variant_storage_plan

# =========================================================
# 판단 기준 상수 (나중에 쉽게 조정)
# =========================================================
AI_IMAGE_MIN_WIDTH = 800
AI_IMAGE_MIN_HEIGHT = 500
AI_IMAGE_MIN_MEGAPIXELS = 0.4
AI_IMAGE_TINY_FILE_SIZE_BYTES = 50_000
# 이보다 크면 tile 분할 후보 (전체화면 캡처 안의 작은 표/차트 대응)
AI_IMAGE_LARGE_MEGAPIXELS = 8.0

# compact crop / partial screen capture 판단 기준 (실제 사용자 캡처 패턴 반영).
# 사용자는 화면 전체가 아니라 필요한 텍스트/표/에러 영역만 작게 잘라 붙이는 경우가 많다.
# "작다"는 이유만으로 무조건 not_recommended 처리하지 않기 위한 하한선.
AI_IMAGE_COMPACT_CROP_MIN_WIDTH = 350
AI_IMAGE_COMPACT_CROP_MIN_HEIGHT = 60
AI_IMAGE_COMPACT_CROP_MIN_ASPECT_RATIO = 3.0
# 이보다 작으면 텍스트조차 읽기 어려운 진짜 thumbnail/too-small 로 본다.
AI_IMAGE_TINY_WIDTH = 250
AI_IMAGE_TINY_HEIGHT = 40

# AI(vision) 입력으로 무난한 타입
AI_SUPPORTED_TYPES = {"image/png", "image/jpeg", "image/webp"}

# compact crop / partial capture 판단 시 "텍스트/캡처 맥락"으로 인정하는 source_entity_type
_CROP_SOURCE_TYPES = {"task_activity", "task_description", "project_note"}

# 역할이 "화면/에러/UI 일부 캡처" 계열 → partial_screen_capture 로 분류
_SCREEN_CAPTURE_ROLES = {
    "error_screen", "partial_screen_capture", "equipment_screen",
    "result_capture", "meeting_slide", "terminal_capture", "log_capture",
}
# 역할이 "텍스트/문서/표" 계열 → compact crop 후보 가산점
_TEXT_LIKE_ROLES = {
    "text_crop", "document_crop", "table", "note_capture", "error_screen",
    "partial_screen_capture", "meeting_slide",
    # 세분화된 텍스트 계열(명령어/코드/로그/설정/문서표) — compact crop 가산점
    "command_snippet", "code_snippet", "log_capture", "config_capture",
    "terminal_capture", "document_table",
}

# readability_status 값:
#   기존: ok / small / low_resolution / thumbnail_suspected /
#         missing_dimensions / unsupported_type / unknown
#   신규: compact_text_crop / small_but_readable / partial_screen_capture /
#         too_small_for_text
# recommendation_level 값: recommended / conditional / not_recommended / unknown


def _recommendation_level_to_bool(level: str) -> bool:
    """recommendation_level → recommended_for_ai(boolean).

    conditional(compact crop 등)도 True 로 둔다 — compact crop 을 완전히 제외하면
    실제 유용한 업무 근거 캡처를 놓치므로, 대신 conditional 로 표시해 모델/프롬프트/
    검증 단계에서 조심해서 다루게 한다. (사용자 요청 6번 권장안)
    """
    return level in ("recommended", "conditional")


def assess_image_quality(
    width: Optional[int],
    height: Optional[int],
    file_size: Optional[int],
    content_type: Optional[str],
    *,
    image_role: Optional[str] = None,
    source_entity_type: Optional[str] = None,
    nearby_text: Optional[str] = None,
    fallback_context_text: Optional[str] = None,
) -> Dict[str, Any]:
    """수집된 메타만으로 이미지의 AI 가독성을 1차 판단.

    "작다 = 무조건 AI 부적합" 이라는 단순 기준 대신, 실제 사용자 캡처 패턴(필요한
    텍스트/표/에러 영역만 compact 하게 잘라 작업노트에 붙이는 경우)을 반영한다.

    image_role / source_entity_type / nearby_text 는 compact crop 여부를 보강 판단하기
    위한 맥락 신호이며, **이미지 바이트를 열지 않는다**(OCR/vision 호출 없음).
    """
    ct = (content_type or "").lower()
    has_dimensions = bool(width and height and width > 0 and height > 0)
    megapixels = round((width * height) / 1_000_000, 3) if has_dimensions else None
    aspect_ratio = round(width / height, 3) if has_dimensions and height else None
    has_context_text = bool((nearby_text or "").strip() or (fallback_context_text or "").strip())
    from_crop_source = source_entity_type in _CROP_SOURCE_TYPES

    is_too_small = False
    is_low_resolution = False
    is_probably_thumbnail = False
    is_compact_crop = False
    notes: List[str] = []

    if not ct.startswith("image/"):
        status = "unsupported_type"
        level = "not_recommended"
        notes.append(f"content_type '{content_type}' 는 이미지가 아님")
    elif ct not in AI_SUPPORTED_TYPES:
        status = "unsupported_type"
        level = "not_recommended"
        notes.append(f"content_type '{content_type}' 는 AI 지원셋(png/jpeg/webp) 밖")
    elif not has_dimensions:
        status = "missing_dimensions"
        level = "unknown"
        notes.append("width/height 메타 없음 — AI 가독성 판단 불가")
    elif width < AI_IMAGE_TINY_WIDTH or height < AI_IMAGE_TINY_HEIGHT:
        # 진짜 너무 작은 이미지 — 텍스트조차 읽기 어려움
        is_too_small = True
        level = "not_recommended"
        if file_size and file_size < AI_IMAGE_TINY_FILE_SIZE_BYTES:
            is_probably_thumbnail = True
            status = "thumbnail_suspected"
            notes.append(
                f"매우 작은 해상도({width}x{height}) + 작은 파일({file_size}B): preview/thumbnail 의심"
            )
        else:
            status = "too_small_for_text"
            notes.append(
                f"해상도가 너무 작아 AI가 글자를 읽기 어려울 수 있음 "
                f"({width}x{height} < {AI_IMAGE_TINY_WIDTH}x{AI_IMAGE_TINY_HEIGHT})"
            )
    elif width < AI_IMAGE_MIN_WIDTH or height < AI_IMAGE_MIN_HEIGHT:
        # 기준 해상도보다 작지만 thumbnail 수준은 아님 → compact crop / 부분 캡처로 판단.
        # 무조건 not_recommended 가 아니라 conditional 로 열어둔다.
        level = "conditional"
        is_wide_thin = bool(
            width >= AI_IMAGE_COMPACT_CROP_MIN_WIDTH
            and height >= AI_IMAGE_COMPACT_CROP_MIN_HEIGHT
            and aspect_ratio is not None
            and aspect_ratio >= AI_IMAGE_COMPACT_CROP_MIN_ASPECT_RATIO
        )
        crop_context = has_context_text or from_crop_source or (image_role in _TEXT_LIKE_ROLES)

        if is_wide_thin and crop_context:
            is_compact_crop = True
            status = "compact_text_crop"
            notes.append(
                "작은 이미지이지만 필요한 텍스트 영역만 잘라낸 캡처로 추정됩니다 "
                f"({width}x{height}, 가로:세로 비율 {aspect_ratio})."
            )
            notes.append("향후 vision 모델 분석 시 원본 이미지를 사용하되, 결과는 검증이 필요합니다.")
        elif image_role in _SCREEN_CAPTURE_ROLES:
            status = "partial_screen_capture"
            notes.append(
                "전체 화면이 아니라 특정 UI/문서/표/에러 영역 일부만 캡처한 것으로 보입니다 "
                f"({width}x{height})."
            )
            notes.append("AI가 읽을 수는 있으나, 글자가 작을 수 있어 결과 검증이 필요합니다.")
        else:
            status = "small_but_readable"
            notes.append(
                f"기준 해상도보다 작지만 AI가 읽을 가능성이 있는 이미지입니다 ({width}x{height})."
            )
            notes.append("모델 품질에 따라 결과가 달라질 수 있어 검증이 필요합니다.")
    elif megapixels is not None and megapixels < AI_IMAGE_MIN_MEGAPIXELS:
        is_low_resolution = True
        level = "not_recommended"
        status = "low_resolution"
        notes.append(f"저해상도 ({megapixels}MP < {AI_IMAGE_MIN_MEGAPIXELS}MP)")
    else:
        status = "ok"
        level = "recommended"

    recommended = _recommendation_level_to_bool(level)

    # UI 표시용 메시지 (사용자에게 너무 기술적이지 않게). 모델 비호출 — 순수 표시용.
    message, message_level = _ui_message_for(status)

    return {
        "width": width,
        "height": height,
        "megapixels": megapixels,
        "aspect_ratio": aspect_ratio,
        "file_size": file_size,
        "content_type": content_type,
        "has_dimensions": has_dimensions,
        "is_too_small": is_too_small,
        "is_low_resolution": is_low_resolution,
        "is_probably_thumbnail": is_probably_thumbnail,
        "is_compact_crop": is_compact_crop,
        "readability_status": status,
        "recommendation_level": level,
        "recommended_for_ai": recommended,
        "quality_notes": notes,
        # UI 표시용: recommended_for_ai=false 여도 "AI가 읽기 어려울 수 있음" 정도로 안내
        "message": message,
        "message_level": message_level,
        # blur 구조만 준비 (이번 범위 미측정)
        "blur_score": None,
        "blur_status": "not_checked",
    }


# readability_status → (UI 메시지, 레벨). 레벨: ok / info / warning
_UI_MESSAGES = {
    "ok": (None, "ok"),
    "small": ("이미지가 작아 AI가 읽기 어려울 수 있습니다.", "warning"),
    "compact_text_crop": ("필요한 텍스트 영역만 잘라낸 캡처로 보입니다. AI 분석은 가능하나 검증이 필요합니다.", "info"),
    "small_but_readable": ("작지만 AI가 읽을 가능성이 있는 이미지입니다. 결과 검증이 필요합니다.", "info"),
    "partial_screen_capture": ("화면 일부를 캡처한 이미지로 보입니다. AI 분석은 가능하나 검증이 필요합니다.", "info"),
    "too_small_for_text": ("해상도가 너무 작아 AI가 글자를 읽기 어려울 수 있습니다.", "warning"),
    "thumbnail_suspected": ("미리보기/썸네일로 보여 AI가 읽기 어려울 수 있습니다.", "warning"),
    "low_resolution": ("해상도가 낮아 AI가 읽기 어려울 수 있습니다.", "warning"),
    "missing_dimensions": ("이미지 크기 정보가 없어 AI 적합 여부를 판단하기 어렵습니다.", "info"),
    "unsupported_type": ("AI가 지원하지 않는 이미지 형식입니다.", "warning"),
}


def _ui_message_for(status: str):
    return _UI_MESSAGES.get(status, (None, "info"))


def build_ai_image_variants(
    storage_ref: Optional[Dict[str, Any]],
    quality: Dict[str, Any],
) -> Dict[str, Any]:
    """원본 / preview / ai_readable / tile variant 구조를 준비(파일 생성은 안 함).

    original.available 은 stored_name/s3_key 참조가 있으면 True 로 본다. 프로젝트 내부
    이미지는 (VOC 와 달리) 서버측 리사이즈를 거치지 않고 업로드 원본을 그대로 저장하므로,
    참조가 있으면 원본 보존으로 간주한다.
    """
    sr = storage_ref or {}
    original_available = bool(sr.get("s3_key") or sr.get("stored_name"))
    status = quality.get("readability_status")
    mp = quality.get("megapixels")
    is_large = mp is not None and mp > AI_IMAGE_LARGE_MEGAPIXELS

    # compact crop / 부분 캡처 계열: 작아도 원본 crop 을 그대로 모델에 주는 게 나을 수 있다.
    # 타일링은 의미가 거의 없으므로 use_original_conditional + tiles 비추천.
    _CONDITIONAL_CROP_STATUSES = (
        "compact_text_crop", "small_but_readable", "partial_screen_capture",
    )

    # recommended_action:
    #   use_original / use_original_conditional / need_higher_resolution_original /
    #   generate_ai_readable_variant / generate_tiles / skip_not_image / unknown
    if status == "unsupported_type":
        action = "skip_not_image"
    elif status == "missing_dimensions":
        action = "unknown"
    elif status in _CONDITIONAL_CROP_STATUSES:
        action = "use_original_conditional"
    elif status in ("small", "low_resolution", "thumbnail_suspected", "too_small_for_text"):
        action = "need_higher_resolution_original"
    elif status == "ok" and is_large:
        action = "generate_tiles"
    else:
        action = "use_original"

    # tiles
    if status in _CONDITIONAL_CROP_STATUSES:
        tiles_recommended, tiles_reason = False, "compact_crop_no_tiling_needed"
    elif status in ("small", "thumbnail_suspected", "low_resolution", "too_small_for_text"):
        tiles_recommended, tiles_reason = False, "image_too_small"
    elif status == "ok" and is_large:
        tiles_recommended, tiles_reason = True, "large_image_may_need_tiles"
    elif status == "ok":
        tiles_recommended, tiles_reason = False, "image_size_ok"
    elif status == "unsupported_type":
        tiles_recommended, tiles_reason = False, "not_image"
    else:  # missing_dimensions
        tiles_recommended, tiles_reason = False, "unknown"

    return {
        "original": {
            "available": original_available,
            "storage_ref": storage_ref if original_available else None,
            "width": quality.get("width"),
            "height": quality.get("height"),
            "content_type": quality.get("content_type"),
        },
        # 현재 preview/thumbnail 전용 저장 경로가 없으므로 항상 미보유.
        "preview": {"available": False, "storage_ref": None},
        "ai_readable": {
            "available": False,
            "planned": True,
            "recommended_action": action,
        },
        "tiles": {
            "available": False,
            "planned": True,
            "recommended": tiles_recommended,
            "reason": tiles_reason,
        },
    }


# =========================================================
# image_role 약한 추정 (nearby_text / fallback_context_text / 비율 / filename / relation)
# =========================================================
# 자동 추정은 과신 금지. 우선순위(중요):
#   1) nearby_text 키워드      (medium)  ← 사용자가 이미지 옆에 직접 적은 맥락
#   2) fallback_context_text   (medium)  ← 작업노트/Task title 등 대체 맥락
#   3) aspect_ratio 휴리스틱    (low)     ← 넓고 얇으면 text_crop
#   4) filename 키워드          (low)     ← Ctrl+V 붙여넣기는 자동 파일명이라 신뢰도 낮음
#   5) relation_type 신호       (low)     ← work_note_evidence → note_capture
#   6) source_entity_type fallback (low)  ← task_activity → note_capture
#
# 핵심 수정 이유: Ctrl+C→Ctrl+V inline image 의 자동 stored_name/filename 에
# note/task_activity 계열 문자열이 들어가 filename_keyword 가 과도하게 우선 적용되어
# 모든 이미지가 note_capture 로 오분류되던 문제. → filename 을 후순위로 내리고,
# note_capture 는 task_activity 맥락의 **fallback role 로만** 사용한다.
#
# image_role 값: chart / table / error_screen / before_after / result_capture /
#               equipment_screen / meeting_slide /
#               text_crop / document_crop / partial_screen_capture / note_capture /
#               unknown
# note_capture 는 키워드 매칭 대상이 아니라 task_activity fallback 전용(아래 참조).
# 우선순위(위에서부터 먼저 매칭). 세분화 role 은 generic role 보다 먼저, 단 과분류 방지를 위해
# 지나치게 일반적인 단어(run/down/status/if/else 등)는 키워드에서 의도적으로 제외했다.
_ROLE_KEYWORDS = [
    ("chart", ["chart", "graph", "plot", "trend", "차트", "그래프", "추이"]),
    ("table", ["table", "sheet", "grid", "표", "목록", "테이블"]),
    ("error_screen", ["error", "exception", "traceback", "alarm", "에러", "오류", "알람", "장애"]),
    ("equipment_screen", ["equipment", "eqp", "hmi", "scada", "interlock", "recipe", "설비", "장비", "monitor", "모니터"]),
    ("meeting_slide", ["meeting", "slide", "ppt", "회의", "발표", "자료"]),
    ("before_after", ["before", "after", "비교", "전후", "vs"]),
    # 명령어/실행방법 — Ctrl+V 자동 파일명 영향 줄이려 distinctive 한 키워드 위주
    ("command_snippet", [
        "uvicorn", "python -m", "python ", "npm ", "yarn ", "pnpm ", "pip ", "conda ",
        "venv", "activate", "docker ", "kubectl", "curl ", "ssh ", "git ", "powershell",
        "명령어", "실행방법", "실행 방법",
    ]),
    ("terminal_capture", ["terminal", "console", "bash", "shell", "zsh", "프롬프트"]),
    ("code_snippet", ["function", "const ", "import ", "export ", "def ", "async ", "await ", "class "]),
    ("log_capture", ["log", "trace", "stack", "stderr", "stdout", "fatal", "로그"]),
    ("config_capture", [".env", "config", "settings", "yaml", ".yml", ".json", ".ini", "database_url", "api_key", "base_url", "환경변수"]),
    ("document_table", ["비교표", "규격표", "스펙표", "사양표", "대비표", "matrix"]),
    ("document_crop", ["document", "doc", "문서", "보고서", "report", "spec", "규격"]),
    ("result_capture", ["result", "측정", "결과", "스크린샷", "screenshot"]),
    ("process_flow", ["flowchart", "workflow", "순서도", "흐름도", "프로세스", "공정", "절차"]),
    ("text_crop", ["text", "문구", "문장", "코드", "설정값"]),
    ("partial_screen_capture", ["screen", "화면", "capture", "캡처"]),
]


def _match_role_keyword(text: Optional[str]):
    """텍스트에서 _ROLE_KEYWORDS 첫 매칭 role 반환(없으면 None)."""
    t = (text or "").lower()
    if not t:
        return None
    for role, kws in _ROLE_KEYWORDS:
        if any(kw in t for kw in kws):
            return role
    return None


def infer_image_role(
    filename: Optional[str],
    nearby_text: Optional[str],
    relation_type: Optional[str],
    *,
    fallback_context_text: Optional[str] = None,
    context_text_source: Optional[str] = None,
    source_entity_type: Optional[str] = None,
    width: Optional[int] = None,
    height: Optional[int] = None,
    aspect_ratio: Optional[float] = None,
) -> Tuple[str, str, str]:
    """약한 휴리스틱으로 image_role 을 추정(과신 금지).

    우선순위: nearby_text → (같은 entity 본문일 때만)fallback_context_text →
    aspect_ratio → filename → relation_type → source_entity_type fallback.
    확실하지 않으면 unknown.

    fallback_context_text 키워드 매칭은 **그 텍스트가 이미지 자신의 source entity 본문에서
    나온 경우(context_text_source == "same_entity_text")에만** 허용한다. Task title /
    Sub Project / Project name / source_entity / (제거된)sibling 작업노트에서 온 fallback 은
    이미지의 실제 내용 설명이 아닐 수 있으므로 키워드로 role 을 강하게 단정하지 않고,
    이미지 메타(aspect_ratio 등) 기반으로만 낮은 confidence 로 추정한다.

    Returns: (role, source, confidence). 매칭 없으면 ("unknown", "none", "none").
    """
    # 1) nearby_text 키워드 — 사용자가 이미지 옆에 직접 적은 맥락(가장 신뢰).
    role = _match_role_keyword(nearby_text)
    if role:
        return role, "nearby_text_keyword", "medium"

    # 2) fallback_context_text 키워드 — **같은 entity 본문에서 나온 경우에만** 허용.
    #    (sibling 작업노트는 builder 에서 이미 fallback 후보에서 제외됨. task_title /
    #     project_name / source_entity 기반 fallback 은 키워드 단정 금지 → 아래 메타 단계로.)
    if context_text_source == "same_entity_text":
        role = _match_role_keyword(fallback_context_text)
        if role:
            return role, "fallback_context_text_keyword", "medium"

    # 3) 가로로 길고 세로가 낮으면(넓은 비율) 텍스트 한두 줄 crop 일 가능성이 높다.
    ar = aspect_ratio
    if ar is None and width and height:
        ar = round(width / height, 3)
    if (
        ar is not None
        and ar >= AI_IMAGE_COMPACT_CROP_MIN_ASPECT_RATIO
        and height is not None
        and height < AI_IMAGE_MIN_HEIGHT
    ):
        return "text_crop", "aspect_ratio_heuristic", "low"

    # 4) filename 키워드 — Ctrl+V 붙여넣기는 자동 파일명이라 신뢰도 낮음(후순위).
    role = _match_role_keyword(filename)
    if role:
        return role, "filename_keyword", "low"

    # 5) relation_type 신호 — work_note_evidence(작업노트 붙여넣기)는 note_capture.
    if relation_type == "work_note_evidence":
        return "note_capture", "relation_type", "low"

    # 6) source_entity_type fallback — task_activity 맥락이면 note_capture.
    if source_entity_type == "task_activity":
        return "note_capture", "fallback", "low"

    return "unknown", "none", "none"


def enrich_manifest_item(item: Dict[str, Any]) -> List[str]:
    """manifest item 1건에 image_quality + ai_image_variants 를 in-place 부여.

    Returns: 이 이미지에 대해 남길 (대표) warning 문자열 리스트(없으면 빈 리스트).
    """
    # image_role 약한 추정 (confidence low/none) — quality 판단의 맥락 신호로 먼저 계산.
    _w, _h = item.get("width"), item.get("height")
    _ar = round(_w / _h, 3) if _w and _h else None
    role, role_source, role_conf = infer_image_role(
        item.get("filename"),
        item.get("nearby_text"),
        item.get("relation_type"),
        fallback_context_text=item.get("fallback_context_text"),
        context_text_source=item.get("context_text_source"),
        source_entity_type=item.get("source_entity_type"),
        width=_w,
        height=_h,
        aspect_ratio=_ar,
    )
    item["image_role"] = role
    item["image_role_source"] = role_source
    item["image_role_confidence"] = role_conf

    quality = assess_image_quality(
        item.get("width"),
        item.get("height"),
        item.get("file_size"),
        item.get("content_type"),
        image_role=role,
        source_entity_type=item.get("source_entity_type"),
        nearby_text=item.get("nearby_text"),
        fallback_context_text=item.get("fallback_context_text"),
    )
    variants = build_ai_image_variants(item.get("storage_ref"), quality)

    # variant 별 (미래) 저장 경로 계획 부여 — content_hash 우선 키
    plan = variant_storage_plan(
        item.get("project_id"),
        item.get("image_id"),
        item.get("content_hash"),
    )
    variants["preview"]["planned_storage_path"] = plan["preview"]
    variants["ai_readable"]["planned_storage_path"] = plan["ai_readable"]
    variants["tiles"]["planned_storage_path"] = plan["tiles"]
    variants["variant_key"] = plan["key"]
    variants["variant_key_source"] = plan["key_source"]

    item["image_quality"] = quality

    item["ai_image_variants"] = variants

    image_id = item.get("image_id")
    warns: List[str] = []
    status = quality["readability_status"]
    wh = f"{quality['width']}x{quality['height']}"
    if status == "missing_dimensions":
        warns.append(f"image {image_id} 에 width/height 메타가 없어 AI 가독성 판단 불가")
    elif status == "compact_text_crop":
        warns.append(
            f"image {image_id} 작은 텍스트 crop 이미지로 추정됨: {wh}, AI 분석은 conditional"
        )
    elif status in ("small_but_readable", "partial_screen_capture"):
        warns.append(
            f"image {image_id} 작지만 읽을 수 있는 부분 캡처로 추정됨: {wh}, AI 분석은 conditional(검증 필요)"
        )
    elif status == "too_small_for_text":
        warns.append(
            f"image {image_id} 해상도가 너무 작아 AI가 읽기 어려울 수 있음: {wh}"
        )
    elif status == "thumbnail_suspected":
        warns.append(
            f"image {image_id} 미리보기/썸네일로 의심됨: {wh}"
        )
    elif status == "low_resolution":
        warns.append(f"image {image_id} 저해상도: {quality['megapixels']}MP")
    elif status == "unsupported_type":
        warns.append(f"image {image_id} 은 AI 지원 이미지 타입이 아님: {quality['content_type']}")
    return warns


def summarize_readiness(manifest: List[Dict[str, Any]]) -> Dict[str, Any]:
    """manifest 전체의 AI 입력 준비도 요약."""
    total = len(manifest)
    base = {
        "total_images": total,
        "recommended_for_ai": 0,
        "not_recommended_for_ai": 0,
        "missing_dimensions": 0,
        "too_small": 0,
        "low_resolution": 0,
        "tiles_recommended": 0,
        # 신규: compact crop / conditional 분류 카운트
        "compact_text_crop": 0,
        "small_but_readable": 0,
        "partial_screen_capture": 0,
        "conditional_for_ai": 0,
        "status": "no_images",
    }
    if total == 0:
        return base

    recommended = 0          # recommendation_level == recommended (해상도 충분 + ok)
    conditional = 0          # recommendation_level == conditional (compact crop 등)
    not_recommended = 0
    missing = 0
    too_small = 0
    low_res = 0
    unsupported = 0
    tiles_rec = 0
    compact_crop = 0
    small_readable = 0
    partial_capture = 0
    for it in manifest:
        q = it.get("image_quality") or {}
        level = q.get("recommendation_level")
        if level == "recommended":
            recommended += 1
        elif level == "conditional":
            conditional += 1
        elif level == "not_recommended":
            not_recommended += 1
        st = q.get("readability_status")
        if st == "missing_dimensions":
            missing += 1
        if q.get("is_too_small"):
            too_small += 1
        if q.get("is_low_resolution"):
            low_res += 1
        if st == "unsupported_type":
            unsupported += 1
        if st == "compact_text_crop":
            compact_crop += 1
        elif st == "small_but_readable":
            small_readable += 1
        elif st == "partial_screen_capture":
            partial_capture += 1
        variants = it.get("ai_image_variants") or {}
        if (variants.get("tiles") or {}).get("recommended"):
            tiles_rec += 1

    # status:
    #   모두 recommended(ok)      → ok
    #   메타 부족으로 판단 불가만   → unknown
    #   conditional / not_recommended 가 섞이면 → needs_review
    if recommended == total:
        status = "ok"
    elif (missing + unsupported) == total:
        status = "unknown"
    else:
        status = "needs_review"

    base.update({
        # recommendation_level=recommended/conditional 둘 다 recommended_for_ai=True 이므로
        # "AI 후보(recommended_for_ai=true)" 카운트는 recommended + conditional.
        "recommended_for_ai": recommended + conditional,
        "not_recommended_for_ai": not_recommended,
        "missing_dimensions": missing,
        "too_small": too_small,
        "low_resolution": low_res,
        "tiles_recommended": tiles_rec,
        "compact_text_crop": compact_crop,
        "small_but_readable": small_readable,
        "partial_screen_capture": partial_capture,
        "conditional_for_ai": conditional,
        "fully_recommended_for_ai": recommended,
        "status": status,
    })
    return base


def readiness_counts(summary: Dict[str, Any]) -> Dict[str, int]:
    """ai-context-preview counts 에 합칠 보조 카운트."""
    return {
        "ai_recommended_images": summary.get("recommended_for_ai", 0),
        "low_quality_images": summary.get("too_small", 0) + summary.get("low_resolution", 0),
        "missing_dimension_images": summary.get("missing_dimensions", 0),
    }
