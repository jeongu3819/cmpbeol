"""Model Compatibility Layer (Model Input Adapter).

PLAN-AI 의 image_manifest / Image Evidence Card 를 **사내 모델 API 가 이해하기 쉬운
표준 입력 패킷(model_input_packet)** 으로 변환하는 중간 계층.

핵심 원칙
---------
- Evidence Card 는 **정답이 아니라 힌트(hint)** 다.
  모델은 이미지에서 실제로 보이는 내용과 명확한 Task 맥락을 우선해야 한다.
- 따라서 ``image_role`` 은 ``image_role_hint`` 로 취급하고, ``role_confidence`` /
  ``context_strength`` 를 함께 전달해 모델이 약한 추정을 강하게 믿지 않도록 한다.
- metadata 와 실제 이미지 내용이 충돌하면 **이미지에서 보이는 사실을 우선**하도록
  global rule 을 항상 포함한다.

이 모듈이 **하지 않는 것**
-------------------------
- 실제 DSLLM / Vision 모델 호출 (payload 만 생성)
- OCR 호출
- 이미지 binary / base64 / storage path 포함  ← image_ref 는 image_id 중심
- DB 저장 / migration

향후 사내 모델 API 포맷이 확정되면 **이 Layer(특히 provider adapter)만 수정**하면
되도록 분리한다. PLAN-AI 의 다른 코드(context builder / endpoint)는 영향받지 않는다.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

# Evidence Card 와 동일한 role → target / instruction_key 매핑을 재사용한다.
# (단일 출처 유지: ROLE_INSTRUCTION_MAP 은 본 모듈이 hint 용으로 별도 보유)
from app.services.project_ai_evidence import (
    ROLE_EXTRACTION_TARGET,
    ROLE_MODEL_INSTRUCTION_KEY,
    DEFAULT_INSTRUCTION_KEY,
    compute_context_strength,
)

MODEL_INPUT_PACKET_VERSION = "project-ai-model-input-v1"

# 지원하는 입력 모드(A/B/C 비교 준비). 실제 모델 호출은 별도 Phase.
INPUT_MODES = ("image_only", "image_with_nearby_text", "image_with_evidence_card")
DEFAULT_INPUT_MODE = "image_with_evidence_card"

SUPPORTED_PROVIDERS = ("generic", "dsllm")
DEFAULT_PROVIDER = "generic"

# =========================================================
# 충돌 방지 Global Rule
#   metadata 와 이미지 내용이 충돌하면 이미지에서 보이는 사실을 우선.
#   (향후 system/user prompt 의 일부로 사용)
# =========================================================
GLOBAL_RULE = (
    "제공된 metadata 는 업무 맥락 힌트입니다. "
    "이미지 내용과 metadata 가 충돌하면, 이미지에서 실제로 보이는 내용과 명확한 Task 맥락을 우선하세요. "
    "보이지 않는 내용은 추정하지 마세요. "
    "숫자, 명령어, 에러 메시지, 파일 경로는 보이는 경우에만 추출하세요. "
    "불확실한 내용은 \"확인 필요\"로 표시하세요."
)

# =========================================================
# role 별 suggested instruction (hint).
#   Evidence Card 의 MODEL_INSTRUCTION_TEMPLATES 가 instruction_key 기반이라면,
#   이쪽은 모델 입력용으로 **role 단위** 힌트를 제공한다(강제 명령 아님).
# =========================================================
ROLE_INSTRUCTION_MAP: Dict[str, str] = {
    "chart": (
        "차트 이미지입니다. 정확한 숫자를 단정하지 말고, 보이는 범위에서 추세/변곡점/이상점 중심으로 "
        "요약하세요. 축/수치가 불명확하면 \"정확한 수치 확인 필요\"라고 표시하세요."
    ),
    "table": (
        "표 이미지입니다. 제목, 컬럼명, 행 단위 주요 값을 분리해서 정리하세요. "
        "읽기 어려운 셀은 추정하지 말고 \"확인 필요\"라고 표시하세요."
    ),
    "document_table": (
        "표 이미지입니다. 제목, 컬럼명, 행 단위 주요 값을 분리해서 정리하세요. "
        "읽기 어려운 셀은 추정하지 말고 \"확인 필요\"라고 표시하세요."
    ),
    "meeting_slide": (
        "회의자료 이미지입니다. 슬라이드 제목, 핵심 항목, 업무 프로세스 적용 포인트, action item 을 "
        "분리해서 정리하세요."
    ),
    "error_screen": (
        "에러 화면입니다. 에러 메시지, 발생 파일/라인, 원인 후보, 다음 조치 순서로 정리하세요. "
        "보이지 않는 내용은 추정하지 마세요."
    ),
    "command_snippet": (
        "명령어/실행방법 캡처입니다. 보이는 명령어를 가능한 원문 순서대로 보존하세요. "
        "오타처럼 보여도 임의 수정하지 말고, 수정이 필요해 보이면 별도 후보로 표시하세요."
    ),
    "code_snippet": (
        "코드 일부 캡처입니다. 보이는 코드 구조, 주요 함수/변수, 의도, 잠재 오류를 분리해서 정리하세요. "
        "보이지 않는 코드는 추정하지 마세요."
    ),
    "log_capture": (
        "로그 또는 터미널 화면입니다. 보이는 메시지, 오류/경고, 실행 명령, 결과를 구분해서 정리하세요. "
        "보이지 않는 원인은 단정하지 말고 후보로만 표시하세요."
    ),
    "terminal_capture": (
        "로그 또는 터미널 화면입니다. 보이는 메시지, 오류/경고, 실행 명령, 결과를 구분해서 정리하세요. "
        "보이지 않는 원인은 단정하지 말고 후보로만 표시하세요."
    ),
    "config_capture": (
        "설정 화면 또는 설정 파일 캡처입니다. 보이는 설정 키/값만 정리하세요. "
        "API Key, Token, Password 등 민감정보로 보이는 값은 원문 전체를 반복하지 말고 마스킹하세요."
    ),
    "text_crop": (
        "작은 텍스트 캡처입니다. 보이는 텍스트만 추출하고, 주변 맥락이 약하면 불확실성을 표시하세요."
    ),
    "document_crop": (
        "작은 텍스트 캡처입니다. 보이는 텍스트만 추출하고, 주변 맥락이 약하면 불확실성을 표시하세요."
    ),
    "note_capture": (
        "작업노트에 붙은 캡처입니다. 무엇을 보여주는지 사실 위주로 요약하고, 불확실하면 표시하세요."
    ),
    "partial_screen_capture": (
        "화면 일부 캡처입니다. 보이는 영역에 한정해 사실만 요약하고, 잘린 부분은 추정하지 마세요."
    ),
    "equipment_screen": (
        "설비/장비 상태 화면입니다. 설비 ID, 상태, 알람, 레시피, RUN/DOWN/LOCAL/PM 관련 정보를 중심으로 "
        "정리하세요. 불명확한 값은 확인 필요로 표시하세요."
    ),
    "process_flow": (
        "프로세스/흐름 이미지입니다. 단계 순서와 분기를 순서대로 정리하세요. 불명확한 연결은 표시만 하세요."
    ),
    "result_capture": (
        "측정/결과 캡처입니다. 보이는 결과값/판정 위주로 요약하고, 정확한 수치는 단정하지 말고 표시하세요."
    ),
    "before_after": (
        "전/후 비교 이미지입니다. 무엇이 바뀌었는지 차이 중심으로 정리하고, 불확실하면 표시하세요."
    ),
    "unknown": (
        "이미지 유형이 확실하지 않습니다. 보이는 사실만 보수적으로 정리하고, 추정은 하지 마세요."
    ),
}

DEFAULT_ROLE_INSTRUCTION = ROLE_INSTRUCTION_MAP["unknown"]

# =========================================================
# output_schema_hint
#   모델이 결과를 구조적으로 반환하도록 유도(강제는 아님). role 별로 일부 특화.
# =========================================================
COMMON_OUTPUT_SCHEMA_HINT: Dict[str, Any] = {
    "visible_facts": [],
    "extracted_text": [],
    "structured_data": {},
    "task_relevance": "",
    "uncertainty": "",
    "suggested_next_action": "",
}

ROLE_OUTPUT_SCHEMA_HINT: Dict[str, Dict[str, Any]] = {
    "error_screen": {
        "error_message": "",
        "file_or_location": "",
        "possible_causes": [],
        "next_actions": [],
        "uncertainty": "",
    },
    "command_snippet": {
        "commands": [],
        "execution_order": [],
        "environment_hint": "",
        "caution": "",
        "uncertainty": "",
    },
    "table": {
        "table_title": "",
        "columns": [],
        "rows_summary": [],
        "important_values": [],
        "unreadable_cells": [],
    },
    "document_table": {
        "table_title": "",
        "columns": [],
        "rows_summary": [],
        "important_values": [],
        "unreadable_cells": [],
    },
    "chart": {
        "trend_summary": "",
        "visible_labels": [],
        "notable_points": [],
        "uncertain_values": [],
    },
}

# 약한 role 추정일 때(role_confidence low/none) 모델이 role 을 강하게 믿지 않도록 덧붙이는 문구
LOW_CONFIDENCE_NOTE = (
    "이 이미지 유형(role) 추정의 신뢰도가 낮습니다. role 을 강하게 믿지 말고, "
    "이미지에서 실제로 보이는 내용을 우선 판단하세요."
)


def output_schema_hint_for(role: Optional[str]) -> Dict[str, Any]:
    """role 에 맞는 output_schema_hint (없으면 공통 schema 의 사본)."""
    schema = ROLE_OUTPUT_SCHEMA_HINT.get(role or "")
    if schema is not None:
        return dict(schema)
    return dict(COMMON_OUTPUT_SCHEMA_HINT)


def role_instruction_for(role: Optional[str], role_confidence: Optional[str]) -> str:
    """role 별 suggested instruction(hint). role_confidence 가 낮으면 경고 문구를 덧붙인다."""
    text = ROLE_INSTRUCTION_MAP.get(role or "", DEFAULT_ROLE_INSTRUCTION)
    if (role_confidence or "").lower() in ("low", "none"):
        text = f"{text}\n{LOW_CONFIDENCE_NOTE}"
    return text


# =========================================================
# Evidence Card / manifest item → hint 필드 추출
# =========================================================

def _evidence_hints(image_item: Dict[str, Any]) -> Dict[str, Any]:
    """manifest item(또는 그 evidence_card)에서 모델 입력용 hint 필드를 뽑는다.

    evidence_card 가 이미 attach 돼 있으면 그 값을 우선 사용하고, 없으면 manifest
    item 의 원시 메타 + 매핑 상수로 보강한다(모델/OCR 미호출).
    """
    card = image_item.get("evidence_card") or {}
    role = card.get("image_role") or image_item.get("image_role") or "unknown"
    quality = image_item.get("image_quality") or {}

    extraction_target = (
        card.get("extraction_target")
        or ROLE_EXTRACTION_TARGET.get(role, ROLE_EXTRACTION_TARGET["unknown"])
    )
    instruction_key = (
        card.get("model_instruction_key")
        or ROLE_MODEL_INSTRUCTION_KEY.get(role, DEFAULT_INSTRUCTION_KEY)
    )
    context_strength = card.get("context_strength") or compute_context_strength(image_item)
    ai_input_strategy = (
        card.get("ai_input_strategy")
        or ((image_item.get("ai_image_variants") or {}).get("ai_readable") or {}).get("recommended_action")
    )

    return {
        "image_id": image_item.get("image_id"),
        # image_role 은 정답이 아니라 hint
        "image_role_hint": role,
        "role_source": card.get("image_role_source") or image_item.get("image_role_source"),
        "role_confidence": card.get("image_role_confidence") or image_item.get("image_role_confidence"),
        "readability_status": card.get("readability_status") or quality.get("readability_status"),
        "recommendation_level": card.get("recommendation_level") or quality.get("recommendation_level"),
        "context_strength": context_strength,
        "extraction_target": extraction_target,
        "model_instruction_key": instruction_key,
        "ai_input_strategy": ai_input_strategy,
        "quality_warning": card.get("quality_warning"),
    }


def _ai_input_strategy_to_image_ref(strategy: Optional[str]) -> str:
    """ai_readable.recommended_action → image_ref.input_strategy 라벨.

    실제 이미지 로딩은 모델 호출 단계에서만 수행한다(여기선 image_id 중심 참조만).
    """
    s = (strategy or "").lower()
    if s in ("use_original", "use_as_is"):
        return "use_original"
    if s in ("needs_higher_resolution", "upscale_needed"):
        return "needs_higher_resolution"
    if s in ("use_tiles", "tile"):
        return "use_tiles"
    # 기본: 원본 사용하되 조건부(가독성/맥락 약하면 검증 필요)
    return "use_original_conditional"


# =========================================================
# Model Input Packet 빌더
# =========================================================

def build_model_input_packet(
    project_context: Dict[str, Any],
    image_item: Dict[str, Any],
    *,
    provider: str = DEFAULT_PROVIDER,
    mode: str = "image_evidence_extraction",
    input_mode: str = DEFAULT_INPUT_MODE,
) -> Dict[str, Any]:
    """image_manifest item 1건을 표준 model_input_packet 으로 변환한다.

    **모델을 호출하지 않는다.** "모델에 넘길 수 있는 표준 입력 구조" 만 생성한다.

    Args:
        project_context: build_project_ai_context().project_context (project/tasks 등).
            현재는 project name 정도만 참조하지만, 향후 확장을 위해 전체를 받는다.
        image_item: image_manifest 의 단일 항목(evidence_card 가 attach 돼 있으면 재사용).
        provider: 입력 패킷이 향할 provider 라벨(메타에만 기록, 호출 안 함).
        mode: 추출 모드 라벨(기본 image_evidence_extraction).
        input_mode: A/B/C 비교용. image_only / image_with_nearby_text /
            image_with_evidence_card.

    Returns:
        dict — packet_version / provider / mode / input_mode / task_context /
        text_context / image_context_hints / model_instruction / safety_policy.
    """
    if input_mode not in INPUT_MODES:
        input_mode = DEFAULT_INPUT_MODE

    hints = _evidence_hints(image_item)
    role = hints["image_role_hint"]
    role_confidence = hints["role_confidence"]

    proj = (project_context or {}).get("project") or {}
    project_name = image_item.get("project_name") or proj.get("name")

    task_context = {
        "project_id": image_item.get("project_id") or proj.get("id"),
        "project_name": project_name,
        "sub_project_id": image_item.get("sub_project_id"),
        "sub_project_name": image_item.get("sub_project_name"),
        "task_id": image_item.get("task_id"),
        "task_title": image_item.get("task_title"),
        "source_entity_type": image_item.get("source_entity_type"),
        "relation_type": image_item.get("relation_type"),
    }

    # ── text_context (input_mode 에 따라 포함 여부 달라짐) ──
    if input_mode == "image_only":
        text_context = {
            "nearby_text": "",
            "fallback_context_text": "",
            "context_text_source": None,
            "context_strength": "none",
        }
    else:
        text_context = {
            "nearby_text": image_item.get("nearby_text") or "",
            "fallback_context_text": image_item.get("fallback_context_text") or "",
            "context_text_source": image_item.get("context_text_source"),
            "context_strength": hints["context_strength"],
        }

    # ── image_context_hints ──
    # image_only/nearby_text 모드에서도 image_id 는 필요하나, role/extraction 같은
    # Evidence Card 힌트는 image_with_evidence_card 에서만 채운다.
    if input_mode == "image_with_evidence_card":
        image_context_hints = {
            "image_id": hints["image_id"],
            "image_role_hint": role,
            "role_source": hints["role_source"],
            "role_confidence": role_confidence,
            "readability_status": hints["readability_status"],
            "recommendation_level": hints["recommendation_level"],
            "extraction_target": hints["extraction_target"],
            "model_instruction_key": hints["model_instruction_key"],
            # AI 입력 전략(원본/조건부원본/고해상도필요 등) — image_ref.input_strategy 산출용
            "ai_input_strategy": hints["ai_input_strategy"],
        }
    else:
        image_context_hints = {
            "image_id": hints["image_id"],
            "image_role_hint": None,
            "role_source": None,
            "role_confidence": None,
            "readability_status": None,
            "recommendation_level": None,
            "extraction_target": None,
            "model_instruction_key": None,
            "ai_input_strategy": None,
        }

    # ── model_instruction ──
    # global_rule 은 항상 포함(충돌 방지). role_instruction / output_schema_hint 는
    # Evidence Card 모드에서만 role 기반으로 채운다.
    if input_mode == "image_with_evidence_card":
        model_instruction = {
            "instruction_strength": "hint",
            "global_rule": GLOBAL_RULE,
            "role_instruction": role_instruction_for(role, role_confidence),
            "output_schema_hint": output_schema_hint_for(role),
        }
    else:
        model_instruction = {
            "instruction_strength": "hint",
            "global_rule": GLOBAL_RULE,
            "role_instruction": None,
            "output_schema_hint": dict(COMMON_OUTPUT_SCHEMA_HINT),
        }

    safety_policy = {
        "do_not_guess": True,
        "visible_content_first": True,
        "metadata_is_hint_only": True,
        "preserve_uncertainty": True,
    }

    return {
        "packet_version": MODEL_INPUT_PACKET_VERSION,
        "provider": provider,
        "mode": mode,
        "input_mode": input_mode,
        "task_context": task_context,
        "text_context": text_context,
        "image_context_hints": image_context_hints,
        "model_instruction": model_instruction,
        "safety_policy": safety_policy,
    }


# =========================================================
# Provider Adapter
#   사내 모델 API 포맷이 확정되기 전이라 payload 구조만 준비한다.
#   실제 호출은 하지 않으며, 이미지 binary/base64/storage path 도 넣지 않는다.
# =========================================================

class BaseModelInputAdapter:
    """provider 별 payload 빌더 base. build_payload 만 구현하면 된다."""

    provider = "base"

    def build_payload(self, packet: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError


def _render_system_message(packet: Dict[str, Any]) -> str:
    """system prompt 후보(충돌 방지 global rule 중심)."""
    return packet["model_instruction"]["global_rule"]


def _render_user_message(packet: Dict[str, Any]) -> str:
    """user prompt 후보. input_mode 에 따라 포함되는 맥락이 달라진다.

    실제 이미지는 image_id 로만 참조하고, 본문에는 binary/base64/경로를 넣지 않는다.
    """
    tc = packet.get("task_context") or {}
    txt = packet.get("text_context") or {}
    hints = packet.get("image_context_hints") or {}
    instr = packet.get("model_instruction") or {}

    lines: List[str] = [
        "아래 이미지와 업무 맥락을 바탕으로 evidence 를 추출하세요.",
        "metadata 는 힌트이며, 이미지에서 실제로 보이는 내용을 우선하세요.",
        "",
        "[업무 맥락]",
        f"- project: {tc.get('project_name') or '-'}",
        f"- task: {tc.get('task_title') or '-'}",
        f"- relation: {tc.get('relation_type') or '-'}",
    ]

    nearby = (txt.get("nearby_text") or "").strip()
    fallback = (txt.get("fallback_context_text") or "").strip()
    if nearby:
        lines.append(f"- 주변 텍스트: {nearby}")
    elif fallback:
        lines.append(f"- 보조 맥락 텍스트: {fallback}")
    if txt.get("context_strength"):
        lines.append(f"- 맥락 신뢰도(context_strength): {txt.get('context_strength')}")

    if hints.get("image_role_hint"):
        lines.append("")
        lines.append("[이미지 힌트] (정답 아님)")
        lines.append(f"- 추정 유형(image_role_hint): {hints.get('image_role_hint')}")
        lines.append(f"- 추정 신뢰도(role_confidence): {hints.get('role_confidence') or '-'}")
        if hints.get("extraction_target"):
            lines.append(f"- 추출 목표(extraction_target): {hints.get('extraction_target')}")

    role_instruction = instr.get("role_instruction")
    if role_instruction:
        lines.append("")
        lines.append("[권장 작업]")
        lines.append(role_instruction)

    schema = instr.get("output_schema_hint")
    if schema:
        lines.append("")
        lines.append("[권장 출력 형식(JSON)]")
        lines.append(", ".join(schema.keys()))

    return "\n".join(lines)


def _common_payload(packet: Dict[str, Any], provider: str) -> Dict[str, Any]:
    hints = packet.get("image_context_hints") or {}
    txt = packet.get("text_context") or {}
    return {
        "provider": provider,
        "messages": [
            {"role": "system", "content": _render_system_message(packet)},
            {"role": "user", "content": _render_user_message(packet)},
        ],
        "metadata": {
            "image_id": hints.get("image_id"),
            "image_role_hint": hints.get("image_role_hint"),
            "context_strength": txt.get("context_strength"),
            "input_mode": packet.get("input_mode"),
            "packet_version": packet.get("packet_version"),
        },
        # 이미지 binary/base64/storage path 미포함 — image_id 중심 참조.
        "image_ref": {
            "image_id": hints.get("image_id"),
            "input_strategy": _ai_input_strategy_to_image_ref(hints.get("ai_input_strategy")),
        },
    }


class GenericVisionAdapter(BaseModelInputAdapter):
    """provider 미확정 단계의 표준(OpenAI-호환 messages 형태) payload."""

    provider = "generic"

    def build_payload(self, packet: Dict[str, Any]) -> Dict[str, Any]:
        return _common_payload(packet, self.provider)


class DSLLMVisionAdapter(BaseModelInputAdapter):
    """사내 DSLLM/Vision 용 payload **자리표시자(placeholder)**.

    실제 사내 API 스펙이 확정되면 이 클래스만 수정한다. 현재는 generic 과 거의 동일하되
    provider 라벨/추가 schema_hint 만 분리해 둔다(실제 호출 없음).
    """

    provider = "dsllm"

    def build_payload(self, packet: Dict[str, Any]) -> Dict[str, Any]:
        payload = _common_payload(packet, self.provider)
        instr = packet.get("model_instruction") or {}
        # DSLLM 내부 룰과 충돌 가능성이 있으므로 schema 는 "권장(hint)" 임을 명시.
        payload["output_schema_hint"] = instr.get("output_schema_hint")
        payload["instruction_strength"] = instr.get("instruction_strength", "hint")
        payload["_note"] = "DSLLM payload placeholder — 실제 API 스펙 확정 시 이 어댑터만 수정"
        return payload


_ADAPTERS: Dict[str, BaseModelInputAdapter] = {
    "generic": GenericVisionAdapter(),
    "dsllm": DSLLMVisionAdapter(),
}


def build_provider_payload(packet: Dict[str, Any], provider: str = DEFAULT_PROVIDER) -> Dict[str, Any]:
    """packet → provider payload. **실제 모델 호출은 하지 않는다.**

    provider 가 미지원이면 generic 으로 fallback 한다.
    """
    adapter = _ADAPTERS.get((provider or "").lower(), _ADAPTERS["generic"])
    return adapter.build_payload(packet)
