# app/services/knox_client.py
import logging
import os
from typing import Optional, Any, Dict, List
import httpx

logger = logging.getLogger("uvicorn.error")


def knox_employee_url() -> Optional[str]:
    """임직원 API 호출 URL. 공통 Knox Gateway base(KNOX_API_URL) + 기능별 path 방식.

      KNOX_EMPLOYEE_API_PATH 있음 → {KNOX_API_URL}{KNOX_EMPLOYEE_API_PATH}
      KNOX_EMPLOYEE_API_PATH 없음 → {KNOX_API_URL} 그대로  (기존 full endpoint 방식과 하위호환)

    앞으로는 base + path 방식이 기본. mail 발송(mail_sender)도 같은 KNOX_API_URL base 를 재사용한다.
    """
    base = (os.getenv("KNOX_API_URL") or "").strip()
    if not base:
        return None
    path = (os.getenv("KNOX_EMPLOYEE_API_PATH") or "").strip()
    if path:
        return base.rstrip("/") + path
    return base  # 하위호환: KNOX_API_URL 을 full endpoint 로 쓰던 기존 배포


def knox_config_state() -> Dict[str, Any]:
    """KNOX 설정/프록시 상태 스냅샷. token 원문은 절대 포함하지 않는다."""
    return {
        "knox_api_url_configured": bool(os.getenv("KNOX_API_URL")),
        "knox_employee_api_path": (os.getenv("KNOX_EMPLOYEE_API_PATH") or "").strip() or None,
        "knox_auth_token_configured": bool(os.getenv("KNOX_AUTH_TOKEN")),
        "knox_system_id_configured": bool(os.getenv("KNOX_SYSTEM_ID")),
        "http_proxy": os.getenv("HTTP_PROXY") or os.getenv("http_proxy"),
        "https_proxy": os.getenv("HTTPS_PROXY") or os.getenv("https_proxy"),
        "no_proxy": os.getenv("NO_PROXY") or os.getenv("no_proxy"),
        "trust_env": False,  # knox_client는 항상 trust_env=False (프록시 env 무시)
    }


def log_knox_env_state() -> None:
    """서버 기동 시 1회 — KNOX env/프록시 상태를 마스킹하여 가시화한다."""
    logger.info("[KNOX] API_URL(base)=%s", os.getenv("KNOX_API_URL") or "<missing>")
    logger.info("[KNOX] EMPLOYEE_API_PATH=%s", (os.getenv("KNOX_EMPLOYEE_API_PATH") or "").strip() or "<none: base를 full endpoint로 사용>")
    logger.info("[KNOX] AUTH_TOKEN configured=%s", bool(os.getenv("KNOX_AUTH_TOKEN")))
    logger.info("[KNOX] SYSTEM_ID configured=%s", bool(os.getenv("KNOX_SYSTEM_ID")))
    logger.info("[KNOX] HTTP_PROXY=%s", os.getenv("HTTP_PROXY") or os.getenv("http_proxy"))
    logger.info("[KNOX] HTTPS_PROXY=%s", os.getenv("HTTPS_PROXY") or os.getenv("https_proxy"))
    logger.info("[KNOX] NO_PROXY=%s", os.getenv("NO_PROXY"))
    logger.info("[KNOX] no_proxy=%s", os.getenv("no_proxy"))
    logger.info("[KNOX] client trust_env=False (proxy/no_proxy env 무시, 사내망 직접 연결)")


class KnoxError(RuntimeError):
    """KNOX 호출 실패. error_type 으로 원인(연결/타임아웃/인증/경로)을 구분한다.

    RuntimeError 를 상속하므로 기존 `except RuntimeError` 핸들러와 호환된다.
    error_type 예시: ConfigMissing, ConnectTimeout, ConnectError, ReadTimeout,
    Unauthorized, NotFound, HTTPError, RequestError, InvalidJSON
    """

    def __init__(self, message: str, *, error_type: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.error_type = error_type
        self.status_code = status_code


def _log_knox_failure(message: str, *, detail=None, status_code=None):
    """system_event_logs 에 Knox 실패 요약 기록 (검색어/토큰 등 민감정보는 저장하지 않음)."""
    try:
        from app.services.system_log import log_event
        log_event("ERROR", "KNOX", message, detail=detail, status_code=status_code)
    except Exception:
        pass


REQUEST_BODY = {
    "resultType": "optional",
    "attributes": [
        "userId",
        "fullName",
        "employeeNumber",
        "departmentCode",
        "departmentName",
        "description",
        "mail",
    ],
}

def _extract_employees(raw: Any) -> List[Dict[str, Any]]:
    if raw is None:
        return []
    if isinstance(raw, dict):
        for key in ("employees", "data", "result", "items", "results", "value"):
            v = raw.get(key)
            if isinstance(v, list):
                return v
        for v in raw.values():
            if isinstance(v, list):
                return v
    if isinstance(raw, list):
        return raw
    return []

async def knox_search_employees(
    *,
    fullName: Optional[str] = None,
    userIds: Optional[str] = None,
    companyCode: str = "C10",
) -> List[Dict[str, Any]]:
    # ✅ 매 호출마다 env를 읽어서 “import 타이밍” 문제 제거
    knox_url = knox_employee_url()  # base(KNOX_API_URL) + KNOX_EMPLOYEE_API_PATH (없으면 base 그대로)
    knox_token = os.getenv("KNOX_AUTH_TOKEN")
    knox_system_id = os.getenv("KNOX_SYSTEM_ID")

    if not knox_url or not knox_token or not knox_system_id:
        raise KnoxError(
            "KNOX env 설정이 누락되었습니다. (KNOX_API_URL / KNOX_AUTH_TOKEN / KNOX_SYSTEM_ID)",
            error_type="ConfigMissing",
        )

    if not fullName and not userIds:
        return []

    headers = {
        "accept": "*/*",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {knox_token}",
        "System-ID": knox_system_id,
    }

    params = {"companyCode": companyCode}
    if fullName:
        params["fullName"] = fullName
    if userIds:
        params["userIds"] = userIds

    # connect 5s는 사내망 지연에 너무 짧을 수 있어 상향. read는 응답 지연 대비.
    timeout = httpx.Timeout(20.0, connect=10.0)

    # trust_env=False: KNOX는 사내망 직접 연결이며, 프록시/no_proxy 등 env 설정의
    # 영향을 의도적으로 받지 않는다. (DSLLM용 no_proxy 설정과 완전히 분리)
    try:
        async with httpx.AsyncClient(trust_env=False, verify=False, timeout=timeout) as client:
            resp = await client.post(
                knox_url,
                headers=headers,
                json=REQUEST_BODY,
                params=params,
            )
    except httpx.ConnectTimeout as e:
        _log_knox_failure("Knox 검색 connect timeout", detail=str(e)[:300])
        raise KnoxError(f"KNOX connect timeout: {e}", error_type="ConnectTimeout")
    except httpx.ReadTimeout as e:
        _log_knox_failure("Knox 검색 read timeout", detail=str(e)[:300])
        raise KnoxError(f"KNOX read timeout: {e}", error_type="ReadTimeout")
    except (httpx.ConnectError, httpx.ProxyError) as e:
        _log_knox_failure(f"Knox 검색 connect error: {type(e).__name__}", detail=str(e)[:300])
        raise KnoxError(f"KNOX connect error: {type(e).__name__}: {e}", error_type="ConnectError")
    except httpx.RequestError as e:
        # ✅ 여기로 오면 운영망에서 KNOX 접근 자체가 실패한 것
        _log_knox_failure(f"Knox 검색 요청 실패: {type(e).__name__}", detail=str(e)[:300])
        raise KnoxError(f"KNOX 요청 실패: {type(e).__name__}: {e}", error_type="RequestError")

    if resp.status_code != 200:
        if resp.status_code in (401, 403):
            et = "Unauthorized"
        elif resp.status_code == 404:
            et = "NotFound"
        else:
            et = "HTTPError"
        _log_knox_failure(f"Knox 검색 HTTP {resp.status_code} ({et})", status_code=resp.status_code)
        raise KnoxError(
            f"KNOX error {resp.status_code}: {resp.text[:300]}",
            error_type=et,
            status_code=resp.status_code,
        )

    try:
        raw = resp.json()
    except ValueError:
        raise KnoxError(f"KNOX 응답이 JSON이 아님: {resp.text[:300]}", error_type="InvalidJSON")

    employees = _extract_employees(raw)

    normalized: List[Dict[str, Any]] = []
    for e in employees:
        if not isinstance(e, dict):
            continue
        normalized.append(
            {
                "userId": e.get("userId"),
                "fullName": e.get("fullName"),
                "departmentName": e.get("departmentName"),
                "departmentCode": e.get("departmentCode"),
                "employeeNumber": e.get("employeeNumber"),
                # ---- alias 추가 (프론트 호환) ----
                "loginid": e.get("userId"),
                "deptname": e.get("departmentName"),
                "email": e.get("mail") or e.get("email"),
            }
        )
    return normalized



async def knox_lookup_user(loginid: str) -> Optional[Dict[str, Any]]:
    """loginid로 정확히 1명 찾기"""
    q = (loginid or "").strip()
    if not q:
        return None

    # KNOX가 부분검색을 돌려줄 수 있으니, exact match를 우선
    lst = await knox_search_employees(userIds=q)
    for e in lst:
        if e.get("userId") == q:
            return e

    # 없으면 첫 번째를 쓰고 싶다면(정책): return lst[0] if lst else None
    return None
