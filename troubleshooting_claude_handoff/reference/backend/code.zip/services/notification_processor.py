"""
notification_events(outbox) 소비 processor + APScheduler.

멘션 이벤트(task_comment_mentioned / task_work_note_mentioned)의 pending row 를 주기적으로
처리해서 조건을 만족하면 users.mail 로 메일을 보낸다.

VOC 답변 이벤트(voc_reply_created)도 같은 스케줄러가 처리하되, 처리 규칙이 달라
(_process_voc_reply) 별도 분기로 다룬다: 관리자가 답변 작성 시 "메일 보내기"를 체크한
경우에만 생성되며, 멘션 pref/접근권한/self 체크 없이 수신자(VOC 작성자) 이메일만 있으면 발송한다.

발송 조건(모두 충족해야 sent 시도):
  1. event.status == pending
  2. target_user 존재 & users.mail 존재
  3. master(mention_email_enabled) AND event별 세부 pref = true
  4. actor_user_id != target_user_id
  5. payload.send_email == true (작성자 측 "메일 알림 보내기")
  6. target 이 해당 task/project 접근 가능 (can_access_task)
  7. MAIL_PROVIDER != disabled
조건 미충족 → status=skipped(+error_message=사유). 발송 실패 → status=failed(+error_message).
댓글/작업노트 저장 자체에는 영향을 주지 않는다(별도 스케줄러 스레드에서 처리).

동시성: 앱 프로세스 내 단일 BackgroundScheduler 를 전제로 한다. 그래도 row 별
'pending→processing' 가드 UPDATE 로 이중 처리를 방지한다(멀티 worker 배포 시에도 안전).
"""

from __future__ import annotations

import logging
import os
from datetime import datetime
from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy import update

from app.db_connections.sqlalchemy import SessionLocal
from app.models import (
    NotificationEvent, User, Task, Project, TaskComment, TaskActivity,
    UserNotificationPreference, VocItem, VocComment,
)
from app.services import mail_sender
from app.services import mail_templates

logger = logging.getLogger("notification_processor")

_MENTION_EVENT_TYPES = ("task_comment_mentioned", "task_work_note_mentioned")
# VOC 알림(관리자 opt-in). 멘션과 처리 로직이 달라 별도 분기로 처리한다.
#   - voc_reply_created: (구) 관리자 답변 알림 — 남아있는 pending row 호환용으로 계속 처리.
#   - voc_admin_memo_mail_requested: 관리자 메모 저장 시 opt-in 알림 (현재 경로).
_VOC_EVENT_TYPES = ("voc_reply_created", "voc_admin_memo_mail_requested")
_PROCESSED_EVENT_TYPES = _MENTION_EVENT_TYPES + _VOC_EVENT_TYPES

_scheduler: Optional[BackgroundScheduler] = None


# ── 환경변수 (호출 시점에 읽음) ──
def _processor_enabled() -> bool:
    return (os.getenv("NOTIFICATION_PROCESSOR_ENABLED") or "true").strip().lower() in ("1", "true", "yes", "on")


def _interval_seconds() -> int:
    try:
        return max(10, int(os.getenv("NOTIFICATION_PROCESSOR_INTERVAL_SECONDS", "60")))
    except (TypeError, ValueError):
        return 60


# ── 사용자 알림설정 get-or-create (prefs API 와 공용) ──
def get_or_create_preference(db, user_id: int) -> UserNotificationPreference:
    pref = (
        db.query(UserNotificationPreference)
        .filter(UserNotificationPreference.user_id == int(user_id))
        .first()
    )
    if pref is None:
        pref = UserNotificationPreference(user_id=int(user_id))
        db.add(pref)
        db.commit()
        db.refresh(pref)
    return pref


def _pref_allows(pref: UserNotificationPreference, event_type: str) -> bool:
    if not bool(pref.mention_email_enabled):
        return False
    if event_type == "task_comment_mentioned":
        return bool(pref.task_mention_email_enabled)
    if event_type == "task_work_note_mentioned":
        return bool(pref.work_note_mention_email_enabled)
    return False


def _finalize(db, event: NotificationEvent, status: str, error: Optional[str] = None) -> None:
    event.status = status
    event.error_message = (error or None)
    event.processed_at = datetime.utcnow()
    db.commit()


def _claim(db, event_id: int) -> bool:
    """pending → processing 가드 UPDATE. 소유권을 얻으면 True."""
    res = db.execute(
        update(NotificationEvent)
        .where(NotificationEvent.id == event_id, NotificationEvent.status == "pending")
        .values(status="processing")
    )
    db.commit()
    return (res.rowcount or 0) == 1


def _load_source(db, event: NotificationEvent):
    """(location_label, content, created_at_str) 반환. 삭제/미존재면 (None, ...)."""
    payload = event.payload_json or {}
    if event.event_type == "task_comment_mentioned":
        cid = payload.get("comment_id")
        c = db.query(TaskComment).filter(
            TaskComment.id == cid, TaskComment.deleted_at.is_(None)
        ).first() if cid else None
        if not c:
            return None, None, None
        created = c.created_at.strftime("%Y-%m-%d %H:%M") if c.created_at else ""
        return "Comments", c.content or "", created
    else:  # task_work_note_mentioned
        wid = payload.get("work_note_id")
        a = db.query(TaskActivity).filter(TaskActivity.id == wid).first() if wid else None
        if not a:
            return None, None, None
        created = a.created_at.strftime("%Y-%m-%d %H:%M") if a.created_at else ""
        return "작업노트", a.content or "", created


def _process_voc_reply(db, event: NotificationEvent) -> None:
    """VOC 알림 메일 처리 (관리자 메모 알림 / 구 답변 알림 공용).

    멘션 메일과 달리:
      - 사용자 멘션 pref/접근권한 체크 없음(관리자가 명시적으로 발송을 선택).
      - self(관리자==작성자) 여도 발송 허용.
      - 대신 payload.send_mail 이 true 이고 수신자 이메일이 있어야 한다.
    """
    # 1) provider disabled
    if not mail_sender.is_mail_enabled():
        _finalize(db, event, "skipped", "provider_disabled")
        return

    payload = event.payload_json or {}
    # 2) 관리자 opt-in 여부 (체크 안 했으면 애초에 이벤트가 없어야 하지만 방어)
    if not bool(payload.get("send_mail", False)):
        _finalize(db, event, "skipped", "send_mail_off")
        return

    # 3) 수신자(VOC 작성자) + 이메일
    if not event.target_user_id:
        _finalize(db, event, "skipped", "no_target")
        return
    target = db.query(User).filter(User.id == event.target_user_id).first()
    if not target:
        _finalize(db, event, "skipped", "target_not_found")
        return
    if not (target.mail or "").strip():
        _finalize(db, event, "skipped", "no_recipient_email")
        return

    # 4) source 로드 (VOC). 삭제/미존재면 skip.
    voc_id = payload.get("voc_id")
    voc = db.query(VocItem).filter(VocItem.id == voc_id).first() if voc_id else None
    if not voc:
        _finalize(db, event, "skipped", "source_deleted")
        return

    voc_url = mail_templates.build_voc_url(voc.id)

    # 5) 이벤트 종류별 메일 빌드
    if event.event_type == "voc_admin_memo_mail_requested":
        # 관리자 메모 알림 — 현재 VOC의 admin_note 를 본문으로 사용.
        memo = (voc.admin_note or "").strip()
        if not memo:
            _finalize(db, event, "skipped", "source_deleted")
            return
        subject, text_body, html_body = mail_templates.build_voc_admin_memo_email(
            voc_title=voc.title or "VOC",
            memo_content=memo,
            voc_url=voc_url,
        )
    else:
        # (구) 관리자 답변 알림 — reply_id 로 댓글 본문 로드.
        reply_id = payload.get("reply_id")
        reply = db.query(VocComment).filter(VocComment.id == reply_id).first() if reply_id else None
        if not reply:
            _finalize(db, event, "skipped", "source_deleted")
            return
        subject, text_body, html_body = mail_templates.build_voc_reply_email(
            voc_title=voc.title or "VOC",
            reply_content=reply.content or "",
            voc_url=voc_url,
        )

    result = mail_sender.send_mail(target.mail.strip(), subject, text_body, html_body)
    if result.status == "sent":
        if result.provider_message_id:
            pj = dict(event.payload_json or {})
            pj["mail_id"] = result.provider_message_id
            event.payload_json = pj
        _finalize(db, event, "sent", None)
    elif result.status in ("disabled", "skipped"):
        _finalize(db, event, "skipped", result.error or result.status)
    else:
        _finalize(db, event, "failed", result.error or "send_failed")


def _process_one(db, event: NotificationEvent) -> None:
    # VOC 답변 알림은 멘션과 처리 규칙이 다르므로 별도 분기.
    if event.event_type in _VOC_EVENT_TYPES:
        _process_voc_reply(db, event)
        return

    # 1) provider disabled → 실제 발송 없음
    if not mail_sender.is_mail_enabled():
        _finalize(db, event, "skipped", "provider_disabled")
        return

    # 2) 대상/작성자
    if not event.target_user_id:
        _finalize(db, event, "skipped", "no_target")
        return
    if event.actor_user_id and int(event.actor_user_id) == int(event.target_user_id):
        from app.services.notifications import allow_self_mention
        if not allow_self_mention():
            _finalize(db, event, "skipped", "self_mention")
            return

    target = db.query(User).filter(User.id == event.target_user_id).first()
    if not target:
        _finalize(db, event, "skipped", "target_not_found")
        return
    if not (target.mail or "").strip():
        _finalize(db, event, "skipped", "no_mail")
        return

    # 3) 작성자 측 opt-in
    payload = event.payload_json or {}
    if not bool(payload.get("send_email", False)):
        _finalize(db, event, "skipped", "sender_optout")
        return

    # 4) 수신자 설정
    pref = get_or_create_preference(db, target.id)
    if not _pref_allows(pref, event.event_type):
        _finalize(db, event, "skipped", "pref_off")
        return

    # 5) 접근 권한 (권한 없는 사용자에게 발송 금지)
    from app.services.mention_resolver import can_access_task
    if not can_access_task(db, target.id, event.project_id):
        _finalize(db, event, "skipped", "no_access")
        return

    # 6) source 로드 (삭제/미존재면 skip)
    location_label, content, created_str = _load_source(db, event)
    if location_label is None:
        _finalize(db, event, "skipped", "source_deleted")
        return

    # 7) 표시 정보
    actor = db.query(User).filter(User.id == event.actor_user_id).first() if event.actor_user_id else None
    # 실제 User 컬럼(username NOT NULL / loginid / mail)만 존재 — display_name/name 없음.
    # 작업노트 메일 "누군가" 버그: 프론트가 author_id 를 안 보내 actor 가 NULL 이던 것이 근본 원인이며,
    # 여기서도 username→loginid→mail 순으로 보강해 조회 성공 시 실제 작성자명이 나오도록 한다.
    actor_name = (
        (getattr(actor, "username", None) or getattr(actor, "loginid", None) or getattr(actor, "mail", None))
        if actor else None
    ) or "누군가"
    task = db.query(Task).filter(Task.id == event.task_id).first() if event.task_id else None
    task_title = (task.title if task and task.title else None) or f"태스크 #{event.task_id}"
    project = db.query(Project).filter(Project.id == event.project_id).first() if event.project_id else None
    project_name = (project.name if project and project.name else None) or "프로젝트"
    mention_ref = payload.get("mention_ref") or ""
    mention_url = mail_templates.build_mention_url(mention_ref)

    subject, text_body, html_body = mail_templates.build_mention_email(
        actor_name=actor_name,
        project_name=project_name,
        task_title=task_title,
        location_label=location_label,
        created_at=created_str or "",
        content_preview=content,
        mention_url=mention_url,
    )

    result = mail_sender.send_mail(target.mail.strip(), subject, text_body, html_body)
    if result.status == "sent":
        # 발송 성공 시 provider mailId 를 payload_json 에 남긴다(error_message 는 NULL 유지).
        if result.provider_message_id:
            pj = dict(event.payload_json or {})
            pj["mail_id"] = result.provider_message_id
            event.payload_json = pj  # 새 dict 할당으로 JSON 컬럼 변경 감지
        _finalize(db, event, "sent", None)
    elif result.status in ("disabled", "skipped"):
        _finalize(db, event, "skipped", result.error or result.status)
    else:  # failed
        _finalize(db, event, "failed", result.error or "send_failed")


def process_pending_notification_events(limit: int = 50) -> dict:
    """pending 멘션 이벤트를 처리한다. 반환: 처리 카운트 요약."""
    db = SessionLocal()
    counts = {"sent": 0, "skipped": 0, "failed": 0, "seen": 0}
    try:
        rows = (
            db.query(NotificationEvent.id)
            .filter(
                NotificationEvent.status == "pending",
                NotificationEvent.event_type.in_(_PROCESSED_EVENT_TYPES),
            )
            .order_by(NotificationEvent.created_at.asc())
            .limit(limit)
            .all()
        )
        for (event_id,) in rows:
            counts["seen"] += 1
            if not _claim(db, event_id):
                continue  # 다른 worker 가 이미 가져감
            event = db.query(NotificationEvent).filter(NotificationEvent.id == event_id).first()
            if not event:
                continue
            try:
                _process_one(db, event)
                counts[event.status] = counts.get(event.status, 0) + 1
            except Exception as e:  # noqa: BLE001
                logger.warning("[notification] event %s 처리 실패: %s", event_id, e)
                try:
                    db.rollback()
                    _finalize(db, event, "failed", f"processor_error: {e}")
                    counts["failed"] += 1
                except Exception:
                    try:
                        db.rollback()
                    except Exception:
                        pass
    finally:
        db.close()
    if counts["seen"]:
        logger.info("[notification] processed %s", counts)
    return counts


# ── 스케줄러 ──────────────────────────────────────────────
def start_notification_scheduler() -> None:
    """FastAPI startup 에서 호출. backup_scheduler 와 달리 S3 무관하게 시작."""
    global _scheduler
    if not _processor_enabled():
        logger.info("알림 processor 비활성화됨 (NOTIFICATION_PROCESSOR_ENABLED=false)")
        return
    if _scheduler and _scheduler.running:
        logger.info("알림 processor 스케줄러 이미 실행 중")
        return

    interval = _interval_seconds()
    _scheduler = BackgroundScheduler(timezone="Asia/Seoul")
    _scheduler.add_job(
        process_pending_notification_events,
        "interval",
        seconds=interval,
        id="notification_processor",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
        misfire_grace_time=interval,
    )
    _scheduler.start()
    logger.info("알림 processor 스케줄러 시작됨 (interval=%ss, provider=%s)", interval, mail_sender.get_mail_provider())


def stop_notification_scheduler() -> None:
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("알림 processor 스케줄러 중지됨")
