"""super_admin 전용 이미지 포함 AI Report 테스트 (Vision Report Test PoC) — orchestration.

기존 텍스트 기반 종합보고서(`/api/report/generate`)와 **완전히 분리된** 별도 PoC.
프로젝트 내 Task/작업노트 캡처 이미지들을 ``text_context`` / ``nearby_text`` /
Image Evidence Card 와 함께 vision 모델(gpt-5.4-mini/gpt-5.4/gpt-5.5)에 넣어
**이미지별 해석 + 종합 요약 품질**을 비교 테스트한다.

이 모듈이 하는 일
-----------------
- 후보 image_manifest 에서 테스트 대상 이미지 **선택**(scope/image_ids/max_images)
- 선택 이미지별 model_input_packet → vision 모델 입력(messages content) **구성**
- 모델 raw 응답 **파싱**(JSON 유도, 실패 시 raw 보존)

이 모듈이 **하지 않는 것**
-------------------------
- DB 저장 (PoC 는 결과를 저장하지 않는다 — save_result 무시)
- 실제 이미지 파일 로딩 (image_id → bytes 는 호출자(main.py)가 서버 내부에서 처리)
- 실제 모델 호출 (openai_adapter.vision_chat 이 담당)
- 기존 report/ai-query 결과 변경

Evidence Card 는 **정답이 아니라 힌트**다. global rule(이미지 우선)을 항상 포함한다.
"""

from __future__ import annotations

import json
import re
from typing import Any, Callable, Dict, List, Optional, Tuple

from app.config import settings
from app.services.project_ai_model_compatibility import (
    GLOBAL_RULE,
    INPUT_MODES,
    DEFAULT_INPUT_MODE,
)

# =========================================================
# 제한/기본값 (부하·비용 가드)
# =========================================================
# 기본 UI 는 "프로젝트 전체 이미지"를 분석한다. 한 번에 모델에 다 넣지 않고 Stage 1 에서
# batch 로 나눠 처리하므로, 여기 상한은 "한 보고서가 다룰 이미지 총량"의 안전 한도일 뿐
# 입력 길이 제한이 아니다(= 일부를 제외하기 위한 값이 아니다).
VISION_TEST_DEFAULT_MAX_IMAGES = 5
# 절대 안전 상한(폭주 방지). 이 수를 넘어가는 초대형 프로젝트만 초과분이 제외된다.
VISION_TEST_HARD_MAX_IMAGES = 40
VISION_TEST_TIMEOUT_SECONDS = 60

# 모델 선택 기본 목록(env 미설정 시 fallback). env 로 override 가능.
DEFAULT_VISION_MODELS = ["gpt-5.4-mini", "gpt-5.4"]

# image_scope: 어떤 이미지를 자동/선택 대상으로 삼을지.
#   task_images_all: 프로젝트 Task/작업노트 이미지 전체(순서대로) — 기본.
#                    "버튼 하나로 프로젝트 전체 이미지 포함" UX 의도에 맞는 기본값.
#   auto          : Task/작업노트 이미지 전체를 우선순위로 랭킹해 상위 max_images 자동 선택
#   review_needed : 검토 필요 이미지만
#   selected      : 사용자가 직접 체크한 image_ids
# ``project_task_images_all`` 은 ``task_images_all`` 의 별칭(요청 호환).
IMAGE_SCOPES = ("task_images_all", "auto", "review_needed", "selected")
SCOPE_ALIASES = {"project_task_images_all": "task_images_all"}
DEFAULT_IMAGE_SCOPE = "task_images_all"

# "프로젝트 내 Task/작업노트 이미지" 로 간주하는 source_entity_type.
TASK_IMAGE_SOURCE_TYPES = {"task_description", "task_activity", "task_attachment"}

# auto 선택 시 우선 포함할 "의미 있는" image_role(자체 판독 가치가 높은 캡처).
MEANINGFUL_ROLES = {
    "error_screen", "table", "document_table", "chart", "text_crop", "document_crop",
    "meeting_slide", "command_snippet", "code_snippet", "log_capture",
    "terminal_capture", "equipment_screen", "result_capture",
}


def available_vision_models() -> List[str]:
    """UI 드롭다운에 노출할 vision 테스트 모델 목록.

    우선순위: ``OPENAI_VISION_MODELS`` → ``OPENAI_MODELS`` → DEFAULT_VISION_MODELS.
    """
    raw = (getattr(settings, "openai_vision_models", "") or "").strip()
    if not raw:
        raw = (getattr(settings, "openai_models", "") or "").strip()
    if raw:
        models = [m.strip() for m in raw.split(",") if m.strip()]
        if models:
            return models
    return list(DEFAULT_VISION_MODELS)


def default_vision_model() -> str:
    """기본 선택 모델. 우선순위: OPENAI_VISION_MODEL → OPENAI_MODEL → 목록 첫 번째."""
    for v in (getattr(settings, "openai_vision_model", ""), getattr(settings, "openai_model", "")):
        v = (v or "").strip()
        if v:
            return v
    models = available_vision_models()
    return models[0] if models else ""


def clamp_max_images(n: Any) -> int:
    """프론트 입력과 무관하게 서버에서 max_images 상한 강제.

    None/0 이하 → 기본 5, HARD(10) 초과 → 10 으로 clamp.
    """
    try:
        v = int(n)
    except (TypeError, ValueError):
        return VISION_TEST_DEFAULT_MAX_IMAGES
    if v <= 0:
        return VISION_TEST_DEFAULT_MAX_IMAGES
    return min(v, VISION_TEST_HARD_MAX_IMAGES)


def resolve_max_images(n: Any) -> int:
    """기본 UI(값 미지정/None) → 안전 상한(HARD)까지 "프로젝트 전체 이미지" 포함.

    명시값(고급 설정) → 1..HARD 로 clamp.
    UI 에는 max_images 를 노출하지 않으므로, 기본 호출은 항상 None 으로 들어와
    HARD 상한까지 자동 포함하고, 초과분은 호출자가 "제외/미처리"로 보고한다.
    """
    if n is None:
        return VISION_TEST_HARD_MAX_IMAGES
    return clamp_max_images(n)


def normalize_scope(scope: Optional[str]) -> str:
    s = (scope or "").strip().lower()
    s = SCOPE_ALIASES.get(s, s)
    return s if s in IMAGE_SCOPES else DEFAULT_IMAGE_SCOPE


def normalize_input_mode(mode: Optional[str]) -> str:
    return mode if mode in INPUT_MODES else DEFAULT_INPUT_MODE


# =========================================================
# 이미지 선택
# =========================================================

def _auto_tier(
    item: Dict[str, Any],
    warning_ids: set,
    is_normal: Optional[Callable[[Dict[str, Any], set], bool]],
) -> int:
    """auto 선택 우선순위(작을수록 우선). 정렬은 stable 이라 동일 tier 는 manifest 순서 유지.

    0 review_needed → 1 conditional → 2 weak/medium context → 3 의미 있는 role →
    4 기타 → 5 recommended 정상(후순위).
    """
    rec = (item.get("image_quality") or {}).get("recommendation_level")
    ctx = (item.get("evidence_card") or {}).get("context_strength")
    role = item.get("image_role")
    if is_normal is not None and not is_normal(item, warning_ids):
        return 0
    if rec == "conditional":
        return 1
    if ctx in ("weak", "medium"):
        return 2
    if role in MEANINGFUL_ROLES:
        return 3
    if rec == "recommended":
        return 5
    return 4


def select_images(
    manifest: List[Dict[str, Any]],
    *,
    image_ids: Optional[List[str]] = None,
    image_scope: str = DEFAULT_IMAGE_SCOPE,
    max_images: int = VISION_TEST_DEFAULT_MAX_IMAGES,
    warning_ids: Optional[set] = None,
    is_normal: Optional[Callable[[Dict[str, Any], set], bool]] = None,
) -> Tuple[List[Dict[str, Any]], str, List[str], Dict[str, int]]:
    """테스트 대상 이미지를 자동/수동으로 선택한다.

    우선순위:
      1. image_ids 가 있으면 → scope 'selected' 강제, manifest 순서 보존 매칭.
         manifest 에 없는 id 는 missing_ids 로 반환(권한 밖/존재하지 않음).
      2. scope == 'auto'(기본) → Task/작업노트 이미지를 우선순위 랭킹해 상위 선택.
      3. scope == 'review_needed' → 검토 필요(is_normal=False) Task/작업노트 이미지.
      4. scope == 'task_images_all' → Task/작업노트 이미지 순서대로.

    마지막에 max_images 로 clamp. 사용되지 않은 후보는 info 로 보고.

    Returns:
        (selected_items, normalized_scope, missing_ids,
         info={"candidate_total", "excluded_count"})
    """
    warning_ids = warning_ids or set()
    cap = clamp_max_images(max_images)

    ids = [i for i in (image_ids or []) if i]
    if ids:
        by_id = {it.get("image_id"): it for it in manifest}
        selected: List[Dict[str, Any]] = []
        missing: List[str] = []
        for iid in ids:
            it = by_id.get(iid)
            if it is not None:
                selected.append(it)
            else:
                missing.append(iid)
        info = {"candidate_total": len(selected), "excluded_count": max(0, len(selected) - cap)}
        return selected[:cap], "selected", missing, info

    scope = normalize_scope(image_scope)
    if scope == "selected":
        # selected 인데 image_ids 가 없음 → 선택된 이미지 없음.
        return [], "selected", [], {"candidate_total": 0, "excluded_count": 0}

    task_pool = [
        it for it in manifest if it.get("source_entity_type") in TASK_IMAGE_SOURCE_TYPES
    ]

    if scope == "review_needed":
        pool = [
            it for it in task_pool
            if (is_normal is None or not is_normal(it, warning_ids))
        ]
    elif scope == "task_images_all":
        pool = list(task_pool)
    else:  # auto (기본). 우선순위 랭킹.
        scope = "auto"
        pool = sorted(task_pool, key=lambda it: _auto_tier(it, warning_ids, is_normal))

    selected = pool[:cap]
    info = {"candidate_total": len(pool), "excluded_count": max(0, len(pool) - len(selected))}
    return selected, scope, [], info


# =========================================================
# 모델 입력 구성 (Responses API content)
# =========================================================

def build_output_schema_instruction() -> str:
    """모델이 '프로젝트 종합 보고서' 형태의 단일 JSON 으로 응답하도록 유도(강제는 아님)."""
    return (
        "결과는 추가 설명 없이 아래 구조의 **단일 JSON 객체**(프로젝트 종합 보고서)로만 응답하세요.\n"
        "```json\n"
        "{\n"
        '  "project_summary": "",\n'
        '  "progress_summary": "",\n'
        '  "image_based_findings": [\n'
        "    {\n"
        '      "image_id": "",\n'
        '      "task_id": "",\n'
        '      "task_title": "",\n'
        '      "image_role_hint": "",\n'
        '      "visible_facts": [],\n'
        '      "interpretation": "",\n'
        '      "task_relevance": "",\n'
        '      "uncertainty": ""\n'
        "    }\n"
        "  ],\n"
        '  "task_level_summary": [],\n'
        '  "additional_insights_from_images": [],\n'
        '  "risks_or_uncertainties": [],\n'
        '  "suggested_next_actions": [],\n'
        '  "report_addendum": "",\n'
        '  "should_include_in_final_report": false\n'
        "}\n"
        "```\n"
        "각 이미지는 전달된 image_id/task_id 를 그대로 사용하세요. "
        "project_summary/progress_summary 는 텍스트 맥락과 이미지를 함께 반영한 종합 요약, "
        "report_addendum 은 기존 텍스트 보고서 대비 이미지로 새로 확인된 점을 작성하세요."
    )


def _render_image_block(packet: Dict[str, Any], index: int) -> str:
    """선택 이미지 1건의 텍스트 블록. packet 이 input_mode 를 이미 반영하므로
    (image_only 면 맥락/Evidence 필드가 비어 있음) 여기서는 packet 값만 그대로 노출한다.
    """
    tc = packet.get("task_context") or {}
    txt = packet.get("text_context") or {}
    hints = packet.get("image_context_hints") or {}
    instr = packet.get("model_instruction") or {}

    lines: List[str] = [f"[이미지 {index}] image_id: {hints.get('image_id') or '-'}"]
    lines.append(f"- project: {tc.get('project_name') or '-'} / task: {tc.get('task_title') or '-'}")
    if tc.get("relation_type"):
        lines.append(f"- relation: {tc.get('relation_type')}")

    nearby = (txt.get("nearby_text") or "").strip()
    fallback = (txt.get("fallback_context_text") or "").strip()
    if nearby:
        lines.append(f"- 주변 텍스트: {nearby}")
    elif fallback:
        lines.append(f"- 보조 맥락 텍스트: {fallback}")
    if txt.get("context_strength"):
        lines.append(f"- 맥락 신뢰도(context_strength): {txt.get('context_strength')}")

    if hints.get("image_role_hint"):
        lines.append(f"- 추정 유형(image_role_hint, 정답 아님): {hints.get('image_role_hint')}")
        if hints.get("role_confidence"):
            lines.append(f"- 추정 신뢰도(role_confidence): {hints.get('role_confidence')}")
        if hints.get("extraction_target"):
            lines.append(f"- 추출 목표(extraction_target): {hints.get('extraction_target')}")

    role_instruction = instr.get("role_instruction")
    if role_instruction:
        lines.append(f"- 권장 작업: {role_instruction}")

    return "\n".join(lines)


def build_vision_input(
    project_context: Dict[str, Any],
    text_context: str,
    prepared_images: List[Dict[str, Any]],
    *,
    input_mode: str = DEFAULT_INPUT_MODE,
    include_text_context: bool = True,
) -> Tuple[str, List[Dict[str, Any]]]:
    """vision 모델 입력(Responses API instructions + user content) 구성.

    Args:
        project_context: build_project_ai_context().project_context.
        text_context: 프로젝트 text_context(프롬프트 비대화 방지를 위해 호출자가 truncate 가능).
        prepared_images: [{"packet": <model_input_packet>, "image_url": "data:...;base64,...",
                           "image_id": str}, ...]
        input_mode: image_only / image_with_nearby_text / image_with_evidence_card.
        include_text_context: image_only 가 아니고 True 면 프로젝트 text_context 를 포함.

    Returns:
        (instructions, content) — content 는 Responses API user 메시지의 content 리스트.
    """
    mode = normalize_input_mode(input_mode)

    instructions = (
        GLOBAL_RULE
        + "\n\n"
        + "당신은 프로젝트 관리 도구의 AI 보고서 어시스턴트입니다. "
        + "전달된 프로젝트 텍스트 맥락과 Task/작업노트 캡처 이미지들을 함께 분석해 "
        + "이미지 내용을 반영한 '프로젝트 종합 보고서'를 작성합니다. "
        + "이미지는 image_id 별로 해석하고, 텍스트 맥락과 연결해 종합하세요.\n\n"
        + build_output_schema_instruction()
    )

    content: List[Dict[str, Any]] = []

    intro_lines = [
        "아래는 한 프로젝트에 포함된 업무 캡처 이미지들과 그 업무 맥락입니다.",
        "각 이미지에서 실제로 보이는 내용을 우선하여 해석하고, metadata 는 힌트로만 사용하세요.",
        f"총 {len(prepared_images)}장의 이미지가 제공됩니다.",
    ]
    if include_text_context and mode != "image_only" and (text_context or "").strip():
        intro_lines.append("")
        intro_lines.append("[프로젝트 맥락]")
        intro_lines.append(text_context.strip())
    content.append({"type": "input_text", "text": "\n".join(intro_lines)})

    for idx, img in enumerate(prepared_images, start=1):
        packet = img.get("packet") or {}
        content.append({"type": "input_text", "text": _render_image_block(packet, idx)})
        content.append({"type": "input_image", "image_url": img.get("image_url")})

    return instructions, content


# =========================================================
# 결과 파싱 (JSON 유도, 실패 시 None → 호출자가 raw_text 표시)
# =========================================================

def _strip_code_fence(text: str) -> str:
    t = (text or "").strip()
    if t.startswith("```"):
        # ```json ... ``` 또는 ``` ... ```
        first_nl = t.find("\n")
        if first_nl != -1:
            t = t[first_nl + 1:]
        if t.rstrip().endswith("```"):
            t = t.rstrip()[:-3]
    return t.strip()


def parse_vision_result(raw_text: Optional[str]) -> Optional[Dict[str, Any]]:
    """모델 raw 응답에서 JSON 객체를 추출/파싱. 실패하면 None.

    보정(정상 응답에 섞인 잡텍스트 제거)만 하고, **잘린 JSON 은 repair 하지 않는다**:
    1) 코드펜스(```json …```) 제거 후 json.loads
    2) 실패 시 첫 '{' ~ 마지막 '}' substring 으로 재시도(앞뒤 설명 텍스트 제거)

    실제로 중간에 끊긴 응답은 닫는 중괄호가 없어 그대로 None 을 반환한다
    (호출자가 truncated 로 표시). 깨진 JSON 을 억지로 복구하지 않는다.
    """
    if not raw_text or not raw_text.strip():
        return None
    candidate = _strip_code_fence(raw_text)
    try:
        obj = json.loads(candidate)
        return obj if isinstance(obj, dict) else None
    except (json.JSONDecodeError, ValueError):
        pass

    start = candidate.find("{")
    end = candidate.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            obj = json.loads(candidate[start:end + 1])
            return obj if isinstance(obj, dict) else None
        except (json.JSONDecodeError, ValueError):
            return None
    return None


def looks_truncated_json(raw_text: Optional[str]) -> bool:
    """raw_text 가 JSON 객체/배열로 시작하지만 중간에 끊긴 것으로 보이는지(휴리스틱).

    코드펜스/잡텍스트 제거 후 '{'/'[' 로 시작하는데 여는 괄호가 닫는 괄호보다 많으면
    출력 길이 제한(max_output_tokens)으로 잘렸을 가능성이 크다고 본다.
    (문자열 안의 괄호까지 정확히 세지는 않는 진단용 추정.)
    """
    if not raw_text:
        return False
    t = _strip_code_fence(raw_text).strip()
    if t.startswith("{"):
        return t.count("{") > t.count("}")
    if t.startswith("["):
        return t.count("[") > t.count("]")
    return False


# =========================================================
# 2단계(2-stage) 보고서 생성
#   Stage 1: 이미지 batch → Image Evidence 추출(내부 중간 결과)
#   Stage 2: text_context + Task 데이터 + Image Evidence → 최종 프로젝트 보고서(기존 AI
#            Report schema 형태) 합성. 이미지별 raw 해석을 메인에 나열하지 않고 섹션에 융합.
# =========================================================

# Stage 1 에서 한 번에 처리할 이미지 수(출력 비대화/truncation 완화). env 로 조정 가능.
STAGE1_BATCH_SIZE = 5
FINAL_REPORT_SCHEMA_VERSION = "vision_report_v2"


def stage1_batch_size() -> int:
    raw = getattr(settings, "vision_report_stage1_batch_size", None)
    try:
        v = int(raw)
        if v >= 1:
            return v
    except (TypeError, ValueError):
        pass
    return STAGE1_BATCH_SIZE


def chunk_list(items: List[Any], size: int) -> List[List[Any]]:
    """items 를 size 개씩 끊어 배치 리스트로. size<=0 이면 통째로 1배치."""
    if size <= 0:
        return [list(items)] if items else []
    return [items[i:i + size] for i in range(0, len(items), size)]


# ---------------------------------------------------------
# Stage 1: Image Evidence Extraction
# ---------------------------------------------------------

def build_stage1_input(
    prepared_batch: List[Dict[str, Any]],
    *,
    input_mode: str = DEFAULT_INPUT_MODE,
) -> Tuple[str, List[Dict[str, Any]]]:
    """이미지 batch → "이미지별 evidence 추출" 전용 입력(instructions, content).

    Stage 1 은 보고서를 쓰지 않는다. 오직 이미지에서 보이는 사실/해석/불확실성을
    image_id 단위로 추출해 **JSON 배열**로만 응답하도록 유도한다(중간 결과).
    """
    mode = normalize_input_mode(input_mode)
    instructions = (
        GLOBAL_RULE
        + "\n\n"
        + "당신은 업무 캡처 이미지에서 '근거(evidence)'만 추출하는 분석기입니다. "
        + "보고서를 작성하지 마세요. 각 이미지에서 실제로 보이는 내용을 우선하고, "
        + "metadata(image_role_hint 등)는 힌트로만 사용하세요. 보이지 않는 내용은 추정하지 말고 "
        + "uncertainty 에 '확인 필요'로 남기세요.\n\n"
        + "결과는 추가 설명 없이 아래 형태의 **JSON 배열**로만 응답하세요.\n"
        + "```json\n"
        + "[\n"
        + "  {\n"
        + '    "image_id": "",\n'
        + '    "task_id": "",\n'
        + '    "task_title": "",\n'
        + '    "image_role_hint": "",\n'
        + '    "visible_facts": [],\n'
        + '    "interpretation": "",\n'
        + '    "task_relevance": "",\n'
        + '    "evidence_type": "",\n'
        + '    "uncertainty": ""\n'
        + "  }\n"
        + "]\n"
        + "```\n"
        + "evidence_type 은 다음 중 하나로만 판단하세요: "
        + '"direct"(이 Task 판단에 직접 쓰이는 근거), "supporting"(보조 근거), '
        + '"reference"(일반 참고자료), "unrelated"(현재 Task와 관련성이 낮음), '
        + '"unreadable"(글자/내용을 읽기 어려워 판독 불가). '
        + "확실하지 않으면 과장하지 말고 \"reference\" 로 두고, 읽을 수 없으면 \"unreadable\" 로 두세요.\n"
        + "전달된 image_id/task_id 를 그대로 사용하세요."
    )

    content: List[Dict[str, Any]] = [{
        "type": "input_text",
        "text": (
            f"아래 {len(prepared_batch)}개 이미지 각각에서 evidence 를 추출하세요. "
            "각 이미지 블록 뒤에 해당 이미지가 옵니다."
        ),
    }]
    for idx, img in enumerate(prepared_batch, start=1):
        packet = img.get("packet") or {}
        content.append({"type": "input_text", "text": _render_image_block(packet, idx)})
        if mode != "image_only":
            pass  # _render_image_block 가 mode 반영된 packet 값을 이미 노출
        content.append({"type": "input_image", "image_url": img.get("image_url")})
    return instructions, content


def parse_stage1_evidence(raw_text: Optional[str]) -> List[Dict[str, Any]]:
    """Stage 1 raw → evidence item 리스트. 실패하면 빈 리스트.

    1) JSON 배열로 파싱 시도
    2) {"image_evidence_summaries": [...]} / {"evidence": [...]} 형태도 허용
    3) 코드펜스/잡텍스트 제거 후 첫 '[' ~ 마지막 ']' 재시도
    """
    if not raw_text or not raw_text.strip():
        return []
    candidate = _strip_code_fence(raw_text)

    def _coerce(obj: Any) -> List[Dict[str, Any]]:
        if isinstance(obj, list):
            return [x for x in obj if isinstance(x, dict)]
        if isinstance(obj, dict):
            for key in ("image_evidence_summaries", "evidence", "items", "results"):
                v = obj.get(key)
                if isinstance(v, list):
                    return [x for x in v if isinstance(x, dict)]
            # 단일 evidence dict 인 경우
            if obj.get("image_id") is not None:
                return [obj]
        return []

    try:
        return _coerce(json.loads(candidate))
    except (json.JSONDecodeError, ValueError):
        pass

    start = candidate.find("[")
    end = candidate.rfind("]")
    if start != -1 and end != -1 and end > start:
        try:
            return _coerce(json.loads(candidate[start:end + 1]))
        except (json.JSONDecodeError, ValueError):
            return []
    return []


def reconcile_evidence_with_images(
    evidence_items: List[Dict[str, Any]],
    batch_images: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """Stage 1 evidence 의 image_id/task_id 를 backend 가 아는 실제 값으로 교정한다.

    LLM 이 echo 한 task_id 는 신뢰하지 않는다 — 모델이 이미지는 잘 읽어도 그 근거를 어느
    Task 에 속한 것으로 태깅하는지가 부정확해, Task 미연결·visual coverage 0% 의 근본 원인이 된다.
    귀속 규칙(오귀속 방지 위해 확실한 경우에만 확정):
      1) evidence 의 image_id 가 이 batch 의 실제 image_id 와 일치하면 그 이미지로 확정.
      2) 아니면, batch 에 이미지가 정확히 1장뿐일 때만 그 이미지로 확정(batch=1 경로는 100% 확실).
      3) 그 외에는 강제 귀속하지 않는다(orphan 으로 남겨 오귀속을 피한다).
    확정된 이미지의 authoritative task_id/task_title/image_id 를 evidence 에 주입한다.

    Args:
        evidence_items: parse_stage1_evidence 결과.
        batch_images: 이 batch 에 실제로 넣은 이미지 메타 [{"image_id","task_id","task_title"}, ...].

    Returns:
        (reconciled_items, stats) — stats={"total","mapped","orphan"} (coverage 측정용).
    """
    items = [e for e in (evidence_items or []) if isinstance(e, dict)]
    by_id = {
        str(b.get("image_id")): b
        for b in (batch_images or [])
        if b.get("image_id") is not None
    }
    single_id = next(iter(by_id)) if len(by_id) == 1 else None

    mapped = 0
    out: List[Dict[str, Any]] = []
    for ev in items:
        ev = dict(ev)
        raw_id = str(ev.get("image_id")) if ev.get("image_id") is not None else None
        target_id = raw_id if raw_id in by_id else single_id
        meta = by_id.get(target_id) if target_id else None
        if meta is not None:
            ev["image_id"] = target_id
            ev["task_id"] = meta.get("task_id")
            ev["task_title"] = meta.get("task_title")
            mapped += 1
        out.append(ev)
    return out, {"total": len(items), "mapped": mapped, "orphan": len(items) - mapped}


# 이미지 근거의 판단 등급(과장 방지용). 최종 보고서에서 등급별로 다르게 취급한다.
EVIDENCE_TYPES = ("direct", "supporting", "reference", "unrelated", "unreadable")
_EVIDENCE_TYPE_ALIASES = {
    "direct": "direct", "direct_evidence": "direct", "primary": "direct", "strong": "direct",
    "supporting": "supporting", "support": "supporting", "secondary": "supporting", "aux": "supporting",
    "reference": "reference", "ref": "reference", "reference_material": "reference", "context": "reference",
    "unrelated": "unrelated", "irrelevant": "unrelated", "not_related": "unrelated", "none": "unrelated",
    "unreadable": "unreadable", "illegible": "unreadable", "low_quality": "unreadable", "unclear": "unreadable",
}


def normalize_evidence_type(value: Any) -> str:
    """evidence_type 을 표준 5분류 중 하나로 정규화한다.

    direct(직접 근거) / supporting(보조 근거) / reference(참고자료) /
    unrelated(관련성 낮음) / unreadable(판독 불가).
    비어 있거나 알 수 없으면 과장 방지를 위해 보수적으로 'reference' 로 둔다.
    """
    if value is None:
        return "reference"
    key = str(value).strip().lower().replace("-", "_").replace(" ", "_")
    return _EVIDENCE_TYPE_ALIASES.get(key, "reference")


# ---------------------------------------------------------
# 텍스트 → 문장 포인트(배열) 정규화 헬퍼
#   모델이 긴 문단을 줘도, 또는 배열을 줘도 항상 "짧은 문장 배열"로 만든다.
# ---------------------------------------------------------

# 한국어 종결 어미(긴 것 우선) — 뒤에 공백이 오면 문장 경계로 보고 줄바꿈을 삽입한다.
# (Python re 는 가변폭 lookbehind 불가 → 사전 치환 방식으로 처리)
_KO_END_RE = re.compile(
    r"(습니다|됩니다|입니다|합니다|니다|했다|된다|이다|였다|있다|없다|필요|예정|완료|진행)(\s+)"
)
# 마침표/물음표/느낌표 뒤 공백, 줄바꿈 → 문장 경계.
_SENT_SPLIT_RE = re.compile(r"(?<=[.!?。])\s+|[\r\n]+")
_MIN_POINT_LEN = 6


def split_sentences_ko(text: str, *, max_points: int = 6) -> List[str]:
    """긴 한국어 문단을 읽기 쉬운 문장 포인트 배열로 분리.

    너무 짧은 조각(_MIN_POINT_LEN 미만)은 앞 문장에 병합한다. bullet 표시용.
    """
    t = (text or "").strip()
    if not t:
        return []
    # 선행 bullet/번호 기호 제거
    t = re.sub(r"^[\s•\-\*·]+", "", t)
    # 한국어 종결 어미 뒤에 줄바꿈 삽입(가변폭 lookbehind 회피).
    t = _KO_END_RE.sub(r"\1\n", t)
    raw = [s.strip(" •-*·\t") for s in _SENT_SPLIT_RE.split(t) if s and s.strip()]
    merged: List[str] = []
    for seg in raw:
        if merged and len(seg) < _MIN_POINT_LEN:
            merged[-1] = (merged[-1] + " " + seg).strip()
        else:
            merged.append(seg)
    return merged[:max_points]


def to_points(value: Any, *, max_points: int = 6) -> List[str]:
    """list[str] → 정리된 list, str → 문장 분리, 그 외 → []. (모델 출력 방어적 정규화)"""
    if isinstance(value, list):
        out: List[str] = []
        for v in value:
            s = str(v).strip(" •-*·\t")
            if s:
                out.append(s)
        return out[:max_points]
    if isinstance(value, str):
        return split_sentences_ko(value, max_points=max_points)
    return []


# ---------------------------------------------------------
# Stage 2(이미지 보강 합성): 이미지 evidence 를 Task별로 묶어 모델에 전달하고,
#   모델은 "분석 문장(포인트)"만 생성한다(구조/기본 데이터는 서버가 결정).
# ---------------------------------------------------------

def group_evidence_by_task(
    base_tasks: List[Dict[str, Any]],
    evidence_summaries: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """deterministic task base + Stage1 evidence → Task별로 묶은 구조(모델 입력용).

    mini 모델이 "이미지가 어느 Task 근거인지" 헷갈리지 않도록 task_id 로 grouping 한다.
    base_tasks 에 없는(또는 task_id 없는) evidence 는 task_id=None 그룹으로 모은다.
    """
    ev_by_task: Dict[Any, List[Dict[str, Any]]] = {}
    for ev in evidence_summaries or []:
        if not isinstance(ev, dict):
            continue
        key = ev.get("task_id")
        ev_by_task.setdefault(str(key) if key is not None else None, []).append(ev)

    grouped: List[Dict[str, Any]] = []
    for t in base_tasks or []:
        tid = t.get("task_id")
        evs = ev_by_task.get(str(tid) if tid is not None else None, [])
        grouped.append({
            "task_id": tid,
            "task_title": t.get("task_title"),
            "status": t.get("status"),
            "progress": t.get("progress"),
            "image_evidence": [
                {
                    "image_id": e.get("image_id"),
                    "role": e.get("image_role_hint"),
                    "caption": (e.get("interpretation") or "").strip()[:120],
                    "visible_facts": e.get("visible_facts") or [],
                    "task_relevance": e.get("task_relevance"),
                    "evidence_type": e.get("evidence_type"),
                    "uncertainty": e.get("uncertainty"),
                }
                for e in evs
            ],
        })
    # task_id 없는 evidence(프로젝트 단위 등)
    orphan = ev_by_task.get(None) or []
    if orphan:
        grouped.append({
            "task_id": None,
            "task_title": "(Task 미연결 이미지)",
            "image_evidence": [
                {
                    "image_id": e.get("image_id"),
                    "role": e.get("image_role_hint"),
                    "caption": (e.get("interpretation") or "").strip()[:120],
                    "visible_facts": e.get("visible_facts") or [],
                    "task_relevance": e.get("task_relevance"),
                    "evidence_type": e.get("evidence_type"),
                    "uncertainty": e.get("uncertainty"),
                }
                for e in orphan
            ],
        })
    return grouped


def build_enhancement_schema_instruction() -> str:
    """모델이 '분석 문장(포인트)'만 채우도록 강하게 제한하는 schema 지시."""
    return (
        "결과는 추가 설명 없이 아래 구조의 **단일 JSON 객체**로만 응답하세요. "
        "모든 문장은 짧고 명확하게, **배열의 한 항목 = 한 문장(한 줄)** 으로 작성하세요. "
        "긴 문단을 하나의 문자열로 쓰지 마세요.\n"
        "```json\n"
        "{\n"
        '  "project_executive_summary": {\n'
        '    "summary_points": [], "key_message": "", "decision_point": ""\n'
        "  },\n"
        '  "task_analysis_enhancements": [\n'
        "    {\n"
        '      "task_id": "", "summary_points": [], "risk_points": [], "next_actions": [],\n'
        '      "has_visual_evidence": false, "visual_evidence_summary_points": [],\n'
        '      "visual_evidence_caption": "", "visual_evidence_judgment_meaning": "",\n'
        '      "additional_visual_evidence_summary": "",\n'
        '      "visual_evidence_confidence": "medium", "visual_evidence_limitations": [],\n'
        '      "context_points": [], "handover_notes": []\n'
        "    }\n"
        "  ],\n"
        '  "overall_analysis": {\n'
        '    "summary_points": [], "key_points": [], "visual_insights": [], "risk_points": []\n'
        "  },\n"
        '  "next_steps": {"summary_points": [], "actions": []}\n'
        "}\n"
        "```\n"
        "task_analysis_enhancements 의 task_id 는 반드시 제공된 Task 목록의 task_id 를 그대로 쓰세요. "
        "image_evidence 가 있는 Task 는 visual_evidence_caption(대표 이미지가 무엇인지 한 문장)과 "
        "visual_evidence_judgment_meaning(그 이미지가 이 Task 의 상태/다음 액션 판단에 갖는 의미 한 문장)을 "
        "반드시 채우세요. 추가 이미지가 더 있으면 additional_visual_evidence_summary 에 한 문장으로 요약하세요. "
        "각 Task 의 분석은 **한 세트만** 작성하세요(brief 와 detailed 를 따로 두 벌 쓰지 마세요 — 화면 표시는 "
        "서버가 나눕니다). summary_points/risk_points/next_actions/visual_evidence_summary_points 는 각각 "
        "**핵심 1~2개**만, 결론 중심으로 짧게 씁니다. 인수인계에 꼭 필요한 추가 맥락만 context_points(진행 배경) "
        "와 handover_notes(후속 담당자가 봐야 할 점)에 각 1~2개 적습니다. 같은 내용을 여러 필드에 반복하지 마세요. "
        "대표 이미지 선정/캡션 재구성은 서버가 하므로 featured 목록은 만들지 마세요. "
        "프로젝트명/팀원/진행률/Task 상태/담당자/마감일 같은 사실 데이터는 다시 만들지 마세요(서버가 채웁니다)."
    )


def build_enhancement_input(
    report_base: Dict[str, Any],
    text_context: str,
    evidence_summaries: List[Dict[str, Any]],
) -> Tuple[str, List[Dict[str, Any]]]:
    """Stage 2(text-only) 입력 — 이미지 보강 합성.

    report_base(서버가 DB로 만든 구조/사실)는 **변경 금지 컨텍스트**로 주고,
    모델은 그 위에 들어갈 분석 포인트만 생성한다(구조를 새로 만들지 않음).
    """
    instructions = (
        GLOBAL_RULE
        + "\n\n"
        + "당신은 임원 보고/인수인계용 프로젝트 AI Report 작성자입니다. 보고서의 구조와 사실 데이터"
        + "(프로젝트명/팀원/진행률/Task 상태·담당자·마감일)는 이미 서버가 확정했습니다. 당신은 그 위에 "
        + "들어갈 **분석 문장만** 채웁니다.\n"
        + "규칙:\n"
        + "1) 반드시 결론 먼저 작성합니다. project_executive_summary.key_message 는 "
        + "\"현재 프로젝트의 핵심 상태는 …\" 처럼 두괄식 한 문장으로 작성합니다.\n"
        + "2) 각 항목은 짧고 명확한 한 문장입니다. 한 문단에 여러 문장을 길게 잇지 마세요.\n"
        + "3) Task별 분석은 summary_points / risk_points / next_actions 배열로 작성합니다.\n"
        + "4) image_evidence 가 있는 Task 는 has_visual_evidence=true 로 두고 "
        + "visual_evidence_summary_points 를 반드시 1개 이상 작성합니다(이미지가 Task 와 관련이 낮으면 "
        + "\"직접 근거보다 참고자료 성격\"이라고 명시). 이미지가 있는데 비워두지 마세요.\n"
        + "5) 이미지 근거는 별도 이미지 목록으로 나열하지 말고, 반드시 해당 Task 의 현재 상태·리스크·다음 액션 "
        + "판단과 연결해 설명합니다. visual_evidence_caption 에는 대표 이미지가 무엇인지 한 문장, "
        + "visual_evidence_judgment_meaning 에는 그 이미지가 Task 판단에 갖는 의미 한 문장을 씁니다. "
        + "이미지가 직접 근거가 아니라 참고자료 성격이면 \"참고자료 성격\"이라고 명시합니다.\n"
        + "6) 이미지별 raw 해석을 그대로 나열하지 말고, Task 판단에 필요한 근거만 요약합니다.\n"
        + "6-1) 각 이미지 근거의 evidence_type 을 반드시 반영합니다. \"direct\" 는 Task 판단 근거로 "
        + "적극 활용하고, \"supporting\" 은 보조 근거로만 쓰며, \"reference\" 는 \"참고자료\"라고 명확히 "
        + "표시합니다. \"unrelated\" 는 판단 근거에서 제외하고, \"unreadable\" 은 \"원본 확인 필요\"로 "
        + "표시합니다. reference/unrelated 를 직접 근거처럼 단정하거나 과장하지 마세요.\n"
        + "7) 진행률/상태/담당자/마감일 등 사실 수치는 제공된 값만 쓰고 추론하지 않습니다.\n"
        + "8) 이미지 속 작은 글자/불확실한 수치는 단정하지 말고 \"확인 필요\"로 표시합니다.\n"
        + "9) 각 Task 는 분석을 **한 세트만** 작성합니다(brief/detailed 를 따로 두 벌 쓰지 않음 — 화면 분기는 "
        + "서버가 함). 핵심 상태·리스크·다음 액션을 각 1~2개로 짧게 쓰고, 인수인계에 꼭 필요한 배경은 "
        + "context_points, 후속 담당자가 봐야 할 점은 handover_notes 에 각 1~2개만 덧붙입니다. 같은 내용을 "
        + "여러 필드에 반복하지 마세요. 이미지 근거가 있는 Task 는 상태/판단과 연결해 설명하고, 이미지가 Task 와 "
        + "직접 관련이 낮으면 \"참고자료 성격\"이라고 표시합니다.\n\n"
        + build_enhancement_schema_instruction()
    )

    base_tasks = (report_base or {}).get("tasks") or []
    grouped = group_evidence_by_task(base_tasks, evidence_summaries)
    try:
        tasks_json = json.dumps(base_tasks, ensure_ascii=False, indent=2, default=str)
    except (TypeError, ValueError):
        tasks_json = "[]"
    try:
        grouped_json = json.dumps(grouped, ensure_ascii=False, indent=2, default=str)
    except (TypeError, ValueError):
        grouped_json = "[]"

    ov = (report_base or {}).get("project_overview") or {}
    lines = [
        "[프로젝트 사실 데이터 (서버 확정, 변경 금지)]",
        f"- 프로젝트명: {ov.get('title') or '-'}",
        f"- 설명: {ov.get('description') or '-'}",
        f"- 팀원: {', '.join(ov.get('team') or []) or '미배정'}",
        f"- 전체 진행률: {ov.get('overall_progress')}%",
        f"- 상태별 Task: {json.dumps(ov.get('status_breakdown') or {}, ensure_ascii=False)}",
        "",
        "[Task 목록 (서버 확정)]",
        tasks_json,
        "",
        # ⚠️ 사용자 화면에 그대로 노출되는 분석 문장이 되므로, 모델이 따라 쓸 수 있는
        #   내부 파이프라인 용어(Stage 1/Stage 2/evidence/schema/fallback)는 프롬프트에
        #   쓰지 않는다. "이미지 근거 자료" 같은 사용자 친화 표현만 사용한다.
        "[Task별 이미지 근거 자료 (이미지에서 확인된 사실·해석, 근거 자료)]",
        grouped_json,
        "",
        "[프로젝트 텍스트 맥락(보조)]",
        (text_context or "").strip()[:3000] or "(없음)",
        "",
        "위 사실 데이터/Task/이미지 근거 자료를 바탕으로, 아래 항목의 분석 포인트만 채워 JSON 으로 응답하세요.",
        "분석 문장에는 'Stage 1', 'Stage 2', 'evidence', 'schema', 'fallback' 같은 내부 용어를 절대 쓰지 마세요. "
        "이미지 근거가 부족하면 '이미지에서 확인 가능한 근거가 제한적' 처럼 사용자가 이해할 수 있는 표현만 쓰세요.",
    ]
    content = [{"type": "input_text", "text": "\n".join(lines)}]
    return instructions, content


def parse_enhancements(raw_text: Optional[str]) -> Optional[Dict[str, Any]]:
    """Stage 2 raw → 분석 보강 dict. (parse_vision_result 와 동일 규칙)."""
    return parse_vision_result(raw_text)


# 하위호환 별칭(혹시 다른 호출부가 있을 때). 신규 코드는 위 함수를 쓴다.
build_stage2_input = build_enhancement_input
parse_final_report = parse_enhancements


# =========================================================
# 금지 문구 validator (§13)
#   images_analyzed > 0 인데 "이미지 evidence가 없다" 류 문구가 나오면 모순이므로
#   해당 문장/포인트를 제거하고 validation_notes 로 보고한다(후처리 안전망).
# =========================================================
FORBIDDEN_NO_IMAGE_PHRASES = (
    "이미지 evidence가 없",
    "제공된 이미지 evidence가 없",
    "이미지 evidence 가 없",
    "이미지 근거가 없",
    # "…직접 활용할 시각 근거가 포함되지 않았습니다" 류(§9) — 실제 이미지가 있는데도 나오는 모순 문구.
    "시각 근거가 포함되지 않",
    "시각 근거는 포함되지 않",
    "활용할 시각 근거가 없",
    "시각적 추가 판단은 제한적",
    "시각적 추가 판단이 제한적",
    "시각적 판단은 제한적",
    "텍스트 기반 판단",
    "텍스트 기반으로 판단",
    "텍스트 기반입니다",
)


def _has_forbidden_phrase(text: str) -> bool:
    t = (text or "")
    return any(p in t for p in FORBIDDEN_NO_IMAGE_PHRASES)


def _scrub_value(value: Any, removed: List[str]) -> Any:
    """enhancement 값(문자열/리스트/딕셔너리)에서 금지 문구가 든 항목을 제거한다.
    제거된 원문은 removed 에 누적(중복 보고 방지는 호출부에서)."""
    if isinstance(value, str):
        if _has_forbidden_phrase(value):
            removed.append(value.strip())
            return ""
        return value
    if isinstance(value, list):
        out = []
        for v in value:
            sv = _scrub_value(v, removed)
            if isinstance(sv, str):
                if sv:  # 빈 문자열(제거됨)은 드롭
                    out.append(sv)
            else:
                out.append(sv)
        return out
    if isinstance(value, dict):
        return {k: _scrub_value(v, removed) for k, v in value.items()}
    return value


def validate_enhancements(
    enhancements: Optional[Dict[str, Any]],
    images_analyzed: int,
) -> Tuple[Optional[Dict[str, Any]], List[str]]:
    """images_analyzed>0 일 때 enhancement 에서 금지 문구가 든 분석 문장을 제거.

    Returns:
        (cleaned_enhancements, validation_notes)
        - enhancements 가 None 이거나 images_analyzed<=0 이면 그대로 반환(notes=[]).
    """
    if not isinstance(enhancements, dict) or images_analyzed <= 0:
        return enhancements, []
    removed: List[str] = []
    cleaned = _scrub_value(enhancements, removed)
    notes: List[str] = []
    if removed:
        uniq = list(dict.fromkeys(removed))  # 순서 보존 dedup
        notes.append(
            f"이미지 {images_analyzed}장을 분석했는데 \"이미지 근거 없음\" 류 문구가 "
            f"{len(uniq)}건 감지되어 제거했습니다."
        )
    return (cleaned if isinstance(cleaned, dict) else enhancements), notes


def merge_usage(acc: Optional[Dict[str, Any]], usage: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """여러 모델 호출의 token usage 를 합산(input/output/total)."""
    acc = dict(acc or {})
    if not usage:
        return acc
    for k in ("input_tokens", "output_tokens", "total_tokens"):
        v = usage.get(k)
        if isinstance(v, (int, float)):
            acc[k] = (acc.get(k) or 0) + v
    return acc


# =========================================================
# 대표 이미지(featured) 선별 — 서버측 결정 로직
#   gpt-5.4-mini 가 featured 를 빠뜨리거나 과다 선택해도 품질이 흔들리지 않도록,
#   Stage 1 evidence + manifest 메타로 importance_score 를 계산해 **서버가** 대표 이미지를
#   확정한다. 모델이 준 caption/display_reason 이 있으면 그대로 활용(보강)한다.
# =========================================================

# 보고서 판단에 직접 기여하는 캡처 유형일수록 높은 가중치(요구사항 §6 기준).
ROLE_IMPORTANCE: Dict[str, float] = {
    "chart": 1.0,
    "process_flow": 0.97,
    "table": 0.95,
    "document_table": 0.95,
    "result_capture": 0.9,
    "error_screen": 0.88,
    "equipment_screen": 0.85,
    "log_capture": 0.72,
    "terminal_capture": 0.7,
    "code_snippet": 0.68,
    "command_snippet": 0.66,
    "meeting_slide": 0.62,
    "document_crop": 0.6,
    "text_crop": 0.55,
}
DEFAULT_FEATURED_MAX = 5
DEFAULT_FEATURED_PER_TASK = 1
# 이 점수 미만은 "대표 이미지"로 올리지 않는다(약맥락/저추천/저관련 단순 참고 이미지).
# 단, featured 가 하나도 없을 때는 최상위 1장은 표시(빈 섹션 방지).
FEATURED_MIN_SCORE = 0.35


def _relevance_weight(value: Any) -> float:
    v = (str(value or "")).strip().lower()
    if v in ("high", "강", "높음", "strong"):
        return 1.0
    if v in ("medium", "중", "보통"):
        return 0.6
    if v in ("low", "약", "낮음", "weak"):
        return 0.3
    return 0.5  # 미지정


def _context_weight(value: Any) -> float:
    v = (str(value or "")).strip().lower()
    if v == "strong":
        return 1.0
    if v == "medium":
        return 0.6
    if v == "weak":
        return 0.25
    return 0.5


def score_image_importance(
    evidence: Dict[str, Any],
    manifest_item: Optional[Dict[str, Any]] = None,
    *,
    model_flagged: bool = False,
) -> float:
    """이미지 1장의 보고서 기여도 점수(0~1 근사). 높을수록 대표 이미지 후보.

    구성: role 가치(0.4) + task_relevance(0.3) + context_strength(0.2) +
          evidence 충실도(0.1) + 모델이 featured 로 지목 시 보너스(+0.12).
    낮은 추천도/약한 맥락/저해상도는 감점.
    """
    manifest_item = manifest_item or {}
    role = evidence.get("image_role_hint") or manifest_item.get("image_role")
    role_w = ROLE_IMPORTANCE.get((role or "").strip(), 0.5)

    rel_w = _relevance_weight(evidence.get("task_relevance"))

    ctx = (manifest_item.get("evidence_card") or {}).get("context_strength")
    ctx_w = _context_weight(ctx)

    facts = evidence.get("visible_facts") or []
    interp = (evidence.get("interpretation") or "").strip()
    richness = 0.0
    if isinstance(facts, list) and facts:
        richness += min(len(facts), 4) / 4.0 * 0.6
    if len(interp) >= 40:
        richness += 0.4
    richness = min(richness, 1.0)

    score = role_w * 0.4 + rel_w * 0.3 + ctx_w * 0.2 + richness * 0.1

    # 저품질/약맥락 감점
    rec = (manifest_item.get("image_quality") or {}).get("recommendation_level")
    if rec == "not_recommended":
        score -= 0.2
    if ctx == "weak":
        score -= 0.05

    if model_flagged:
        score += 0.12

    return max(0.0, min(round(score, 4), 1.0))


def _evidence_caption(evidence: Dict[str, Any]) -> str:
    """evidence 로 대표 이미지 캡션 한 줄 합성(모델 caption 이 없을 때 fallback)."""
    interp = (evidence.get("interpretation") or "").strip()
    if interp:
        return interp if len(interp) <= 120 else interp[:117] + "…"
    facts = evidence.get("visible_facts") or []
    if isinstance(facts, list) and facts:
        joined = " · ".join(str(f) for f in facts[:3])
        return joined if len(joined) <= 120 else joined[:117] + "…"
    return (evidence.get("task_title") or "이미지 근거").strip()


def select_featured_visual_evidence(
    evidence_summaries: List[Dict[str, Any]],
    manifest_by_id: Dict[str, Dict[str, Any]],
    *,
    model_featured: Optional[List[Dict[str, Any]]] = None,
    model_non_featured: Optional[Dict[str, Any]] = None,
    max_featured: int = DEFAULT_FEATURED_MAX,
    max_per_task: int = DEFAULT_FEATURED_PER_TASK,
    min_score: float = FEATURED_MIN_SCORE,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any], Dict[str, str]]:
    """Stage 1 evidence 를 점수화해 대표 이미지(featured)를 서버에서 확정한다.

    Returns:
        (featured_visual_evidence, non_featured_visual_summary, task_featured_map)
        - featured_visual_evidence: 최대 ``max_featured`` 개. Task 당 ``max_per_task`` 개.
        - non_featured_visual_summary: {count, summary, grouped_by_task}.
        - task_featured_map: {task_id(str): {image_id, caption, judgment_meaning,
          display_reason, image_role_hint, importance_score}} — Task 카드 대표 이미지/캡션 주입용.
          (Task 카드가 이미지 근거의 주 표시 위치이므로 캡션/판단 의미를 함께 내려준다.)
    """
    model_by_id: Dict[str, Dict[str, Any]] = {}
    for mf in (model_featured or []):
        if isinstance(mf, dict) and mf.get("image_id"):
            model_by_id[str(mf.get("image_id"))] = mf

    # 1) 후보 점수화 (image_id 중복 제거 — 첫 evidence 우선)
    scored: List[Dict[str, Any]] = []
    seen_ids: set = set()
    for ev in evidence_summaries:
        if not isinstance(ev, dict):
            continue
        iid = ev.get("image_id")
        if not iid or str(iid) in seen_ids:
            continue
        seen_ids.add(str(iid))
        man = manifest_by_id.get(str(iid)) or {}
        flagged = str(iid) in model_by_id
        score = score_image_importance(ev, man, model_flagged=flagged)
        scored.append({
            "image_id": str(iid),
            "task_id": ev.get("task_id") if ev.get("task_id") is not None else man.get("task_id"),
            "task_title": ev.get("task_title") or man.get("task_title") or "",
            "image_role_hint": ev.get("image_role_hint") or man.get("image_role") or "",
            "importance_score": score,
            "_evidence": ev,
        })

    # 점수 내림차순(동점은 manifest 등장 순서 유지 위해 stable)
    scored.sort(key=lambda x: x["importance_score"], reverse=True)

    # 2) featured 선별 — Task 당 max_per_task, 전체 max_featured
    featured: List[Dict[str, Any]] = []
    task_count: Dict[str, int] = {}
    task_featured_map: Dict[str, Dict[str, Any]] = {}
    featured_ids: set = set()
    for cand in scored:
        if len(featured) >= max_featured:
            break
        # 점수 미달은 건너뛴다. 단 featured 가 아직 0개면 최상위 1장은 허용(빈 섹션 방지).
        if cand["importance_score"] < min_score and featured:
            continue
        tkey = str(cand["task_id"]) if cand["task_id"] is not None else f"_img_{cand['image_id']}"
        if task_count.get(tkey, 0) >= max_per_task:
            continue
        mf = model_by_id.get(cand["image_id"], {})
        ev = cand["_evidence"]
        caption = (mf.get("caption") or "").strip() or _evidence_caption(ev)
        display_reason = (mf.get("display_reason") or "").strip()
        if not display_reason:
            role = cand["image_role_hint"] or "캡처"
            display_reason = f"{cand['task_title'] or '해당 Task'}의 핵심 판단 근거({role})로 활용된 이미지입니다."
        # 판단 의미(이 이미지가 Task 판단에 갖는 뜻) — 모델이 주면 사용, 없으면 display_reason 으로 대체.
        judgment_meaning = (mf.get("judgment_meaning") or "").strip() or display_reason
        report_section = (mf.get("report_section") or "").strip() or "task_analysis"
        featured.append({
            "image_id": cand["image_id"],
            "task_id": cand["task_id"],
            "task_title": cand["task_title"],
            "image_role_hint": cand["image_role_hint"],
            "importance_score": cand["importance_score"],
            "display_reason": display_reason,
            "judgment_meaning": judgment_meaning,
            "caption": caption,
            "report_section": report_section,
            "thumbnail_preview_url": None,  # FE 가 image_id 로 안전하게 로딩
        })
        task_count[tkey] = task_count.get(tkey, 0) + 1
        task_featured_map[tkey] = {
            "image_id": cand["image_id"],
            "caption": caption,
            "judgment_meaning": judgment_meaning,
            "display_reason": display_reason,
            "image_role_hint": cand["image_role_hint"],
            "importance_score": cand["importance_score"],
        }
        featured_ids.add(cand["image_id"])

    # 3) 나머지(non-featured) 요약 — Task 별로 묶어 한 줄
    non_ids = [c for c in scored if c["image_id"] not in featured_ids]
    grouped: Dict[str, List[str]] = {}
    for c in non_ids:
        label = (c["task_title"] or "기타").strip() or "기타"
        role = c["image_role_hint"]
        grouped.setdefault(label, []).append(role or "이미지")
    grouped_by_task = [
        {"task_title": k, "count": len(v), "roles": v} for k, v in grouped.items()
    ]
    model_nf_summary = ((model_non_featured or {}).get("summary") or "").strip()
    if model_nf_summary:
        nf_summary = model_nf_summary
    elif non_ids:
        head = ", ".join(list(grouped.keys())[:5])
        nf_summary = (
            f"{head} 등 {len(non_ids)}장의 이미지는 보조 근거로 분석에 함께 활용되었습니다."
        )
    else:
        nf_summary = ""
    non_featured = {
        "count": len(non_ids),
        "summary": nf_summary,
        "grouped_by_task": grouped_by_task,
    }
    return featured, non_featured, task_featured_map


def apply_featured_to_report(
    report: Dict[str, Any],
    evidence_summaries: List[Dict[str, Any]],
    manifest_by_id: Dict[str, Dict[str, Any]],
    *,
    max_featured: int = DEFAULT_FEATURED_MAX,
    max_per_task: int = DEFAULT_FEATURED_PER_TASK,
) -> Dict[str, Any]:
    """report(dict) 에 서버 확정 featured/non_featured 와 Task 대표 이미지(featured_image_id)를
    주입한다. report 가 dict 가 아니면 그대로 반환.

    모델이 준 featured_visual_evidence/non_featured_visual_summary 는 caption/display_reason
    보강에만 쓰고, 최종 목록은 서버 결정으로 덮어쓴다(개수/Task당 1장 규칙 보장).
    """
    if not isinstance(report, dict):
        return report
    featured, non_featured, task_map = select_featured_visual_evidence(
        evidence_summaries,
        manifest_by_id,
        model_featured=report.get("featured_visual_evidence"),
        model_non_featured=report.get("non_featured_visual_summary"),
        max_featured=max_featured,
        max_per_task=max_per_task,
    )
    report["featured_visual_evidence"] = featured
    report["non_featured_visual_summary"] = non_featured

    # Task 카드에 대표 이미지(featured_image_id) 주입.
    tasks = report.get("task_analysis")
    if isinstance(tasks, list):
        for t in tasks:
            if not isinstance(t, dict):
                continue
            tid = t.get("task_id")
            if tid is None:
                continue
            entry = task_map.get(str(tid))
            iid = (entry or {}).get("image_id")
            if iid and not t.get("featured_image_id"):
                t["featured_image_id"] = iid
    return report


# =========================================================
# Task 카드 대표 이미지 fallback 체인 (badge 만 보이고 이미지가 안 뜨는 버그 방지)
#   select_featured_visual_evidence 는 전체 최대5·Task당1·min_score 로 제한하므로, 상위 5개
#   밖이거나 점수 낮은 Task 는 featured_image_id 가 비어 이미지가 렌더되지 않는다. 이미지가
#   있는(evidence/manifest 존재) 모든 Task 는 대표 이미지 1장을 반드시 찾아 렌더한다.
# =========================================================

def _norm_key(v: Any) -> str:
    return str(v).strip() if v is not None else ""


def _norm_title(v: Any) -> str:
    return str(v).strip().lower() if v is not None else ""


def resolve_task_visual_image(
    task: Dict[str, Any],
    task_map: Dict[str, Dict[str, Any]],
    evidence_summaries: List[Dict[str, Any]],
    manifest_by_id: Dict[str, Dict[str, Any]],
) -> Dict[str, Any]:
    """Task 1개의 대표 이미지를 fallback 체인으로 확정한다.

    순서(스펙 §3): 서버 featured(task_map) → evidence(task_id, 점수 최고) →
    evidence(task_title, relevance high/medium) → manifest(task_id, recommended) →
    manifest(task_id 첫 이미지). task_id 는 number/string 혼용을 _norm_key 로 흡수.

    Returns:
        {image_id, caption, judgment_meaning, resolved_from, importance_score, hidden_reason}
        - image_id 가 None 이면 못 찾음(hidden_reason 채움). caption/judgment 는 없을 수 있음.
    """
    tid = _norm_key(task.get("task_id"))
    ttl = _norm_title(task.get("task_title"))
    image_count = task.get("image_count") or 0

    def _from(image_id, resolved_from, *, caption="", judgment="", score=None):
        return {
            "image_id": image_id,
            "caption": caption,
            "judgment_meaning": judgment,
            "resolved_from": resolved_from,
            "importance_score": score,
            "hidden_reason": None,
        }

    # 1) 서버 featured(task_map) — caption/judgment 까지 갖춘 최선.
    fmap = task_map.get(tid) if tid else None
    if fmap and fmap.get("image_id"):
        return _from(
            fmap["image_id"], "featured",
            caption=fmap.get("caption") or "",
            judgment=fmap.get("judgment_meaning") or fmap.get("display_reason") or "",
            score=fmap.get("importance_score"),
        )

    # 2)/3) evidence_summaries — task_id 우선, 없으면 task_title. 점수 최고 이미지.
    def _scored_candidates(match_by_title: bool):
        out = []
        for ev in evidence_summaries or []:
            if not isinstance(ev, dict) or not ev.get("image_id"):
                continue
            man = manifest_by_id.get(_norm_key(ev.get("image_id"))) or {}
            if match_by_title:
                if not ttl or _norm_title(ev.get("task_title") or man.get("task_title")) != ttl:
                    continue
                rel = _relevance_weight(ev.get("task_relevance"))
                if rel < 0.6:  # high/medium 만
                    continue
            else:
                ev_tid = _norm_key(ev.get("task_id") if ev.get("task_id") is not None else man.get("task_id"))
                if not tid or ev_tid != tid:
                    continue
            out.append((score_image_importance(ev, man), ev))
        out.sort(key=lambda x: x[0], reverse=True)
        return out

    for by_title in (False, True):
        cands = _scored_candidates(by_title)
        if cands:
            score, ev = cands[0]
            return _from(
                _norm_key(ev.get("image_id")),
                "image_evidence_summaries_title" if by_title else "image_evidence_summaries",
                caption=_evidence_caption(ev),
                score=round(score, 4),
            )

    # 4)/5) manifest — task_id 일치 이미지(recommended 우선, 없으면 첫 이미지).
    task_manifest = [
        it for it in manifest_by_id.values()
        if it.get("image_id") and _norm_key(it.get("task_id")) == tid and tid
    ]
    if task_manifest:
        recommended = [
            it for it in task_manifest
            if (it.get("image_quality") or {}).get("recommendation_level") != "not_recommended"
        ]
        pick = (recommended or task_manifest)[0]
        return _from(
            _norm_key(pick.get("image_id")),
            "image_manifest_recommended" if recommended else "image_manifest_first",
        )

    # 못 찾음 — image_count>0 인데 매핑 실패면 명확한 버그 신호.
    reason = (
        "image_count>0 인데 evidence/manifest 에서 대표 이미지를 찾지 못함(매핑 실패)"
        if image_count else "이 Task 에 연결된 이미지 없음"
    )
    return {
        "image_id": None, "caption": "", "judgment_meaning": "",
        "resolved_from": None, "importance_score": None, "hidden_reason": reason,
    }


# =========================================================
# Task별 "연결된 이미지 전체" 목록 (인수인계 상세 보기 = ViewMode 결정론)
#   인수인계 상세 모드가 featured_image_id 1장에 의존하지 않도록, Task 에 연결된 모든
#   이미지를 image_id 단위 목록으로 deterministic 하게 만든다(스펙 §1·§3·§4).
#   featured 만 믿지 않고, evidence(모델 해석) + full manifest(분석 안 된 나머지)까지 합쳐
#   image_count 만큼의 이미지를 대표부터 순서대로 채운다. 렌더 정책(간결=1장 / 상세=전체)은
#   프론트가 ViewMode 로만 판단한다(모델 응답에 따라 랜덤하게 달라지지 않게).
# =========================================================

# 인수인계 상세에서 Task 당 실제로 펼쳐 표시할 이미지 최대치(성능 가드, 스펙 §5).
# 초과분만 "+ 나머지 n장"으로 요약. 2~4장 수준이면 전부 표시된다.
TASK_VISUAL_DETAILED_MAX = 6


def _relevance_confidence(value: Any) -> str:
    """task_relevance → confidence 라벨(high/medium/low). 미지정은 low 로 보수적 처리."""
    w = _relevance_weight(value)
    if w >= 1.0:
        return "high"
    if w >= 0.6:
        return "medium"
    return "low"


def build_task_visual_evidence_images(
    task: Dict[str, Any],
    task_map: Dict[str, Dict[str, Any]],
    evidence_summaries: List[Dict[str, Any]],
    full_manifest_by_id: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Task 1개에 연결된 이미지 전체를 대표 우선·중복 제거로 수집한다(스펙 §3·§4).

    우선순위:
      1) 서버 featured(task_map)      — 대표 이미지(is_featured=true)
      2) image_evidence_summaries      — task_id 일치 → task_title 일치(모델 해석 caption)
      3) image_manifest(full)          — task_id 일치(분석 안 된 나머지 이미지까지)
    각 이미지: {image_id, is_featured, caption, judgment_meaning, confidence, role,
                rendered, hidden_reason, source}. not_recommended 는 rendered=false +
    hidden_reason='not_recommended' 로 목록에 남긴다(스펙 §8·§9, 상세 debug 노출용).
    """
    tid = _norm_key(task.get("task_id"))
    ttl = _norm_title(task.get("task_title"))

    ev_by_id: Dict[str, Dict[str, Any]] = {}
    for ev in evidence_summaries or []:
        if isinstance(ev, dict) and ev.get("image_id"):
            ev_by_id.setdefault(_norm_key(ev.get("image_id")), ev)

    images: List[Dict[str, Any]] = []
    seen: set = set()

    def _push(image_id, *, is_featured=False, caption="", judgment="",
              confidence="", role="", source=""):
        key = _norm_key(image_id)
        if not key or key in seen:
            return
        seen.add(key)
        man = full_manifest_by_id.get(key) or {}
        ev = ev_by_id.get(key) or {}
        cap = (caption or "").strip()
        if not cap and ev:
            cap = _evidence_caption(ev)
        if not cap:
            cap = (man.get("nearby_text") or man.get("fallback_context_text") or "").strip()[:120]
        conf = (confidence or "").strip()
        if not conf:
            conf = _relevance_confidence(ev.get("task_relevance")) if ev else "low"
        r = (role or ev.get("image_role_hint") or man.get("image_role") or "").strip()
        rec = (man.get("image_quality") or {}).get("recommendation_level")
        rendered, hidden_reason = True, None
        if rec == "not_recommended":
            rendered, hidden_reason = False, "not_recommended"
        images.append({
            "image_id": key,
            "is_featured": bool(is_featured),
            "caption": cap,
            "judgment_meaning": (judgment or "").strip(),
            "confidence": conf,
            "role": r,
            "rendered": rendered,
            "hidden_reason": hidden_reason,
            "source": source,
        })

    # 1) 서버 featured 대표 이미지
    fmap = task_map.get(tid) if tid else None
    if fmap and fmap.get("image_id"):
        _push(
            fmap["image_id"], is_featured=True,
            caption=fmap.get("caption") or "",
            judgment=fmap.get("judgment_meaning") or fmap.get("display_reason") or "",
            confidence="high", source="featured",
        )

    # 2) evidence_summaries — task_id 일치 먼저, 없으면 task_title(relevance high/medium)
    def _ev_matches(ev: Dict[str, Any], by_title: bool) -> bool:
        man = full_manifest_by_id.get(_norm_key(ev.get("image_id"))) or {}
        if by_title:
            if not ttl or _norm_title(ev.get("task_title") or man.get("task_title")) != ttl:
                return False
            return _relevance_weight(ev.get("task_relevance")) >= 0.6
        ev_tid = _norm_key(ev.get("task_id") if ev.get("task_id") is not None else man.get("task_id"))
        return bool(tid) and ev_tid == tid

    for by_title in (False, True):
        cands: List[Tuple[float, Dict[str, Any]]] = []
        for ev in evidence_summaries or []:
            if not isinstance(ev, dict) or not ev.get("image_id"):
                continue
            if _norm_key(ev.get("image_id")) in seen:
                continue
            if _ev_matches(ev, by_title):
                man = full_manifest_by_id.get(_norm_key(ev.get("image_id"))) or {}
                cands.append((score_image_importance(ev, man), ev))
        cands.sort(key=lambda x: x[0], reverse=True)  # 대표 다음, 의미 있는 근거부터
        for _score, ev in cands:
            _push(
                ev.get("image_id"),
                caption=_evidence_caption(ev),
                confidence=_relevance_confidence(ev.get("task_relevance")),
                role=ev.get("image_role_hint") or "",
                source="image_evidence_summaries_title" if by_title else "image_evidence_summaries",
            )

    # 3) full manifest — task_id 일치(분석 안 된 나머지 이미지까지 포함해 image_count 를 채운다)
    if tid:
        man_items = [
            it for it in full_manifest_by_id.values()
            if it.get("image_id")
            and _norm_key(it.get("task_id")) == tid
            and _norm_key(it.get("image_id")) not in seen
        ]
        # recommended 를 not_recommended 보다 앞에(안정 정렬)
        man_items.sort(
            key=lambda it: 1 if (it.get("image_quality") or {}).get("recommendation_level") == "not_recommended" else 0
        )
        for it in man_items:
            _push(it.get("image_id"), source="image_manifest")

    return images


# =========================================================
# 최종 합성: deterministic base(서버 DB) + 모델 분석 포인트 → 최종 보고서 view model
#   핵심 원칙: 구조/사실 데이터는 base(DB)에서 그대로, 분석 문장만 모델 enhancement 에서.
# =========================================================

def build_vision_enhanced_report(
    report_base: Dict[str, Any],
    enhancements: Optional[Dict[str, Any]],
    evidence_summaries: List[Dict[str, Any]],
    manifest_by_id: Dict[str, Dict[str, Any]],
    full_manifest_by_id: Optional[Dict[str, Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """deterministic base + 모델 enhancement 를 병합해 최종 report dict 를 만든다.

    Args:
        report_base: main.py 가 DB 로 만든 {project_overview, tasks, attachment_summary}.
        enhancements: parse_enhancements 결과(모델 분석 포인트). None 이면 base 만으로 렌더.
        evidence_summaries: Stage 1 image evidence.
        manifest_by_id: image_id → manifest item(분석 대상=선택 이미지. 점수/대표 이미지용).
        full_manifest_by_id: image_id → manifest item(프로젝트 전체 이미지). 인수인계 상세
            보기가 image_count 만큼 모든 이미지를 펼치려면 분석 안 된 이미지까지 필요하다.
            None 이면 manifest_by_id 로 대체(하위호환).
    """
    enh = enhancements if isinstance(enhancements, dict) else {}
    base = report_base or {}
    full_mbi = full_manifest_by_id or manifest_by_id or {}

    # ── 1) 프로젝트 개요: 사실(DB) + 모델 요약 포인트 ──
    base_ov = dict(base.get("project_overview") or {})
    exec_sum = enh.get("project_executive_summary") or {}
    base_ov["summary_points"] = to_points(exec_sum.get("summary_points"), max_points=6)
    base_ov["key_message"] = (exec_sum.get("key_message") or "").strip()
    base_ov["decision_point"] = (exec_sum.get("decision_point") or "").strip()

    # ── 2) 대표 이미지(server 확정) + Task별 대표 이미지 ──
    featured, non_featured, task_map = select_featured_visual_evidence(
        evidence_summaries,
        manifest_by_id,
        model_featured=enh.get("featured_visual_evidence"),
    )

    # ── 3) Task별 분석: DB 사실 + 모델 enhancement(task_id 매칭) ──
    enh_by_task: Dict[str, Dict[str, Any]] = {}
    for e in (enh.get("task_analysis_enhancements") or []):
        if isinstance(e, dict) and e.get("task_id") is not None:
            enh_by_task[str(e.get("task_id"))] = e

    # evidence 가 있는 task_id 집합(coverage 계산용)
    tasks_with_images: set = set()
    for ev in evidence_summaries or []:
        if isinstance(ev, dict) and ev.get("task_id") is not None:
            tasks_with_images.add(str(ev.get("task_id")))

    task_analysis: List[Dict[str, Any]] = []
    tasks_with_visual_points: set = set()
    task_visual_debug: List[Dict[str, Any]] = []
    task_visual_evidence_map: Dict[str, Dict[str, Any]] = {}
    hidden_task_images: List[Dict[str, Any]] = []
    for t in (base.get("tasks") or []):
        tid = t.get("task_id")
        tid_key = str(tid) if tid is not None else None
        e = enh_by_task.get(tid_key, {}) if tid_key else {}
        has_img = bool(t.get("image_count")) or (tid_key in tasks_with_images)
        v_points = to_points(e.get("visual_evidence_summary_points"), max_points=5)
        if v_points:
            tasks_with_visual_points.add(tid_key)
        # 대표 이미지: featured 만 믿지 말고 fallback 체인(evidence/manifest)으로 반드시 찾는다.
        resolved = resolve_task_visual_image(t, task_map, evidence_summaries, manifest_by_id)
        featured_iid = resolved.get("image_id")
        # 캡션/판단 의미: 모델 Task 보강값 우선, 없으면 resolve 로 고른 대표 이미지 메타로 대체.
        v_caption = (e.get("visual_evidence_caption") or "").strip() or (resolved.get("caption") or "").strip()
        v_judgment = (
            (e.get("visual_evidence_judgment_meaning") or "").strip()
            or (resolved.get("judgment_meaning") or "").strip()
        )
        # 개발자 debug — image_count>0·badge=true 인데 resolved=None·rendered=false 는 명확한 버그.
        task_visual_debug.append({
            "task_id": tid,
            "task_title": t.get("task_title"),
            "image_count": t.get("image_count") or 0,
            "has_visual_evidence": has_img,
            "badge_visible": has_img,
            "resolved_image_id": featured_iid,
            "resolved_from": resolved.get("resolved_from"),
            "importance_score": resolved.get("importance_score"),
            "rendered": bool(featured_iid),
            "hidden_reason": resolved.get("hidden_reason"),
        })
        # 인수인계 상세용 — Task 에 연결된 이미지 전체 목록(대표 우선, 중복 제거). featured 1장에
        # 의존하지 않고 image_count 만큼 채운다(스펙 §1·§3·§4). 렌더는 프론트가 ViewMode 로 판단.
        visual_images = build_task_visual_evidence_images(
            t, task_map, evidence_summaries, full_mbi
        )
        if tid_key is not None:
            task_visual_evidence_map[tid_key] = {
                "task_id": tid,
                "task_title": t.get("task_title"),
                "featured_image_id": featured_iid,
                "image_count": t.get("image_count") or 0,
                "images": visual_images,
            }
        for vi in visual_images:
            if not vi.get("rendered"):
                hidden_task_images.append({
                    "task_id": tid,
                    "image_id": vi.get("image_id"),
                    "rendered": False,
                    "hidden_reason": vi.get("hidden_reason"),
                })
        # 추가 이미지(대표 1장 외) 개수 — DB image_count 기준. "+ 추가 이미지 n장" 표기용.
        img_total = t.get("image_count") or 0
        additional_count = max(0, img_total - (1 if featured_iid else 0))
        additional_summary = (e.get("additional_visual_evidence_summary") or "").strip()
        # ── 분석은 단일 세트만 생성(중복 출력 제거). 상세(인수인계) 보기는 서버가 같은 세트에
        #    context_points/handover_notes(상세 전용)를 더해 구성한다. brief 는 이 세트의 부분집합.
        #    (하위호환: 구버전 응답의 detailed 객체가 오면 그 값도 fallback 으로 받아준다.)
        det = e.get("detailed") or {}
        brief_summary = to_points(e.get("summary_points"), max_points=6)
        brief_risk = to_points(e.get("risk_points"), max_points=5)
        brief_next = to_points(e.get("next_actions"), max_points=5)
        detailed = {
            "context_points": to_points(e.get("context_points") or det.get("context_points"), max_points=6),
            "summary_points": brief_summary or to_points(det.get("summary_points"), max_points=8),
            "risk_points": brief_risk or to_points(det.get("risk_points"), max_points=6),
            "next_actions": brief_next or to_points(det.get("next_actions"), max_points=6),
            "visual_evidence_summary_points": v_points or to_points(
                det.get("visual_evidence_summary_points"), max_points=6
            ),
            "handover_notes": to_points(e.get("handover_notes") or det.get("handover_notes"), max_points=6),
        }
        task_analysis.append({
            # ── 사실 데이터(DB, 그대로) ──
            "task_id": tid,
            "task_title": t.get("task_title"),
            "status": t.get("status"),
            "priority": t.get("priority"),
            "progress": t.get("progress"),
            "due_date": t.get("due_date"),
            "assignees": t.get("assignees") or [],
            "sub_project": t.get("sub_project"),
            "image_count": t.get("image_count") or 0,
            # 근거 자료 수(📷/📝/🔗) — base(DB)에서 그대로 전달(Task 표 근거 컬럼용).
            "note_count": t.get("note_count") or 0,
            "url_count": t.get("url_count") or 0,
            "file_count": t.get("file_count") or 0,
            # ── 분석 포인트(모델) — 최상위는 brief(임원 보고용) ──
            "summary_points": brief_summary,
            "risk_points": brief_risk,
            "next_actions": brief_next,
            # ── 상세(인수인계용) 분석 포인트 — detailed 보기 모드에서 사용 ──
            "detailed": detailed,
            "has_visual_evidence": has_img,
            "visual_evidence_summary_points": v_points,
            "visual_evidence_confidence": (e.get("visual_evidence_confidence") or "").strip() or None,
            "visual_evidence_limitations": to_points(e.get("visual_evidence_limitations"), max_points=3),
            "featured_image_id": featured_iid,
            # Task 카드가 이미지 근거의 주 표시 위치 — 캡션/판단 의미/추가 이미지 요약을 Task 에 직접 싣는다.
            "visual_evidence_caption": v_caption or None,
            "visual_evidence_judgment_meaning": v_judgment or None,
            "additional_image_count": additional_count,
            "additional_visual_evidence_summary": additional_summary or None,
            # 인수인계 상세 보기용 — Task 에 연결된 이미지 전체(대표 우선). 스펙 §4 우선순위 2번.
            "visual_evidence": {
                "images": visual_images,
                "image_count": t.get("image_count") or 0,
            },
        })

    # ── 4) 종합 현황 / 다음 단계: 모델 포인트 ──
    oa = enh.get("overall_analysis") or {}
    overall_analysis = {
        "summary_points": to_points(oa.get("summary_points"), max_points=6),
        "key_points": to_points(oa.get("key_points"), max_points=6),
        "visual_insights": to_points(oa.get("visual_insights"), max_points=6),
        "risk_points": to_points(oa.get("risk_points"), max_points=6),
    }
    ns = enh.get("next_steps") or {}
    next_steps = {
        "summary_points": to_points(ns.get("summary_points"), max_points=4),
        "actions": to_points(ns.get("actions"), max_points=8),
    }

    # ── 5) 디버그 지표(이미지 활용도) ──
    image_task_count = len(tasks_with_images)
    debug_metrics = {
        "tasks_total": len(base.get("tasks") or []),
        "tasks_with_images": image_task_count,
        "tasks_with_visual_points": len(tasks_with_visual_points),
        "visual_evidence_coverage": (
            round(len(tasks_with_visual_points) / image_task_count, 3) if image_task_count else None
        ),
        "featured_image_task_coverage": len([1 for t in task_analysis if t.get("featured_image_id")]),
        # featured 이미지가 연결된 Task 수 / 이미지가 있는 Task 수(비율, §17).
        "featured_image_task_coverage_ratio": (
            round(len([1 for t in task_analysis if t.get("featured_image_id")]) / image_task_count, 3)
            if image_task_count else None
        ),
        "featured_image_count": len(featured),
        # Task 카드에 실제 렌더될 대표 이미지가 있는 Task 수(§8 task_card_visible_image_count).
        "task_card_visible_image_count": len([1 for t in task_analysis if t.get("featured_image_id")]),
        # image_count>0 인데 대표 이미지를 못 찾은 Task(명확한 버그 케이스, §3/§10).
        "missing_task_image_mapping": [
            {"task_id": d["task_id"], "task_title": d["task_title"],
             "image_count": d["image_count"], "hidden_reason": d["hidden_reason"]}
            for d in task_visual_debug
            if d["image_count"] and not d["resolved_image_id"]
        ],
        "task_visual_debug": task_visual_debug,
        # 상세 모드에서 숨긴 이미지(스펙 §8·§9) — rendered=false + hidden_reason.
        "hidden_task_images": hidden_task_images,
        # 상세 모드에서 실제 펼쳐질 이미지 총량(간결=대표 위주와 구분되는 지표).
        "detailed_visible_image_count": sum(
            len([im for im in (v.get("images") or []) if im.get("rendered")])
            for v in task_visual_evidence_map.values()
        ),
    }

    return {
        "project_overview": base_ov,
        "task_analysis": task_analysis,
        "attachment_summary": base.get("attachment_summary") or [],
        "overall_analysis": overall_analysis,
        "next_steps": next_steps,
        "featured_visual_evidence": featured,
        "non_featured_visual_summary": non_featured,
        # 인수인계 상세 보기(ViewMode) 결정론 — Task별 연결 이미지 전체 맵(스펙 §4).
        "task_visual_evidence_map": task_visual_evidence_map,
        "debug_metrics": debug_metrics,
    }
