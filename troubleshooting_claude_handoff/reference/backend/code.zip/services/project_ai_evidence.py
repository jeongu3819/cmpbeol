"""Image Evidence Card.

낮은 성능의 사내/저비용 vision 모델도 활용할 수 있도록, 이미지를 그냥 모델에 던지지 않고
이미지마다 **무엇을 보여주는지 / 어떤 Task·작업노트의 근거인지 / 모델이 무엇을 추출해야 하는지 /
결과를 얼마나 믿을 수 있는지**를 구조화한 카드를 만든다.

이 모듈은 **모델/OCR 을 호출하지 않는다.** 이미 수집된 manifest 메타(역할/가독성/맥락/품질)를
조합해 모델에 넘길 수 있는 안전한 메타/지시 정보만 생성한다. 이미지 바이트/base64/storage path 는
절대 포함하지 않는다.

연결 구조:
    이미지 → Project → Task → 작업노트 → 주변 텍스트(context_strength) → 역할(image_role) →
    추출 목적(extraction_target) → 모델 지시(model_instruction_key/text)
"""

from __future__ import annotations

from typing import Any, Dict, Optional

EVIDENCE_CARD_VERSION = "evidence-card-v1"

# nearby_text 가 이 길이 이상이면 "의미 있는 맥락"으로 본다(strong 판정 보조).
MEANINGFUL_NEARBY_LEN = 15

# =========================================================
# role → extraction_target (모델이 이미지에서 무엇을 뽑아야 하는가)
# =========================================================
ROLE_EXTRACTION_TARGET: Dict[str, str] = {
    "chart": "trend_summary",
    "table": "table_structure",
    "document_table": "table_structure",
    "meeting_slide": "slide_summary",
    "error_screen": "error_diagnosis",
    "command_snippet": "command_lines",
    "code_snippet": "code_summary",
    "log_capture": "log_events",
    "terminal_capture": "terminal_output",
    "config_capture": "config_values",
    "text_crop": "text_lines",
    "document_crop": "text_lines",
    "note_capture": "visual_note_summary",
    "partial_screen_capture": "visible_region_summary",
    "equipment_screen": "equipment_status_summary",
    "process_flow": "process_steps",
    "result_capture": "result_summary",
    "before_after": "before_after_comparison",
    "unknown": "conservative_visual_summary",
}

# =========================================================
# role → model_instruction_key (나중에 role 별 프롬프트 분기용)
# =========================================================
ROLE_MODEL_INSTRUCTION_KEY: Dict[str, str] = {
    "chart": "analyze_chart_conservatively",
    "table": "extract_table_carefully",
    "document_table": "extract_table_carefully",
    "meeting_slide": "summarize_meeting_slide",
    "error_screen": "extract_error_and_next_action",
    "command_snippet": "extract_commands_preserve_order",
    "code_snippet": "summarize_code_snippet",
    "log_capture": "extract_log_events",
    "terminal_capture": "extract_terminal_output",
    "config_capture": "extract_config_safely",
    "text_crop": "extract_text_crop",
    "document_crop": "extract_text_crop",
    "note_capture": "summarize_visual_note",
    "partial_screen_capture": "summarize_visible_region",
    "equipment_screen": "summarize_equipment_screen",
    "process_flow": "extract_process_steps",
    "result_capture": "summarize_result_capture",
    "before_after": "compare_before_after",
    "unknown": "describe_visible_facts_only",
}

# =========================================================
# model_instruction_key → 지시사항 템플릿(한국어).
# **실제 모델 호출은 아직 없음.** 모델 연결 전 프롬프트 품질 검토용 텍스트.
# =========================================================
MODEL_INSTRUCTION_TEMPLATES: Dict[str, str] = {
    "analyze_chart_conservatively": (
        "차트 이미지입니다. 정확한 숫자를 단정하지 말고, 보이는 범위에서 추세/변곡점/이상점 중심으로 "
        "요약하세요. 축/수치가 불명확하면 \"정확한 수치 확인 필요\"라고 표시하세요."
    ),
    "extract_table_carefully": (
        "표 이미지입니다. 제목, 컬럼명, 행 단위 주요 값을 분리해서 정리하세요. "
        "읽기 어려운 셀은 추정하지 말고 \"확인 필요\"라고 표시하세요."
    ),
    "summarize_meeting_slide": (
        "회의자료 이미지입니다. 슬라이드 제목, 핵심 항목, 업무 프로세스 적용 포인트, action item 을 "
        "분리해서 정리하세요."
    ),
    "extract_error_and_next_action": (
        "에러 화면입니다. 에러 메시지, 발생 파일/라인, 원인 후보, 다음 조치 순서로 정리하세요. "
        "보이지 않는 내용은 추정하지 마세요."
    ),
    "extract_commands_preserve_order": (
        "명령어/실행방법 캡처입니다. 보이는 명령어를 가능한 원문 순서대로 보존하세요. "
        "오타처럼 보여도 임의 수정하지 말고, 수정이 필요해 보이면 별도 후보로 표시하세요."
    ),
    "summarize_code_snippet": (
        "코드 일부 캡처입니다. 보이는 코드의 목적/핵심 로직을 요약하되, 줄 단위로 임의 보완하지 마세요. "
        "잘린 부분은 \"이후 생략/확인 필요\"로 표시하세요."
    ),
    "extract_log_events": (
        "로그/스택트레이스 캡처입니다. 시간순/발생 순서대로 주요 이벤트(에러/경고/상태)를 추출하세요. "
        "잘린 로그는 추정하지 말고 표시만 하세요."
    ),
    "extract_terminal_output": (
        "터미널/콘솔 출력 캡처입니다. 실행한 명령과 그 출력 결과를 구분해서 정리하세요. "
        "보이지 않는 출력은 추정하지 마세요."
    ),
    "extract_config_safely": (
        "설정/환경변수 캡처입니다. 키 이름 위주로 정리하고, 민감정보(키/토큰/비밀번호/접속정보)로 보이는 "
        "값은 그대로 노출하지 말고 마스킹/요약하세요. 값이 불확실하면 추정하지 마세요."
    ),
    "extract_text_crop": (
        "작은 텍스트 캡처입니다. 보이는 텍스트만 추출하고, 주변 맥락이 약하면 불확실성을 표시하세요."
    ),
    "summarize_visual_note": (
        "작업노트에 붙은 캡처입니다. 무엇을 보여주는지 사실 위주로 요약하고, 불확실하면 표시하세요."
    ),
    "summarize_visible_region": (
        "화면 일부 캡처입니다. 보이는 영역에 한정해 사실만 요약하고, 잘린 부분은 추정하지 마세요."
    ),
    "summarize_equipment_screen": (
        "설비/장비 화면 캡처입니다. 설비명/상태/알람/주요 값 위주로 정리하고, 불명확한 값은 추정하지 마세요."
    ),
    "extract_process_steps": (
        "프로세스/흐름 이미지입니다. 단계 순서와 분기를 순서대로 정리하세요. 불명확한 연결은 표시만 하세요."
    ),
    "summarize_result_capture": (
        "측정/결과 캡처입니다. 보이는 결과값/판정 위주로 요약하고, 정확한 수치는 단정하지 말고 표시하세요."
    ),
    "compare_before_after": (
        "전/후 비교 이미지입니다. 무엇이 바뀌었는지 차이 중심으로 정리하고, 불확실하면 표시하세요."
    ),
    "describe_visible_facts_only": (
        "역할이 불확실한 이미지입니다. 보이는 사실만 보수적으로 묘사하고, 의미/원인은 단정하지 마세요."
    ),
}

DEFAULT_INSTRUCTION_KEY = "describe_visible_facts_only"

# context_strength 가 약한 이미지의 표준 경고 문구
WEAK_CONTEXT_WARNING = "nearby_text가 없거나 약해 이미지 자체 판독 의존도가 높음"

# 약한 맥락으로 보는 fallback 출처
_WEAK_CONTEXT_SOURCES = {"task_title", "sub_project_name", "project_name"}
_LOW_READABILITY_STATUSES = {
    "compact_text_crop", "small_but_readable", "partial_screen_capture",
    "too_small_for_text", "thumbnail_suspected", "low_resolution",
}


def _is_descriptive(text: Optional[str]) -> bool:
    """Task title 등이 의미 있게 설명적인지(예: '4' 는 약함, 'spec 비교' 는 설명적)."""
    t = (text or "").strip()
    if not t:
        return False
    if t.isdigit():
        return False
    return len(t) >= 5


def compute_context_strength(item: Dict[str, Any]) -> str:
    """이미지-텍스트 맥락 신뢰도. strong / medium / weak / none."""
    src = item.get("context_text_source")
    nearby = (item.get("nearby_text") or "").strip()
    fallback = (item.get("fallback_context_text") or "").strip()

    if not nearby and not fallback:
        return "none"
    if src == "nearby_text":
        return "strong" if len(nearby) >= MEANINGFUL_NEARBY_LEN else "medium"
    if src == "same_entity_text":
        # 같은 TaskActivity/설명/노트 본문에서 온 fallback
        return "medium" if fallback else "weak"
    if src == "task_title":
        return "medium" if _is_descriptive(fallback) else "weak"
    if src in _WEAK_CONTEXT_SOURCES:
        return "weak"
    if src == "source_entity":
        # "task_activity:461" 같은 식별자뿐 — 실제 맥락 아님
        return "none"
    return "weak"


def _quality_warning(item: Dict[str, Any], context_strength: str) -> Optional[str]:
    q = item.get("image_quality") or {}
    status = q.get("readability_status")
    parts = []
    if context_strength in ("weak", "none"):
        parts.append(WEAK_CONTEXT_WARNING)
    if status in _LOW_READABILITY_STATUSES:
        parts.append("작은/부분 캡처로 글자 판독이 어려울 수 있어 결과 검증 필요")
    elif status == "missing_dimensions":
        parts.append("이미지 크기 메타가 없어 판독 적합성 판단 불가")
    elif status == "unsupported_type":
        parts.append("AI 지원 이미지 형식이 아님")
    if item.get("image_role_confidence") in ("low", "none"):
        parts.append("image_role 신뢰도 낮음(키워드/메타 기반 약한 추정)")
    return " / ".join(parts) if parts else None


def build_evidence_card(item: Dict[str, Any]) -> Dict[str, Any]:
    """manifest item 1건으로부터 Evidence Card 를 생성(이미지 바이트/경로 미포함)."""
    role = item.get("image_role") or "unknown"
    q = item.get("image_quality") or {}
    variants = item.get("ai_image_variants") or {}
    ai_readable = variants.get("ai_readable") or {}

    context_strength = compute_context_strength(item)
    extraction_target = ROLE_EXTRACTION_TARGET.get(role, ROLE_EXTRACTION_TARGET["unknown"])
    instruction_key = ROLE_MODEL_INSTRUCTION_KEY.get(role, DEFAULT_INSTRUCTION_KEY)
    instruction_text = MODEL_INSTRUCTION_TEMPLATES.get(
        instruction_key, MODEL_INSTRUCTION_TEMPLATES[DEFAULT_INSTRUCTION_KEY]
    )

    return {
        "version": EVIDENCE_CARD_VERSION,
        "image_id": item.get("image_id"),
        "project_id": item.get("project_id"),
        "project_name": item.get("project_name"),
        "task_id": item.get("task_id"),
        "task_title": item.get("task_title"),
        "source_entity_type": item.get("source_entity_type"),
        "relation_type": item.get("relation_type"),

        "nearby_text": item.get("nearby_text"),
        "fallback_context_text": item.get("fallback_context_text"),
        "context_text_source": item.get("context_text_source"),
        "context_strength": context_strength,

        "image_role": role,
        "image_role_source": item.get("image_role_source"),
        "image_role_confidence": item.get("image_role_confidence"),

        "readability_status": q.get("readability_status"),
        "recommendation_level": q.get("recommendation_level"),
        "quality_warning": _quality_warning(item, context_strength),

        "extraction_target": extraction_target,
        "model_instruction_key": instruction_key,
        "model_instruction_text": instruction_text,
        # AI 입력 전략(원본/조건부원본/고해상도필요 등) — variants 재사용
        "ai_input_strategy": ai_readable.get("recommended_action"),
    }


def attach_evidence_card(item: Dict[str, Any]) -> None:
    """manifest item 에 evidence_card 를 in-place 부여."""
    item["evidence_card"] = build_evidence_card(item)
