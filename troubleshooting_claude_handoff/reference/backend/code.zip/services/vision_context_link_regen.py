"""Stale ContextLink 재생성 (2b-2b) — 원본 이미지 없이 Text 모델 batch 로 문맥만 재평가.

ImageObservation 은 캐시 hit 인데 Task/작업노트 텍스트가 바뀌어 ContextLink 가 stale 이 되면,
**원본 이미지를 다시 Vision 에 보내지 않고** 저장된 Observation(객관 사실)+현재 Task 문맥만
Text 모델에 batch 로 보내 evidence_type/task_relevance/context_summary 등 문맥값만 재생성한다.

- provider 독립: 실제 LLM 호출은 호출부가 text_chat_fn 으로 주입한다(Gemma4/GPT-OSS 전환 대비).
- 이미지별 호출 금지 — 한 요청의 stale 항목을 batch 로 묶어 호출.
- 이미지 bytes/base64/URL 을 입력에 절대 포함하지 않는다.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Callable, Dict, List, Optional, Tuple

from app.services.vision_image_observation import (
    normalize_task_relevance,
    build_context_summary,
    _ALLOWED_EVIDENCE_TYPES,
)

logger = logging.getLogger("main")

TASK_RELEVANCE_ENUM = ("high", "medium", "low", "unknown")

_SYSTEM_PROMPT = (
    "당신은 이미지에서 이미 추출된 관찰 결과(observation)와 현재 Task/작업노트 문맥을 받아, "
    "그 이미지가 이 Task 에 갖는 의미만 판정하는 분석기입니다. 이미지를 직접 보지 않습니다. "
    "observation 에 있는 사실만 근거로 쓰고, 보이지 않는 내용을 새로 지어내지 마세요.\n"
    "각 항목마다 아래 값을 판정합니다.\n"
    "- evidence_type: direct(직접 근거) / supporting(보조) / reference(참고자료) / "
    "unrelated(관련성 낮음) / unreadable(판독 불가) 중 하나\n"
    "- task_relevance: high / medium / low / unknown 중 하나\n"
    "- context_summary: 이 이미지가 현재 Task 판단에 갖는 의미 1~2문장\n"
    "- supports: 이 이미지가 뒷받침하는 작업노트/Task 내용(짧은 문장 배열)\n"
    "- contradictions: 작업노트와 충돌하는 내용이 있으면 배열, 없으면 []\n"
    "- confidence: 0~1 사이 숫자\n"
    "결과는 추가 설명 없이 **JSON 배열**로만, 각 항목에 canonical_image_id 를 그대로 포함해 반환하세요."
)


def build_regen_input_item(
    *,
    canonical_image_id: str,
    project_id: int,
    task_id: int,
    task_title: Optional[str],
    task_description: Optional[str],
    note_text: Optional[str],
    nearby_text: Optional[str],
    caption: Optional[str],
    image_role: Optional[str],
    observation_json: Dict[str, Any],
) -> Dict[str, Any]:
    """stale 항목 → Text 모델 입력(문맥 독립 observation 필드만 사용, 이미지 미포함)."""
    oj = observation_json or {}
    return {
        "canonical_image_id": canonical_image_id,
        "project_id": project_id,
        "task_id": task_id,
        "task_title": task_title or "",
        "task_description": (task_description or "")[:1500],
        "note_text": (note_text or nearby_text or "")[:1500],
        "nearby_text": (nearby_text or "")[:800],
        "caption": caption or "",
        "image_role": image_role or oj.get("image_type") or "",
        # context-independent observation 만(과거 evidence_type/task_relevance 는 넣지 않음).
        "observation": {
            "image_type": oj.get("image_type"),
            "visible_facts": oj.get("visible_facts") or [],
            "visible_text": oj.get("visible_text") or [],
            "interpretation": oj.get("interpretation") or "",
            "warnings": oj.get("warnings") or [],
        },
    }


def build_regen_prompt(items: List[Dict[str, Any]]) -> Tuple[str, str]:
    """(system, user) 프롬프트. user 는 stale 항목 배열 JSON."""
    payload = {"items": items}
    user = (
        "아래 items 각각에 대해 evidence_type/task_relevance/context_summary/supports/"
        "contradictions/confidence 를 판정해 JSON 배열로 반환하세요. canonical_image_id 는 그대로 두세요.\n"
        + json.dumps(payload, ensure_ascii=False)
    )
    return _SYSTEM_PROMPT, user


def _coerce_list(raw: Any) -> List[Dict[str, Any]]:
    if isinstance(raw, list):
        return [x for x in raw if isinstance(x, dict)]
    if isinstance(raw, dict):
        for k in ("items", "results", "context_links"):
            v = raw.get(k)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, dict)]
        if raw.get("canonical_image_id"):
            return [raw]
    return []


def parse_regen_output(raw_text: Optional[str]) -> Dict[str, Dict[str, Any]]:
    """Text 모델 raw → {canonical_image_id: result}. 파싱 실패 시 빈 dict."""
    if not raw_text or not raw_text.strip():
        return {}
    text = raw_text.strip()
    if text.startswith("```"):
        # 코드펜스 제거
        text = text.strip("`")
        nl = text.find("\n")
        if nl != -1:
            text = text[nl + 1:]
    out: Dict[str, Dict[str, Any]] = {}

    def _accept(items: List[Dict[str, Any]]):
        for it in items:
            cid = it.get("canonical_image_id")
            if cid:
                out[str(cid)] = it

    try:
        _accept(_coerce_list(json.loads(text)))
        if out:
            return out
    except (json.JSONDecodeError, ValueError):
        pass
    # 배열 구간만 재시도
    s = text.find("[")
    e = text.rfind("]")
    if s != -1 and e != -1 and e > s:
        try:
            _accept(_coerce_list(json.loads(text[s:e + 1])))
        except (json.JSONDecodeError, ValueError):
            return {}
    return out


def normalize_regen_result(result: Dict[str, Any]) -> Dict[str, Any]:
    """모델 출력 → 저장/변환용 정규화(evidence_type/task_relevance enum, 문장 보존)."""
    et = (result.get("evidence_type") or "").strip().lower()
    if et not in _ALLOWED_EVIDENCE_TYPES:
        et = "reference"
    relevance = normalize_task_relevance(result.get("task_relevance"), evidence_type=et)
    supports = result.get("supports") if isinstance(result.get("supports"), list) else []
    contradictions = (
        result.get("contradictions") if isinstance(result.get("contradictions"), list) else []
    )
    conf = result.get("confidence")
    try:
        conf = float(conf) if conf is not None else None
    except (TypeError, ValueError):
        conf = None
    # 모델이 등급 대신 설명 문장을 task_relevance 로 준 경우, 그 문장을 context_summary 에 보존.
    raw_relevance = result.get("task_relevance")
    relevance_reason = None
    if isinstance(raw_relevance, str) and raw_relevance.strip().lower() not in TASK_RELEVANCE_ENUM:
        relevance_reason = raw_relevance.strip() or None
    return {
        "evidence_type": et,
        "task_relevance": relevance,
        "context_summary": build_context_summary(
            (result.get("context_summary") or "").strip() or None, relevance_reason
        ),
        "supports": [str(s).strip() for s in supports if str(s).strip()][:6],
        "contradictions": [str(s).strip() for s in contradictions if str(s).strip()][:6],
        "confidence": conf,
    }


def _new_regen_stats() -> Dict[str, Any]:
    return {
        "enabled": True, "requested": 0, "batch_calls": 0,
        "succeeded": 0, "failed": 0,
        "input_tokens": 0, "output_tokens": 0, "elapsed_ms": 0,
        "first_error_stage": None, "first_error_type": None, "first_error_message": None,
    }


def _chunks(seq: List[Any], size: int) -> List[List[Any]]:
    size = max(1, int(size or 1))
    return [seq[i:i + size] for i in range(0, len(seq), size)]


def regenerate_context_links_batch(
    items: List[Dict[str, Any]],
    *,
    text_chat_fn: Callable[[str, str], str],
    batch_size: int = 12,
) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Any]]:
    """stale 항목들을 batch(Text)로 재평가한다.

    text_chat_fn(system, user) -> raw_text 를 호출부가 주입(provider 독립).
    반환: (normalized_results_by_id, stats). 실패/누락 항목은 결과에 없다(호출부가 vision fallback).
    """
    import time

    stats = _new_regen_stats()
    stats["requested"] = len(items or [])
    results: Dict[str, Dict[str, Any]] = {}
    if not items:
        stats["enabled"] = True
        return results, stats

    t0 = time.perf_counter()
    for batch in _chunks(items, batch_size):
        stats["batch_calls"] += 1
        try:
            system, user = build_regen_prompt(batch)
            raw = text_chat_fn(system, user)
            parsed = parse_regen_output(raw)
            for it in batch:
                cid = str(it.get("canonical_image_id"))
                res = parsed.get(cid)
                if res is None:
                    stats["failed"] += 1
                    continue
                results[cid] = normalize_regen_result(res)
                stats["succeeded"] += 1
        except Exception as exc:  # batch 전체 실패 → 이 batch 항목 전부 fallback
            stats["failed"] += len(batch)
            if stats["first_error_stage"] is None:
                stats["first_error_stage"] = "text_batch_call"
                stats["first_error_type"] = type(exc).__name__
                stats["first_error_message"] = str(exc)[:200]
                logger.exception("[ContextLinkRegen] text batch 실패 (해당 항목 vision fallback)")
    stats["elapsed_ms"] = int((time.perf_counter() - t0) * 1000)
    return results, stats
