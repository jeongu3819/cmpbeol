"""
공통 멘션 resolver + notification 생성 helper.

Task 작업노트(TaskActivity)와 Comment(TaskComment)의 @멘션을 **동일한 규칙**으로
처리하기 위한 모듈. 중복 구현 금지 — comment/worknote 엔드포인트 양쪽에서 이 모듈을 쓴다.

핵심 정책
─────────
* 멘션 대상 확정 기준은 username 문자열이 아니라 **user_id** 다.
  - explicit_user_ids(프론트 피커가 고른 id)가 오면 그걸 우선하되, 각 id 가 실제로 해당
    Task/Project 에 접근 가능한 사용자인지 backend 에서 재검증한다.
  - explicit 이 없으면 기존처럼 @token 문자열을 파싱하되, **현재 Project/Space 멤버 범위**
    안에서만 매칭한다.
* 동명이인(같은 username 2명 이상)이 후보에 있으면 임의로 한 명을 고르지 않는다.
  → ambiguous 로 분류하고 **메일 발송 대상에서 제외**한다.
* 접근 권한 게이트(_can_access_task)가 최종 안전장치다. 후보 집합이 다소 느슨해도
  권한 없는 사용자에게는 이벤트가 생성되지 않는다.

main.py 의 access helper 는 순환 import 를 피하기 위해 함수 내부에서 lazy import 한다
(backup_scheduler 가 main 의 _cleanup_empty_spaces 를 lazy import 하는 것과 동일한 패턴).
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, Iterable, List, Optional

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models import User, ProjectMember, SpaceMember
from app.services.notifications import create_notification_event

logger = logging.getLogger("mention")

# 작성자 측 "메일 알림 보내기" 기본값. 프론트 피커가 없는 Phase A 및 값 미지정 시 적용.
# 부담되면 False 로 바꾸면 된다(수신자 on/off 가 최종 게이트라 기본 True 로 둔다).
DEFAULT_SEND_MENTION_EMAIL = True

_MENTION_TOKEN_RE = re.compile(r"@(\S+)")


# ──────────────────────────────────────────────────────────
# 접근 권한 판정 (발송 게이트 / mention detail API 공용)
# ──────────────────────────────────────────────────────────
def can_access_task(db: Session, user_id: int, project_id: Optional[int]) -> bool:
    """user_id 가 해당 project(=task 소속) 를 조회할 수 있는지 boolean 으로 반환.

    main.check_project_access 는 통과 시 True, 실패 시 HTTPException 을 던지므로
    여기서 boolean 으로 감싼다. admin/owner/member/공개-space 규칙을 그대로 재사용한다.
    """
    if not user_id or not project_id:
        return False
    try:
        from main import check_project_access, load_state  # lazy: 순환 import 방지
        state = load_state()
        return bool(check_project_access(db, state, int(project_id), int(user_id)))
    except Exception:
        return False


# ──────────────────────────────────────────────────────────
# 후보 집합 (현재 Project/Space 멤버)
# ──────────────────────────────────────────────────────────
def _project_member_ids(db: Session, project_id: int) -> set[int]:
    ids: set[int] = set()
    for m in db.query(ProjectMember).filter(ProjectMember.project_id == int(project_id)).all():
        if m.user_id:
            ids.add(int(m.user_id))
    # sidecar project_members + owner_id (state 기반)
    try:
        from main import load_state, get_project_meta  # lazy
        state = load_state()
        for m in state.get("project_members", []):
            if int(m.get("project_id") or 0) == int(project_id) and m.get("user_id") is not None:
                ids.add(int(m.get("user_id")))
        meta = get_project_meta(state, int(project_id))
        if meta.get("owner_id"):
            ids.add(int(meta["owner_id"]))
    except Exception:
        pass
    return ids


def _space_member_ids(db: Session, space_id: Optional[int]) -> set[int]:
    if not space_id:
        return set()
    return {
        int(sm.user_id)
        for sm in db.query(SpaceMember).filter(SpaceMember.space_id == int(space_id)).all()
        if sm.user_id
    }


def _match_token(db: Session, token: str, candidate_ids: set[int]) -> List[User]:
    """후보 집합 안에서 @token(loginid 또는 username) 과 일치하는 User 들을 반환."""
    if not candidate_ids:
        return []
    tok = token.strip().rstrip(".,;:!?").lower()
    if not tok:
        return []
    return (
        db.query(User)
        .filter(
            User.id.in_(candidate_ids),
            User.is_active == True,  # noqa: E712
            (func.lower(User.loginid) == tok) | (func.lower(User.username) == tok),
        )
        .all()
    )


# ──────────────────────────────────────────────────────────
# 멘션 대상 resolve
# ──────────────────────────────────────────────────────────
def resolve_mention_targets(
    db: Session,
    *,
    text: str = "",
    explicit_user_ids: Optional[Iterable[int]] = None,
    space_id: Optional[int] = None,
    project_id: Optional[int] = None,
    task_id: Optional[int] = None,
) -> Dict[str, Any]:
    """멘션 대상을 user_id 기준으로 확정한다.

    반환:
        {
          "resolved_user_ids": [int, ...],   # 메일 발송 안전 대상 (접근권한 검증 완료, 동명이인 아님)
          "ambiguous": [{"token": "@홍길동", "candidates": [{id,loginid,username,deptname}...]}],
          "unresolved": ["@없는사람", ...],
        }
    """
    resolved: set[int] = set()
    ambiguous: List[Dict[str, Any]] = []
    unresolved: List[str] = []

    # 1) explicit ids 경로 — 프론트 피커가 user_id 를 명시적으로 보낸 경우
    if explicit_user_ids is not None:
        for raw in explicit_user_ids:
            try:
                uid = int(raw)
            except (TypeError, ValueError):
                continue
            if can_access_task(db, uid, project_id):
                resolved.add(uid)
            else:
                # 권한 없는 대상 — 프론트 후보 숨김을 우회한 경우 방어
                unresolved.append(f"user:{uid}")
                logger.info("[mention] explicit id %s dropped (no access to project %s)", uid, project_id)
        return {
            "resolved_user_ids": sorted(resolved),
            "ambiguous": ambiguous,
            "unresolved": unresolved,
        }

    # 2) text 경로 — @token 을 현재 Project/Space 멤버 범위에서만 매칭
    plain = re.sub(r"<[^>]+>", " ", text or "")
    tokens = _MENTION_TOKEN_RE.findall(plain)
    if not tokens:
        return {"resolved_user_ids": [], "ambiguous": [], "unresolved": []}

    project_ids = _project_member_ids(db, project_id) if project_id else set()
    space_ids = _space_member_ids(db, space_id)

    seen_tokens: set[str] = set()
    for token in tokens:
        tok_key = token.strip().rstrip(".,;:!?").lower()
        if not tok_key or tok_key in seen_tokens:
            continue
        seen_tokens.add(tok_key)

        # project 멤버 우선, 없으면 space 멤버로 fallback
        matches = _match_token(db, token, project_ids)
        if not matches and space_ids:
            matches = _match_token(db, token, space_ids)

        if len(matches) == 1:
            resolved.add(int(matches[0].id))
        elif len(matches) >= 2:
            ambiguous.append({
                "token": f"@{token}",
                "candidates": [
                    {"id": u.id, "loginid": u.loginid, "username": u.username, "deptname": u.deptname}
                    for u in matches
                ],
            })
        else:
            unresolved.append(f"@{token}")

    if ambiguous:
        logger.info(
            "[mention] ambiguous mentions (email skipped) project=%s task=%s: %s",
            project_id, task_id, [a["token"] for a in ambiguous],
        )
    return {
        "resolved_user_ids": sorted(resolved),
        "ambiguous": ambiguous,
        "unresolved": unresolved,
    }


# ──────────────────────────────────────────────────────────
# notification_events (outbox) 생성 — comment / worknote 공용
# ──────────────────────────────────────────────────────────
_SOURCE_META = {
    "task_comment": ("task_comment_mentioned", "comment_id", "comment"),
    "task_work_note": ("task_work_note_mentioned", "work_note_id", "activity"),
}


def create_mention_notifications(
    db: Session,
    *,
    source_type: str,
    source_id: int,
    task,
    space_id: Optional[int],
    actor_user_id: Optional[int],
    resolved_user_ids: Iterable[int],
    send_email: bool,
) -> List[int]:
    """resolved 멘션 대상에게 notification_events(pending) 를 적재한다.

    - source_type: 'task_comment' | 'task_work_note'
    - self-mention(actor==target) 은 create_notification_event 가 skip.
    - 같은 source(source_id)+target 중복 이벤트는 생성하지 않는다.
    - commit 은 호출자 책임.
    반환: 이번에 생성한 target_user_id 목록.
    """
    meta = _SOURCE_META.get(source_type)
    if not meta:
        logger.warning("[mention] unknown source_type=%s (이벤트 미생성)", source_type)
        return []
    event_type, id_key, ref_prefix = meta
    mention_ref = f"{ref_prefix}-{source_id}"

    from app.models import NotificationEvent  # lazy (순환 방지는 아니지만 국소화)

    target_ids = [int(r) for r in resolved_user_ids if str(r).strip().lstrip("-").isdigit()]
    logger.info(
        "[mention] create_notifications source=%s source_id=%s actor=%s targets=%s",
        source_type, source_id, actor_user_id, target_ids,
    )

    created: List[int] = []
    seen: set[int] = set()
    for raw in resolved_user_ids:
        try:
            uid = int(raw)
        except (TypeError, ValueError):
            continue
        if uid in seen:
            continue
        seen.add(uid)
        if actor_user_id is not None and uid == int(actor_user_id):
            from app.services.notifications import allow_self_mention
            if not allow_self_mention():
                logger.info("[mention] skip uid=%s (self-mention, actor==target)", uid)
                continue
            logger.info("[mention] allow uid=%s (self-mention, NOTIFICATION_ALLOW_SELF_MENTION=true)", uid)
        # 동일 source+target 중복 방지 (댓글 수정 재저장 등)
        duplicate = False
        for row in db.query(NotificationEvent).filter(
            NotificationEvent.event_type == event_type,
            NotificationEvent.target_user_id == uid,
            NotificationEvent.task_id == (task.id if task else None),
        ).all():
            pj = row.payload_json or {}
            if isinstance(pj, dict) and pj.get(id_key) == source_id:
                duplicate = True
                break
        if duplicate:
            logger.info("[mention] skip uid=%s (duplicate event for %s=%s)", uid, id_key, source_id)
            continue

        ev = create_notification_event(
            db,
            event_type=event_type,
            task_id=(task.id if task else None),
            project_id=(task.project_id if task else None),
            space_id=space_id,
            actor_user_id=actor_user_id,
            target_user_id=uid,
            payload={
                id_key: source_id,
                "task_id": (task.id if task else None),
                "source": source_type,
                "send_email": bool(send_email),
                "mention_ref": mention_ref,
            },
        )
        if ev is not None:
            created.append(uid)
            logger.info("[mention] created event uid=%s type=%s %s=%s", uid, event_type, id_key, source_id)
        else:
            logger.info("[mention] event NOT created uid=%s (create_notification_event returned None)", uid)
    if not created:
        logger.info(
            "[mention] no events created source=%s source_id=%s (targets=%s actor=%s) — self/duplicate/empty",
            source_type, source_id, target_ids, actor_user_id,
        )
    return created
