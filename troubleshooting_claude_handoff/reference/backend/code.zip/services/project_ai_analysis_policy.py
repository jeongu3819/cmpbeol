"""이미지 분석 결과 재사용 정책 + 재분석 가능 구조.

핵심 방향
---------
이미지 **메타데이터/품질 판단**(width/height/hash/readiness/variant)은 캐시해도 되지만,
**모델이 해석한 이미지 의미**(차트/표/에러화면 해석, 증가·감소·원인·결과 판단)는
정답처럼 고정 캐시하면 안 된다. 잘못 해석된 1건이 영구 재사용되면 이후 프로젝트 AI
요약이 계속 오염될 수 있다.

따라서 PLAN-AI 는 "이미지 분석 캐시"가 아니라
**"이미지 분석 시도 이력(versioned attempt) + 재분석 가능 구조"** 를 지향한다.

이번 단계 범위
--------------
- 실제 vision 모델 호출 / OCR / 의미 분석 **없음**.
- DB(ImageAnalysisAttempt) **미구현** — 향후 설계만 docs 에 기록.
- 여기서는 manifest item 에 ① 재사용 정책 ② 재분석 식별자/캐시키 preview ③ 재분석 트리거
  를 부여하고, preview 응답에 정책 요약을 싣는다.

# Future:
# - semantic 분석 결과는 ImageAnalysisAttempt 로 누적(이력)하고, is_current_candidate 로
#   "현재 후보"만 표시하되 정답으로 단정하지 않는다.
# - semantic_cache_key 는 image_fingerprint + model + prompt + context schema +
#   nearby_text_hash + task_context_hash + project_context_hash 의 조합이어야 한다
#   (image_hash 단독 금지).
"""

from __future__ import annotations

import hashlib
from typing import Any, Dict, List, Optional

# =========================================================
# 버전 상수 (캐시/재분석 조건의 단일 출처)
# =========================================================
PROJECT_AI_CONTEXT_SCHEMA_VERSION = "project-ai-context-v1"
IMAGE_MANIFEST_VERSION = "image-manifest-v1"
IMAGE_READINESS_VERSION = "image-readiness-v1"
# 아직 실제 vision 프롬프트는 없음 — 미래 분석 프롬프트의 버전 자리만 예약.
FUTURE_IMAGE_ANALYSIS_PROMPT_VERSION = "future-project-image-analysis-v1"

ANALYSIS_MODE = "project_image_context"

ANALYSIS_POLICY_STATEMENT = (
    "semantic_image_analysis_must_be_versioned_attempts_not_permanent_cache"
)

# 향후 재분석이 필요한 조건들. ImageAnalysisAttempt 설계 시 그대로 사용.
REANALYSIS_TRIGGERS: List[str] = [
    "image_file_changed",
    "model_changed",
    "model_version_changed",
    "prompt_version_changed",
    "context_schema_changed",
    "nearby_text_changed",
    "task_context_changed",
    "project_context_changed",
    "manual_reanalysis_requested",
    "low_confidence_previous_result",
    "user_feedback_reported_wrong",
]


def _sha256_text(text: Optional[str]) -> Optional[str]:
    """원문은 보관하지 않고 sha256 hex 만 반환(민감정보/로그 비대화 방지)."""
    if text is None:
        return None
    s = str(text)
    if not s.strip():
        return None
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def build_analysis_reuse_policy() -> Dict[str, Any]:
    """이미지별 재사용 정책(정적). 의미 분석은 기본 재사용 금지."""
    return {
        # 객관 메타(해상도/hash/readiness/variant)는 재사용 가능
        "metadata_cacheable": True,
        # 모델 의미 해석은 정답 캐시 금지
        "semantic_analysis_cacheable": False,
        "reuse_semantic_result_by_default": False,
        # 모델/프롬프트/주변텍스트/Task 맥락이 바뀌면 재분석 필요
        "requires_context_aware_reanalysis": True,
        "manual_reanalysis_supported_future": True,
        "reason": (
            "Image interpretation is model/context dependent and must not be "
            "treated as a permanent truth."
        ),
    }


def project_context_hash(project_name: Optional[str], project_description: Optional[str]) -> Optional[str]:
    """프로젝트 맥락 hash (이름+설명). 맥락 변경 감지용."""
    return _sha256_text(f"{project_name or ''}\n{project_description or ''}")


def _task_context_hash(item: Dict[str, Any]) -> Optional[str]:
    if not item.get("task_id"):
        return None
    parts = [
        str(item.get("task_id") or ""),
        str(item.get("task_title") or ""),
        str(item.get("task_status") or ""),
        str(item.get("task_priority") or ""),
        str(item.get("sub_project_id") or ""),
        str(item.get("sub_project_name") or ""),
    ]
    return _sha256_text("|".join(parts))


def _image_fingerprint(item: Dict[str, Any]) -> str:
    """이미지의 안정 식별자. image_hash 가 아직 없어도 동작하도록 fallback 체인."""
    sr = item.get("storage_ref") or {}
    return (
        item.get("content_hash")
        or sr.get("s3_key")
        or sr.get("stored_name")
        or str(item.get("image_id") or "unknown")
    )


def attach_analysis_metadata(
    item: Dict[str, Any],
    *,
    project_ctx_hash: Optional[str],
    model_key: Optional[str] = None,
    model_version: Optional[str] = None,
) -> None:
    """manifest item 에 analysis_reuse_policy / analysis_identity / reanalysis_triggers 부여(in-place).

    semantic_cache_key_preview 는 **실제 캐시용이 아니라 미래 구조 확인용**이며,
    원문 텍스트가 아니라 hash 조합으로만 구성한다.
    """
    fingerprint = _image_fingerprint(item)
    image_hash = item.get("content_hash")
    nearby_hash = _sha256_text(item.get("nearby_text"))
    task_hash = _task_context_hash(item)

    # semantic_cache_key_preview = 식별 요소 조합의 sha256 (원문 미포함)
    key_components = [
        fingerprint,
        image_hash or "no_hash",
        model_key or "no_model",
        model_version or "no_model_version",
        FUTURE_IMAGE_ANALYSIS_PROMPT_VERSION,
        PROJECT_AI_CONTEXT_SCHEMA_VERSION,
        IMAGE_MANIFEST_VERSION,
        IMAGE_READINESS_VERSION,
        nearby_hash or "no_nearby",
        task_hash or "no_task_ctx",
        project_ctx_hash or "no_project_ctx",
    ]
    cache_key_preview = hashlib.sha256("|".join(key_components).encode("utf-8")).hexdigest()

    item["analysis_reuse_policy"] = build_analysis_reuse_policy()
    item["analysis_identity"] = {
        "image_fingerprint": fingerprint,
        "image_hash": image_hash,
        "context_schema_version": PROJECT_AI_CONTEXT_SCHEMA_VERSION,
        "image_manifest_version": IMAGE_MANIFEST_VERSION,
        "readiness_version": IMAGE_READINESS_VERSION,
        "nearby_text_hash": nearby_hash,
        "task_context_hash": task_hash,
        "project_context_hash": project_ctx_hash,
        "analysis_mode": ANALYSIS_MODE,
        "prompt_version": FUTURE_IMAGE_ANALYSIS_PROMPT_VERSION,
        # 현재 실제 vision 모델 호출이 없으므로 null.
        "model_key": model_key,
        "model_version": model_version,
        "semantic_cache_key_preview": cache_key_preview,
    }
    item["reanalysis_triggers"] = list(REANALYSIS_TRIGGERS)


def summarize_analysis_policy(manifest: List[Dict[str, Any]]) -> Dict[str, Any]:
    """preview 응답용 정책 요약."""
    metadata_cacheable = 0
    semantic_cacheable = 0
    requires_reanalysis = 0
    has_cache_key = 0
    for it in manifest:
        pol = it.get("analysis_reuse_policy") or {}
        ident = it.get("analysis_identity") or {}
        if pol.get("metadata_cacheable"):
            metadata_cacheable += 1
        if pol.get("semantic_analysis_cacheable"):
            semantic_cacheable += 1
        if pol.get("requires_context_aware_reanalysis"):
            requires_reanalysis += 1
        if ident.get("semantic_cache_key_preview"):
            has_cache_key += 1

    return {
        "metadata_cacheable_images": metadata_cacheable,
        "semantic_cacheable_by_default": semantic_cacheable,
        "requires_context_aware_reanalysis": requires_reanalysis,
        "has_cache_key_preview": has_cache_key,
        "policy": ANALYSIS_POLICY_STATEMENT,
    }
