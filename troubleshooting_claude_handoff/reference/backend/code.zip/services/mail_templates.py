"""
멘션 메일 템플릿 빌더.

주의(보안/민감정보):
* comment/work note 본문 전체를 넣지 않는다. HTML 제거 후 preview 만(기본 280자) 넣는다.
* 이미지/첨부는 메일에 직접 첨부하지 않는다. 사이트 링크로만 확인하게 한다.
* URL 에는 mentionId(ref) 만 넣는다. 본문/description 을 URL 에 싣지 않는다.
"""

from __future__ import annotations

import html
import os
import re
from typing import Optional, Tuple

_PREVIEW_MAX = 280
MAIL_SUBJECT = "[PLAN-AI] 작업에서 나를 언급했습니다"


def frontend_base_url() -> str:
    """FRONTEND_BASE_URL 우선, 없으면 SSO 프론트 redirect(=FRONTEND_REDIRECT_URI) fallback."""
    return (
        os.getenv("FRONTEND_BASE_URL")
        or os.getenv("FRONTEND_REDIRECT_URI")
        or os.getenv("REDIRECT_URI_LOCAL")
        or "http://localhost:5173"
    ).rstrip("/")


def build_mention_url(mention_ref: str) -> str:
    """메일 딥링크. 프론트 @나를 언급 페이지가 ?mentionId= 를 받아 해당 카드로 스크롤/highlight."""
    return f"{frontend_base_url()}/mentions?mentionId={mention_ref}"


def build_voc_url(voc_id: int) -> str:
    """VOC 답변 메일 딥링크. 프론트 VOC 목록(/voc)이 ?vocId= 를 받아 해당 VOC 카드로
    스크롤/highlight 하고 댓글(답변) 영역을 펼친다. 상세 전용 라우트가 없어 목록 딥링크로 처리한다."""
    return f"{frontend_base_url()}/voc?vocId={int(voc_id)}"


def make_preview(content: str, limit: int = _PREVIEW_MAX) -> str:
    plain = re.sub(r"<[^>]+>", " ", content or "")
    plain = re.sub(r"\s+", " ", plain).strip()
    if len(plain) > limit:
        plain = plain[:limit].rstrip() + "…"
    return plain


def build_mention_email(
    *,
    actor_name: str,
    project_name: str,
    task_title: str,
    location_label: str,          # "작업노트" | "Comments"
    created_at: str,              # 표시용 문자열
    content_preview: str,         # 이미 preview 처리된(또는 원문) 내용 — 여기서 다시 truncate
    mention_url: str,
) -> Tuple[str, str, str]:
    """(subject, text_body, html_body) 반환."""
    preview = make_preview(content_preview)

    text_body = (
        "안녕하세요.\n\n"
        f"PLAN-AI에서 {actor_name}님이 회원님을 언급했습니다.\n\n"
        f"Project: {project_name}\n"
        f"Task: {task_title}\n"
        f"위치: {location_label}\n"
        f"작성자: {actor_name}\n"
        f"작성 시간: {created_at}\n\n"
        "내용:\n"
        f"{preview}\n\n"
        "아래 링크를 클릭하면 PLAN-AI의 @나를 언급 페이지에서 해당 항목을 확인할 수 있습니다.\n\n"
        f"바로가기:\n{mention_url}\n"
    )

    e = html.escape
    html_body = f"""\
<div style="font-family:Apple SD Gothic Neo,Malgun Gothic,Arial,sans-serif;font-size:14px;color:#1A1D29;line-height:1.6">
  <p>안녕하세요.</p>
  <p>PLAN-AI에서 <b>{e(actor_name)}</b>님이 회원님을 언급했습니다.</p>
  <table style="border-collapse:collapse;margin:12px 0">
    <tr><td style="padding:2px 12px 2px 0;color:#6B7280">Project</td><td>{e(project_name)}</td></tr>
    <tr><td style="padding:2px 12px 2px 0;color:#6B7280">Task</td><td>{e(task_title)}</td></tr>
    <tr><td style="padding:2px 12px 2px 0;color:#6B7280">위치</td><td>{e(location_label)}</td></tr>
    <tr><td style="padding:2px 12px 2px 0;color:#6B7280">작성자</td><td>{e(actor_name)}</td></tr>
    <tr><td style="padding:2px 12px 2px 0;color:#6B7280">작성 시간</td><td>{e(created_at)}</td></tr>
  </table>
  <div style="padding:12px 14px;background:#F3F4F6;border-radius:8px;white-space:pre-wrap">{e(preview)}</div>
  <p style="margin-top:20px">
    <a href="{e(mention_url)}" target="_blank"
       style="display:inline-block;padding:10px 18px;background:#2955FF;color:#fff;
              text-decoration:none;border-radius:8px;font-weight:600">언급 내용 확인하기</a>
  </p>
  <p style="color:#6B7280;font-size:12px;margin-top:16px">
    버튼이 열리지 않으면 아래 주소를 복사해 브라우저에 붙여넣어 주세요.<br/>
    <a href="{e(mention_url)}" target="_blank" style="color:#2955FF;word-break:break-all">{e(mention_url)}</a>
  </p>
  <p style="color:#9CA3AF;font-size:12px">이 메일은 PLAN-AI 멘션 알림 설정에 따라 발송되었습니다. 설정에서 알림을 끌 수 있습니다.</p>
</div>"""

    return MAIL_SUBJECT, text_body, html_body


VOC_REPLY_SUBJECT_PREFIX = "[PLAN-AI] VOC 답변 알림"


def build_voc_reply_email(
    *,
    voc_title: str,
    reply_content: str,     # 원문(HTML 가능) — 여기서 preview 처리
    voc_url: str,
) -> Tuple[str, str, str]:
    """(subject, text_body, html_body) 반환. VOC 답변 등록 알림 메일.

    멘션 메일과 동일 정책: 본문 전체 대신 preview 만, 링크로만 확인, 첨부 없음.
    """
    preview = make_preview(reply_content)
    safe_title = voc_title or "VOC"
    subject = f"{VOC_REPLY_SUBJECT_PREFIX}: {safe_title}"

    text_body = (
        "안녕하세요.\n\n"
        "등록하신 VOC(개선 요청)에 답변이 등록되었습니다.\n\n"
        f"VOC 제목: {safe_title}\n\n"
        "답변 내용:\n"
        f"{preview}\n\n"
        "아래 링크를 클릭하면 PLAN-AI에서 답변을 확인할 수 있습니다.\n\n"
        f"바로가기:\n{voc_url}\n"
    )

    e = html.escape
    html_body = f"""\
<div style="font-family:Apple SD Gothic Neo,Malgun Gothic,Arial,sans-serif;font-size:14px;color:#1A1D29;line-height:1.6">
  <p>안녕하세요.</p>
  <p>등록하신 <b>VOC(개선 요청)</b>에 답변이 등록되었습니다.</p>
  <table style="border-collapse:collapse;margin:12px 0">
    <tr><td style="padding:2px 12px 2px 0;color:#6B7280">VOC 제목</td><td>{e(safe_title)}</td></tr>
  </table>
  <div style="color:#6B7280;margin-bottom:6px">답변 내용</div>
  <div style="padding:12px 14px;background:#F3F4F6;border-radius:8px;white-space:pre-wrap">{e(preview)}</div>
  <p style="margin-top:20px">
    <a href="{e(voc_url)}" target="_blank"
       style="display:inline-block;padding:10px 18px;background:#2955FF;color:#fff;
              text-decoration:none;border-radius:8px;font-weight:600">VOC 답변 확인하기</a>
  </p>
  <p style="color:#6B7280;font-size:12px;margin-top:16px">
    버튼이 열리지 않으면 아래 주소를 복사해 브라우저에 붙여넣어 주세요.<br/>
    <a href="{e(voc_url)}" target="_blank" style="color:#2955FF;word-break:break-all">{e(voc_url)}</a>
  </p>
  <p style="color:#9CA3AF;font-size:12px">이 메일은 관리자가 답변 등록 시 알림 발송을 선택한 경우에만 발송됩니다.</p>
</div>"""

    return subject, text_body, html_body


VOC_ADMIN_MEMO_SUBJECT_PREFIX = "[PLAN-AI] VOC 관리자 메모 알림"


def build_voc_admin_memo_email(
    *,
    voc_title: str,
    memo_content: str,      # 원문(HTML 가능) — 여기서 preview 처리
    voc_url: str,
) -> Tuple[str, str, str]:
    """(subject, text_body, html_body) 반환. VOC 관리자 메모 알림 메일.

    관리자가 메모 저장 시 "메일 알림 보내기"를 선택한 경우에만 발송된다.
    멘션 메일과 동일 정책: 본문 전체 대신 preview 만, 링크로만 확인, 첨부 없음.
    """
    preview = make_preview(memo_content)
    safe_title = voc_title or "VOC"
    subject = f"{VOC_ADMIN_MEMO_SUBJECT_PREFIX}: {safe_title}"

    text_body = (
        "안녕하세요.\n\n"
        "등록하신 VOC(개선 요청)에 관리자 메모가 등록되었습니다.\n\n"
        f"VOC 제목: {safe_title}\n\n"
        "관리자 메모:\n"
        f"{preview}\n\n"
        "아래 링크를 클릭하면 PLAN-AI에서 내용을 확인할 수 있습니다.\n\n"
        f"바로가기:\n{voc_url}\n"
    )

    e = html.escape
    html_body = f"""\
<div style="font-family:Apple SD Gothic Neo,Malgun Gothic,Arial,sans-serif;font-size:14px;color:#1A1D29;line-height:1.6">
  <p>안녕하세요.</p>
  <p>등록하신 <b>VOC(개선 요청)</b>에 관리자 메모가 등록되었습니다.</p>
  <table style="border-collapse:collapse;margin:12px 0">
    <tr><td style="padding:2px 12px 2px 0;color:#6B7280">VOC 제목</td><td>{e(safe_title)}</td></tr>
  </table>
  <div style="color:#6B7280;margin-bottom:6px">관리자 메모</div>
  <div style="padding:12px 14px;background:#F3F4F6;border-radius:8px;white-space:pre-wrap">{e(preview)}</div>
  <p style="margin-top:20px">
    <a href="{e(voc_url)}" target="_blank"
       style="display:inline-block;padding:10px 18px;background:#2955FF;color:#fff;
              text-decoration:none;border-radius:8px;font-weight:600">VOC 확인하기</a>
  </p>
  <p style="color:#6B7280;font-size:12px;margin-top:16px">
    버튼이 열리지 않으면 아래 주소를 복사해 브라우저에 붙여넣어 주세요.<br/>
    <a href="{e(voc_url)}" target="_blank" style="color:#2955FF;word-break:break-all">{e(voc_url)}</a>
  </p>
  <p style="color:#9CA3AF;font-size:12px">이 메일은 관리자가 메모 저장 시 알림 발송을 선택한 경우에만 발송됩니다.</p>
</div>"""

    return subject, text_body, html_body
