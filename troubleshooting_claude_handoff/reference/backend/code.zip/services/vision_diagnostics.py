"""Vision Report / DSLLM 실패의 "실행 가능한 진단" 구성 (순수 로직, DB 접근 없음).

기존 관리자 시스템 로그(SystemEventLog)에 저장할 진단 dict 를 만든다. 어느 단계에서
(failure_stage) 어떤 유형의 오류가(error_type) 났는지에 따라 운영자가 바로 대응할 수 있는
요약/추정 원인/권장 대응/재시도 안전 여부를 결정론적으로 계산한다.

설계 원칙
- 이 모듈은 **민감정보를 절대 만들지 않는다**. details 는 화이트리스트 키(크기/치수/ID 등)만
  통과시키고, base64/프롬프트/헤더/키 같은 값은 애초에 담기지 않는다(호출부 책임 + 여기서 재차 필터).
- LLM 호출/네트워크/DB 접근 없음. 입력 → 진단 dict 매핑만 한다.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

# =========================================================
# §3 failure_stage 표준값 + 표시명
# =========================================================
FAILURE_STAGE_LABELS: Dict[str, str] = {
    "ai_settings_vision_test": "AI 설정 vision 입력 테스트",
    "cache_lookup": "이미지 캐시 조회",
    "context_link_regeneration": "ContextLink 텍스트 재생성",
    "stage1_image_prepare": "이미지 전처리",
    "stage1_vision": "Stage 1 이미지 분석",
    "stage1_response_parse": "Stage 1 응답 파싱",
    "stage2_synthesis": "Stage 2 최종 보고서 합성",
    "stage2_response_parse": "최종 보고서 응답 파싱",
    "context_link_save": "ContextLink 저장",
    "report_reconcile": "보고서 근거 정합",
    "frontend_timeout": "프론트엔드 시간 초과",
    "unknown": "알 수 없는 단계",
}
DEFAULT_FAILURE_STAGE = "unknown"


def normalize_failure_stage(value: Optional[str]) -> str:
    v = (value or "").strip()
    return v if v in FAILURE_STAGE_LABELS else DEFAULT_FAILURE_STAGE


def failure_stage_label(value: Optional[str]) -> str:
    return FAILURE_STAGE_LABELS.get(normalize_failure_stage(value), FAILURE_STAGE_LABELS[DEFAULT_FAILURE_STAGE])


# =========================================================
# §4 error_type 표준값
# =========================================================
ERROR_TYPES = {
    "connect_timeout", "read_timeout", "write_timeout", "pool_timeout",
    "connection_error", "dns_or_proxy_error", "payload_too_large",
    "unsupported_payload", "invalid_request", "authentication_error",
    "permission_error", "model_not_found", "model_unavailable",
    "gateway_4xx", "gateway_5xx", "malformed_response", "json_parse_error",
    "schema_validation_error", "image_decode_error", "image_preprocess_error",
    "context_regeneration_failed", "user_cancelled", "frontend_timeout",
    "unknown_error",
}
DEFAULT_ERROR_TYPE = "unknown_error"

# dsllm_adapter._classify_vision_error 가 쓰는 값 → 표준 error_type 별칭.
_ERROR_TYPE_ALIASES = {
    "gateway_http_4xx": "gateway_4xx",
    "gateway_http_5xx": "gateway_5xx",
    "unknown_transport_error": "connection_error",
    "json_parse": "json_parse_error",
    "schema_validation": "schema_validation_error",
}


def normalize_error_type(value: Optional[str]) -> str:
    v = (value or "").strip()
    v = _ERROR_TYPE_ALIASES.get(v, v)
    return v if v in ERROR_TYPES else DEFAULT_ERROR_TYPE


# =========================================================
# §9/§2 details 화이트리스트 — 민감정보 저장 방지
# =========================================================
ALLOWED_DETAIL_KEYS = (
    "project_id", "canonical_image_id", "image_count", "mime",
    "width", "height", "original_bytes", "processed_bytes",
    "base64_chars", "payload_bytes", "max_tokens", "timeout_seconds",
    "elapsed_ms", "batch_index", "image_transport", "batch_size",
)


def sanitize_details(details: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """허용된 (비민감) 지표 키만 통과. 그 외 키(프롬프트/키/base64 등)는 버린다."""
    out: Dict[str, Any] = {}
    for k in ALLOWED_DETAIL_KEYS:
        if details and k in details and details[k] is not None:
            out[k] = details[k]
    return out


# =========================================================
# §5 상태 및 오류별 자동 진단 (error_type → 기본 진단)
# =========================================================
# 각 항목: (reason_short, summary, likely_cause, recommended_action, retry_safe)
_BASE_DIAGNOSIS: Dict[str, Dict[str, Any]] = {
    "payload_too_large": {
        "reason_short": "이미지 요청 크기 초과",
        "summary": "DSLLM Gateway가 이미지 요청 크기를 허용하지 않았습니다.",
        "likely_cause": "전처리 이미지 또는 전체 JSON payload가 Gateway 제한을 초과했습니다.",
        "recommended_action": "processed_bytes와 payload_bytes를 확인하고 이미지 해상도 또는 파일 크기를 줄이세요.",
        "retry_safe": False,
    },
    "unsupported_payload": {
        "reason_short": "DSLLM 요청 형식 오류",
        "summary": "DSLLM Gateway가 이미지 요청 형식을 처리하지 못했습니다.",
        "likely_cause": "이미지 content schema/MIME/data URL 형식 또는 모델 입력 규칙이 맞지 않을 수 있습니다.",
        "recommended_action": "이미지 content schema, MIME, data URL 길이와 모델 입력 규칙을 확인하세요.",
        "retry_safe": False,
    },
    "invalid_request": {
        "reason_short": "DSLLM 요청 형식 오류",
        "summary": "DSLLM 요청 형식이 올바르지 않아 거부됐습니다.",
        "likely_cause": "요청 schema/파라미터/토큰 조합이 모델 규칙과 맞지 않을 수 있습니다.",
        "recommended_action": "이미지 content schema, MIME, data URL 길이와 max_tokens 조합을 확인하세요.",
        "retry_safe": False,
    },
    "authentication_error": {
        "reason_short": "DSLLM 인증 실패",
        "summary": "DSLLM Gateway 인증에 실패했습니다.",
        "likely_cause": "API key 또는 Authorization 헤더가 올바르지 않을 수 있습니다.",
        "recommended_action": "API key와 Authorization 헤더를 확인하세요.",
        "retry_safe": False,
    },
    "permission_error": {
        "reason_short": "DSLLM 모델 사용 권한 없음",
        "summary": "현재 계정/키로 해당 DSLLM 모델을 사용할 권한이 없습니다.",
        "likely_cause": "모델 접근 권한 또는 사내 API 허용 정책 문제일 수 있습니다.",
        "recommended_action": "모델 접근 권한과 사내 API 허용 정책을 확인하세요.",
        "retry_safe": False,
    },
    "model_not_found": {
        "reason_short": "DSLLM 모델/Endpoint 미확인",
        "summary": "DSLLM 모델 또는 Endpoint를 찾지 못했습니다.",
        "likely_cause": "BASE_URL 또는 모델명이 올바르지 않을 수 있습니다.",
        "recommended_action": "BASE_URL과 모델명을 확인하세요.",
        "retry_safe": False,
    },
    "model_unavailable": {
        "reason_short": "DSLLM 모델 사용 불가",
        "summary": "요청한 DSLLM 모델을 현재 사용할 수 없습니다.",
        "likely_cause": "모델 서버가 내려갔거나 일시적으로 사용 불가 상태일 수 있습니다.",
        "recommended_action": "잠시 후 재시도하고 모델 서버 상태를 확인하세요.",
        "retry_safe": True,
    },
    "gateway_4xx": {
        "reason_short": "DSLLM 요청 거부",
        "summary": "DSLLM Gateway가 요청을 거부했습니다(4xx).",
        "likely_cause": "요청 형식/권한/모델명 등 클라이언트 측 요인일 수 있습니다.",
        "recommended_action": "요청 형식과 모델/권한 설정을 확인하세요.",
        "retry_safe": False,
    },
    "gateway_5xx": {
        "reason_short": "DSLLM Gateway/모델 서버 처리 실패",
        "summary": "DSLLM Gateway 또는 모델 서버가 요청을 처리하지 못했습니다.",
        "likely_cause": "Gateway 또는 모델 서버의 일시적 장애일 수 있습니다.",
        "recommended_action": "잠시 후 재시도하고 Gateway와 모델 서버 상태를 확인하세요.",
        "retry_safe": True,
    },
    "connect_timeout": {
        "reason_short": "DSLLM Gateway 연결 시간 초과",
        "summary": "DSLLM Gateway 연결 시간이 초과됐습니다.",
        "likely_cause": "네트워크, 프록시, DNS, 방화벽 또는 Gateway 주소 문제일 수 있습니다.",
        "recommended_action": "BASE_URL, proxy/no_proxy, DNS, 방화벽 설정을 확인하세요.",
        "retry_safe": True,
    },
    "read_timeout": {
        "reason_short": "모델 응답 시간 초과",
        "summary": "DSLLM 모델이 제한 시간 내 응답하지 못했습니다.",
        "likely_cause": "이미지 크기 또는 모델 처리 시간이 현재 read timeout을 초과했을 가능성이 높습니다.",
        "recommended_action": "processed_bytes와 해상도를 확인하고 이미지 크기 축소 또는 timeout 조정을 검토하세요.",
        "retry_safe": True,
    },
    "write_timeout": {
        "reason_short": "요청 전송 시간 초과",
        "summary": "이미지 요청 전송이 제한 시간 내 완료되지 못했습니다.",
        "likely_cause": "payload 크기 또는 업링크 네트워크 상태 문제일 수 있습니다.",
        "recommended_action": "payload_bytes와 네트워크 상태를 확인하세요.",
        "retry_safe": True,
    },
    "pool_timeout": {
        "reason_short": "연결 풀 대기 시간 초과",
        "summary": "DSLLM 연결 풀 확보 대기 시간이 초과됐습니다.",
        "likely_cause": "동시 요청이 많거나 연결이 반환되지 않았을 수 있습니다.",
        "recommended_action": "동시 요청 수와 연결 풀 설정을 확인하세요.",
        "retry_safe": True,
    },
    "connection_error": {
        "reason_short": "DSLLM Gateway 연결 실패",
        "summary": "DSLLM Gateway에 연결하지 못했습니다.",
        "likely_cause": "네트워크, 프록시, 방화벽 또는 Gateway 주소 문제일 수 있습니다.",
        "recommended_action": "BASE_URL, proxy/no_proxy, DNS, 방화벽 설정을 확인하세요.",
        "retry_safe": True,
    },
    "dns_or_proxy_error": {
        "reason_short": "DNS/프록시 오류",
        "summary": "DSLLM Gateway 주소 확인 또는 프록시 처리에 실패했습니다.",
        "likely_cause": "DNS 해석 실패 또는 프록시 설정 문제일 수 있습니다.",
        "recommended_action": "DNS, proxy/no_proxy, 사내 네트워크 정책을 확인하세요.",
        "retry_safe": True,
    },
    "malformed_response": {
        "reason_short": "DSLLM 응답 구조 처리 실패",
        "summary": "DSLLM 응답을 정상적으로 해석하지 못했습니다.",
        "likely_cause": "응답 형식이 예상과 다르거나 손상됐을 수 있습니다.",
        "recommended_action": "응답 형식과 parser validation 결과를 확인하세요.",
        "retry_safe": True,
    },
    "json_parse_error": {
        "reason_short": "응답 JSON 파싱 실패",
        "summary": "모델 응답을 JSON으로 파싱하지 못했습니다.",
        "likely_cause": "출력이 잘렸거나 JSON 형식이 아닐 수 있습니다.",
        "recommended_action": "출력 잘림(max_tokens)과 응답 형식을 확인하세요.",
        "retry_safe": True,
    },
    "schema_validation_error": {
        "reason_short": "응답 schema 검증 실패",
        "summary": "모델 응답이 기대한 schema를 만족하지 못했습니다.",
        "likely_cause": "모델이 요구한 필드/구조를 지키지 않았을 수 있습니다.",
        "recommended_action": "응답 형식과 parser validation 결과를 확인하세요.",
        "retry_safe": True,
    },
    "image_decode_error": {
        "reason_short": "이미지 디코딩 실패",
        "summary": "이미지를 디코딩하지 못했습니다.",
        "likely_cause": "손상된 이미지 또는 지원하지 않는 형식일 수 있습니다.",
        "recommended_action": "원본 이미지 형식과 무결성을 확인하세요.",
        "retry_safe": False,
    },
    "image_preprocess_error": {
        "reason_short": "이미지 전처리 실패",
        "summary": "AI 전송용 이미지 전처리에 실패했습니다.",
        "likely_cause": "이미지 형식/크기 또는 전처리 라이브러리 문제일 수 있습니다.",
        "recommended_action": "원본 이미지 형식/크기와 전처리 설정을 확인하세요.",
        "retry_safe": False,
    },
    "context_regeneration_failed": {
        "reason_short": "재생성 실패",
        "summary": "ContextLink 텍스트 재생성에 실패했습니다.",
        "likely_cause": "Batch 크기 또는 입력 문맥 길이, Text 모델 응답 문제일 수 있습니다.",
        "recommended_action": "Batch 크기와 입력 문맥 길이, Text 모델 timeout을 확인하세요.",
        "retry_safe": True,
    },
    "user_cancelled": {
        "reason_short": "사용자 취소",
        "summary": "사용자가 요청을 취소했습니다.",
        "likely_cause": "사용자가 진행 중 요청을 중단했습니다.",
        "recommended_action": "필요하면 다시 실행하세요.",
        "retry_safe": True,
    },
    "frontend_timeout": {
        "reason_short": "프론트엔드 시간 초과",
        "summary": "프론트엔드에서 응답 대기 시간이 초과됐습니다.",
        "likely_cause": "서버 처리 지연 또는 네트워크 문제일 수 있습니다.",
        "recommended_action": "서버 처리 시간(elapsed_ms)과 네트워크 상태를 확인하세요.",
        "retry_safe": True,
    },
    "unknown_error": {
        "reason_short": "알 수 없는 오류",
        "summary": "분류되지 않은 오류가 발생했습니다.",
        "likely_cause": "원인이 자동 분류되지 않았습니다.",
        "recommended_action": "원본 상세 JSON과 서버 로그를 확인하세요.",
        "retry_safe": True,
    },
}

# read_timeout 은 단계별로 추정 원인/권장 대응을 달리한다(§5 stage1/stage2/regen).
_READ_TIMEOUT_BY_STAGE: Dict[str, Dict[str, str]] = {
    "stage2_synthesis": {
        "likely_cause": "입력 문맥, 반복 필드 또는 출력 token 요청이 클 수 있습니다.",
        "recommended_action": "Stage 2 input/output token, max_tokens와 반복 데이터를 확인하세요.",
    },
    "context_link_regeneration": {
        "likely_cause": "Batch 크기 또는 입력 문맥 길이가 클 수 있습니다.",
        "recommended_action": "Batch 크기와 입력 문맥 길이, Text 모델 timeout을 확인하세요.",
    },
}


def build_diagnosis(
    failure_stage: Optional[str],
    error_type: Optional[str],
    *,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    http_status: Optional[int] = None,
    details: Optional[Dict[str, Any]] = None,
    retry_safe: Optional[bool] = None,
) -> Dict[str, Any]:
    """failure_stage + error_type → 저장/표시용 진단 dict.

    Returns dict: failure_stage/failure_stage_label/error_type/provider/model/http_status/
    message/summary/likely_cause/recommended_action/retry_safe/details(화이트리스트).
    """
    stage = normalize_failure_stage(failure_stage)
    etype = normalize_error_type(error_type)
    base = dict(_BASE_DIAGNOSIS.get(etype, _BASE_DIAGNOSIS[DEFAULT_ERROR_TYPE]))

    # read_timeout 단계별 override.
    if etype == "read_timeout" and stage in _READ_TIMEOUT_BY_STAGE:
        base.update(_READ_TIMEOUT_BY_STAGE[stage])

    stage_label = failure_stage_label(stage)
    reason_short = base["reason_short"]
    # 파이프라인 단계(unknown 제외)면 "<단계> 실패 — <사유>" 로, 아니면 사유만.
    if stage != "unknown":
        message = f"{stage_label} 실패 — {reason_short}"
    else:
        message = reason_short

    return {
        "failure_stage": stage,
        "failure_stage_label": stage_label,
        "error_type": etype,
        "provider": provider,
        "model": model,
        "http_status": http_status,
        "message": message,
        "summary": base["summary"],
        "likely_cause": base["likely_cause"],
        "recommended_action": base["recommended_action"],
        "retry_safe": base["retry_safe"] if retry_safe is None else bool(retry_safe),
        "details": sanitize_details(details),
    }


def build_copy_text(diagnosis: Dict[str, Any], *, request_id: str = "", created_at: str = "") -> str:
    """§9 진단 정보 복사용 텍스트(비민감 필드만). base64/키/프롬프트는 애초에 포함되지 않는다."""
    d = diagnosis.get("details") or {}
    dims = None
    if d.get("width") is not None and d.get("height") is not None:
        dims = f"{d.get('width')}x{d.get('height')}"
    lines = [
        "Vision Report 진단",
        f"time={created_at}" if created_at else None,
        f"request_id={request_id}" if request_id else None,
        f"project_id={d.get('project_id')}" if d.get("project_id") is not None else None,
        f"stage={diagnosis.get('failure_stage')}",
        f"provider={diagnosis.get('provider')}",
        f"model={diagnosis.get('model')}",
        f"error_type={diagnosis.get('error_type')}",
        f"http_status={diagnosis.get('http_status') if diagnosis.get('http_status') is not None else 'none'}",
        f"image_count={d.get('image_count')}" if d.get("image_count") is not None else None,
        f"mime={d.get('mime')}" if d.get("mime") else None,
        f"dimensions={dims}" if dims else None,
        f"processed_bytes={d.get('processed_bytes')}" if d.get("processed_bytes") is not None else None,
        f"payload_bytes={d.get('payload_bytes')}" if d.get("payload_bytes") is not None else None,
        f"timeout_seconds={d.get('timeout_seconds')}" if d.get("timeout_seconds") is not None else None,
        f"elapsed_ms={d.get('elapsed_ms')}" if d.get("elapsed_ms") is not None else None,
        f"summary={diagnosis.get('summary')}",
        f"recommended_action={diagnosis.get('recommended_action')}",
    ]
    return "\n".join(l for l in lines if l)
