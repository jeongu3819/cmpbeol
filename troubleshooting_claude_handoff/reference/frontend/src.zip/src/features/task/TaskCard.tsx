import React from 'react';
import { Paper, Typography, Box, Chip, Avatar, AvatarGroup, Tooltip, IconButton } from '@mui/material';
import { Task } from '../../types';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import FlagIcon from '@mui/icons-material/Flag';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import SubdirectoryArrowRightIcon from '@mui/icons-material/SubdirectoryArrowRight';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { useQuery } from '@tanstack/react-query';
import { api, User } from '../../api/client';
import { descriptionToPreviewText } from '../../utils/richImage';
import { planAiColors, planAiShadows, planAiRadius } from '../../theme/tokens';

interface TaskCardProps {
    task: Task;
    onClick: () => void;
    style?: React.CSSProperties;
    compact?: boolean;
    // ── Task 상하 관계(Parent) 표시 (Board 전용, 미전달 시 기존과 동일) ──
    parentBadge?: boolean;          // 좌상단 "상위 작업" 칩 (이 카드가 하위 작업 = parent 보유)
    childCount?: number;            // >0 이면 우상단 "하위 N개" 칩 + 카드 강조
    collapsed?: boolean;            // 하위 접힘 여부 (▲/▼ 방향)
    onToggleChildren?: () => void;  // "하위 N개" 칩 클릭 (카드 클릭과 분리)
    // ── 다단계 Board DnD 계층 표현 ──
    depth?: number;                 // 트리 깊이 (들여쓰기용 — 렌더는 wrapper 담당, 여기선 표기 보조)
    isLinkTarget?: boolean;         // Drag 중 유효한 "하위 작업으로 연결" 대상 강조
    linkInvalid?: boolean;          // Drag 중 유효하지 않은 대상(같은 단계 아님/순환) 표시
    onMore?: (e: React.MouseEvent<HTMLElement>) => void; // "더보기(...)" 메뉴 (상위 작업 연결 해제 등)
}

const statusColors: Record<string, string> = {
    todo: planAiColors.text.tertiary,
    in_progress: planAiColors.brand.primary,
    done: planAiColors.status.success,
    hold: planAiColors.status.warning,
};

const priorityConfig: Record<string, { color: string; label: string }> = {
    low: { color: planAiColors.text.tertiary, label: 'Low' },
    medium: { color: planAiColors.brand.primary, label: 'Medium' },
    high: { color: planAiColors.status.danger, label: 'High' },
};

/** Remove first character (surname) and return the rest. If 1 char, return as-is. */
const shortName = (name: string): string => {
    if (!name) return '';
    return name.length <= 1 ? name : name.slice(1);
};

const MAX_DISPLAY = 3;

const TaskCard: React.FC<TaskCardProps> = ({
    task,
    onClick,
    style,
    compact = false,
    parentBadge = false,
    childCount = 0,
    collapsed = false,
    onToggleChildren,
    isLinkTarget = false,
    linkInvalid = false,
    onMore,
}) => {
    const priority = task.priority ? priorityConfig[task.priority] : null;
    const hasChildren = childCount > 0;

    const { data: users = [] } = useQuery<User[]>({
        queryKey: ['users'],
        queryFn: () => api.getUsers(),
    });

    // Resolve assignee names
    const assignees = (task.assignee_ids || [])
        .map(id => users.find(u => u.id === id))
        .filter((u): u is User => !!u);

    const fullTooltip = assignees.map(u => u.username).join(', ');

    return (
        <Paper
            elevation={0}
            sx={{
                p: compact ? 1.2 : 2,
                mb: hasChildren ? 0.5 : 1,
                cursor: 'pointer',
                borderRadius: `${planAiRadius.md}px`,
                border: isLinkTarget
                    ? `2px solid ${planAiColors.status.success}`
                    : linkInvalid
                    ? `2px dashed ${planAiColors.status.danger}`
                    : hasChildren
                    ? '1px solid rgba(37, 99, 235, 0.35)'
                    : `1px solid ${planAiColors.border.soft}`,
                bgcolor: isLinkTarget ? `${planAiColors.status.success}0F` : 'rgba(255,255,255,0.92)',
                backdropFilter: 'blur(4px)',
                boxShadow: isLinkTarget
                    ? `0 0 0 3px ${planAiColors.status.success}33`
                    : hasChildren ? '0 10px 26px rgba(37, 99, 235, 0.10)' : planAiShadows.sm,
                opacity: linkInvalid ? 0.6 : 1,
                transition: 'transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease',
                position: 'relative',
                overflow: 'hidden',
                '&:hover': {
                    borderColor: planAiColors.brand.primary,
                    boxShadow: '0 4px 14px rgba(37, 99, 235, 0.14)',
                    transform: 'translateY(-1px)',
                },
                '@media (prefers-reduced-motion: reduce)': {
                    transition: 'none',
                    '&:hover': { transform: 'none', boxShadow: planAiShadows.md },
                },
                '&::before': {
                    content: '""',
                    position: 'absolute',
                    left: 0,
                    top: 0,
                    bottom: 0,
                    width: 3,
                    bgcolor: statusColors[task.status] || planAiColors.text.tertiary,
                    borderRadius: '3px 0 0 3px',
                },
                ...style,
            }}
            onClick={onClick}
        >
            {/* Drag 중 유효한 연결 대상 오버레이 */}
            {isLinkTarget && (
                <Box
                    sx={{
                        position: 'absolute', inset: 0, zIndex: 3, pointerEvents: 'none',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        bgcolor: `${planAiColors.status.success}14`,
                    }}
                >
                    <Chip
                        icon={<SubdirectoryArrowRightIcon sx={{ fontSize: '0.85rem !important' }} />}
                        label="하위 작업으로 연결"
                        size="small"
                        sx={{
                            height: 24, fontSize: '0.68rem', fontWeight: 700,
                            bgcolor: planAiColors.status.success, color: '#fff',
                            boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
                            '& .MuiChip-icon': { color: '#fff' },
                        }}
                    />
                </Box>
            )}

            {/* 상하 관계 헤더: 좌 "상위 작업"(하위 작업 카드) · 우 "하위 N개 ▲/▼" + 더보기 */}
            {(parentBadge || hasChildren || onMore) && (
                <Box
                    sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: 1,
                        mb: 0.8,
                    }}
                >
                    {parentBadge ? (
                        <Chip
                            icon={<SubdirectoryArrowRightIcon sx={{ fontSize: '0.72rem !important' }} />}
                            label="상위 작업"
                            size="small"
                            sx={{
                                height: 20,
                                fontSize: '0.62rem',
                                fontWeight: 700,
                                bgcolor: 'rgba(37, 99, 235, 0.10)',
                                color: planAiColors.brand.primary,
                                border: '1px solid rgba(37, 99, 235, 0.24)',
                                '& .MuiChip-icon': { color: planAiColors.brand.primary },
                            }}
                        />
                    ) : (
                        <Box />
                    )}
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        {hasChildren && (
                            <Chip
                                label={`하위 ${childCount}개`}
                                size="small"
                                icon={
                                    collapsed ? (
                                        <KeyboardArrowDownIcon sx={{ fontSize: '0.9rem !important' }} />
                                    ) : (
                                        <KeyboardArrowUpIcon sx={{ fontSize: '0.9rem !important' }} />
                                    )
                                }
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onToggleChildren?.();
                                }}
                                sx={{
                                    height: 20,
                                    fontSize: '0.62rem',
                                    fontWeight: 700,
                                    cursor: onToggleChildren ? 'pointer' : 'default',
                                    flexDirection: 'row-reverse', // 아이콘을 오른쪽에
                                    bgcolor: planAiColors.brand.primarySoft,
                                    color: planAiColors.brand.primary,
                                    border: `1px solid ${planAiColors.brand.primaryBorder}`,
                                    '& .MuiChip-icon': { color: planAiColors.brand.primary, mr: 0, ml: '-2px' },
                                    '&:hover': onToggleChildren ? { bgcolor: planAiColors.brand.primaryBorder } : undefined,
                                }}
                            />
                        )}
                        {onMore && (
                            <IconButton
                                size="small"
                                onClick={(e) => { e.stopPropagation(); onMore(e); }}
                                sx={{ p: 0.2, color: planAiColors.text.muted, '&:hover': { color: planAiColors.text.secondary } }}
                                aria-label="더보기"
                            >
                                <MoreVertIcon sx={{ fontSize: '1rem' }} />
                            </IconButton>
                        )}
                    </Box>
                </Box>
            )}

            {/* Priority Flag */}
            {priority && task.priority !== 'medium' && (
                <Box sx={{ mb: 0.8 }}>
                    <Chip
                        icon={<FlagIcon sx={{ fontSize: '0.8rem !important' }} />}
                        label={priority.label}
                        size="small"
                        sx={{
                            height: 20,
                            fontSize: '0.65rem',
                            fontWeight: 600,
                            bgcolor: `${priority.color}15`,
                            color: priority.color,
                            border: `1px solid ${priority.color}30`,
                            '& .MuiChip-icon': { color: priority.color },
                        }}
                    />
                </Box>
            )}

            {/* Title */}
            <Typography
                variant="body2"
                sx={{
                    fontWeight: 600,
                    fontSize: compact ? '0.8rem' : '0.875rem',
                    lineHeight: 1.4,
                    color: planAiColors.text.primary,
                    mb: task.description || task.due_date ? 0.8 : 0,
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                }}
            >
                {task.title}
            </Typography>

            {/* Description preview */}
            {!compact && task.description && (
                <Typography
                    variant="caption"
                    sx={{
                        color: planAiColors.text.muted,
                        display: '-webkit-box',
                        WebkitLineClamp: 1,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                        mb: 1,
                        fontSize: '0.75rem',
                    }}
                >
                    {descriptionToPreviewText(task.description)}
                </Typography>
            )}

            {/* 단계 완료 선언 표시 (사용자가 현재 단계 완료를 선언한 경우) */}
            {task.current_stage_completed && (
                <Box sx={{ mt: 0.6 }}>
                    <Chip
                        icon={<FlagIcon sx={{ fontSize: '0.7rem !important' }} />}
                        label="단계 완료"
                        size="small"
                        sx={{
                            height: 18, fontSize: '0.62rem', fontWeight: 600,
                            bgcolor: `${planAiColors.status.success}14`, color: planAiColors.status.success,
                            '& .MuiChip-icon': { color: planAiColors.status.success, ml: '4px' },
                        }}
                    />
                </Box>
            )}

            {/* Footer: Due date + Attachment indicator + Assignees */}
            {(task.due_date || assignees.length > 0 || (task as any).attachment_count > 0) && (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: 0.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        {task.due_date && (
                            <Box sx={{
                                display: 'flex', alignItems: 'center', gap: 0.5,
                                color: planAiColors.text.muted, fontSize: '0.7rem',
                            }}>
                                <AccessTimeIcon sx={{ fontSize: '0.8rem' }} />
                                <span>{task.due_date}</span>
                            </Box>
                        )}
                        {(task as any).attachment_count > 0 && (
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.3, color: planAiColors.text.muted, fontSize: '0.7rem' }}>
                                <AttachFileIcon sx={{ fontSize: '0.8rem' }} />
                                <span>{(task as any).attachment_count}</span>
                            </Box>
                        )}
                    </Box>
                    {assignees.length > 0 && (
                        <Tooltip title={fullTooltip} arrow>
                            <AvatarGroup
                                max={MAX_DISPLAY + 1}
                                sx={{
                                    '& .MuiAvatar-root': {
                                        width: 22, height: 22, fontSize: '0.55rem', fontWeight: 600,
                                        border: '1.5px solid #fff',
                                    },
                                }}
                            >
                                {assignees.map(u => (
                                    <Avatar key={u.id} sx={{ bgcolor: u.avatar_color || planAiColors.brand.primary }}>
                                        {shortName(u.username)}
                                    </Avatar>
                                ))}
                            </AvatarGroup>
                        </Tooltip>
                    )}
                </Box>
            )}
        </Paper>
    );
};

export default TaskCard;
