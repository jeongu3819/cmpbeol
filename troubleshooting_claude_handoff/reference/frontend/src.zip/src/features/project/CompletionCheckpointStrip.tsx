import React from 'react';
import { Box, Typography, LinearProgress, Popover, Tooltip, Button, Divider } from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import FlagOutlinedIcon from '@mui/icons-material/FlagOutlined';
import { planAiColors } from '../../theme/tokens';
import {
  computeCompletionCheckpoints,
  countCompletionCheckpoints,
  getCheckpointTaskBuckets,
} from '../../utils/completionCheckpoints';
import { useAppStore } from '../../stores/useAppStore';
import type { CompletionCheckpoint, Task, WorkflowConfig } from '../../types';

export type CheckpointViewType = 'board' | 'list' | 'roadmap';

/** 접기/펼치기 상태 저장 key — projectId + view별로 독립 저장 */
const collapseKey = (projectId: number, viewType: CheckpointViewType) => `${projectId}:${viewType}`;

interface Props {
  tasks: Task[];
  workflow?: WorkflowConfig;
  projectId: number;
  /** 접기/펼치기 상태를 view별로 저장하기 위한 구분자 */
  viewType: CheckpointViewType;
}

/**
 * 접힌 상태에서 각 view toolbar 안에 들어가는 compact trigger.
 * 표시 조건: CUSTOM 워크플로우 + 체크포인트 1개 이상 + collapsed=true.
 * 클릭 시 collapsed=false 로 바꿔 큰 패널을 다시 펼친다. (계산/로직 불변, 표시 전환만)
 */
export const IntermediateCompletionCompactButton: React.FC<{
  workflow?: WorkflowConfig;
  projectId: number;
  viewType: CheckpointViewType;
}> = ({ workflow, projectId, viewType }) => {
  const key = collapseKey(projectId, viewType);
  const collapsed = useAppStore(state => state.checkpointPanelCollapsed[key] ?? false);
  const setCollapsed = useAppStore(state => state.setCheckpointPanelCollapsed);

  const count = React.useMemo(
    () => countCompletionCheckpoints(workflow?.columns ?? []),
    [workflow?.columns],
  );

  // 펼쳐진 상태이거나 체크포인트가 없으면 chip 을 노출하지 않는다.
  if (workflow?.mode !== 'CUSTOM' || count === 0 || !collapsed) return null;

  // Board 는 검색/필터 toolbar(필터·정렬 버튼)와 같은 컨트롤 그룹처럼 보이도록 사이즈/정렬을 맞춘다.
  // (필터·정렬 버튼: height 30 / px 1.25 / 0.78rem / weight 600 / icon 16, 38px pill 안에서 세로 중앙)
  // List / Roadmap 은 기존 스타일을 그대로 유지한다.
  const isBoard = viewType === 'board';

  return (
    <Tooltip title="중간 완료 단계 보기" arrow placement="top">
      <Box
        role="button"
        aria-label="중간 완료 단계 펼치기"
        onClick={() => setCollapsed(key, false)}
        sx={{
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 0.5,
          cursor: 'pointer',
          height: 30,
          lineHeight: 1,
          whiteSpace: 'nowrap',
          borderRadius: '999px',
          background: planAiColors.status.successSoft,
          border: `1px solid ${planAiColors.status.success}33`,
          color: planAiColors.status.success,
          transition: 'background 140ms, box-shadow 140ms',
          '&:hover': { background: `${planAiColors.status.success}22` },
          ...(isBoard
            ? { px: 1.25, alignSelf: 'center' } // 38px pill 행 안에서 세로 중앙 정렬
            : { pl: 1, pr: 1.25 }),
        }}
      >
        <FlagOutlinedIcon sx={{ fontSize: isBoard ? 14 : 15 }} />
        <Typography
          sx={{
            fontSize: isBoard ? '0.78rem' : '0.76rem',
            fontWeight: isBoard ? 600 : 700,
            color: 'inherit',
            lineHeight: 1,
          }}
        >
          중간 완료 {count}단계
        </Typography>
      </Box>
    </Tooltip>
  );
};

const STATUS_META = {
  completed: { label: '완료', color: planAiColors.status.success, soft: planAiColors.status.successSoft },
  in_progress: { label: '진행중', color: planAiColors.status.warning, soft: planAiColors.status.warningSoft },
  waiting: { label: '대기', color: planAiColors.text.muted, soft: planAiColors.background.surfaceAlt },
} as const;

const CompletionCheckpointStrip: React.FC<Props> = ({ tasks, workflow, projectId, viewType }) => {
  const [anchor, setAnchor] = React.useState<{ el: HTMLElement; cp: CompletionCheckpoint } | null>(null);
  const openDrawer = useAppStore(state => state.openDrawer);
  const boardCheckpointFilter = useAppStore(state => state.boardCheckpointFilter);
  const setBoardCheckpointFilter = useAppStore(state => state.setBoardCheckpointFilter);

  // 접기/펼치기 상태 — view별로 공유 스토어에 저장 (표시 UI만 제어, 계산/로직 불변)
  const key = collapseKey(projectId, viewType);
  const collapsed = useAppStore(state => state.checkpointPanelCollapsed[key] ?? false);
  const setCollapsed = useAppStore(state => state.setCheckpointPanelCollapsed);

  const checkpoints = React.useMemo(
    () => computeCompletionCheckpoints(tasks, workflow?.columns ?? []),
    [tasks, workflow?.columns],
  );

  // CUSTOM 모드 + 체크포인트가 있을 때만 노출 (없으면 영역 자체를 숨김)
  if (workflow?.mode !== 'CUSTOM' || checkpoints.length === 0) return null;

  // 접힌 상태: 큰 패널은 렌더링하지 않는다.
  // compact chip 은 각 view toolbar 안의 IntermediateCompletionCompactButton 이 담당한다.
  if (collapsed) return null;

  const activeFilterColId =
    boardCheckpointFilter && boardCheckpointFilter.projectId === projectId
      ? boardCheckpointFilter.columnId
      : null;

  const handleCardClick = (e: React.MouseEvent<HTMLElement>, cp: CompletionCheckpoint) => {
    // 카드 클릭 = 포함 Task 목록 Popover + Board 필터 적용(교체)
    setBoardCheckpointFilter({ projectId, columnId: cp.checkpointColumnId, label: cp.checkpointLabel });
    setAnchor({ el: e.currentTarget, cp });
  };

  return (
    <Box
      aria-label="완료 체크포인트"
      sx={{
        mt: 2,
        mb: 3,
        px: 2.5,
        py: 2.25,
        borderRadius: '22px',
        background: 'rgba(255, 255, 255, 0.42)',
        border: '1px solid rgba(255, 255, 255, 0.55)',
        boxShadow: '0 18px 45px rgba(15, 23, 42, 0.10)',
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 1.5 }}>
        <InfoOutlinedIcon sx={{ fontSize: 15, color: planAiColors.text.tertiary }} />
        <Typography sx={{ fontSize: '0.74rem', fontWeight: 500, color: planAiColors.text.secondary }}>
          진행 기준: 다음 단계로 넘어간 Task와 현재 단계에서 100% 완료된 Task
        </Typography>
        <Tooltip title="중간 완료 단계 접기" arrow placement="top">
          <Button
            size="small"
            onClick={() => setCollapsed(key, true)}
            startIcon={<KeyboardArrowUpIcon sx={{ fontSize: 16 }} />}
            sx={{
              ml: 'auto',
              flex: '0 0 auto',
              minWidth: 0,
              px: 1,
              py: 0.25,
              fontSize: '0.72rem',
              fontWeight: 600,
              textTransform: 'none',
              color: planAiColors.text.secondary,
              '& .MuiButton-startIcon': { mr: 0.25 },
            }}
          >
            접기
          </Button>
        </Tooltip>
      </Box>

      <Box
        sx={{
          display: 'flex',
          alignItems: 'stretch',
          gap: 1,
          overflowX: 'auto',
          pb: 0.5,
          '&::-webkit-scrollbar': { height: 6 },
          '&::-webkit-scrollbar-thumb': { background: planAiColors.border.soft, borderRadius: 3 },
        }}
      >
        {checkpoints.map((cp, idx) => {
          const meta = STATUS_META[cp.status];
          const badgeBg = cp.status === 'waiting' ? planAiColors.text.muted : meta.color;
          const isActive = activeFilterColId === cp.checkpointColumnId;
          return (
            <React.Fragment key={cp.checkpointColumnId}>
              {idx > 0 && (
                <Box sx={{ flex: '0 0 auto', display: 'flex', alignItems: 'center', color: planAiColors.text.disabled }}>
                  <ChevronRightIcon sx={{ fontSize: 22 }} />
                </Box>
              )}
              <Tooltip title="포함된 Task 보기" arrow placement="top">
                <Box
                  onClick={(e) => handleCardClick(e, cp)}
                  sx={{
                    flex: '0 0 auto',
                    minWidth: 200,
                    maxWidth: 240,
                    cursor: 'pointer',
                    px: 2,
                    py: 1.75,
                    borderRadius: '16px',
                    background: 'rgba(255, 255, 255, 0.58)',
                    border: isActive ? `2px solid ${meta.color}` : '1px solid rgba(255, 255, 255, 0.70)',
                    boxShadow: isActive ? '0 12px 28px rgba(15, 23, 42, 0.14)' : '0 8px 24px rgba(15, 23, 42, 0.07)',
                    transition: 'box-shadow 160ms, transform 160ms, border-color 160ms',
                    '&:hover': { boxShadow: '0 12px 28px rgba(15, 23, 42, 0.12)', transform: 'translateY(-1px)' },
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                    <Box
                      sx={{
                        width: 26,
                        height: 26,
                        borderRadius: '999px',
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '0.8rem',
                        fontWeight: 700,
                        color: '#fff',
                        bgcolor: badgeBg,
                        flex: '0 0 auto',
                      }}
                    >
                      {idx + 1}
                    </Box>
                    <Typography
                      sx={{ fontSize: '0.85rem', fontWeight: 600, color: planAiColors.text.primary, lineHeight: 1.2 }}
                      noWrap
                      title={cp.checkpointLabel}
                    >
                      {cp.checkpointLabel}
                    </Typography>
                  </Box>
                  {/* 완료 체크포인트 설명 — 워크플로우 설정에서 입력한 기준/의미 (2줄까지, 전체는 hover) */}
                  {cp.checkpointDescription && (
                    <Typography
                      title={cp.checkpointDescription}
                      sx={{
                        fontSize: '0.72rem',
                        color: 'rgba(71, 85, 105, 0.82)',
                        lineHeight: 1.35,
                        mb: 0.75,
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden',
                      }}
                    >
                      {cp.checkpointDescription}
                    </Typography>
                  )}
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.75 }}>
                    <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: meta.color }}>{meta.label}</Typography>
                    <Typography sx={{ fontSize: '0.74rem', fontWeight: 600, color: planAiColors.text.secondary }}>
                      {cp.passedTaskCount} / {cp.totalTaskCount}
                    </Typography>
                  </Box>
                  <LinearProgress
                    variant="determinate"
                    value={cp.progressPercent}
                    sx={{
                      height: 6,
                      borderRadius: 3,
                      bgcolor: meta.soft,
                      '& .MuiLinearProgress-bar': { bgcolor: meta.color, borderRadius: 3 },
                    }}
                  />
                </Box>
              </Tooltip>
            </React.Fragment>
          );
        })}
      </Box>

      <Popover
        open={!!anchor}
        anchorEl={anchor?.el ?? null}
        onClose={() => setAnchor(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        transformOrigin={{ vertical: 'top', horizontal: 'left' }}
      >
        {anchor && (() => {
          const { completed, pending } = getCheckpointTaskBuckets(
            tasks,
            workflow?.columns ?? [],
            anchor.cp.checkpointColumnId,
          );
          return (
            <Box sx={{ p: 1.5, width: 300, maxWidth: '90vw' }}>
              <Typography sx={{ fontSize: '0.82rem', fontWeight: 700, mb: 0.25 }}>{anchor.cp.checkpointLabel}</Typography>
              {anchor.cp.checkpointDescription && (
                <Typography sx={{ fontSize: '0.72rem', color: planAiColors.text.secondary, lineHeight: 1.4, mb: 0.75 }}>
                  {anchor.cp.checkpointDescription}
                </Typography>
              )}
              <Typography sx={{ fontSize: '0.7rem', color: planAiColors.text.tertiary, mb: 1 }}>
                완료 {completed.length}개 · 남은 Task {pending.length}개
              </Typography>
              {pending.length === 0 ? (
                <Typography sx={{ fontSize: '0.75rem', color: planAiColors.text.muted, py: 1.5, textAlign: 'center' }}>
                  모든 Task가 이 체크포인트 기준을 충족했습니다.
                </Typography>
              ) : (
                <Box sx={{ maxHeight: 260, overflowY: 'auto' }}>
                  {pending.map(({ task, currentStepLabel, progress, reason }) => (
                    <Box
                      key={task.id}
                      onClick={() => { openDrawer(task, projectId); setAnchor(null); }}
                      sx={{
                        px: 1,
                        py: 0.75,
                        borderRadius: 1.5,
                        cursor: 'pointer',
                        '&:hover': { bgcolor: 'rgba(0,0,0,0.04)' },
                      }}
                    >
                      <Typography
                        sx={{ fontSize: '0.78rem', fontWeight: 600, color: planAiColors.text.primary }}
                        noWrap
                        title={task.title}
                      >
                        {task.title}
                      </Typography>
                      <Typography sx={{ fontSize: '0.68rem', color: planAiColors.text.tertiary }}>
                        {currentStepLabel || '—'} · {reason === 'earlier_step'
                          ? '이전 단계 진행 필요'
                          : `현재 단계 진행 중 · progress ${progress}%`}
                      </Typography>
                    </Box>
                  ))}
                </Box>
              )}
              <Divider sx={{ my: 1 }} />
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Typography sx={{ fontSize: '0.68rem', color: planAiColors.text.tertiary }}>
                  Board에 남은 Task만 표시 중
                </Typography>
                <Button
                  size="small"
                  onClick={() => { setBoardCheckpointFilter(null); setAnchor(null); }}
                  sx={{ fontSize: '0.72rem', textTransform: 'none' }}
                >
                  필터 해제
                </Button>
              </Box>
            </Box>
          );
        })()}
      </Popover>
    </Box>
  );
};

export default CompletionCheckpointStrip;
