import React from 'react';
import {
  Box,
  Paper,
  Typography,
  Chip,
  Tooltip,
  LinearProgress,
  Menu,
  MenuItem as MuiMenuItem,
  ListItemIcon,
  ListItemText,
  Button,
} from '@mui/material';
import LinkOffIcon from '@mui/icons-material/LinkOff';
import CalendarViewWeekIcon from '@mui/icons-material/CalendarViewWeek';
import ViewKanbanIcon from '@mui/icons-material/ViewKanban';
import TuneIcon from '@mui/icons-material/Tune';
import { Task } from '../../types';
import BoardFilterBar, { BoardSortField, BoardPriorityFilter } from './BoardFilterBar';
import { ScheduleFilter, taskMatchesScheduleFilter } from '../../utils/scheduleFormat';
import WeeklyProgressView from './WeeklyProgressView';
import WorkflowSettingsDrawer from './WorkflowSettingsDrawer';
import { api } from '../../api/client';
import { useWorkflow } from '../../hooks/useWorkflow';
import { resolveTaskColumnId } from '../../utils/workflowSummary';
import { getCheckpointTaskBuckets } from '../../utils/completionCheckpoints';
import { IntermediateCompletionCompactButton } from './CompletionCheckpointStrip';
import { descriptionToPreviewText } from '../../utils/richImage';
import {
  BOARD_COLUMNS,
  ALL_COLUMN_IDS,
  belongsToColumn,
  computeColumnMoveUpdates,
  deriveBoardColumn,
  type BoardColumnId,
} from '../../utils/taskStatus';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useSnackbar } from 'notistack';
import { useAppStore } from '../../stores/useAppStore';
import { planAiColors, planAiShadows, planAiRadius } from '../../theme/tokens';

// CUSTOM 컬럼이 색을 지정하지 않은 경우 mapped_status 기준 기본색
const statusColorFallback: Record<string, string> = {
  todo: planAiColors.text.tertiary,
  in_progress: planAiColors.brand.primary,
  done: planAiColors.status.success,
  hold: planAiColors.status.warning,
};

// Board 컬럼 공통 디스크립터 (DEFAULT/CUSTOM 통합)
interface ColDesc {
  id: string;               // droppable/sortable id (DEFAULT: BoardColumnId, CUSTOM: `wf-<id>`)
  label: string;
  sublabel?: string;
  description?: string | null;  // CUSTOM 단계 세부 설명 (헤더 제목 아래 표시)
  color: string;
  status: Task['status'];
  colNumId?: number;        // CUSTOM 전용 workflow_column_id
}
import MagicInput from '../../components/MagicInput';
import TaskCard from '../task/TaskCard';
import {
  DndContext,
  pointerWithin,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
  DragStartEvent,
  DragEndEvent,
  DragOverEvent,
  useDroppable,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { buildTaskTree, canLinkTaskAsChild, type TaskTreeNode } from '../../utils/taskTree';
import { useChangeTaskParent, type ParentChangeNotify } from '../../hooks/useChangeTaskParent';

interface BoardViewProps {
  projectId: number;
}

// Columns and drop IDs now live in utils/taskStatus.ts so that board/list/detail
// share one source of truth for the `in_progress` vs `in_progress_advanced`
// (≥50% progress) distinction.

// 정렬/우선순위 타입·옵션은 BoardFilterBar 에서 공유 (이름순/생성일순은 제거됨)
const priorityOrder: Record<string, number> = { high: 0, medium: 1, low: 2 };

// 과거 버전에서 Board 필터를 저장하던 localStorage key prefix.
// 현재 정책: 필터/정렬은 임시 탐색용 → 영속화하지 않고, 남아있는 옛 값은 정리만 한다.
const LEGACY_FILTER_STORAGE_PREFIX = 'planai:boardFilters:';

// Sortable task wrapper (최상위 Task 전용 — 자식은 드래그 불가)
const SortableTaskItem = ({
  task,
  onClick,
  compact,
  parentBadge,
  childCount,
  collapsed,
  onToggleChildren,
  depth = 0,
  isLinkTarget,
  linkInvalid,
  onMore,
  onContextMenu,
}: {
  task: Task;
  onClick: () => void;
  compact?: boolean;
  parentBadge?: boolean;
  childCount?: number;
  collapsed?: boolean;
  onToggleChildren?: () => void;
  depth?: number;
  isLinkTarget?: boolean;
  linkInvalid?: boolean;
  onMore?: (e: React.MouseEvent<HTMLElement>) => void;
  onContextMenu?: (e: React.MouseEvent) => void;
}) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: task.id,
    data: { task },
  });

  // 들여쓰기는 단계당 제한된 크기(깊어져도 카드 폭이 과하게 줄지 않도록 최대 4단계까지만 증가).
  const indent = Math.min(depth, 4) * 16;

  const style: React.CSSProperties = {
    transform: CSS.Translate.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
    marginLeft: indent,
    // 계층 가이드 선 (하위 단계일 때만)
    borderLeft: depth > 0 ? `2px solid ${planAiColors.brand.primaryBorder}` : undefined,
    paddingLeft: depth > 0 ? 8 : undefined,
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners} onContextMenu={onContextMenu}>
      <TaskCard
        task={task}
        onClick={onClick}
        compact={compact || depth > 0}
        parentBadge={parentBadge}
        childCount={childCount}
        collapsed={collapsed}
        onToggleChildren={onToggleChildren}
        depth={depth}
        isLinkTarget={isLinkTarget}
        linkInvalid={linkInvalid}
        onMore={onMore}
      />
    </div>
  );
};

// Droppable column wrapper
const DroppableColumn = ({ id, children }: { id: string; children: React.ReactNode }) => {
  const { setNodeRef, isOver } = useDroppable({ id });
  return (
    <div
      ref={setNodeRef}
      style={{
        flexGrow: 1,
        overflowY: 'auto',
        padding: '8px',
        minHeight: 100,
        borderRadius: 8,
        backgroundColor: isOver ? 'rgba(37, 99, 235, 0.08)' : 'transparent',
        transition: 'background-color 0.2s ease',
      }}
    >
      {children}
    </div>
  );
};

// Flow connector between columns (CSS-based)
const FlowConnector = ({ fromColor, toColor }: { fromColor: string; toColor: string }) => (
  <Box
    sx={{
      display: 'flex',
      alignItems: 'center',
      width: 20,
      flexShrink: 0,
      mx: 0.5,
    }}
  >
    {/* Solid gradient bar */}
    <Box
      sx={{
        flex: 1,
        height: 6,
        borderRadius: 3,
        background: `linear-gradient(to right, ${fromColor}66, ${toColor}99)`,
      }}
    />
    {/* Triangle arrowhead */}
    <Box
      sx={{
        width: 0,
        height: 0,
        borderTop: '8px solid transparent',
        borderBottom: '8px solid transparent',
        borderLeft: `10px solid ${toColor}88`,
        flexShrink: 0,
      }}
    />
  </Box>
);


const BoardView: React.FC<BoardViewProps> = ({ projectId }) => {
  const queryClient = useQueryClient();
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();
  const openDrawer = useAppStore(state => state.openDrawer);
  const currentUserId = useAppStore(state => state.currentUserId);
  const filterSearch = useAppStore(state => state.filterSearch);
  const boardCheckpointFilter = useAppStore(state => state.boardCheckpointFilter);
  const setBoardCheckpointFilter = useAppStore(state => state.setBoardCheckpointFilter);

  const { data: rawTasks, isLoading } = useQuery({
    queryKey: ['tasks', projectId, currentUserId],
    queryFn: () => api.getTasks(projectId, currentUserId),
  });
  const tasks = React.useMemo(() => {
    if (!rawTasks) return rawTasks;
    if (!filterSearch.trim()) return rawTasks;
    const q = filterSearch.trim().toLowerCase();
    return rawTasks.filter(t => t.title.toLowerCase().includes(q));
  }, [rawTasks, filterSearch]);
  const [activeTask, setActiveTask] = React.useState<Task | null>(null);
  // 드래그 중 "하위 작업으로 연결" 대상 카드 하이라이트 (valid=녹색/ invalid=빨강)
  const [dropLink, setDropLink] = React.useState<{ targetId: number; valid: boolean } | null>(null);
  // 카드 우클릭 / 더보기 메뉴 (상위 작업 연결 해제)
  const [taskMenu, setTaskMenu] = React.useState<{ task: Task; anchor: { top: number; left: number } } | null>(null);
  // 필터/정렬은 임시 탐색용 — Board 화면에 머무는 동안만 유지, 재진입 시 항상 기본값.
  const [sortField, setSortField] = React.useState<BoardSortField>('default');
  // Board 전용 필터 (정렬과 독립) — 검색어는 250ms debounce
  const [searchInput, setSearchInput] = React.useState('');
  const [taskSearch, setTaskSearch] = React.useState('');
  const [priorityFilter, setPriorityFilter] = React.useState<BoardPriorityFilter>('all');
  const [scheduleFilter, setScheduleFilter] = React.useState<ScheduleFilter>('all');

  React.useEffect(() => {
    const id = setTimeout(() => setTaskSearch(searchInput), 250);
    return () => clearTimeout(id);
  }, [searchInput]);

  // 과거 버전에서 저장됐을 수 있는 Board 필터 localStorage 정리 (현재는 영속화 안 함)
  React.useEffect(() => {
    try {
      const stale: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(LEGACY_FILTER_STORAGE_PREFIX)) stale.push(k);
      }
      stale.forEach(k => localStorage.removeItem(k));
    } catch {
      /* localStorage 접근 불가 시 무시 */
    }
  }, []);

  // 다른 프로젝트로 이동하면 체크포인트 필터 해제 (Board 필터는 일시적 탐색 상태)
  React.useEffect(() => {
    const f = useAppStore.getState().boardCheckpointFilter;
    if (f && f.projectId !== projectId) setBoardCheckpointFilter(null);
  }, [projectId, setBoardCheckpointFilter]);

  // 초기화: 검색어/정렬/우선순위 모두 기본값으로 (popover '초기화' 버튼)
  const handleResetFilters = React.useCallback(() => {
    setSearchInput('');
    setTaskSearch('');
    setSortField('default');
    setPriorityFilter('all');
    setScheduleFilter('all');
  }, []);

  const [viewMode, setViewMode] = React.useState<'board' | 'weekly'>('board');
  const [settingsOpen, setSettingsOpen] = React.useState(false);

  // 워크플로우 설정 (DEFAULT면 columns 비어있음)
  const { data: workflow } = useWorkflow(projectId);
  const isCustom = !!workflow && workflow.mode === 'CUSTOM' && (workflow.columns?.length ?? 0) > 0;
  // 컬럼 배치 resolver 용 active 컬럼(정렬) — Board 컬럼/상단 chip count 일치 보장
  const activeWfColumns = React.useMemo(
    () => (workflow?.columns ? workflow.columns.filter(c => c.active).slice().sort((a, b) => a.sort_order - b.sort_order) : []),
    [workflow],
  );

  // 통합 컬럼 디스크립터
  const columns: ColDesc[] = React.useMemo(() => {
    if (isCustom && workflow) {
      return [...workflow.columns]
        .sort((a, b) => a.sort_order - b.sort_order)
        .map(c => ({
          id: `wf-${c.id}`,
          label: c.label,
          description: c.description || undefined,
          color: c.color || statusColorFallback[c.mapped_status] || planAiColors.text.tertiary,
          status: c.mapped_status as Task['status'],
          colNumId: c.id,
        }));
    }
    return BOARD_COLUMNS.map(c => ({ id: c.id, label: c.label, sublabel: c.sublabel, color: c.color, status: c.status }));
  }, [isCustom, workflow]);

  const sortTasks = React.useCallback(
    (taskList: Task[]): Task[] => {
      if (sortField === 'default') return taskList;
      return [...taskList].sort((a, b) => {
        switch (sortField) {
          case 'due_date': {
            const aVal = a.due_date || '';
            const bVal = b.due_date || '';
            if (!aVal && !bVal) return 0;
            if (!aVal) return 1;
            if (!bVal) return -1;
            return aVal.localeCompare(bVal);
          }
          case 'priority': {
            const aP = priorityOrder[a.priority || ''] ?? 3;
            const bP = priorityOrder[b.priority || ''] ?? 3;
            return aP - bP;
          }
          default:
            return 0;
        }
      });
    },
    [sortField]
  );

  // Sort by due_date ascending (earlier first, no date last)
  const sortByDueDateAsc = (list: Task[]) =>
    [...list].sort((a, b) => {
      const aD = a.due_date || '';
      const bD = b.due_date || '';
      if (!aD && !bD) return 0;
      if (!aD) return 1;
      if (!bD) return -1;
      return aD.localeCompare(bD);
    });

  // Sort by due_date descending (latest first, no date last)
  const sortByDueDateDesc = (list: Task[]) =>
    [...list].sort((a, b) => {
      const aD = a.due_date || '';
      const bD = b.due_date || '';
      if (!aD && !bD) return 0;
      if (!aD) return 1;
      if (!bD) return -1;
      return bD.localeCompare(aD);
    });

  // Board 전용 필터 적용 결과 (원본 tasks 불변 — 별도 배열 계산).
  // 검색어 + 우선순위 chip을 AND 조건으로 적용.
  // 검색 대상은 Board 가 이미 가진 Task payload 필드만 사용 → 별도 로딩/버퍼링 없음.
  //   - Task 이름/설명, 담당자명·login_id, 서브프로젝트명 (payload enrich)
  //   - 해당 정보가 payload 에 없으면 그냥 검색 대상에서 제외 (오류 아님)
  //   - 작업노트/첨부/댓글/VOC 는 제외, null/undefined 는 빈 문자열, 대소문자 무시
  // 완료 체크포인트 필터 — 이 프로젝트에 적용 중일 때만. 카드/Popover와 동일 helper로 live 재계산.
  const activeCheckpoint =
    boardCheckpointFilter && boardCheckpointFilter.projectId === projectId ? boardCheckpointFilter : null;
  // Board 필터는 '아직 진행해야 할(남은) Task' 기준 — 카드/Popover와 동일 helper
  const checkpointTaskIds = React.useMemo(() => {
    if (!activeCheckpoint || !rawTasks || !workflow?.columns) return null;
    return new Set(
      getCheckpointTaskBuckets(rawTasks, workflow.columns, activeCheckpoint.columnId).pending.map(e => e.task.id),
    );
  }, [activeCheckpoint, rawTasks, workflow?.columns]);

  const filteredTasks = React.useMemo(() => {
    if (!tasks) return tasks;
    let result = tasks;
    // 1) 체크포인트 필터 먼저 적용 → 2) 검색어/우선순위
    if (checkpointTaskIds) {
      result = result.filter(t => checkpointTaskIds.has(t.id));
    }
    const q = taskSearch.trim().toLowerCase();
    if (q) {
      result = result.filter(t => {
        const haystack = [
          t.title,
          t.description ? descriptionToPreviewText(t.description) : '',
          ...(t.assignee_names || []),
          ...(t.assignee_login_ids || []),
          t.sub_project_name || '',
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();
        return haystack.includes(q);
      });
    }
    if (priorityFilter !== 'all') {
      result = result.filter(t => (t.priority || '') === priorityFilter);
    }
    if (scheduleFilter !== 'all') {
      result = result.filter(t => taskMatchesScheduleFilter(t, scheduleFilter));
    }
    return result;
  }, [tasks, taskSearch, priorityFilter, scheduleFilter, checkpointTaskIds]);

  // ── Task 상하 관계 (Parent / Child) ──
  // parent_task_id 기준 자식 그룹핑. 구조는 필터와 무관하게 rawTasks 기준으로 안정 유지.
  const childrenByParent = React.useMemo(() => {
    const m = new Map<number, Task[]>();
    (rawTasks || []).forEach(t => {
      if (t.parent_task_id != null) {
        const arr = m.get(t.parent_task_id);
        if (arr) arr.push(t);
        else m.set(t.parent_task_id, [t]);
      }
    });
    return m;
  }, [rawTasks]);

  // 필터/검색 컨텍스트 보존 (스펙 §10/§11): 매칭된 child의 parent, 매칭된 parent의 child를
  // 결과에 함께 포함해 parent-child 구조가 끊기지 않게 한다. (구조 복원은 rawTasks에서 역참조)
  const displayTasks = React.useMemo(() => {
    if (!filteredTasks) return filteredTasks;
    if (!rawTasks) return filteredTasks;
    const byId = new Map(rawTasks.map(t => [t.id, t] as const));
    const result = new Map<number, Task>();
    filteredTasks.forEach(t => result.set(t.id, t));
    filteredTasks.forEach(t => {
      if (t.parent_task_id != null) {
        const p = byId.get(t.parent_task_id);
        if (p) result.set(p.id, p);
      }
      const kids = childrenByParent.get(t.id);
      if (kids) kids.forEach(k => result.set(k.id, k));
    });
    return Array.from(result.values());
  }, [filteredTasks, rawTasks, childrenByParent]);

  // 하위 접힘 상태 — 기본 전부 펼침(빈 집합). 새로고침/재진입 시 리셋(localStorage 미저장).
  const [collapsedParents, setCollapsedParents] = React.useState<Set<number>>(new Set());
  const toggleCollapse = React.useCallback((id: number) => {
    setCollapsedParents(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  // Get tasks for each visual column (parent + child 모두 — count/정렬 기준).
  // 렌더는 최상위(parent_task_id==null)만 카드로 그리고 자식은 parent 아래에 중첩한다.
  //  - CUSTOM: workflow_column_id 기준 필터 (status 자동 파생 없음)
  //  - DEFAULT: 기존 derivation (utils/taskStatus.ts)
  const getColumnTasks = React.useCallback(
    (col: ColDesc): Task[] => {
      if (!displayTasks) return [];
      if (isCustom) {
        return displayTasks.filter(t => resolveTaskColumnId(t, activeWfColumns) === col.colNumId);
      }
      const filtered = displayTasks.filter(t => belongsToColumn(t, col.id as BoardColumnId));
      if (col.id === 'in_progress' || col.id === 'in_progress_advanced') return sortByDueDateAsc(filtered);
      if (col.id === 'done') return sortByDueDateDesc(filtered);
      return filtered;
    },
    [displayTasks, isCustom, activeWfColumns]
  );

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 8 },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const updateTaskMutation = useMutation({
    mutationFn: ({ taskId, updates }: { taskId: number; updates: Partial<Task> }) =>
      api.updateTask(taskId, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
    },
  });

  // 상위 작업 연결/해제 + 실행 취소 — 공통 hook 재사용(Board/Graph/메뉴 공용, 새 API 없음).
  const { changeParent } = useChangeTaskParent(projectId, currentUserId);
  const notifyParentChange = React.useCallback<ParentChangeNotify>(({ message, variant, undo }) => {
    enqueueSnackbar(message, {
      variant,
      action: undo
        ? (key) => (
            <Button
              size="small"
              color="inherit"
              onClick={() => { undo(); closeSnackbar(key); }}
              sx={{ fontWeight: 700, textTransform: 'none' }}
            >
              실행 취소
            </Button>
          )
        : undefined,
    });
  }, [enqueueSnackbar, closeSnackbar]);

  // Board 단계 비교키 — 같은 단계(컬럼/status)의 작업끼리만 하위 연결 허용.
  const taskColKey = React.useCallback((t: Task): string | null => {
    if (isCustom) {
      const c = resolveTaskColumnId(t, activeWfColumns);
      return c == null ? null : `c${c}`;
    }
    const col = deriveBoardColumn(t);
    return col ? `d${col}` : null;
  }, [isCustom, activeWfColumns]);

  // over.id 가 컬럼인지(=단계 이동) 아니면 Task 카드인지(=하위 연결) 판별.
  const isColumnDropId = React.useCallback((overId: string): boolean => (
    isCustom ? columns.some(c => c.id === overId) : (ALL_COLUMN_IDS as string[]).includes(overId)
  ), [isCustom, columns]);

  // 카드 우클릭 / 더보기 메뉴 열기 — 상위 작업이 있는 Task 에서만.
  const openTaskMenu = (task: Task, e: React.MouseEvent) => {
    if (task.parent_task_id == null) return;
    e.preventDefault();
    e.stopPropagation();
    setTaskMenu({ task, anchor: { top: e.clientY, left: e.clientX } });
  };

  const handleDragStart = (event: DragStartEvent) => {
    const task = (rawTasks || []).find(t => t.id === event.active.id);
    if (task) setActiveTask(task);
  };

  // 드래그 중 대상 카드 하이라이트 계산 (카드 위=연결 의도, 컬럼 위=단계 이동).
  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (!over) { setDropLink(null); return; }
    const overId = String(over.id);
    const activeId = active.id as number;
    if (isColumnDropId(overId)) { setDropLink(null); return; }
    const overTask = (rawTasks || []).find(t => t.id === Number(overId));
    const activeT = (rawTasks || []).find(t => t.id === activeId);
    if (!overTask || !activeT || overTask.id === activeId) { setDropLink(null); return; }
    const structOk = canLinkTaskAsChild(activeId, overTask.id, rawTasks || []);
    const sameStage = taskColKey(activeT) != null && taskColKey(activeT) === taskColKey(overTask);
    setDropLink({ targetId: overTask.id, valid: structOk && sameStage });
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveTask(null);
    setDropLink(null);
    if (!over) return;

    const activeId = active.id as number;
    const overId = String(over.id);
    const draggedTask = (rawTasks || []).find(t => t.id === activeId);
    if (!draggedTask) return;

    // ── 카드 위 Drop = "하위 작업으로 연결" (컬럼 위 Drop 만 단계 이동으로 넘어간다) ──
    if (!isColumnDropId(overId)) {
      const overTask = (rawTasks || []).find(t => t.id === Number(overId));
      if (!overTask || overTask.id === activeId) return;
      const structOk = canLinkTaskAsChild(activeId, overTask.id, rawTasks || []);
      const sameStage = taskColKey(draggedTask) != null && taskColKey(draggedTask) === taskColKey(overTask);
      if (structOk && sameStage) {
        changeParent({
          taskId: activeId,
          newParentId: overTask.id,
          previousParentId: draggedTask.parent_task_id ?? null,
          activeTitle: draggedTask.title,
          targetTitle: overTask.title,
          notify: notifyParentChange,
        });
      } else if (!sameStage) {
        enqueueSnackbar('같은 Board 단계의 작업끼리만 하위로 연결할 수 있습니다.', { variant: 'warning' });
      }
      return; // 카드 위 Drop 은 단계 이동으로 처리하지 않음
    }

    if (isCustom) {
      // CUSTOM: 대상 컬럼의 workflow_column_id 로 이동 (status는 서버가 mapped_status 동기화)
      let targetColNumId: number | null = null;
      const dropCol = columns.find(c => c.id === overId);
      if (dropCol) {
        targetColNumId = dropCol.colNumId ?? null;
      } else {
        const overTask = tasks?.find(t => t.id === Number(overId));
        if (overTask) targetColNumId = resolveTaskColumnId(overTask, activeWfColumns);
      }
      if (targetColNumId == null || targetColNumId === draggedTask.workflow_column_id) return;
      updateTaskMutation.mutate({ taskId: activeId, updates: { workflow_column_id: targetColNumId } });
      notifyChildrenMoved(activeId);
      return;
    }

    // DEFAULT: 기존 status/progress 파생 이동
    let targetCol: BoardColumnId | null = null;
    if ((ALL_COLUMN_IDS as string[]).includes(overId)) {
      targetCol = overId as BoardColumnId;
    } else {
      const overTask = tasks?.find(t => t.id === Number(overId));
      if (overTask) {
        // Derive the column (including in_progress vs in_progress_advanced)
        // from the over-task so dropping on a task in the ≥50% column lands there.
        targetCol = deriveBoardColumn(overTask);
      }
    }
    if (!targetCol) return;

    const updates = computeColumnMoveUpdates(draggedTask, targetCol);
    if (updates) {
      updateTaskMutation.mutate({ taskId: activeId, updates });
      notifyChildrenMoved(activeId);
    }
  };

  // 상위 Task 이동 시, 백엔드가 하위 Task 들도 같은 단계로 함께 옮긴다. 그 사실을 사용자에게 안내.
  const notifyChildrenMoved = (parentId: number) => {
    const n = (childrenByParent.get(parentId) || []).length;
    if (n > 0) {
      enqueueSnackbar(`상위 Task가 이동되어 하위 Task ${n}개도 함께 이동되었습니다.`, { variant: 'info' });
    }
  };

  // 컬럼 내 다단계 트리 재귀 렌더 — 각 카드는 드래그 가능 + 하위 연결 대상.
  const renderTaskTree = (nodes: TaskTreeNode[]): React.ReactNode =>
    nodes.map(node => {
      const isCollapsed = collapsedParents.has(node.id);
      const hasKids = node.children.length > 0;
      const hasParent = node.parent_task_id != null;
      return (
        <React.Fragment key={node.id}>
          <SortableTaskItem
            task={node}
            depth={node.depth}
            onClick={() => openDrawer(node, projectId)}
            parentBadge={hasParent}
            childCount={node.children.length}
            collapsed={isCollapsed}
            onToggleChildren={hasKids ? () => toggleCollapse(node.id) : undefined}
            isLinkTarget={dropLink?.targetId === node.id && dropLink.valid}
            linkInvalid={dropLink?.targetId === node.id && !dropLink.valid}
            onMore={hasParent ? (e) => openTaskMenu(node, e) : undefined}
            onContextMenu={hasParent ? (e) => openTaskMenu(node, e) : undefined}
          />
          {hasKids && !isCollapsed && renderTaskTree(node.children)}
        </React.Fragment>
      );
    });

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', gap: 2, p: 2 }}>
        {BOARD_COLUMNS.map(col => (
          <Paper
            key={col.id}
            sx={{ flex: 1, minWidth: 240, height: 400, bgcolor: planAiColors.background.surfaceAlt, borderRadius: `${planAiRadius.lg}px` }}
            elevation={0}
          />
        ))}
      </Box>
    );
  }

  if (viewMode === 'weekly') {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 220px)' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', mb: 1.5, flexShrink: 0 }}>
          <Tooltip title="보드 뷰">
            <Chip
              data-tour="board-view-btn"
              icon={<ViewKanbanIcon sx={{ fontSize: 16 }} />}
              label="보드"
              size="small"
              onClick={() => setViewMode('board')}
              sx={{
                height: 30,
                fontSize: '0.78rem',
                fontWeight: 600,
                bgcolor: planAiColors.background.surfaceAlt,
                color: planAiColors.text.secondary,
                cursor: 'pointer',
                '&:hover': { bgcolor: planAiColors.border.soft },
              }}
            />
          </Tooltip>
        </Box>
        <Box sx={{ flex: 1, overflow: 'auto' }}>
          <WeeklyProgressView projectId={projectId} />
        </Box>
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 220px)' }}>
      {/* 통합 필터바 + 우측 보드 컨트롤 */}
      <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5, mb: 1.5, flexShrink: 0, flexWrap: 'wrap' }}>
        <BoardFilterBar
          searchQuery={searchInput}
          onSearchQueryChange={setSearchInput}
          sortBy={sortField}
          onSortByChange={setSortField}
          priorityFilter={priorityFilter}
          onPriorityFilterChange={setPriorityFilter}
          scheduleFilter={scheduleFilter}
          onScheduleFilterChange={setScheduleFilter}
          onResetFilters={handleResetFilters}
        />

        <IntermediateCompletionCompactButton workflow={workflow} projectId={projectId} viewType="board" />

        {activeCheckpoint && (
          <Chip
            size="small"
            label={`${activeCheckpoint.label}까지 남은 Task · ${checkpointTaskIds?.size ?? 0}개 표시 중`}
            onDelete={() => setBoardCheckpointFilter(null)}
            sx={{
              height: 30,
              fontSize: '0.76rem',
              fontWeight: 700,
              bgcolor: planAiColors.brand.primarySoft,
              color: planAiColors.brand.primary,
              border: `1px solid ${planAiColors.brand.primaryBorder}`,
              '& .MuiChip-deleteIcon': { color: planAiColors.brand.primary },
            }}
          />
        )}

        <Box sx={{ flex: 1 }} />
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, height: 38 }}>
        <Chip
          size="small"
          label={isCustom ? '커스텀' : '기본'}
          sx={{
            height: 24,
            fontSize: '0.68rem',
            fontWeight: 700,
            bgcolor: isCustom ? planAiColors.status.purpleSoft : planAiColors.background.surfaceAlt,
            color: isCustom ? planAiColors.status.purple : planAiColors.text.tertiary,
          }}
        />
        <Tooltip title="워크플로우(보드 단계) 설정">
          <Chip
            icon={<TuneIcon sx={{ fontSize: 16 }} />}
            label="워크플로우 설정"
            size="small"
            onClick={() => setSettingsOpen(true)}
            sx={{
              height: 30,
              fontSize: '0.78rem',
              fontWeight: 600,
              bgcolor: planAiColors.background.surfaceAlt,
              color: planAiColors.text.secondary,
              cursor: 'pointer',
              '&:hover': { bgcolor: planAiColors.border.soft },
            }}
          />
        </Tooltip>
        <Tooltip title="주차별 진척사항">
          <Chip
            data-tour="weekly-progress-btn"
            icon={<CalendarViewWeekIcon sx={{ fontSize: 16 }} />}
            label="주차별 진척사항"
            size="small"
            onClick={() => setViewMode('weekly')}
            sx={{
              height: 30,
              fontSize: '0.78rem',
              fontWeight: 600,
              bgcolor: planAiColors.brand.primarySoft,
              color: planAiColors.brand.primary,
              cursor: 'pointer',
              '&:hover': { bgcolor: planAiColors.brand.primaryBorder },
            }}
          />
        </Tooltip>
        </Box>
      </Box>

      <DndContext
        sensors={sensors}
        collisionDetection={pointerWithin}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
        onDragCancel={() => { setActiveTask(null); setDropLink(null); }}
      >
        {/* Main Board Columns */}
        <Box
          sx={{ display: 'flex', gap: 0, alignItems: 'stretch', overflowX: 'auto', pb: 1.5, flex: 1, minHeight: 0 }}
        >
          {columns.map((col, colIndex) => {
            // colTasks = parent+child 전체 (count/§9 기준). 다단계 트리로 묶어 재귀 렌더.
            const colTasks = sortTasks(getColumnTasks(col));
            const colTree = buildTaskTree(colTasks);        // root + children (같은 컬럼 내)
            const colAllIds = colTasks.map(t => t.id);      // 모든 깊이 카드가 드래그 대상
            // DEFAULT: 'done' 다음엔 화살표 대신 Hold 앞 간격 / CUSTOM: 모든 인접 컬럼에 화살표
            const isDefaultDone = !isCustom && col.id === 'done';
            const showArrow = colIndex < columns.length - 1 && !isDefaultDone;
            const showQuickAdd = isCustom ? colIndex === 0 : (col.id === 'todo' || col.id === 'in_progress');

            return (
              <React.Fragment key={col.id}>
              <Box
                sx={{
                  flex: 1,
                  minWidth: 240,
                  bgcolor: 'rgba(248,250,252,0.72)',
                  backdropFilter: 'blur(8px)',
                  border: `1px solid ${planAiColors.border.soft}`,
                  borderRadius: `${planAiRadius.lg}px`,
                  boxShadow: planAiShadows.sm,
                  display: 'flex',
                  flexDirection: 'column',
                  height: '100%',
                }}
              >
                {/* Column Header */}
                <Box
                  sx={{
                    p: 1.5,
                    px: 2,
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'flex-start',
                  }}
                >
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.25, minWidth: 0 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: col.color, flexShrink: 0 }} />
                      <Typography
                        variant="subtitle2"
                        sx={{ fontWeight: 700, fontSize: '0.85rem', color: planAiColors.text.secondary }}
                      >
                        {col.label}
                      </Typography>
                      {col.sublabel && (
                        <Chip
                          label={col.sublabel}
                          size="small"
                          sx={{
                            height: 18,
                            fontSize: '0.62rem',
                            fontWeight: 600,
                            bgcolor: `${col.color}15`,
                            color: col.color,
                            border: `1px solid ${col.color}30`,
                          }}
                        />
                      )}
                      <Chip
                        label={colTasks.length}
                        size="small"
                        sx={{
                          height: 20,
                          minWidth: 20,
                          fontSize: '0.7rem',
                          fontWeight: 600,
                          bgcolor: planAiColors.border.soft,
                          color: planAiColors.text.tertiary,
                        }}
                      />
                    </Box>
                    {col.description && (
                      <Typography
                        sx={{
                          pl: '16px',           // dot(8) + gap(8) 만큼 들여써 라벨과 정렬
                          fontSize: '0.72rem',
                          lineHeight: 1.4,
                          color: planAiColors.text.muted,
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                          whiteSpace: 'pre-line',
                        }}
                      >
                        {col.description}
                      </Typography>
                    )}
                  </Box>
                </Box>

                {/* Progress bar for advanced column (DEFAULT 전용) */}
                {!isCustom && col.id === 'in_progress_advanced' && (
                  <Box sx={{ px: 2, pb: 1 }}>
                    <LinearProgress
                      variant="determinate"
                      value={50}
                      sx={{
                        height: 3,
                        borderRadius: 2,
                        bgcolor: planAiColors.border.soft,
                        '& .MuiLinearProgress-bar': {
                          bgcolor: col.color,
                          borderRadius: 2,
                        },
                      }}
                    />
                  </Box>
                )}

                {/* Droppable + Sortable Area — 모든 깊이 카드 드래그 가능, 하위는 parent 아래 재귀 중첩 */}
                <SortableContext
                  id={col.id}
                  items={colAllIds}
                  strategy={verticalListSortingStrategy}
                >
                  <DroppableColumn id={col.id}>
                    {colTree.length === 0 ? (
                      <Box
                        sx={{
                          p: 3,
                          textAlign: 'center',
                          color: planAiColors.text.muted,
                          border: `1.5px dashed ${planAiColors.border.normal}`,
                          borderRadius: `${planAiRadius.md}px`,
                        }}
                      >
                        <Typography variant="caption" sx={{ fontSize: '0.75rem' }}>
                          Drop tasks here
                        </Typography>
                      </Box>
                    ) : (
                      renderTaskTree(colTree)
                    )}
                  </DroppableColumn>
                </SortableContext>

                {/* Quick Add — DEFAULT: todo/in_progress, CUSTOM: 첫 컬럼 */}
                {showQuickAdd && (
                  <Box sx={{ px: 1, pb: 1 }}>
                    <MagicInput projectId={projectId} defaultStatus={col.status} />
                  </Box>
                )}
              </Box>
              {/* Flow connector between columns / spacer before Hold(DEFAULT) */}
              {showArrow && (
                <FlowConnector
                  fromColor={col.color}
                  toColor={columns[colIndex + 1].color}
                />
              )}
              {isDefaultDone && (
                <Box sx={{ width: 20 + 8, flexShrink: 0 }} />
              )}
              </React.Fragment>
            );
          })}
        </Box>

        {/* Drag Overlay */}
        <DragOverlay>
          {activeTask ? (
            <TaskCard
              task={activeTask}
              onClick={() => {}}
              style={{ boxShadow: planAiShadows.lg, transform: 'rotate(3deg)' }}
            />
          ) : null}
        </DragOverlay>
      </DndContext>

      {/* 카드 우클릭 / 더보기 메뉴 — 상위 작업 연결 해제 */}
      <Menu
        open={!!taskMenu}
        onClose={() => setTaskMenu(null)}
        anchorReference="anchorPosition"
        anchorPosition={taskMenu ? taskMenu.anchor : undefined}
      >
        <MuiMenuItem
          onClick={() => {
            if (taskMenu) {
              changeParent({
                taskId: taskMenu.task.id,
                newParentId: null,
                previousParentId: taskMenu.task.parent_task_id ?? null,
                activeTitle: taskMenu.task.title,
                notify: notifyParentChange,
              });
            }
            setTaskMenu(null);
          }}
        >
          <ListItemIcon><LinkOffIcon fontSize="small" /></ListItemIcon>
          <ListItemText>상위 작업 연결 해제</ListItemText>
        </MuiMenuItem>
      </Menu>

      <WorkflowSettingsDrawer
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        projectId={projectId}
      />
    </Box>
  );
};

export default BoardView;
