// src/features/project/VisionReportTestPanel.tsx
// super_admin 전용 "프로젝트 단위 이미지 포함 AI Report" PoC.
// 기존 텍스트 종합보고서/AI 자유질문과 완전히 분리. 결과는 저장되지 않는다.
//
// UX 의도: 이미지를 하나하나 고르는 도구가 아니라, 버튼 하나로 프로젝트의 텍스트 +
// Task/작업노트 이미지를 자동으로 함께 분석해 "이미지 포함 종합 보고서"를 생성한다.
// 후보 이미지 목록/수동선택은 고급 설정(접기 영역)으로만 노출한다.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Alert,
  Button,
  Chip,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Checkbox,
  Collapse,
  Divider,
  ToggleButton,
  ToggleButtonGroup,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from '@mui/material';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import SummarizeIcon from '@mui/icons-material/Summarize';
import AssignmentIcon from '@mui/icons-material/Assignment';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import InsightsIcon from '@mui/icons-material/Insights';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';
import ImageSearchIcon from '@mui/icons-material/ImageSearch';

import { api } from '../../api/client';
import {
  AiManifestImage,
  VisionReportTestMeta,
  VisionReportTestResponse,
  VisionProjectReport,
  VisionStatusBreakdown,
  VisionFeaturedEvidence,
  VisionTaskVisualImage,
} from '../../api/client';

const asArr = <T,>(v: any): T[] => (Array.isArray(v) ? v : []);
const asStrArr = (v: any): string[] => asArr<any>(v).map(x => String(x).trim()).filter(Boolean);

/* ─────────────────────────────────────────────────────────────
   사용자 화면 문구 정리 — 내부 파이프라인 용어 제거(스펙 §2).
   모델이 프롬프트의 "Stage 1/Stage 2/evidence/schema/fallback" 를 따라 써서
   사용자 화면에 노출되는 문제를 방지한다. 개발자 접기 영역(raw/evidence)은 이
   함수를 거치지 않으므로 내부 용어를 그대로 볼 수 있다.
───────────────────────────────────────────────────────────── */
const HUMANIZE_FALLBACK_SENTENCE =
  '이미지에서 확인 가능한 근거가 제한적이어서 작업노트와 텍스트 내용을 중심으로 판단했습니다.';
function humanizeInternalTerms(input?: string | null): string {
  const s = (input || '').trim();
  if (!s) return '';
  // "Stage N …" 처럼 파이프라인 단계를 언급하며 근거 부족을 설명하는 문장은
  // 통째로 사용자 친화 문장으로 대체(가장 흔한 누출 패턴).
  if (/stage\s*\d/i.test(s)) return HUMANIZE_FALLBACK_SENTENCE;
  // 그 외 흩어진 내부 토큰만 부드럽게 치환.
  return s
    .replace(/\bevidence\b/gi, '이미지 근거')
    .replace(/\bschema\b/gi, '항목')
    .replace(/\bfallback\b/gi, '대체 처리')
    .replace(/\s{2,}/g, ' ')
    .trim();
}
const humanizeArr = (arr: string[]): string[] => arr.map(humanizeInternalTerms).filter(Boolean);

/* ─────────────────────────────────────────────────────────────
   문장 → 포인트(bullet) 정규화.
   모델이 배열을 주면 그대로, 긴 문단(문자열)을 주면 문장 단위로 쪼갠다.
   (백엔드도 동일 정규화를 하지만, legacy 문자열 필드 fallback 으로 한 번 더)
───────────────────────────────────────────────────────────── */
function splitKoreanSentences(text: string, max = 6): string[] {
  const t = (text || '').trim();
  if (!t) return [];
  // 한국어 종결 어미 뒤 공백 → 줄바꿈, 마침표/물음표/느낌표 뒤 공백 → 줄바꿈
  const marked = t
    .replace(/^[\s•\-*·]+/, '')
    .replace(/(습니다|됩니다|입니다|합니다|니다|했다|된다|이다|였다|있다|없다|필요|예정|완료|진행)(\s+)/g, '$1\n')
    .replace(/([.!?。])\s+/g, '$1\n');
  const raw = marked
    .split(/\n+/)
    .map(s => s.trim().replace(/^[•\-*·]+\s*/, ''))
    .filter(Boolean);
  const merged: string[] = [];
  for (const seg of raw) {
    if (merged.length && seg.length < 6) merged[merged.length - 1] = `${merged[merged.length - 1]} ${seg}`;
    else merged.push(seg);
  }
  return merged.slice(0, max);
}

// 배열이면 정리, 문자열이면 문장 분리. (fallbackStr: 구 스키마의 단일 문자열 필드)
function toPoints(value: any, fallbackStr?: string, max = 6): string[] {
  if (Array.isArray(value) && value.length) return humanizeArr(asStrArr(value).slice(0, max));
  if (typeof value === 'string' && value.trim()) return humanizeArr(splitKoreanSentences(value, max));
  if (fallbackStr && fallbackStr.trim()) return humanizeArr(splitKoreanSentences(fallbackStr, max));
  return [];
}

// 앞 배열이 비어 있으면 뒤 배열로 fallback (detailed → brief).
function firstNonEmpty(primary: string[], fallback: string[]): string[] {
  return primary.length ? primary : fallback;
}

// Task id/title 매칭용 normalize — number/string 혼용, 대소문자/공백 흡수(스펙 §4).
const nkey = (v: unknown): string => (v === null || v === undefined ? '' : String(v).trim());
const ntitle = (v: unknown): string =>
  v === null || v === undefined ? '' : String(v).trim().toLowerCase();

/* ─────────────────────────────────────────────────────────────
   Vision 보고서 View Model — 구조/사실은 DB(base), 분석은 포인트 배열.
   buildVisionEnhancedReportViewModel: 서버 report → 렌더용 VM(누락 방어).
───────────────────────────────────────────────────────────── */
// 인수인계 상세 보기용 — Task 에 연결된 이미지 1장(대표/추가 공통). 렌더 정책은 ViewMode 로만 판단.
type VisualImageVM = {
  imageId: string;
  isFeatured: boolean;
  caption: string;
  judgment: string;
  confidence: string;
  role: string;
  rendered: boolean;
  hiddenReason?: string | null;
};

type TaskVM = {
  taskId?: number | string;
  title: string;
  status?: string;
  priority?: string;
  progress?: number | string;
  dueDate?: string | null;
  assignees: string[];
  subProject?: string | null;
  imageCount: number;
  noteCount: number;
  urlCount: number;
  fileCount: number;
  summaryPoints: string[];
  riskPoints: string[];
  nextActions: string[];
  hasVisual: boolean;
  visualPoints: string[];
  visualConfidence?: string | null;
  visualLimitations: string[];
  featuredImageId?: string | null;
  // Task 카드 내부 시각 근거(주 표시 위치)
  visualCaption: string;
  visualJudgment: string;
  additionalImageCount: number;
  additionalSummary: string;
  // 인수인계 상세 보기용 포인트(비면 brief 값으로 fallback)
  detailContextPoints: string[];
  detailSummaryPoints: string[];
  detailRiskPoints: string[];
  detailNextActions: string[];
  detailVisualPoints: string[];
  handoverNotes: string[];
  // 서버가 결정론적으로 내려준 Task 연결 이미지 전체(대표 우선). 상세 모드 렌더의 기준.
  visualImages: VisualImageVM[];
};

type ProjectReportVM = {
  overview: {
    title: string;
    description: string;
    team: string[];
    overallProgress?: number;
    statusBreakdown?: VisionStatusBreakdown;
    summaryPoints: string[];
    keyMessage: string;
    decisionPoint: string;
  };
  tasks: TaskVM[];
  attachments: { taskId?: number | string; taskTitle: string; urls: string[]; files: string[]; imageCount: number }[];
  overall: { summaryPoints: string[]; keyPoints: string[]; visualInsights: string[]; riskPoints: string[] };
  nextSteps: { summaryPoints: string[]; actions: string[] };
  featured: VisionFeaturedEvidence[];
  nonFeatured: {
    count: number;
    summary: string;
    groupedByTask: { taskTitle: string; count: number; roles: string[] }[];
  };
  debug?: VisionProjectReport['debug_metrics'];
  meta: {
    model?: string;
    imagesTotal?: number;
    imagesAnalyzed?: number;
    imagesFailed?: number;
    imagesExcluded?: number;
    batches?: number;
    uncertaintyNotes: string[];
    validationNotes: string[];
  };
};

function buildVisionEnhancedReportViewModel(
  r: VisionProjectReport | null | undefined
): ProjectReportVM | null {
  if (!r || typeof r !== 'object') return null;
  const ov = r.project_overview || {};
  const oa = r.overall_analysis || {};
  const ns = r.next_steps || {};
  const nf = r.non_featured_visual_summary || {};
  const meta = r.vision_poc_meta || {};

  const tasks: TaskVM[] = asArr<any>(r.task_analysis).map(t => ({
    taskId: t.task_id,
    title: (t.task_title || '').trim() || '(제목 없음)',
    status: t.status,
    priority: t.priority,
    progress: t.progress,
    dueDate: t.due_date,
    assignees: asStrArr(t.assignees),
    subProject: t.sub_project,
    imageCount: typeof t.image_count === 'number' ? t.image_count : 0,
    noteCount: typeof t.note_count === 'number' ? t.note_count : 0,
    urlCount: typeof t.url_count === 'number' ? t.url_count : 0,
    fileCount: typeof t.file_count === 'number' ? t.file_count : 0,
    summaryPoints: toPoints(t.summary_points, t.summary),
    riskPoints: toPoints(t.risk_points, t.risk_or_issue),
    nextActions: toPoints(t.next_actions, t.next_action),
    hasVisual: !!t.has_visual_evidence || !!t.featured_image_id || (t.image_count || 0) > 0,
    visualPoints: toPoints(t.visual_evidence_summary_points, t.visual_evidence_summary, 5),
    visualConfidence: t.visual_evidence_confidence || null,
    visualLimitations: toPoints(t.visual_evidence_limitations, undefined, 3),
    featuredImageId: t.featured_image_id ?? null,
    visualCaption: humanizeInternalTerms(t.visual_evidence_caption),
    visualJudgment: humanizeInternalTerms(t.visual_evidence_judgment_meaning),
    additionalImageCount:
      typeof t.additional_image_count === 'number'
        ? t.additional_image_count
        : Math.max(0, (typeof t.image_count === 'number' ? t.image_count : 0) - (t.featured_image_id ? 1 : 0)),
    additionalSummary: humanizeInternalTerms(t.additional_visual_evidence_summary),
    // 상세 보기 포인트 — detailed 가 비면 brief(최상위) 값으로 fallback(빈 상세 방지).
    detailContextPoints: toPoints(t.detailed?.context_points),
    detailSummaryPoints: firstNonEmpty(
      toPoints(t.detailed?.summary_points, undefined, 8),
      toPoints(t.summary_points, t.summary)
    ),
    detailRiskPoints: firstNonEmpty(
      toPoints(t.detailed?.risk_points),
      toPoints(t.risk_points, t.risk_or_issue)
    ),
    detailNextActions: firstNonEmpty(
      toPoints(t.detailed?.next_actions),
      toPoints(t.next_actions, t.next_action)
    ),
    detailVisualPoints: firstNonEmpty(
      toPoints(t.detailed?.visual_evidence_summary_points, undefined, 6),
      toPoints(t.visual_evidence_summary_points, t.visual_evidence_summary, 6)
    ),
    handoverNotes: toPoints(t.detailed?.handover_notes),
    // 서버 결정론적 이미지 목록(스펙 §4). caption/판단 의미는 사용자 문구 정리 적용.
    visualImages: asArr<VisionTaskVisualImage>(t.visual_evidence?.images).map(im => ({
      imageId: String(im.image_id),
      isFeatured: !!im.is_featured,
      caption: humanizeInternalTerms(im.caption),
      judgment: humanizeInternalTerms(im.judgment_meaning),
      confidence: (im.confidence || '').trim(),
      role: (im.role || '').trim(),
      rendered: im.rendered !== false,
      hiddenReason: im.hidden_reason ?? null,
    })).filter(im => im.imageId),
  }));

  return {
    overview: {
      title: (ov.title || '').trim(),
      description: (ov.description || '').trim(),
      team: asStrArr(ov.team),
      overallProgress: typeof ov.overall_progress === 'number' ? ov.overall_progress : undefined,
      statusBreakdown: ov.status_breakdown,
      summaryPoints: toPoints(ov.summary_points, ov.summary),
      keyMessage: (ov.key_message || '').trim(),
      decisionPoint: (ov.decision_point || '').trim(),
    },
    tasks,
    attachments: asArr<any>(r.attachment_summary).map(a => ({
      taskId: a.task_id,
      taskTitle: (a.task_title || a.filename_or_source || '').trim(),
      urls: asStrArr(a.urls),
      files: asStrArr(a.files),
      imageCount: typeof a.image_count === 'number' ? a.image_count : 0,
    })),
    overall: {
      summaryPoints: toPoints(oa.summary_points, oa.summary),
      keyPoints: toPoints(oa.key_points),
      visualInsights: toPoints((oa as any).visual_insights ?? oa.visual_evidence_insights),
      riskPoints: toPoints((oa as any).risk_points ?? oa.risk_or_uncertainty),
    },
    nextSteps: {
      summaryPoints: toPoints(ns.summary_points, ns.summary),
      actions: toPoints(ns.actions, undefined, 8),
    },
    featured: asArr<VisionFeaturedEvidence>(r.featured_visual_evidence),
    nonFeatured: {
      count: typeof nf.count === 'number' ? nf.count : 0,
      summary: (nf.summary || '').trim(),
      groupedByTask: asArr<any>(nf.grouped_by_task).map(g => ({
        taskTitle: (g.task_title || '').trim() || '기타',
        count: typeof g.count === 'number' ? g.count : 0,
        roles: asStrArr(g.roles),
      })),
    },
    debug: r.debug_metrics,
    meta: {
      model: meta.model,
      imagesTotal: meta.images_total,
      imagesAnalyzed: meta.images_analyzed ?? meta.images_used,
      imagesFailed: meta.images_failed,
      imagesExcluded: meta.images_excluded,
      batches: meta.batches,
      uncertaintyNotes: asStrArr(meta.uncertainty_notes),
      validationNotes: asStrArr(meta.validation_notes),
    },
  };
}

/* ─────────────────────────────────────────────────────────────
   대표 이미지 표시 — image_id 로만 안전 로딩(preview endpoint).
   storage path/base64 를 프론트에 노출하지 않는다. PDF 캡처 안정성을 위해
   blob → dataURL 로 변환해 캐시한다(html2canvas 가 그대로 그릴 수 있음).
───────────────────────────────────────────────────────────── */
const EvidenceImage: React.FC<{
  imageId?: string | null;
  src?: string;
  failed?: boolean;
  requestImage: (id: string) => void;
  maxHeight?: number;
  alt?: string;
}> = ({ imageId, src, failed, requestImage, maxHeight = 220, alt }) => {
  useEffect(() => {
    if (imageId && !src && !failed) requestImage(String(imageId));
  }, [imageId, src, failed, requestImage]);
  if (!imageId) return null;
  if (failed) {
    return (
      <Box
        sx={{
          height: 64,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 2,
          bgcolor: '#F3F4F6',
          color: '#9CA3AF',
          fontSize: '0.72rem',
        }}
      >
        이미지를 불러오지 못했습니다
      </Box>
    );
  }
  if (!src) {
    return (
      <Box
        sx={{
          height: maxHeight,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 2,
          bgcolor: '#F8FAFC',
          border: '1px solid #EEF2F7',
        }}
      >
        <CircularProgress size={18} />
      </Box>
    );
  }
  return (
    <Box
      component="img"
      src={src}
      alt={alt || String(imageId)}
      sx={{
        display: 'block',
        maxWidth: '100%',
        maxHeight,
        width: 'auto',
        borderRadius: 2,
        border: '1px solid #E5E7EB',
        objectFit: 'contain',
        bgcolor: '#fff',
      }}
    />
  );
};

// "이미지 근거 반영" 마커 (Task/종합 카드 안에서 시각 자료가 쓰였음을 작게 표시)
const VisualEvidenceTag: React.FC<{ label?: string }> = ({ label = '이미지 근거 반영' }) => (
  <Chip
    icon={<ImageSearchIcon sx={{ fontSize: '0.8rem !important' }} />}
    size="small"
    label={label}
    sx={{ height: 20, fontSize: '0.62rem', bgcolor: '#F3E8FF', color: '#8B5CF6', fontWeight: 700 }}
  />
);

// Task 표 "근거" 컬럼 — 📷 이미지 · 📝 작업노트 · 🔗 URL 수. 0 인 유형은 생략.
const EvidenceBadges: React.FC<{ image: number; note: number; url: number; file?: number }> = ({
  image,
  note,
  url,
  file = 0,
}) => {
  const parts: string[] = [];
  if (image) parts.push(`📷 ${image}`);
  if (note) parts.push(`📝 ${note}`);
  if (url) parts.push(`🔗 ${url}`);
  if (file) parts.push(`📎 ${file}`);
  return (
    <Box sx={{ display: 'flex', gap: 0.6, flexWrap: 'wrap' }}>
      {parts.length ? (
        parts.map((p, i) => (
          <Box
            key={i}
            sx={{
              fontSize: '0.66rem',
              fontWeight: 700,
              color: '#4B5563',
              bgcolor: '#F3F4F6',
              borderRadius: 1,
              px: 0.6,
              py: 0.1,
              whiteSpace: 'nowrap',
            }}
          >
            {p}
          </Box>
        ))
      ) : (
        <Typography sx={{ fontSize: '0.7rem', color: '#9CA3AF' }}>-</Typography>
      )}
    </Box>
  );
};

// 기존 AI Report 와 동일한 카드 컨테이너(Paper + 섹션 헤더)
const SectionCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
  className?: string;
}> = ({ icon, title, children, className = 'report-card' }) => (
  <Paper
    className={className}
    sx={{
      p: 3,
      mb: 2.5,
      borderRadius: 3,
      border: '1px solid rgba(0,0,0,0.08)',
      bgcolor: 'rgba(255,255,255,0.7)',
      backdropFilter: 'blur(8px)',
      boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
    }}
  >
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
      {icon}
      <Typography variant="h6" sx={{ fontWeight: 700, color: '#1A1D29', fontSize: '1rem' }}>
        {title}
      </Typography>
    </Box>
    {children}
  </Paper>
);

// 분석 포인트(bullet) 렌더 — 한 줄에 한 문장. 긴 문단을 이어 쓰지 않는다.
const BulletList: React.FC<{ title?: string; items: string[]; color?: string; tag?: React.ReactNode }> = ({
  title,
  items,
  color = '#374151',
  tag,
}) =>
  items.length > 0 ? (
    <Box sx={{ mb: 1.5 }}>
      {title && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.7, mb: 0.4 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1A1D29' }}>
            {title}
          </Typography>
          {tag}
        </Box>
      )}
      <Box component="ul" sx={{ m: 0, pl: 2.2 }}>
        {items.map((it, i) => (
          <Box component="li" key={i} sx={{ fontSize: '0.83rem', color, lineHeight: 1.65, mb: 0.2 }}>
            {it}
          </Box>
        ))}
      </Box>
    </Box>
  ) : null;

const STATUS_COLOR: Record<string, string> = {
  done: '#22C55E',
  in_progress: '#2955FF',
  todo: '#6B7280',
  hold: '#F59E0B',
};
const STATUS_LABEL: Record<string, string> = {
  done: 'Done',
  in_progress: 'In Progress',
  todo: 'To Do',
  hold: 'Hold',
};
const PRIORITY_COLOR: Record<string, string> = { high: '#EF4444', medium: '#F59E0B', low: '#22C55E' };

// 개발자용 raw 텍스트 블록(접기 영역)
const RawPre: React.FC<{ label: string; text: string }> = ({ label, text }) => (
  <Box sx={{ mb: 1.5 }}>
    <Typography variant="caption" sx={{ color: '#6B7280', fontWeight: 700, display: 'block', mb: 0.5 }}>
      {label}
    </Typography>
    <Box
      component="pre"
      sx={{
        p: 1.5,
        bgcolor: '#0F172A',
        color: '#E2E8F0',
        borderRadius: 2,
        fontSize: '0.72rem',
        overflowX: 'auto',
        whiteSpace: 'pre-wrap',
        maxHeight: 320,
      }}
    >
      {text}
    </Box>
  </Box>
);

interface Props {
  projectId: number;
  userId: number;
}

const INPUT_MODE_LABELS: Record<string, string> = {
  image_only: 'A. image_only',
  image_with_nearby_text: 'B. image_with_nearby_text',
  image_with_evidence_card: 'C. image_with_evidence_card',
};
const SCOPE_LABELS: Record<string, string> = {
  task_images_all: '프로젝트 Task/작업노트 이미지 전체 (기본)',
  auto: '자동 우선순위 (상위 N장)',
  review_needed: '검토 필요 이미지만',
  selected: '선택한 이미지',
};

const TASK_IMAGE_SOURCES = ['task_description', 'task_activity', 'task_attachment'];

const truncate = (s?: string | null, n = 60) => {
  const t = (s || '').trim();
  return t.length > n ? t.slice(0, n) + '…' : t;
};

// 실패 시 사용자 화면에는 짧은 메시지 + Request ID 안내만 보여준다(§10). 상세 진단은
// 관리자 → 시스템 로그 → 해당 Request ID 로 확인한다. 모든 응답 헤더 X-Request-ID 를 사용.
const formatVisionRunError = (err: any, fallbackMsg: string): string => {
  const base = err?.response?.data?.detail || err?.message || fallbackMsg;
  const reqId = err?.response?.headers?.['x-request-id'];
  return reqId ? `${base}\n시스템 로그에서 Request ID ${reqId} 를 확인하세요.` : base;
};

const VisionReportTestPanel: React.FC<Props> = ({ projectId, userId }) => {
  const [meta, setMeta] = useState<VisionReportTestMeta | null>(null);
  const [metaError, setMetaError] = useState<string | null>(null);

  const [model, setModel] = useState('');
  // 아래 3개는 고급 설정 전용. 기본 UI 에는 노출하지 않는다.
  //   input_mode = image_with_evidence_card / scope = task_images_all(프로젝트 전체)
  //   maxImages  = null → 백엔드 안전 상한까지 전체 포함(전체 이미지 포함 UX)
  const [inputMode, setInputMode] = useState('image_with_evidence_card');
  const [scope, setScope] = useState('task_images_all');
  const [maxImages, setMaxImages] = useState<number | null>(null);

  // 고급 설정(후보 이미지 / 수동선택) 접기 영역
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [candidates, setCandidates] = useState<AiManifestImage[]>([]);
  const [candidatesLoading, setCandidatesLoading] = useState(false);
  const [candidatesLoaded, setCandidatesLoaded] = useState(false);
  const [candidatesError, setCandidatesError] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const [running, setRunning] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);
  const [result, setResult] = useState<VisionReportTestResponse | null>(null);
  const [rawOpen, setRawOpen] = useState(false);
  // ── 지연 시 텍스트 전용 fallback (Gemma4 느림 → 사용자 선택 modal) ──
  const [fallbackModalOpen, setFallbackModalOpen] = useState(false);
  const [fallbackRunning, setFallbackRunning] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const softTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // 보기 모드: 보고용 간결(brief) | 인수인계 상세(detailed). 기본 = 간결(스펙 §7).
  const [viewMode, setViewMode] = useState<'brief' | 'detailed'>('brief');
  const [pdfBusy, setPdfBusy] = useState(false);
  // PDF 캡처 동안만 true. PDF 에서만 Task 표 뒤에 "핵심 시각 근거 요약"(작은 바로가기)
  // 섹션을 추가한다. 대표 이미지는 웹/PDF 모두 Task 카드 안에서 표시한다(스펙 §4).
  const [pdfMode, setPdfMode] = useState(false);

  // 대표 이미지 캐시: image_id → dataURL. 실패한 id 는 imageFailed 에 기록.
  const [imageCache, setImageCache] = useState<Record<string, string>>({});
  const [imageFailed, setImageFailed] = useState<Record<string, boolean>>({});
  const requestedRef = useRef<Set<string>>(new Set());
  const reportRef = useRef<HTMLDivElement>(null);

  const hardMax = meta?.hard_max_images ?? 40;

  // image_id 1장을 preview endpoint 로 로딩 → dataURL 캐시(중복 요청 방지).
  const loadImage = useCallback(
    (imageId: string) => {
      if (!imageId || requestedRef.current.has(imageId)) return;
      requestedRef.current.add(imageId);
      api
        .getProjectAiContextPreviewImage(projectId, imageId, userId)
        .then(
          blob =>
            new Promise<string>((resolve, reject) => {
              const fr = new FileReader();
              fr.onload = () => resolve(fr.result as string);
              fr.onerror = () => reject(new Error('read failed'));
              fr.readAsDataURL(blob);
            })
        )
        .then(dataUrl => setImageCache(prev => ({ ...prev, [imageId]: dataUrl })))
        .catch(() => setImageFailed(prev => ({ ...prev, [imageId]: true })));
    },
    [projectId, userId]
  );

  // meta 로드 (모델/제한/기본값)
  useEffect(() => {
    let cancelled = false;
    api
      .getVisionReportTestMeta(projectId, userId)
      .then(m => {
        if (cancelled) return;
        setMeta(m);
        // default_model 이 목록에 있으면 그것을, 아니면 목록 첫 번째.
        const dm = m.default_model && m.models.includes(m.default_model) ? m.default_model : m.models[0];
        if (dm) setModel(prev => prev || dm);
        if (m.default_input_mode) setInputMode(m.default_input_mode);
        if (m.default_image_scope) setScope(m.default_image_scope);
        // max_images 는 기본값으로 두지 않는다(null = 전체). 고급 설정에서만 명시.
      })
      .catch(err => {
        if (!cancelled)
          setMetaError(err?.response?.data?.detail || err.message || 'meta 로드 실패');
      });
    return () => {
      cancelled = true;
    };
  }, [projectId, userId]);

  // 후보 이미지는 고급 설정을 처음 펼칠 때만 lazy 로드 (메인 흐름엔 불필요)
  const loadCandidates = React.useCallback(() => {
    setCandidatesLoading(true);
    setCandidatesError(null);
    api
      .getProjectAiContextPreview(projectId, userId, { include_images: true, max_images: 100 })
      .then(res => {
        const imgs = (res.image_manifest || []).filter(im =>
          TASK_IMAGE_SOURCES.includes(im.source_entity_type || '')
        );
        setCandidates(imgs);
        setCandidatesLoaded(true);
      })
      .catch(err => {
        setCandidatesError(err?.response?.data?.detail || err.message || '후보 이미지 로드 실패');
      })
      .finally(() => setCandidatesLoading(false));
  }, [projectId, userId]);

  const toggleAdvanced = () => {
    const next = !advancedOpen;
    setAdvancedOpen(next);
    if (next && !candidatesLoaded && !candidatesLoading) loadCandidates();
  };

  const toggleId = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAll = () => setSelectedIds(new Set(candidates.map(c => c.image_id)));
  const clearSelection = () => setSelectedIds(new Set());

  const selectReviewNeeded = async () => {
    try {
      const res = await api.getProjectAiContextPreview(projectId, userId, {
        include_images: true,
        max_images: 100,
        image_scope: 'review_needed',
      });
      const ids = new Set(
        (res.image_manifest || [])
          .filter(im => TASK_IMAGE_SOURCES.includes(im.source_entity_type || ''))
          .map(im => im.image_id)
      );
      setSelectedIds(ids);
    } catch (err: any) {
      setCandidatesError(err?.response?.data?.detail || err.message || 'review_needed 조회 실패');
    }
  };

  const selectedCount = selectedIds.size;
  // 수동 선택이 있으면 그 이미지로(selected), 없으면 scope 기준 자동.
  const effectiveScope = selectedCount > 0 ? 'selected' : scope;

  // soft timeout(초) — 이 시간 초과 시 사용자 선택 modal 표시. 미설정 시 60.
  const softTimeoutSec = meta?.soft_timeout_seconds ?? 60;
  const fallbackEnabled = meta?.fallback_text_enabled ?? false;
  const fallbackModelName = meta?.fallback_text_model || '';

  const clearSoftTimer = () => {
    if (softTimerRef.current) {
      clearTimeout(softTimerRef.current);
      softTimerRef.current = null;
    }
  };

  const handleRun = async () => {
    setRunning(true);
    setRunError(null);
    setResult(null);
    setFallbackModalOpen(false);
    // 이전 실행의 대표 이미지 캐시 초기화(이미지 id 가 달라질 수 있음).
    setImageCache({});
    setImageFailed({});
    requestedRef.current = new Set();

    // AbortController — fallback/취소 시 진행 중 Vision 요청 중단.
    const controller = new AbortController();
    abortRef.current = controller;
    // soft timeout 타이머 — 초과 & 아직 진행 중이면 사용자 선택 modal 표시.
    clearSoftTimer();
    softTimerRef.current = setTimeout(() => {
      setFallbackModalOpen(true);
    }, Math.max(1, softTimeoutSec) * 1000);

    try {
      const res = await api.runVisionReportTest(
        projectId,
        {
          user_id: userId,
          model: model || undefined,
          // provider 는 Vision AI 설정(서버)이 결정한다. 여기선 전달만(서버가 무시/우선).
          provider: meta?.provider || 'openai',
          // 고급 설정값(미변경 시 백엔드 기본값과 동일). max_images=null → 전체 포함.
          input_mode: inputMode,
          image_scope: scope,
          max_images: maxImages,
          image_ids: Array.from(selectedIds),
          include_text_context: true,
          include_image_evidence: true,
          save_result: false,
        },
        controller.signal
      );
      setResult(res);
      setFallbackModalOpen(false);
    } catch (err: any) {
      // 사용자가 fallback/취소로 중단한 경우(CanceledError)는 에러로 표시하지 않는다.
      const canceled =
        err?.name === 'CanceledError' || err?.code === 'ERR_CANCELED' || err?.message === 'canceled';
      if (!canceled) {
        setRunError(formatVisionRunError(err, 'Vision 보고서 테스트 실행 실패'));
        setFallbackModalOpen(false);
      }
    } finally {
      clearSoftTimer();
      abortRef.current = null;
      setRunning(false);
    }
  };

  // 모달: "계속 기다리기" — Gemma4 요청 유지, modal 닫기만.
  const handleKeepWaiting = () => setFallbackModalOpen(false);

  // 모달: "GPT-OSS로 텍스트 전용 생성" — Vision 요청 중단 후 텍스트 전용 fallback 실행.
  const handleUseTextFallback = async () => {
    setFallbackModalOpen(false);
    clearSoftTimer();
    // 진행 중 Vision 요청 중단(가능하면). 중단이 안 돼도 아래 결과로 덮어쓴다.
    abortRef.current?.abort();
    abortRef.current = null;
    setRunning(false);
    setFallbackRunning(true);
    setRunError(null);
    try {
      const res = await api.runVisionTextFallbackReport(projectId, {
        user_id: userId,
        source: 'vision_timeout_user_selected',
        user_choice: 'text_only_fallback',
      });
      setResult(res);
    } catch (err: any) {
      setRunError(formatVisionRunError(err, '텍스트 전용 보고서 생성 실패'));
    } finally {
      setFallbackRunning(false);
    }
  };

  // 모달: "취소" — 요청 취소, 결과 미표시.
  const handleCancelRun = () => {
    setFallbackModalOpen(false);
    clearSoftTimer();
    abortRef.current?.abort();
    abortRef.current = null;
    setRunning(false);
  };

  // 언마운트 시 타이머/요청 정리.
  useEffect(() => {
    return () => {
      clearSoftTimer();
      abortRef.current?.abort();
    };
  }, []);

  // fallback(텍스트 전용) 결과 여부 — badge/notice 표시용.
  const isTextOnlyFallback = result?.report_mode === 'text_only_fallback';

  // 서버 report(구조=DB / 분석=모델 포인트)를 렌더용 VM 으로 normalize.
  const report = useMemo<ProjectReportVM | null>(
    () => buildVisionEnhancedReportViewModel(result?.report || null),
    [result?.report]
  );
  const evidence = result?.image_evidence_summaries || [];
  const openaiConfigured = meta?.openai_configured ?? true;
  // dsllm(사내) provider 는 OpenAI key 가 필요 없다 — openai provider 일 때만 key 게이트.
  const needsOpenai = (meta?.provider || 'openai') === 'openai';

  // Task 카드 대표 이미지 fallback(프론트 안전망, 스펙 §3·§5): 백엔드가 featured_image_id 를
  // 채우면 그대로 쓰되, 비어 있으면 featured_visual_evidence → image_evidence_summaries 에서
  // task_id/title 매칭으로 최선의 image_id 를 찾는다. featured_image_id 만 믿지 않는다.
  const resolveTaskImageId = useCallback(
    (t: TaskVM): string | null => {
      if (t.featuredImageId) return String(t.featuredImageId);
      const tid = nkey(t.taskId);
      const ttl = ntitle(t.title);
      // featured_visual_evidence 중 task_id/title 일치
      const feat = (report?.featured || []).find(
        f => (tid && nkey(f.task_id) === tid) || (ttl && ntitle(f.task_title) === ttl)
      );
      if (feat?.image_id) return String(feat.image_id);
      // image_evidence_summaries 중 task_id 일치, 없으면 title 일치(relevance high/medium)
      const byId = evidence.find(e => tid && nkey(e.task_id) === tid && e.image_id);
      if (byId?.image_id) return String(byId.image_id);
      const byTitle = evidence.find(
        e =>
          ttl &&
          ntitle(e.task_title) === ttl &&
          e.image_id &&
          ['high', 'medium', '강', '높음', '중', '보통'].includes(String(e.task_relevance || '').toLowerCase())
      );
      return byTitle?.image_id ? String(byTitle.image_id) : null;
    },
    [report?.featured, evidence]
  );

  // 인수인계 상세 모드용 — 해당 Task 가 참고한 이미지 id 를 대표부터 순서대로 모두 수집(중복 제거).
  // (구 경로 fallback) featured_visual_evidence + image_evidence_summaries 를 task_id/title 로 매칭.
  const DETAILED_MAX_IMAGES = 6;
  const resolveTaskImageIds = useCallback(
    (t: TaskVM): string[] => {
      const ids: string[] = [];
      const push = (id?: string | null) => {
        const s = id ? String(id) : '';
        if (s && !ids.includes(s)) ids.push(s);
      };
      push(resolveTaskImageId(t)); // 대표 이미지 우선
      const tid = nkey(t.taskId);
      const ttl = ntitle(t.title);
      (report?.featured || []).forEach(f => {
        if ((tid && nkey(f.task_id) === tid) || (ttl && ntitle(f.task_title) === ttl)) push(f.image_id);
      });
      evidence.forEach(e => {
        if ((tid && nkey(e.task_id) === tid) || (ttl && ntitle(e.task_title) === ttl)) push(e.image_id);
      });
      return ids;
    },
    [resolveTaskImageId, report?.featured, evidence]
  );

  // ViewMode 결정론 이미지 목록(스펙 §2·§4): 서버가 내려준 visualImages(rendered)를 그대로 쓰고,
  // 비어 있을 때만 구 프론트 resolve(featured+evidence)로 fallback. 모델 응답이 아니라 이 목록만 렌더한다.
  const getTaskVisualImages = useCallback(
    (t: TaskVM): VisualImageVM[] => {
      const rendered = (t.visualImages || []).filter(im => im.rendered && im.imageId);
      if (rendered.length) return rendered;
      // fallback — 구 경로. 대표 이미지를 featured 로 표시.
      return resolveTaskImageIds(t).map((id, idx) => ({
        imageId: id,
        isFeatured: idx === 0,
        caption: idx === 0 ? t.visualCaption : '',
        judgment: idx === 0 ? t.visualJudgment : '',
        confidence: t.visualConfidence || '',
        role: '',
        rendered: true,
        hiddenReason: null,
      }));
    },
    [resolveTaskImageIds]
  );

  // 결과가 오면 대표 + 상세 모드에서 보일 이미지(Task당 최대 DETAILED_MAX_IMAGES장)를 미리 로딩 → 화면/PDF 동시 대비.
  useEffect(() => {
    if (!report) return;
    report.featured.forEach(f => f.image_id && loadImage(String(f.image_id)));
    report.tasks.forEach(t => {
      getTaskVisualImages(t).slice(0, DETAILED_MAX_IMAGES).forEach(im => loadImage(im.imageId));
    });
  }, [report, loadImage, getTaskVisualImages]);

  // PDF 다운로드: 대표 이미지가 실제 이미지로 포함된 보고서 영역만 캡처.
  // page-break-inside: avoid (CSS) 로 카드/이미지가 페이지 경계에서 잘리지 않게 한다.
  const handleDownloadPdf = async () => {
    if (!reportRef.current) return;
    setPdfBusy(true);
    // PDF 전용 순서/중복제거를 적용한 뒤 다음 페인트까지 기다렸다가 캡처.
    setPdfMode(true);
    await new Promise<void>(resolve =>
      requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
    );
    try {
      const html2pdf = (await import('html2pdf.js')).default;
      await html2pdf()
        .set({
          margin: 10,
          filename: `vision_report_${projectId}.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, useCORS: true },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
          // html2pdf.js 타입에는 없지만 런타임 지원 — 카드/이미지가 페이지 경계에서 잘리지 않게.
          pagebreak: { mode: ['css', 'legacy'], avoid: ['.report-card', '.visual-evidence-card', '.task-visual-evidence', '.task-visual-evidence-item'] },
        } as any)
        .from(reportRef.current)
        .save();
    } catch {
      setRunError('PDF 생성에 실패했습니다.');
    } finally {
      setPdfMode(false);
      setPdfBusy(false);
    }
  };

  const usageText = useMemo(() => {
    const u = result?.usage;
    if (!u) return '';
    const parts: string[] = [];
    if (u.input_tokens != null) parts.push(`in ${u.input_tokens}`);
    if (u.output_tokens != null) parts.push(`out ${u.output_tokens}`);
    if (u.total_tokens != null) parts.push(`total ${u.total_tokens}`);
    return parts.join(' / ');
  }, [result?.usage]);

  return (
    <Box>
      {/* 헤더 */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
        <AutoAwesomeIcon sx={{ color: '#8B5CF6', fontSize: '1.8rem' }} />
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 800, color: '#1A1D29' }}>
            Vision Report 테스트
          </Typography>
          <Typography variant="body2" sx={{ color: '#6B7280', fontSize: '0.8rem' }}>
            버튼 하나로 프로젝트의 텍스트와 Task/작업노트 이미지를 함께 분석해 이미지 포함 종합
            보고서를 생성합니다.
          </Typography>
        </Box>
      </Box>

      {/* 경고 배너 */}
      <Alert severity="warning" sx={{ mb: 2, borderRadius: 2 }}>
        이 기능은 super_admin 전용 이미지 포함 AI Report PoC입니다. 기존 텍스트 기반 종합보고서
        생성에는 영향을 주지 않으며, 결과는 저장되지 않습니다. 이미지 모델 품질은 아직 검증 중이므로
        운영 보고서에 자동 반영하지 않습니다.
      </Alert>

      {meta?.using_text_fallback && (
        <Alert severity="warning" sx={{ mb: 2, borderRadius: 2 }}>
          {meta.fallback_reason ||
            'Vision 전용 모델 설정이 없어 Text AI 모델을 fallback으로 사용 중입니다. 이미지 인식이 실패할 수 있습니다.'}{' '}
          AI Settings의 Vision AI 설정에서 vision 지원 모델을 지정하세요.
        </Alert>
      )}
      {meta?.vision_enabled === false && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>
          Vision AI가 비활성화되어 있습니다. AI Settings의 Vision AI 설정에서 활성화한 뒤 사용하세요.
        </Alert>
      )}

      {metaError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {metaError}
        </Alert>
      )}
      {needsOpenai && !openaiConfigured && (
        <Alert severity="error" sx={{ mb: 2 }}>
          OpenAI API Key가 설정되어 있지 않습니다. backend env(OPENAI_API_KEY)를 설정한 뒤 사용하세요.
        </Alert>
      )}

      {/* 실행 컨트롤 (메인) — 모델 선택 + 생성 버튼만. 보고서 생성 중심. */}
      <Paper sx={{ p: 2.5, mb: 2, borderRadius: 3, border: '1px solid #E5E7EB' }}>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, alignItems: 'center' }}>
          <FormControl size="small" sx={{ minWidth: 200 }}>
            <InputLabel>모델</InputLabel>
            <Select label="모델" value={model} onChange={e => setModel(e.target.value)}>
              {(meta?.models || []).map(m => (
                <MenuItem key={m} value={m}>
                  {m}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <Button
            variant="contained"
            onClick={handleRun}
            disabled={running || fallbackRunning || (needsOpenai && !openaiConfigured)}
            startIcon={
              running || fallbackRunning ? (
                <CircularProgress size={16} color="inherit" />
              ) : (
                <AutoAwesomeIcon />
              )
            }
            sx={{ bgcolor: '#8B5CF6', borderRadius: 2, ml: 'auto', px: 2.5, fontWeight: 700 }}
          >
            {fallbackRunning
              ? '텍스트 전용 생성 중...'
              : running
                ? '보고서 생성 중...'
                : '이미지 포함 AI 보고서 생성'}
          </Button>
        </Box>
        <Typography variant="caption" sx={{ color: '#9CA3AF', mt: 1.5, display: 'block' }}>
          버튼을 누르면 프로젝트의 텍스트 맥락과 Task/작업노트 이미지를 시스템이 자동으로 수집해 함께
          분석합니다. 이미지를 직접 고를 필요가 없습니다 · super_admin 전용 PoC, 결과 저장 안 함.
        </Typography>

        {/* 고급 설정 토글 — 개발자용 옵션/후보 이미지 확인 (기본 숨김) */}
        <Divider sx={{ my: 1.5 }} />
        <Button
          size="small"
          onClick={toggleAdvanced}
          endIcon={advancedOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}
          sx={{ color: '#6B7280', textTransform: 'none' }}
        >
          고급 설정 / 사용 이미지 확인
        </Button>

        <Collapse in={advancedOpen}>
          <Box sx={{ mt: 1.5 }}>
            {/* 개발자 검증용 파라미터 — 기본값으로 두면 "프로젝트 전체 이미지 자동 포함" */}
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, alignItems: 'center', mb: 2 }}>
              <FormControl size="small" sx={{ minWidth: 220 }}>
                <InputLabel>input_mode</InputLabel>
                <Select label="input_mode" value={inputMode} onChange={e => setInputMode(e.target.value)}>
                  {(meta?.input_modes || Object.keys(INPUT_MODE_LABELS)).map(m => (
                    <MenuItem key={m} value={m}>
                      {INPUT_MODE_LABELS[m] || m}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <FormControl size="small" sx={{ minWidth: 240 }}>
                <InputLabel>이미지 범위</InputLabel>
                <Select
                  label="이미지 범위"
                  value={scope}
                  onChange={e => setScope(e.target.value)}
                  disabled={selectedCount > 0}
                >
                  {(meta?.image_scopes || Object.keys(SCOPE_LABELS)).map(s => (
                    <MenuItem key={s} value={s}>
                      {SCOPE_LABELS[s] || s}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <TextField
                size="small"
                type="number"
                label={`max_images (자동=전체, ≤${hardMax})`}
                placeholder="자동"
                value={maxImages ?? ''}
                onChange={e => {
                  const raw = e.target.value;
                  if (raw === '') return setMaxImages(null);
                  const v = parseInt(raw, 10);
                  if (Number.isNaN(v)) return setMaxImages(null);
                  setMaxImages(Math.max(1, Math.min(v, hardMax)));
                }}
                sx={{ width: 200 }}
              />
            </Box>
            <Typography variant="caption" sx={{ color: '#9CA3AF', display: 'block', mb: 1.5 }}>
              실제 전송 범위: <strong>{SCOPE_LABELS[effectiveScope] || effectiveScope}</strong>
              {selectedCount > 0 && ` (체크한 ${selectedCount}장으로 제한)`} · max_images 비우면 안전
              상한까지 전체 포함.
            </Typography>
            <Divider sx={{ mb: 1.5 }} />

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1, flexWrap: 'wrap' }}>
              <Typography variant="body2" sx={{ fontWeight: 700, color: '#374151' }}>
                후보 이미지 ({candidates.length})
              </Typography>
              <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
                — 디버깅/확인용. 체크하면 그 이미지로만 테스트(selected). 비우면 자동 선택.
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, ml: 'auto', flexWrap: 'wrap' }}>
                <Button size="small" variant="outlined" onClick={selectAll} disabled={!candidates.length}>
                  전체 선택
                </Button>
                <Button
                  size="small"
                  variant="outlined"
                  onClick={selectReviewNeeded}
                  disabled={!candidates.length}
                >
                  검토 필요만 선택
                </Button>
                <Button
                  size="small"
                  variant="outlined"
                  onClick={clearSelection}
                  disabled={!selectedCount}
                >
                  선택 해제
                </Button>
              </Box>
            </Box>

            {candidatesError && (
              <Alert severity="error" sx={{ mb: 1 }}>
                {candidatesError}
              </Alert>
            )}

            {candidatesLoading ? (
              <Box sx={{ textAlign: 'center', py: 3 }}>
                <CircularProgress size={24} />
              </Box>
            ) : candidatesLoaded && candidates.length === 0 ? (
              <Typography variant="body2" sx={{ color: '#9CA3AF', py: 2 }}>
                이 프로젝트의 Task/작업노트에서 캡처 이미지를 찾지 못했습니다.
              </Typography>
            ) : candidates.length > 0 ? (
              <TableContainer sx={{ maxHeight: 300, borderRadius: 2, border: '1px solid #F1F5F9' }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell padding="checkbox" />
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>image_id</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>task</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>role</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>context</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>추천도</TableCell>
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>nearby_text</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {candidates.map(c => (
                      <TableRow
                        key={c.image_id}
                        hover
                        onClick={() => toggleId(c.image_id)}
                        sx={{ cursor: 'pointer' }}
                      >
                        <TableCell padding="checkbox">
                          <Checkbox size="small" checked={selectedIds.has(c.image_id)} />
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.72rem', fontFamily: 'monospace' }}>
                          {c.image_id}
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.72rem' }}>
                          {c.task_id ? `#${c.task_id} ` : ''}
                          {truncate(c.task_title, 24)}
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.72rem' }}>{c.image_role || '-'}</TableCell>
                        <TableCell sx={{ fontSize: '0.72rem' }}>
                          {c.evidence_card?.context_strength || '-'}
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.72rem' }}>
                          {c.image_quality?.recommendation_level || '-'}
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.72rem', color: '#6B7280' }}>
                          {truncate(c.nearby_text || c.fallback_context_text, 48)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            ) : null}
          </Box>
        </Collapse>
      </Paper>

      {/* 지연 시 사용자 선택 modal — soft timeout 초과 시 표시(자동 전환 금지, §4·§5) */}
      <Dialog open={fallbackModalOpen} onClose={handleKeepWaiting} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 800 }}>이미지 포함 분석이 예상보다 오래 걸리고 있습니다</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ fontSize: '0.88rem', color: '#374151' }}>
            {meta?.provider === 'dsllm' ? 'Gemma4' : 'Vision 모델'}가 이미지를 분석하는 데 시간이 걸리고 있습니다.
            계속 기다리거나, {fallbackModelName || '텍스트 전용 모델'}로 텍스트 전용 보고서를 빠르게 생성할 수 있습니다.
          </DialogContentText>
          {fallbackEnabled && fallbackModelName ? (
            <Typography sx={{ fontSize: '0.75rem', color: '#9CA3AF', mt: 1.5 }}>
              텍스트 전용 보고서는 Task·작업노트·첨부 텍스트만 반영하며 캡처 이미지는 분석하지 않습니다.
              선택해도 AI 설정 값은 바뀌지 않습니다(일회성).
            </Typography>
          ) : (
            <Alert severity="info" sx={{ mt: 1.5, fontSize: '0.75rem' }}>
              텍스트 전용 fallback이 설정되어 있지 않습니다. Vision AI 설정에서 Fallback Text Model을 지정하면 이
              옵션을 사용할 수 있습니다.
            </Alert>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2, flexWrap: 'wrap', gap: 1 }}>
          <Button onClick={handleCancelRun} color="inherit" sx={{ textTransform: 'none' }}>
            취소
          </Button>
          <Box sx={{ flex: 1 }} />
          <Button onClick={handleKeepWaiting} variant="outlined" sx={{ textTransform: 'none' }}>
            계속 기다리기
          </Button>
          <Button
            onClick={handleUseTextFallback}
            variant="contained"
            disabled={!fallbackEnabled || !fallbackModelName}
            sx={{ bgcolor: '#8B5CF6', textTransform: 'none', fontWeight: 700 }}
          >
            {fallbackModelName ? `${fallbackModelName}로 텍스트 전용 생성` : '텍스트 전용 생성'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* 결과 (보고서 중심) */}
      {runError && (
        <Alert severity="error" sx={{ mb: 2, whiteSpace: 'pre-line' }}>
          {runError}
        </Alert>
      )}

      {result && (
        <Box>
          {/* 메타 줄: 이미지 분석 현황 + 모델 / 토큰 / latency + PDF */}
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2, alignItems: 'center' }}>
            <Chip size="small" label={`AI: ${result.model}`} sx={{ bgcolor: '#F3E8FF', color: '#8B5CF6', fontWeight: 700 }} />
            {isTextOnlyFallback ? (
              <>
                <Chip size="small" label="텍스트 전용 요약" sx={{ bgcolor: '#FEF3C7', color: '#B45309', fontWeight: 700 }} />
                <Chip size="small" label="이미지 미포함" sx={{ bgcolor: '#F3F4F6', color: '#6B7280', fontWeight: 700 }} />
              </>
            ) : (
              <Chip
                size="small"
                label={
                  result.images_analyzed != null && result.images_analyzed >= result.images_total
                    ? `이미지 ${result.images_total}장 전체 분석`
                    : `이미지 ${result.images_analyzed ?? result.images_used}/${result.images_total}장 분석`
                }
                sx={{ bgcolor: '#EEF2FF', color: '#2955FF', fontWeight: 700 }}
              />
            )}
            {(result.batches ?? 0) > 1 && (
              <Chip size="small" label={`batch ${result.batches}개`} sx={{ bgcolor: '#ECFEFF', color: '#0E7490' }} />
            )}
            {(result.images_failed ?? 0) > 0 && (
              <Chip
                size="small"
                label={`실패 ${result.images_failed}장`}
                sx={{ bgcolor: '#FEE2E2', color: '#B91C1C' }}
              />
            )}
            {result.images_excluded > 0 && (
              <Chip
                size="small"
                label={`후속 분석 ${result.images_excluded}장`}
                sx={{ bgcolor: '#FEF3C7', color: '#D97706' }}
              />
            )}
            <Chip size="small" label={`latency: ${result.latency_ms}ms`} />
            {usageText && <Chip size="small" label={`tokens: ${usageText}`} />}
            <Chip size="small" label="DB 저장 안 함" sx={{ bgcolor: '#F3F4F6', color: '#6B7280' }} />
            {report && (
              <Button
                size="small"
                variant="outlined"
                onClick={handleDownloadPdf}
                disabled={pdfBusy}
                startIcon={pdfBusy ? <CircularProgress size={14} /> : undefined}
                sx={{ ml: 'auto', borderColor: '#E5E7EB', color: '#374151', textTransform: 'none' }}
              >
                PDF 다운로드
              </Button>
            )}
          </Box>

          {/* 텍스트 전용 fallback 안내 — Gemma4 지연으로 GPT-OSS 텍스트 전용 보고서를 생성한 경우(§7) */}
          {isTextOnlyFallback && (
            <Alert severity="info" icon={<ImageSearchIcon fontSize="inherit" />} sx={{ mb: 2, borderRadius: 2 }}>
              <strong>{result.primary_vision_model || 'Gemma4'}</strong> 이미지 분석이 지연되어{' '}
              <strong>{result.actual_model_used || result.model}</strong> 기반 <strong>텍스트 전용 보고서</strong>로
              생성되었습니다. Task·작업노트·첨부 URL 등 텍스트 정보는 반영되었지만, 캡처 이미지 내용은 분석에 포함되지
              않았습니다.
            </Alert>
          )}

          {/* 이미지 분석 현황 요약 — 기본 UX 는 프로젝트 전체 이미지를 batch 로 모두 분석 */}
          {!isTextOnlyFallback && (
          <Alert
            severity={
              (result.images_failed ?? 0) > 0 ||
              result.images_excluded > 0 ||
              (result.truncated ?? false)
                ? 'warning'
                : 'success'
            }
            sx={{ mb: 2, borderRadius: 2 }}
          >
            프로젝트 이미지 <strong>{result.images_total}</strong>개를{' '}
            {result.images_analyzed != null && result.images_analyzed >= result.images_total
              ? '전체'
              : <><strong>{result.images_analyzed ?? result.images_used}</strong>개</>}{' '}
            분석했습니다
            {(result.batches ?? 0) > 1 && <> · batch {result.batches}개로 나눠 처리</>}
            {(result.images_failed ?? 0) > 0 && <> · 실패 {result.images_failed}개</>}
            {result.images_excluded > 0 && (
              <>
                . <strong>{result.images_excluded}</strong>장은{' '}
                {result.excluded_reason || '후속 배치 분석 대상'}
              </>
            )}
            .
          </Alert>
          )}

          {result.truncated && (
            <Alert severity="warning" sx={{ mb: 2, borderRadius: 2 }}>
              응답이 출력 길이 제한(max_output_tokens
              {result.max_output_tokens != null ? ` ${result.max_output_tokens}` : ''})으로 잘렸을
              가능성이 있습니다. env <code>VISION_REPORT_MAX_OUTPUT_TOKENS</code>를 늘리거나, 고급
              설정에서 이미지 수를 줄여 다시 시도해주세요.
            </Alert>
          )}

          {!result.report_parse_ok && (
            <Alert severity={result.truncated ? 'warning' : 'info'} sx={{ mb: 2 }}>
              {result.parse_message ||
                '보고서 합성 결과를 파싱하지 못했습니다. 개발자용 원본을 확인하세요.'}
            </Alert>
          )}

          {report && report.meta.validationNotes.length > 0 && (
            <Alert severity="info" sx={{ mb: 2, borderRadius: 2 }}>
              {report.meta.validationNotes.join(' · ')}
            </Alert>
          )}

          {/* 보기 모드 전환: 보고용 간결 | 인수인계 상세 (스펙 §5·§7, 기본=간결) */}
          {report && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2, mb: 2, flexWrap: 'wrap' }}>
              <Typography sx={{ fontSize: '0.78rem', fontWeight: 700, color: '#6B7280' }}>
                보기 모드
              </Typography>
              <ToggleButtonGroup
                size="small"
                exclusive
                value={viewMode}
                onChange={(_e, v) => v && setViewMode(v)}
                sx={{
                  '& .MuiToggleButton-root': {
                    textTransform: 'none',
                    px: 1.6,
                    fontWeight: 700,
                    fontSize: '0.76rem',
                    borderColor: '#E5E7EB',
                    color: '#6B7280',
                  },
                  '& .Mui-selected': {
                    bgcolor: '#F3E8FF !important',
                    color: '#8B5CF6 !important',
                  },
                }}
              >
                <ToggleButton value="brief">보고용 간결</ToggleButton>
                <ToggleButton value="detailed">인수인계 상세</ToggleButton>
              </ToggleButtonGroup>
              <Typography sx={{ fontSize: '0.7rem', color: '#9CA3AF' }}>
                {viewMode === 'brief'
                  ? '임원 보고·회의용 · 짧고 결론 중심'
                  : '업무 인수인계용 · 진행 배경·이미지 근거·후속 액션 상세'}
              </Typography>
            </Box>
          )}

          {/* ═══ 최종 보고서 — 구조/사실(DB) + 분석 포인트(모델) ═══ */}
          {report && (() => {
            // 이미지 근거의 주 표시 위치는 Task별 상세 카드다. 별도 "핵심 시각 근거" 큰
            // 이미지 섹션은 제거했고(웹), PDF 에서는 Task 표 뒤에 작은 "요약/바로가기"만 둔다.

            // 1. 프로젝트 개요 (사실은 DB, 두괄식 요약은 모델)
            const overviewSection = (
              <SectionCard icon={<SummarizeIcon sx={{ color: '#2955FF' }} />} title="프로젝트 개요">
                {report.overview.title && (
                  <Typography sx={{ fontWeight: 800, fontSize: '1.05rem', color: '#1A1D29', mb: 0.3 }}>
                    {report.overview.title}
                  </Typography>
                )}
                {report.overview.description && (
                  <Typography variant="body2" sx={{ color: '#6B7280', lineHeight: 1.6, mb: 1 }}>
                    {report.overview.description}
                  </Typography>
                )}

                {/* 두괄식 결론 메시지 */}
                {report.overview.keyMessage && (
                  <Box sx={{ mb: 1.5, p: 1.5, bgcolor: 'rgba(41,85,255,0.06)', borderRadius: 2, borderLeft: '3px solid #2955FF' }}>
                    <Typography sx={{ fontSize: '0.9rem', fontWeight: 700, color: '#111827' }}>
                      {report.overview.keyMessage}
                    </Typography>
                  </Box>
                )}

                {/* 팀원 / 전체 진행률 / 상태 count (DB 사실) */}
                <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap', mb: 1.5 }}>
                  <Box>
                    <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#9CA3AF', mb: 0.4 }}>팀원</Typography>
                    <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                      {report.overview.team.length > 0 ? (
                        report.overview.team.map((m, i) => (
                          <Chip key={i} size="small" label={m} sx={{ height: 22, fontSize: '0.68rem', bgcolor: '#F3F4F6' }} />
                        ))
                      ) : (
                        <Typography sx={{ fontSize: '0.78rem', color: '#9CA3AF' }}>미배정</Typography>
                      )}
                    </Box>
                  </Box>
                  {report.overview.overallProgress != null && (
                    <Box sx={{ minWidth: 180 }}>
                      <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: '#9CA3AF', mb: 0.4 }}>
                        전체 진행률 {report.overview.overallProgress}%
                      </Typography>
                      <Box sx={{ height: 8, borderRadius: 4, bgcolor: '#E5E7EB', overflow: 'hidden' }}>
                        <Box
                          sx={{
                            width: `${Math.min(100, Math.max(0, report.overview.overallProgress))}%`,
                            height: '100%',
                            bgcolor: report.overview.overallProgress >= 80 ? '#22C55E' : report.overview.overallProgress >= 50 ? '#2955FF' : '#F59E0B',
                          }}
                        />
                      </Box>
                    </Box>
                  )}
                </Box>
                {report.overview.statusBreakdown && (
                  <Box sx={{ display: 'flex', gap: 0.8, flexWrap: 'wrap', mb: report.overview.summaryPoints.length ? 1.5 : 0 }}>
                    {([
                      ['todo', report.overview.statusBreakdown.todo],
                      ['in_progress', report.overview.statusBreakdown.in_progress],
                      ['done', report.overview.statusBreakdown.done],
                      ['hold', report.overview.statusBreakdown.hold],
                    ] as [string, number | undefined][]).map(([k, v]) => (
                      <Chip
                        key={k}
                        size="small"
                        label={`${STATUS_LABEL[k]} ${v ?? 0}`}
                        sx={{ height: 22, fontSize: '0.68rem', bgcolor: '#F9FAFB', color: STATUS_COLOR[k], fontWeight: 700, border: `1px solid ${STATUS_COLOR[k]}33` }}
                      />
                    ))}
                    <Chip size="small" label={`전체 ${report.overview.statusBreakdown.total ?? 0}`} sx={{ height: 22, fontSize: '0.68rem' }} />
                  </Box>
                )}

                {/* 핵심 요약 (모델 두괄식 포인트) */}
                <BulletList title="핵심 요약" items={report.overview.summaryPoints} />
                {report.overview.decisionPoint && (
                  <Typography sx={{ fontSize: '0.82rem', color: '#0D9488', mt: 0.5 }}>
                    <strong>의사결정 포인트:</strong> {report.overview.decisionPoint}
                  </Typography>
                )}
              </SectionCard>
            );

            // 2. Task별 현황 표 (DB 사실) + 근거 컬럼(📷/📝/🔗)
            const taskTableSection = report.tasks.length > 0 ? (
                <SectionCard icon={<AssignmentIcon sx={{ color: '#8B5CF6' }} />} title="Task별 현황">
                  <TableContainer sx={{ borderRadius: 2, border: '1px solid #F1F5F9' }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>Task</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>상태</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>우선순위</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>진행률</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>마감일</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>담당자</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.72rem' }}>근거</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {report.tasks.map((t, i) => (
                          <TableRow key={i}>
                            <TableCell sx={{ fontSize: '0.74rem', fontWeight: 600 }}>{t.title}</TableCell>
                            <TableCell>
                              <Chip size="small" label={STATUS_LABEL[t.status || ''] || t.status || '-'} sx={{ height: 18, fontSize: '0.6rem', bgcolor: '#F9FAFB', color: STATUS_COLOR[t.status || ''] || '#6B7280' }} />
                            </TableCell>
                            <TableCell sx={{ fontSize: '0.72rem', color: PRIORITY_COLOR[t.priority || ''] || '#6B7280', fontWeight: 700 }}>
                              {t.priority || '-'}
                            </TableCell>
                            <TableCell sx={{ fontSize: '0.72rem' }}>{t.progress != null ? `${t.progress}%` : '-'}</TableCell>
                            <TableCell sx={{ fontSize: '0.72rem', color: '#6B7280' }}>{t.dueDate || '미정'}</TableCell>
                            <TableCell sx={{ fontSize: '0.72rem', color: '#6B7280' }}>{t.assignees.length ? t.assignees.join(', ') : '미배정'}</TableCell>
                            <TableCell>
                              <EvidenceBadges image={t.imageCount} note={t.noteCount} url={t.urlCount} file={t.fileCount} />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </SectionCard>
            ) : null;

            // 3. Task별 상세 분석 — 보기 모드(brief/detailed)에 따라 밀도/이미지 크기/구성 변경.
            //    brief: 핵심 요약→리스크→다음액션→시각근거(작은 이미지+캡션).
            //    detailed: 진행 배경→현재 상태→이미지 근거(큰 이미지+facts/의미/불확실)→리스크→다음액션→인수인계 메모.
            const renderVisualBlock = (
              t: TaskVM,
              opts: { maxHeight: number; points: string[]; mode: 'brief' | 'detailed' }
            ) => {
              const isDetailed = opts.mode === 'detailed';
              // ViewMode 결정론(스펙 §2): 서버가 내려준 Task 연결 이미지 전체 목록.
              //   brief    → 대표 이미지 1장만 표시, 나머지는 "+ 추가 이미지 n장" 요약.
              //   detailed → 연결된 이미지를 최대 DETAILED_MAX_IMAGES 장까지 grid 로 모두 표시.
              // 대표(is_featured) 이미지가 항상 먼저 오도록 안정 정렬.
              const ordered = [...getTaskVisualImages(t)].sort((a, b) =>
                a.isFeatured === b.isFeatured ? 0 : a.isFeatured ? -1 : 1
              );
              const shown = isDetailed ? ordered.slice(0, DETAILED_MAX_IMAGES) : ordered.slice(0, 1);
              const primary = shown[0] || null;
              // image_count 를 함께 고려해 "펼치지 못한 나머지" 수를 계산(스펙 §1: image_count 만큼 표시).
              const totalKnown = Math.max(ordered.length, t.imageCount || 0);
              const remaining = Math.max(0, totalKnown - shown.length);

              const hasAny = primary || opts.points.length > 0 || t.visualCaption || t.visualJudgment;
              if (!hasAny) return null;

              // 개별 이미지 아래 캡션/판단 의미/신뢰도(스펙 §5 상세). 대표 이미지는 Task 캡션으로 보완.
              const imgCaption = (im: VisualImageVM) => im.caption || (im.isFeatured ? t.visualCaption : '');
              const imgJudgment = (im: VisualImageVM) => im.judgment || (im.isFeatured ? t.visualJudgment : '');

              return (
                <Box className="task-visual-evidence" sx={{ mt: 0.8, p: 1.2, borderRadius: 1.5, bgcolor: '#FAF5FF', border: '1px solid #F3E8FF' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.6, mb: 0.5 }}>
                    <ImageSearchIcon sx={{ fontSize: '0.9rem', color: '#8B5CF6' }} />
                    <Typography sx={{ fontSize: '0.72rem', fontWeight: 700, color: '#8B5CF6' }}>연결된 시각 근거</Typography>
                    {isDetailed && shown.length > 0 && (
                      <Chip size="small" label={`${shown.length}장`} sx={{ height: 16, fontSize: '0.56rem', bgcolor: '#EDE9FE', color: '#7C3AED' }} />
                    )}
                    {t.visualConfidence && (
                      <Chip size="small" label={`신뢰도 ${t.visualConfidence}`} sx={{ height: 16, fontSize: '0.56rem', bgcolor: '#EDE9FE', color: '#7C3AED' }} />
                    )}
                  </Box>
                  {isDetailed && shown.length > 0 ? (
                    // 오른쪽 여백이 비지 않도록 auto-fit grid(스펙 §1·§6 CSS). 이미지별 캡션/판단/신뢰도 포함.
                    <Box
                      className="visual-evidence-grid"
                      sx={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                        gap: 1.2,
                        alignItems: 'start',
                        mb: 0.6,
                      }}
                    >
                      {shown.map(im => (
                        <Box key={im.imageId} className="task-visual-evidence-item" sx={{ minWidth: 0 }}>
                          <EvidenceImage
                            imageId={im.imageId}
                            src={imageCache[im.imageId]}
                            failed={imageFailed[im.imageId]}
                            requestImage={loadImage}
                            maxHeight={opts.maxHeight}
                            alt={imgCaption(im) || t.title}
                          />
                          {imgCaption(im) && (
                            <Typography sx={{ fontSize: '0.76rem', color: '#374151', fontWeight: 600, mt: 0.4 }}>
                              {imgCaption(im)}
                            </Typography>
                          )}
                          {imgJudgment(im) && (
                            <Typography sx={{ fontSize: '0.7rem', color: '#7C3AED', mt: 0.1 }}>
                              판단 의미: {imgJudgment(im)}
                            </Typography>
                          )}
                          <Box sx={{ display: 'flex', gap: 0.4, flexWrap: 'wrap', mt: 0.3 }}>
                            {im.isFeatured && (
                              <Chip size="small" label="대표" sx={{ height: 15, fontSize: '0.54rem', bgcolor: '#F3E8FF', color: '#8B5CF6', fontWeight: 700 }} />
                            )}
                            {im.confidence && (
                              <Chip size="small" label={`신뢰도 ${im.confidence}`} sx={{ height: 15, fontSize: '0.54rem', bgcolor: '#EEF2FF', color: '#2955FF' }} />
                            )}
                          </Box>
                        </Box>
                      ))}
                    </Box>
                  ) : primary ? (
                    <Box sx={{ mb: 0.6 }}>
                      <EvidenceImage
                        imageId={primary.imageId}
                        src={imageCache[primary.imageId]}
                        failed={imageFailed[primary.imageId]}
                        requestImage={loadImage}
                        maxHeight={opts.maxHeight}
                        alt={imgCaption(primary) || t.title}
                      />
                    </Box>
                  ) : null}
                  {/* 간결 모드: 대표 이미지 캡션/판단 의미는 이미지 아래에 한 번만 표시(상세는 이미지별로 이미 표시). */}
                  {!isDetailed && t.visualCaption && (
                    <Typography sx={{ fontSize: '0.8rem', color: '#374151', fontWeight: 600, mb: 0.2 }}>
                      {t.visualCaption}
                    </Typography>
                  )}
                  {!isDetailed && t.visualJudgment && (
                    <Typography sx={{ fontSize: '0.74rem', color: '#7C3AED', mb: 0.4 }}>
                      판단 의미: {t.visualJudgment}
                    </Typography>
                  )}
                  <BulletList items={opts.points} color="#4B5563" />
                  {t.visualLimitations.length > 0 && (
                    <BulletList title="이미지 한계" items={t.visualLimitations} color="#D97706" />
                  )}
                  {/* 상세: DETAILED_MAX_IMAGES 초과분만 요약(스펙 §5). 간결: 대표 외 나머지 요약. */}
                  {isDetailed
                    ? remaining > 0 && (
                        <Typography sx={{ fontSize: '0.68rem', color: '#9CA3AF', mt: 0.4 }}>
                          + 나머지 {remaining}장
                          {t.additionalSummary ? ` — ${t.additionalSummary}` : ''}
                        </Typography>
                      )
                    : t.additionalImageCount > 0 && (
                        <Typography sx={{ fontSize: '0.68rem', color: '#9CA3AF', mt: 0.4 }}>
                          + 추가 이미지 {t.additionalImageCount}장
                          {t.additionalSummary ? ` — ${t.additionalSummary}` : ''}
                        </Typography>
                      )}
                </Box>
              );
            };

            // Task 카드에 실제로 렌더될 이미지 수(§8). 0 이면 "핵심 시각 근거 요약" 안내 문구를 숨긴다.
            const taskCardVisibleImageCount = report.tasks.filter(t => resolveTaskImageId(t)).length;

            const taskDetailSection = report.tasks.length > 0 ? (
                <SectionCard
                  icon={<AssignmentIcon sx={{ color: '#8B5CF6' }} />}
                  title={viewMode === 'detailed' ? 'Task별 상세 분석 (인수인계)' : 'Task별 상세 분석'}
                >
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                    {report.tasks.map((t, i) => (
                      <Box key={i} className="visual-evidence-card" sx={{ p: 2, borderRadius: 2, bgcolor: '#F9FAFB', border: '1px solid #E5E7EB' }}>
                        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap', mb: 0.7 }}>
                          <Typography sx={{ fontWeight: 800, fontSize: '0.9rem', color: '#1A1D29' }}>{t.title}</Typography>
                          <Chip size="small" label={STATUS_LABEL[t.status || ''] || t.status} sx={{ height: 20, fontSize: '0.62rem', bgcolor: '#EEF2FF', color: STATUS_COLOR[t.status || ''] || '#2955FF' }} />
                          {t.progress != null && <Chip size="small" label={`${t.progress}%`} sx={{ height: 20, fontSize: '0.62rem' }} />}
                          {t.hasVisual && <VisualEvidenceTag />}
                        </Box>

                        {viewMode === 'detailed' ? (
                          <>
                            <BulletList title="진행 배경" items={t.detailContextPoints} />
                            <BulletList title="현재 상태" items={t.detailSummaryPoints} />
                            {/* 이미지 근거를 리스크 앞(현재 상태 뒤)에 크게 배치. 상세 모드는 grid 로 여러 장(스펙 §1·§7). */}
                            {renderVisualBlock(t, { maxHeight: 200, points: t.detailVisualPoints, mode: 'detailed' })}
                            <BulletList title="리스크 / 이슈" items={t.detailRiskPoints} color="#B91C1C" />
                            <BulletList title="다음 액션" items={t.detailNextActions} color="#0D9488" />
                            <BulletList title="인수인계 메모" items={t.handoverNotes} color="#6D28D9" />
                          </>
                        ) : (
                          <>
                            <BulletList items={t.summaryPoints} />
                            <BulletList title="리스크 / 이슈" items={t.riskPoints} color="#B91C1C" />
                            <BulletList title="다음 액션" items={t.nextActions} color="#0D9488" />
                            {/* 간결 모드: 대표 이미지 1장 + 캡션/판단 의미 + 추가 이미지 요약(스펙 §1·§7). */}
                            {renderVisualBlock(t, { maxHeight: 140, points: t.visualPoints, mode: 'brief' })}
                          </>
                        )}
                      </Box>
                    ))}
                  </Box>
                </SectionCard>
            ) : null;

            // 4. 첨부/근거 자료 — Task 단위 요약(이미지 id 나열 X)
            const attachmentsSection = report.attachments.length > 0 ? (
                <SectionCard icon={<AttachFileIcon sx={{ color: '#EC4899' }} />} title="첨부/근거 자료">
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.8 }}>
                    {report.attachments.map((a, i) => (
                      <Box key={i} sx={{ display: 'flex', gap: 1, alignItems: 'baseline', flexWrap: 'wrap' }}>
                        <Typography sx={{ fontSize: '0.82rem', fontWeight: 700, color: '#1A1D29', minWidth: 140 }}>
                          {a.taskTitle || '(자료)'}
                        </Typography>
                        <Typography sx={{ fontSize: '0.8rem', color: '#4B5563' }}>
                          {[
                            a.imageCount ? `이미지 ${a.imageCount}개` : '',
                            a.files.length ? `파일 ${a.files.length}개` : '',
                            a.urls.length ? `URL ${a.urls.length}개` : '',
                          ].filter(Boolean).join(' · ') || '자료 없음'}
                        </Typography>
                      </Box>
                    ))}
                  </Box>
                </SectionCard>
            ) : null;

            // 5. 종합 현황 분석
            const overallSection = (report.overall.summaryPoints.length > 0 ||
                report.overall.keyPoints.length > 0 ||
                report.overall.visualInsights.length > 0 ||
                report.overall.riskPoints.length > 0) ? (
                <SectionCard icon={<InsightsIcon sx={{ color: '#0D9488' }} />} title="종합 현황 분석">
                  <BulletList items={report.overall.summaryPoints} />
                  <BulletList title="핵심 포인트" items={report.overall.keyPoints} />
                  <BulletList
                    title="시각 자료 근거 인사이트"
                    items={report.overall.visualInsights}
                    color="#6D28D9"
                    tag={<VisualEvidenceTag label="이미지 기반" />}
                  />
                  <BulletList title="리스크 / 불확실성" items={report.overall.riskPoints} color="#B91C1C" />
                </SectionCard>
            ) : null;

            // 6. 다음 단계 추천
            const nextStepsSection = (report.nextSteps.summaryPoints.length > 0 || report.nextSteps.actions.length > 0) ? (
                <SectionCard icon={<EventAvailableIcon sx={{ color: '#2955FF' }} />} title="다음 단계 추천">
                  <BulletList items={report.nextSteps.summaryPoints} />
                  <BulletList title="추천 액션" items={report.nextSteps.actions} />
                </SectionCard>
            ) : null;

            // 핵심 시각 근거 요약 (PDF 전용, 스펙 §3-B/§4) — 큰 이미지 카드가 아니라
            // "Task별 핵심 근거 한 줄 요약/바로가기" 느낌. 실제 이미지는 Task 카드 내부에서 표시한다.
            const featuredSummarySection = report.featured.length > 0 ? (
                <SectionCard icon={<ImageSearchIcon sx={{ color: '#8B5CF6' }} />} title="핵심 시각 근거 요약">
                  {/* 안내 문구는 실제로 Task 카드에 이미지가 렌더될 때만 표시(스펙 §8). */}
                  {taskCardVisibleImageCount > 0 ? (
                    <Typography sx={{ fontSize: '0.74rem', color: '#9CA3AF', mb: 1 }}>
                      실제 대표 이미지는 아래 “Task별 상세 분석”의 각 Task 카드 안에서 함께 확인할 수 있습니다.
                    </Typography>
                  ) : (
                    <Typography sx={{ fontSize: '0.74rem', color: '#D97706', mb: 1 }}>
                      이미지 근거는 분석에 활용되었지만 Task 카드 이미지 매핑에 실패했습니다. 개발자 정보에서
                      missing_task_image_mapping 을 확인하세요.
                    </Typography>
                  )}
                  <Box component="ul" sx={{ m: 0, pl: 2.2 }}>
                    {report.featured.map((f, i) => (
                      <Box component="li" key={i} sx={{ fontSize: '0.8rem', color: '#374151', lineHeight: 1.7, mb: 0.3 }}>
                        <strong>{f.task_title || '이미지 근거'}</strong>
                        {f.caption ? `: ${f.caption}` : ''}
                      </Box>
                    ))}
                  </Box>
                  {report.nonFeatured.count > 0 && (
                    <Typography sx={{ fontSize: '0.74rem', color: '#6B7280', mt: 0.8 }}>
                      그 외 이미지 {report.nonFeatured.count}장
                      {report.nonFeatured.summary ? ` — ${report.nonFeatured.summary}` : '은 보조 근거로 함께 활용되었습니다.'}
                    </Typography>
                  )}
                </SectionCard>
            ) : null;

            const uncertaintyCaption = report.meta.uncertaintyNotes.length > 0 ? (
                <Typography variant="caption" sx={{ color: '#9CA3AF', display: 'block', mb: 2 }}>
                  {report.meta.uncertaintyNotes.join(' · ')}
                </Typography>
            ) : null;

            // 웹(스펙 §4): 개요 → Task표 → Task상세(이미지 포함) → 첨부 → 종합 → 다음단계
            //   별도 "핵심 시각 근거" 큰 이미지 섹션은 제거(이미지는 Task 카드 안에서 표시).
            // PDF(스펙 §4): 개요 → Task표 → 핵심 시각 근거 요약(작은 바로가기) → Task상세(대표 이미지 포함)
            //   → 첨부 → 종합 → 다음단계
            const ordered = pdfMode
              ? [overviewSection, taskTableSection, featuredSummarySection, taskDetailSection, attachmentsSection, overallSection, nextStepsSection]
              : [overviewSection, taskTableSection, taskDetailSection, attachmentsSection, overallSection, nextStepsSection];

            return (
              <Box ref={reportRef}>
                {ordered.map((s, i) => (s ? <React.Fragment key={i}>{s}</React.Fragment> : null))}
                {uncertaintyCaption}
              </Box>
            );
          })()}

          {/* ═══ 개발자용 이미지 해석 원본 보기 (접기) ═══ */}
          <Divider sx={{ my: 2 }} />
          <Button
            size="small"
            onClick={() => setRawOpen(o => !o)}
            endIcon={rawOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}
            sx={{ color: '#6B7280', textTransform: 'none' }}
          >
            개발자용 이미지 해석 원본 보기
          </Button>
          <Collapse in={rawOpen}>
            <Box sx={{ mt: 1.5 }}>
              <Typography variant="caption" sx={{ color: '#6B7280', display: 'block', mb: 1 }}>
                사용 image_ids: {result.used_image_ids.join(', ') || '-'}
                {result.missing_image_ids.length > 0 && (
                  <> · 누락(권한밖/없음): {result.missing_image_ids.join(', ')}</>
                )}
                {result.load_errors.length > 0 && (
                  <> · 로드실패: {result.load_errors.map(e => e.image_id).join(', ')}</>
                )}
                {' · '}stage1 batches: {result.stage1_batches ?? '-'} · evidence:{' '}
                {result.evidence_count}개
              </Typography>

              {/* 품질 지표 (§17) — 모델/토큰/batch/이미지 현황 + 이미지 활용도(coverage) */}
              <Box sx={{ display: 'flex', gap: 0.8, flexWrap: 'wrap', mb: 1.5 }}>
                <Chip size="small" label={`model: ${result.model}`} sx={{ bgcolor: '#F3E8FF', color: '#8B5CF6', fontWeight: 700 }} />
                <Chip size="small" label={`latency: ${result.latency_ms}ms`} />
                {usageText && <Chip size="small" label={`tokens: ${usageText}`} />}
                <Chip size="small" label={`batch ${result.batches ?? result.stage1_batches ?? 1}개`} />
                <Chip size="small" label={`images total ${result.images_total}`} sx={{ bgcolor: '#EEF2FF', color: '#2955FF' }} />
                <Chip size="small" label={`analyzed ${result.images_analyzed ?? result.images_used}`} />
                {result.cache_read_active && (
                  <>
                    <Chip
                      size="small"
                      label={`캐시 ${result.images_from_cache ?? 0}`}
                      sx={{ bgcolor: '#DCFCE7', color: '#15803D', fontWeight: 700 }}
                    />
                    {(result.images_context_regenerated ?? 0) > 0 && (
                      <Chip
                        size="small"
                        label={`Context 재생성 ${result.images_context_regenerated}`}
                        sx={{ bgcolor: '#FEF9C3', color: '#A16207', fontWeight: 700 }}
                      />
                    )}
                    <Chip size="small" label={`Vision 신규 ${result.images_vision_analyzed ?? 0}`} />
                    <Chip size="small" label={`Vision 호출 ${result.vision_model_calls ?? 0}`} />
                  </>
                )}
                {(result.images_failed ?? 0) > 0 && (
                  <Chip size="small" label={`failed ${result.images_failed}`} sx={{ bgcolor: '#FEE2E2', color: '#B91C1C' }} />
                )}
              </Box>
              {report?.debug && (
                <Box sx={{ display: 'flex', gap: 0.8, flexWrap: 'wrap', mb: 1.5 }}>
                  <Chip size="small" label={`Task ${report.debug.tasks_total ?? 0}개`} />
                  <Chip size="small" label={`이미지 있는 Task ${report.debug.tasks_with_images ?? 0}개`} sx={{ bgcolor: '#EEF2FF', color: '#2955FF' }} />
                  <Chip
                    size="small"
                    label={`이미지 근거 반영 ${report.debug.tasks_with_visual_points ?? 0}개`}
                    sx={{ bgcolor: '#F3E8FF', color: '#8B5CF6' }}
                  />
                  <Chip
                    size="small"
                    label={`visual coverage ${
                      report.debug.visual_evidence_coverage != null
                        ? `${Math.round(report.debug.visual_evidence_coverage * 100)}%`
                        : '-'
                    }`}
                    sx={{
                      bgcolor:
                        (report.debug.visual_evidence_coverage ?? 0) >= 0.8
                          ? '#DCFCE7'
                          : (report.debug.visual_evidence_coverage ?? 0) >= 0.5
                          ? '#FEF3C7'
                          : '#FEE2E2',
                      fontWeight: 700,
                    }}
                  />
                  <Chip
                    size="small"
                    label={`featured coverage ${
                      report.debug.featured_image_task_coverage_ratio != null
                        ? `${Math.round(report.debug.featured_image_task_coverage_ratio * 100)}%`
                        : '-'
                    } (${report.debug.featured_image_task_coverage ?? 0}개)`}
                  />
                  <Chip size="small" label={`featured 이미지 ${report.debug.featured_image_count ?? 0}장`} />
                  <Chip
                    size="small"
                    label={`Task 카드 이미지 ${report.debug.task_card_visible_image_count ?? 0}개`}
                    sx={{ bgcolor: '#ECFEFF', color: '#0E7490', fontWeight: 700 }}
                  />
                  <Chip
                    size="small"
                    label={`상세 표시 이미지 ${report.debug.detailed_visible_image_count ?? 0}장`}
                    sx={{ bgcolor: '#F0FDF4', color: '#15803D', fontWeight: 700 }}
                  />
                </Box>
              )}

              {/* 상세 모드에서 숨긴 이미지(스펙 §8·§9) — rendered=false + hidden_reason */}
              {(report?.debug?.hidden_task_images?.length ?? 0) > 0 && (
                <Alert severity="info" sx={{ mb: 1.5, borderRadius: 2 }}>
                  <Typography sx={{ fontSize: '0.76rem', fontWeight: 700, mb: 0.3 }}>
                    hidden_task_images — 상세 모드에서 제외된 이미지
                  </Typography>
                  <Box component="ul" sx={{ m: 0, pl: 2.2 }}>
                    {report!.debug!.hidden_task_images!.map((h, i) => (
                      <Box component="li" key={i} sx={{ fontSize: '0.72rem', color: '#374151', fontFamily: 'monospace' }}>
                        #{h.task_id} · {h.image_id} — rendered:{String(h.rendered ?? false)} · {h.hidden_reason || '-'}
                      </Box>
                    ))}
                  </Box>
                </Alert>
              )}

              {/* Task 카드 이미지 매핑 실패(§10) — image_count>0 인데 대표 이미지 못 찾음 = 버그 신호 */}
              {(report?.debug?.missing_task_image_mapping?.length ?? 0) > 0 && (
                <Alert severity="warning" sx={{ mb: 1.5, borderRadius: 2 }}>
                  <Typography sx={{ fontSize: '0.76rem', fontWeight: 700, mb: 0.3 }}>
                    missing_task_image_mapping — 이미지가 있는데 Task 카드 대표 이미지를 찾지 못한 Task
                  </Typography>
                  <Box component="ul" sx={{ m: 0, pl: 2.2 }}>
                    {report!.debug!.missing_task_image_mapping!.map((m, i) => (
                      <Box component="li" key={i} sx={{ fontSize: '0.72rem', color: '#92400E' }}>
                        #{m.task_id} {m.task_title} — image_count {m.image_count} · {m.hidden_reason}
                      </Box>
                    ))}
                  </Box>
                </Alert>
              )}

              {/* Task별 이미지 해결(resolve) 경로 debug 표 (§10 task_visual_debug) */}
              {(report?.debug?.task_visual_debug?.length ?? 0) > 0 && (
                <Box sx={{ mb: 1.5 }}>
                  <Typography variant="caption" sx={{ color: '#6B7280', fontWeight: 700, display: 'block', mb: 0.5 }}>
                    task_visual_debug — Task별 대표 이미지 resolve 경로
                  </Typography>
                  <TableContainer sx={{ maxHeight: 260, borderRadius: 2, border: '1px solid #F1F5F9' }}>
                    <Table size="small" stickyHeader>
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.68rem' }}>task</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.68rem' }}>img</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.68rem' }}>badge</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.68rem' }}>resolved_image_id</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.68rem' }}>from</TableCell>
                          <TableCell sx={{ fontWeight: 700, fontSize: '0.68rem' }}>rendered</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {report!.debug!.task_visual_debug!.map((d, i) => {
                          const bug = !!d.image_count && !d.resolved_image_id;
                          return (
                            <TableRow key={i} sx={bug ? { bgcolor: '#FEF2F2' } : undefined}>
                              <TableCell sx={{ fontSize: '0.68rem' }}>
                                #{d.task_id} {truncate(d.task_title, 20)}
                              </TableCell>
                              <TableCell sx={{ fontSize: '0.68rem' }}>{d.image_count ?? 0}</TableCell>
                              <TableCell sx={{ fontSize: '0.68rem' }}>{d.badge_visible ? '✓' : '-'}</TableCell>
                              <TableCell sx={{ fontSize: '0.66rem', fontFamily: 'monospace', color: bug ? '#B91C1C' : '#374151' }}>
                                {d.resolved_image_id || (bug ? 'null ⚠' : '-')}
                              </TableCell>
                              <TableCell sx={{ fontSize: '0.66rem', color: '#6B7280' }}>{d.resolved_from || '-'}</TableCell>
                              <TableCell sx={{ fontSize: '0.68rem', color: d.rendered ? '#16A34A' : bug ? '#B91C1C' : '#9CA3AF' }}>
                                {d.rendered ? '✓' : '✗'}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              )}

              {/* Stage 1: image_evidence_summaries (raw 해석) */}
              {evidence.length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1A1D29', mb: 1 }}>
                    Stage 1 — image_evidence_summaries ({evidence.length})
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    {evidence.map((e, i) => (
                      <Box key={i} sx={{ p: 1.5, borderRadius: 2, bgcolor: '#F9FAFB', border: '1px solid #E5E7EB' }}>
                        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 0.3, alignItems: 'center' }}>
                          <Typography sx={{ fontSize: '0.72rem', fontFamily: 'monospace', fontWeight: 700 }}>
                            {e.image_id || `#${i + 1}`}
                          </Typography>
                          {(e.task_id || e.task_title) && (
                            <Typography sx={{ fontSize: '0.7rem', color: '#6B7280' }}>
                              {e.task_id ? `Task #${e.task_id} ` : ''}{e.task_title || ''}
                            </Typography>
                          )}
                          {e.image_role_hint && (
                            <Chip size="small" label={e.image_role_hint} sx={{ height: 18, fontSize: '0.6rem' }} />
                          )}
                        </Box>
                        {!!e.visible_facts?.length && (
                          <Typography sx={{ fontSize: '0.78rem', color: '#374151' }}>
                            <strong>보이는 사실:</strong> {e.visible_facts.join(' · ')}
                          </Typography>
                        )}
                        {e.interpretation && (
                          <Typography sx={{ fontSize: '0.78rem', color: '#374151' }}>
                            <strong>해석:</strong> {e.interpretation}
                          </Typography>
                        )}
                        {e.uncertainty && (
                          <Typography sx={{ fontSize: '0.78rem', color: '#D97706' }}>
                            <strong>불확실:</strong> {e.uncertainty}
                          </Typography>
                        )}
                      </Box>
                    ))}
                  </Box>
                </Box>
              )}

              {/* raw text: stage1 / stage2 / parsed json */}
              <RawPre label="Stage 2 raw (최종 보고서 합성)" text={result.stage2_raw_text || '(빈 응답)'} />
              {(result.stage1_raw_texts || []).map((t, i) => (
                <RawPre key={i} label={`Stage 1 raw (batch ${i + 1})`} text={t || '(빈 응답)'} />
              ))}
              {result.report && (
                <RawPre label="parsed report (JSON)" text={JSON.stringify(result.report, null, 2)} />
              )}
            </Box>
          </Collapse>
        </Box>
      )}
    </Box>
  );
};

export default VisionReportTestPanel;
