import React from 'react';
import {
  Drawer,
  Box,
  Typography,
  Chip,
  Button,
  IconButton,
  TextField,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Tooltip,
  Checkbox,
  FormControlLabel,
  Collapse,
  Switch,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import AddIcon from '@mui/icons-material/Add';
import { enqueueSnackbar } from 'notistack';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable,
  arrayMove,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { api } from '../../api/client';
import { useWorkflow, workflowQueryKey } from '../../hooks/useWorkflow';
import { planAiColors, planAiRadius } from '../../theme/tokens';
import type { WorkflowMode, WorkflowModePreview } from '../../types';

interface Props {
  open: boolean;
  onClose: () => void;
  projectId: number;
}

// 편집 중 컬럼 (id 없으면 신규)
interface EditCol {
  uid: string;          // 로컬 dnd 키
  id?: number;
  label: string;
  description?: string | null;    // 단계 세부 설명 (optional)
  color?: string | null;
  mapped_status?: string | null;  // 'hold' 만 보존
  is_checkpoint?: boolean;        // 완료 체크포인트로 사용 여부
  checkpoint_label?: string | null;
  checkpoint_description?: string | null;
  auto_move_on_complete?: boolean;        // 완료 체크 시 다음 단계로 이동할지
}

const DESC_MAX = 200;
const CP_LABEL_MAX = 120;

const STATUS_KO: Record<string, string> = {
  todo: '시작 전',
  in_progress: '진행 중',
  done: '완료',
  hold: '보류',
};

const SortableRow = ({ col, isLastStage, nextLabel, onLabel, onDescription, onPatch, onDelete }: {
  col: EditCol;
  isLastStage: boolean;
  nextLabel?: string | null;
  onLabel: (v: string) => void;
  onDescription: (v: string) => void;
  onPatch: (patch: Partial<EditCol>) => void;
  onDelete: () => void;
}) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: col.uid });
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };
  return (
    <Box
      ref={setNodeRef}
      style={style}
      sx={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: 1,
        py: 0.75,
        px: 1,
        mb: 1,
        bgcolor: planAiColors.background.surfaceAlt,
        borderRadius: `${planAiRadius.md}px`,
        border: `1px solid ${planAiColors.border.soft}`,
      }}
    >
      <Box {...attributes} {...listeners} sx={{ cursor: 'grab', display: 'flex', color: planAiColors.text.muted, pt: 0.5 }}>
        <DragIndicatorIcon fontSize="small" />
      </Box>
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <TextField
            value={col.label}
            onChange={e => onLabel(e.target.value)}
            placeholder="단계 이름"
            size="small"
            variant="standard"
            InputProps={{ disableUnderline: true, sx: { fontSize: '0.85rem', fontWeight: 600 } }}
            sx={{ flex: 1 }}
          />
          {col.mapped_status === 'hold' && (
            <Chip label="보류" size="small" sx={{ height: 18, fontSize: '0.6rem' }} />
          )}
        </Box>
        <TextField
          value={col.description ?? ''}
          onChange={e => onDescription(e.target.value.slice(0, DESC_MAX))}
          placeholder="세부 설명 (선택)"
          size="small"
          variant="standard"
          multiline
          maxRows={2}
          InputProps={{ disableUnderline: true, sx: { fontSize: '0.72rem', color: planAiColors.text.muted } }}
          sx={{ width: '100%', mt: 0.25 }}
        />

        {/* 완료 체크포인트 설정 */}
        <Box sx={{ mt: 0.75, pt: 0.75, borderTop: `1px dashed ${planAiColors.border.soft}` }}>
          <FormControlLabel
            control={
              <Checkbox
                size="small"
                checked={!!col.is_checkpoint}
                onChange={e => onPatch({ is_checkpoint: e.target.checked })}
                sx={{ py: 0, pl: 0.5 }}
              />
            }
            label={<Typography sx={{ fontSize: '0.72rem', fontWeight: 600 }}>완료 체크포인트로 사용</Typography>}
            sx={{ m: 0 }}
          />
          <Collapse in={!!col.is_checkpoint} unmountOnExit>
            <Typography sx={{ fontSize: '0.66rem', color: planAiColors.text.muted, mt: 0.25, mb: 0.5, lineHeight: 1.4 }}>
              이 단계를 프로젝트의 중간 완료 기준으로 표시합니다. 진행 상황을 단계별로 보기 위한 보조 지표입니다.
            </Typography>
            <TextField
              value={col.checkpoint_label ?? ''}
              onChange={e => onPatch({ checkpoint_label: e.target.value.slice(0, CP_LABEL_MAX) })}
              placeholder="예: 후보 선정 완료, 테스트 완료, 적용 완료"
              size="small"
              variant="outlined"
              fullWidth
              InputProps={{ sx: { fontSize: '0.74rem' } }}
              sx={{ mb: 0.75 }}
            />
            <TextField
              value={col.checkpoint_description ?? ''}
              onChange={e => onPatch({ checkpoint_description: e.target.value.slice(0, DESC_MAX) })}
              placeholder="예: 절감 대상과 후보 부품이 정리된 상태"
              size="small"
              variant="outlined"
              fullWidth
              multiline
              maxRows={3}
              InputProps={{ sx: { fontSize: '0.72rem' } }}
            />
          </Collapse>
        </Box>

        {/* 단계 완료 시 동작 */}
        <Box sx={{ mt: 0.75, pt: 0.75, borderTop: `1px dashed ${planAiColors.border.soft}` }}>
          {isLastStage ? (
            <Typography sx={{ fontSize: '0.66rem', color: planAiColors.text.muted, lineHeight: 1.4 }}>
              마지막 단계는 다음 단계가 없어 <b>최종 완료 처리</b>됩니다.
            </Typography>
          ) : (
            <>
              <FormControlLabel
                control={
                  <Switch
                    size="small"
                    checked={col.auto_move_on_complete ?? true}
                    onChange={e => onPatch({ auto_move_on_complete: e.target.checked })}
                  />
                }
                label={<Typography sx={{ fontSize: '0.72rem', fontWeight: 600 }}>완료 체크 시 다음 단계로 이동</Typography>}
                sx={{ m: 0 }}
              />
              <Typography sx={{ fontSize: '0.66rem', color: planAiColors.text.muted, mt: 0.25, lineHeight: 1.4 }}>
                {(col.auto_move_on_complete ?? true)
                  ? `Task에서 이 단계 완료를 체크하면 ${nextLabel ? `'${nextLabel}'` : '다음'} 단계로 이동합니다.`
                  : '꺼두면 완료 체크 후 현재 단계에 유지됩니다.'}
              </Typography>
            </>
          )}
        </Box>
      </Box>
      <Tooltip title="단계 삭제">
        <IconButton size="small" onClick={onDelete} sx={{ color: planAiColors.text.muted, '&:hover': { color: planAiColors.status.danger }, mt: 0.25 }}>
          <DeleteOutlineIcon sx={{ fontSize: 18 }} />
        </IconButton>
      </Tooltip>
    </Box>
  );
};

const WorkflowSettingsDrawer: React.FC<Props> = ({ open, onClose, projectId }) => {
  const queryClient = useQueryClient();
  const { data: workflow } = useWorkflow(open ? projectId : undefined);

  const isCustom = workflow?.mode === 'CUSTOM';
  const [cols, setCols] = React.useState<EditCol[]>([]);
  const [dirty, setDirty] = React.useState(false);

  // 모드 변경 확인 흐름
  const [confirmMode, setConfirmMode] = React.useState<WorkflowMode | null>(null);
  const [preview, setPreview] = React.useState<WorkflowModePreview | null>(null);
  const [previewLoading, setPreviewLoading] = React.useState(false);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  // 마지막 flow 단계(hold 제외) = 자동 이동 불가 (다음 단계 없음)
  const lastFlowUid = React.useMemo(() => {
    const flow = cols.filter(c => c.mapped_status !== 'hold');
    return flow.length ? flow[flow.length - 1].uid : null;
  }, [cols]);

  // workflow 로드 시 편집 상태 초기화
  React.useEffect(() => {
    if (!open || !workflow) return;
    const sorted = [...workflow.columns].sort((a, b) => a.sort_order - b.sort_order);
    setCols(
      sorted.map((c, i) => ({
        uid: `c-${c.id}-${i}`, id: c.id, label: c.label, description: c.description ?? '', color: c.color,
        mapped_status: c.mapped_status, is_checkpoint: !!c.is_checkpoint,
        checkpoint_label: c.checkpoint_label ?? '', checkpoint_description: c.checkpoint_description ?? '',
        auto_move_on_complete: c.auto_move_on_complete ?? true,
      }))
    );
    setDirty(false);
  }, [open, workflow]);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: workflowQueryKey(projectId) });
    queryClient.invalidateQueries({ queryKey: ['tasks'] });
  };

  // ── 컬럼 저장 ──
  const saveMutation = useMutation({
    mutationFn: () =>
      api.saveWorkflowColumns(
        projectId,
        cols.map((c, i) => {
          // 마지막 flow 단계·hold 단계는 다음 단계가 없거나 흐름 밖 → 자동 이동 대상 아님.
          // is_checkpoint(완료 체크포인트로 사용)와는 독립. 완료 체크포인트 여부는 auto_move 저장에 영향을 주지 않는다.
          const movable = c.mapped_status !== 'hold' && c.uid !== lastFlowUid;
          return {
            id: c.id,
            label: c.label.trim() || `단계 ${i + 1}`,
            description: (c.description ?? '').trim() || null,
            color: c.color,
            sort_order: i,
            mapped_status: c.mapped_status,
            is_checkpoint: !!c.is_checkpoint,
            checkpoint_label: c.is_checkpoint ? ((c.checkpoint_label ?? '').trim() || null) : null,
            checkpoint_description: c.is_checkpoint ? ((c.checkpoint_description ?? '').trim() || null) : null,
            auto_move_on_complete: movable ? (c.auto_move_on_complete ?? true) : false,
          };
        }),
      ),
    onSuccess: () => {
      invalidate();
      setDirty(false);
      enqueueSnackbar('워크플로우 단계가 저장되었습니다.', { variant: 'success' });
    },
    onError: (err: any) => {
      enqueueSnackbar(err?.response?.data?.detail || '저장에 실패했습니다.', { variant: 'error' });
    },
  });

  // ── 모드 변경 적용 ──
  const changeModeMutation = useMutation({
    mutationFn: (target: WorkflowMode) => api.changeWorkflowMode(projectId, target),
    onSuccess: () => {
      invalidate();
      setConfirmMode(null);
      setPreview(null);
      enqueueSnackbar('워크플로우 모드가 변경되었습니다.', {
        variant: 'success',
        action: () => (
          <Button
            size="small"
            sx={{ color: '#fff' }}
            onClick={() => {
              undoMutation.mutate();
            }}
          >
            되돌리기
          </Button>
        ),
      });
    },
    onError: (err: any) => {
      enqueueSnackbar(err?.response?.data?.detail || '모드 변경에 실패했습니다.', { variant: 'error' });
    },
  });

  const undoMutation = useMutation({
    mutationFn: () => api.undoWorkflowMode(projectId),
    onSuccess: () => {
      invalidate();
      enqueueSnackbar('워크플로우 설정을 되돌렸습니다.', { variant: 'info' });
    },
    onError: (err: any) => {
      enqueueSnackbar(err?.response?.data?.detail || '되돌리기에 실패했습니다.', { variant: 'error' });
    },
  });

  const handleDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    setCols(prev => {
      const oldIdx = prev.findIndex(c => c.uid === active.id);
      const newIdx = prev.findIndex(c => c.uid === over.id);
      if (oldIdx < 0 || newIdx < 0) return prev;
      return arrayMove(prev, oldIdx, newIdx);
    });
    setDirty(true);
  };

  const addColumn = () => {
    setCols(prev => [...prev, { uid: `new-${Date.now()}`, label: '새 단계' }]);
    setDirty(true);
  };

  // 전체 일괄 적용: auto_move_on_complete 값에만 적용(hold·마지막 단계 제외).
  // '완료 체크포인트로 사용'(is_checkpoint)은 독립 설정이므로 절대 건드리지 않는다.
  const applyAutoMoveAll = (value: boolean) => {
    setCols(prev => prev.map(c => {
      const movable = c.mapped_status !== 'hold' && c.uid !== lastFlowUid;
      return movable ? { ...c, auto_move_on_complete: value } : c;
    }));
    setDirty(true);
  };

  // 자동 이동을 적용할 수 있는(hold·마지막 제외) 단계가 하나라도 있는지
  const hasMovableStage = React.useMemo(
    () => cols.some(c => c.mapped_status !== 'hold' && c.uid !== lastFlowUid),
    [cols, lastFlowUid],
  );

  // 모드 선택(임시 preview) — 즉시 저장하지 않고 확인 모달
  const requestModeChange = async (target: WorkflowMode) => {
    if (target === workflow?.mode) return;
    setConfirmMode(target);
    setPreview(null);
    setPreviewLoading(true);
    try {
      const p = await api.previewWorkflowMode(projectId, target);
      setPreview(p);
    } catch {
      setPreview(null);
    } finally {
      setPreviewLoading(false);
    }
  };

  const tryClose = () => {
    if (dirty && !window.confirm('저장하지 않은 단계 변경사항이 있습니다. 닫을까요?')) return;
    onClose();
  };

  const currentMode = workflow?.mode ?? 'DEFAULT';

  return (
    <>
      <Drawer anchor="right" open={open} onClose={tryClose} PaperProps={{ sx: { width: 380, p: 0 } }}>
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          {/* Header */}
          <Box sx={{ p: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: `1px solid ${planAiColors.border.soft}` }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Typography sx={{ fontWeight: 700, fontSize: '1rem' }}>워크플로우 설정</Typography>
              <Chip
                size="small"
                label={`현재: ${currentMode === 'CUSTOM' ? '커스텀' : '기본'}`}
                sx={{
                  height: 22,
                  fontSize: '0.66rem',
                  fontWeight: 700,
                  bgcolor: currentMode === 'CUSTOM' ? planAiColors.status.purpleSoft : planAiColors.background.surfaceAlt,
                  color: currentMode === 'CUSTOM' ? planAiColors.status.purple : planAiColors.text.tertiary,
                }}
              />
            </Box>
            <IconButton size="small" onClick={tryClose}><CloseIcon fontSize="small" /></IconButton>
          </Box>

          <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
            {/* 모드 선택 */}
            <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, color: planAiColors.text.tertiary, mb: 1 }}>모드</Typography>
            <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
              {(['DEFAULT', 'CUSTOM'] as WorkflowMode[]).map(m => {
                const selected = currentMode === m;
                return (
                  <Button
                    key={m}
                    variant={selected ? 'contained' : 'outlined'}
                    size="small"
                    onClick={() => requestModeChange(m)}
                    sx={{ flex: 1, textTransform: 'none', fontWeight: 600 }}
                  >
                    {m === 'DEFAULT' ? '기본 모드' : '커스텀 모드'}
                  </Button>
                );
              })}
            </Box>
            <Typography sx={{ fontSize: '0.72rem', color: planAiColors.text.muted, mb: 2 }}>
              모드 변경은 즉시 적용되지 않고, 미리보기와 확인을 거칩니다.
            </Typography>

            <Divider sx={{ my: 2 }} />

            {/* 컬럼 편집 (CUSTOM 전용) */}
            {isCustom ? (
              <>
                <Typography sx={{ fontSize: '0.78rem', fontWeight: 600, color: planAiColors.text.tertiary, mb: 0.5 }}>현재 단계</Typography>
                <Typography sx={{ fontSize: '0.7rem', color: planAiColors.text.muted, mb: 1.5, lineHeight: 1.5 }}>
                  각 단계의 완료 조건을 설정하면, 조건을 만족한 Task가 다음 단계로 자동 이동합니다.
                </Typography>

                {/* 전체 일괄 적용 — 아래 단계별 설정을 한 번에 켜고 끈다 */}
                <Box
                  sx={{
                    mb: 1.5, p: 1.25, borderRadius: `${planAiRadius.md}px`,
                    bgcolor: planAiColors.background.surfaceAlt,
                    border: `1px solid ${planAiColors.border.soft}`,
                  }}
                >
                  <Typography sx={{ fontSize: '0.74rem', fontWeight: 700, mb: 0.25 }}>완료 시 다음 단계 이동 · 전체 적용</Typography>
                  <Typography sx={{ fontSize: '0.66rem', color: planAiColors.text.muted, mb: 1, lineHeight: 1.4 }}>
                    아래 토글은 Task에서 단계 완료를 체크했을 때 다음 단계로 이동할지 설정합니다.
                    전체 켜기/끄기는 ‘완료 체크 시 다음 단계로 이동’ 설정에만 적용됩니다. ‘완료 체크포인트로 사용’ 설정은 변경하지 않습니다.
                    마지막 단계는 다음 단계가 없어 제외됩니다.
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Button
                      size="small"
                      variant="outlined"
                      disabled={!hasMovableStage}
                      onClick={() => applyAutoMoveAll(true)}
                      sx={{ flex: 1, textTransform: 'none', fontSize: '0.72rem', fontWeight: 600 }}
                    >
                      전체 켜기
                    </Button>
                    <Button
                      size="small"
                      variant="outlined"
                      disabled={!hasMovableStage}
                      onClick={() => applyAutoMoveAll(false)}
                      sx={{ flex: 1, textTransform: 'none', fontSize: '0.72rem', fontWeight: 600 }}
                    >
                      전체 끄기
                    </Button>
                  </Box>
                </Box>

                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                  <SortableContext items={cols.map(c => c.uid)} strategy={verticalListSortingStrategy}>
                    {cols.map((c, i) => (
                      <SortableRow
                        key={c.uid}
                        col={c}
                        isLastStage={c.uid === lastFlowUid}
                        nextLabel={(() => {
                          const flow = cols.filter(x => x.mapped_status !== 'hold');
                          const idx = flow.findIndex(x => x.uid === c.uid);
                          return idx >= 0 && idx < flow.length - 1 ? flow[idx + 1].label : null;
                        })()}
                        onLabel={(v) => { setCols(prev => prev.map((x, xi) => xi === i ? { ...x, label: v } : x)); setDirty(true); }}
                        onDescription={(v) => { setCols(prev => prev.map((x, xi) => xi === i ? { ...x, description: v } : x)); setDirty(true); }}
                        onPatch={(patch) => { setCols(prev => prev.map((x, xi) => xi === i ? { ...x, ...patch } : x)); setDirty(true); }}
                        onDelete={() => { setCols(prev => prev.filter((_, xi) => xi !== i)); setDirty(true); }}
                      />
                    ))}
                  </SortableContext>
                </DndContext>
                <Button startIcon={<AddIcon />} size="small" onClick={addColumn} sx={{ textTransform: 'none', mt: 0.5 }}>
                  단계 추가
                </Button>
                <Typography sx={{ fontSize: '0.72rem', color: planAiColors.text.muted, mt: 2 }}>
                  기본적으로 첫 번째 단계는 시작 전, 마지막 단계는 완료 상태로 계산됩니다.
                </Typography>
              </>
            ) : (
              <Typography sx={{ fontSize: '0.8rem', color: planAiColors.text.tertiary }}>
                기본 모드에서는 To Do / In Progress / Done / Hold 단계를 사용합니다.
                커스텀 모드로 전환하면 프로젝트별로 단계를 자유롭게 구성할 수 있습니다.
              </Typography>
            )}
          </Box>

          {/* Footer */}
          {isCustom && (
            <Box sx={{ p: 2, borderTop: `1px solid ${planAiColors.border.soft}`, display: 'flex', gap: 1, justifyContent: 'flex-end' }}>
              <Button size="small" onClick={tryClose} sx={{ textTransform: 'none' }}>취소</Button>
              <Button
                size="small"
                variant="contained"
                disabled={!dirty || saveMutation.isPending}
                onClick={() => saveMutation.mutate()}
                sx={{ textTransform: 'none' }}
              >
                {saveMutation.isPending ? '저장 중…' : '저장'}
              </Button>
            </Box>
          )}
        </Box>
      </Drawer>

      {/* 모드 변경 확인 모달 */}
      <Dialog open={!!confirmMode} onClose={() => { setConfirmMode(null); setPreview(null); }} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>워크플로우 모드를 변경할까요?</DialogTitle>
        <DialogContent>
          <Typography sx={{ fontSize: '0.82rem', color: planAiColors.text.secondary, mb: 2 }}>
            워크플로우 모드를 변경하면 Board 컬럼 표시 방식이 달라집니다. 기존 Task 데이터는 삭제되지
            않지만, 화면에 표시되는 단계와 상태 배지가 변경될 수 있습니다.
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
            <Box>
              <Typography sx={{ fontSize: '0.7rem', color: planAiColors.text.muted }}>변경 전</Typography>
              <Typography sx={{ fontSize: '0.85rem', fontWeight: 700 }}>{currentMode === 'CUSTOM' ? '커스텀 모드' : '기본 모드'}</Typography>
            </Box>
            <Box>
              <Typography sx={{ fontSize: '0.7rem', color: planAiColors.text.muted }}>변경 후</Typography>
              <Typography sx={{ fontSize: '0.85rem', fontWeight: 700, color: planAiColors.brand.primary }}>
                {confirmMode === 'CUSTOM' ? '커스텀 모드' : '기본 모드'}
              </Typography>
            </Box>
          </Box>

          {previewLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}><CircularProgress size={22} /></Box>}

          {preview && (
            <Box sx={{ bgcolor: planAiColors.background.surfaceAlt, borderRadius: `${planAiRadius.md}px`, p: 1.5 }}>
              {preview.columns.length > 0 && (
                <>
                  <Typography sx={{ fontSize: '0.72rem', fontWeight: 600, color: planAiColors.text.tertiary, mb: 0.5 }}>
                    {preview.columns.some(c => c.restored) ? '복원될 단계' : '생성될 단계'}
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 1 }}>
                    {preview.columns.map((c, i) => (
                      <Chip key={i} size="small" label={`${c.label} · ${STATUS_KO[c.mapped_status] || c.mapped_status}`} sx={{ height: 22, fontSize: '0.66rem' }} />
                    ))}
                  </Box>
                </>
              )}
              {Object.keys(preview.task_buckets).length > 0 && (
                <Typography sx={{ fontSize: '0.72rem', color: planAiColors.text.muted, mb: 0.5 }}>
                  Task 배치: {Object.entries(preview.task_buckets).map(([s, n]) => `${STATUS_KO[s] || s} ${n}건`).join(', ')}
                </Typography>
              )}
              <Typography sx={{ fontSize: '0.72rem', color: planAiColors.text.muted }}>{preview.auto_progress_note}</Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 2, pb: 2 }}>
          <Button onClick={() => { setConfirmMode(null); setPreview(null); }} sx={{ textTransform: 'none' }}>취소</Button>
          <Button
            variant="contained"
            disabled={changeModeMutation.isPending}
            onClick={() => confirmMode && changeModeMutation.mutate(confirmMode)}
            sx={{ textTransform: 'none' }}
          >
            {changeModeMutation.isPending ? '적용 중…' : '변경사항 적용'}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default WorkflowSettingsDrawer;
