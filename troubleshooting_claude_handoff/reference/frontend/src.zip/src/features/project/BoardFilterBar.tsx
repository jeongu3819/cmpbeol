import React from 'react';
import {
  Box,
  InputBase,
  IconButton,
  Popover,
  Typography,
  Chip,
  Divider,
  Button,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import CloseIcon from '@mui/icons-material/Close';
import TuneIcon from '@mui/icons-material/Tune';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import CheckIcon from '@mui/icons-material/Check';
import { planAiColors, planAiShadows, planAiRadius } from '../../theme/tokens';
import { ScheduleFilter, SCHEDULE_FILTER_OPTIONS } from '../../utils/scheduleFormat';

// ── Board 정렬/우선순위 공통 정의 (BoardView 와 공유) ──
export type BoardSortField = 'default' | 'due_date' | 'priority';
export type BoardPriorityFilter = 'all' | 'high' | 'medium' | 'low';

const scheduleFilterLabel = (v: ScheduleFilter) =>
  SCHEDULE_FILTER_OPTIONS.find(o => o.value === v)?.label ?? '전체';

const BOARD_SORT_OPTIONS: { value: BoardSortField; label: string }[] = [
  { value: 'default', label: '기본순서' },
  { value: 'due_date', label: '마감일순' },
  { value: 'priority', label: '우선순위순' },
];

const BOARD_PRIORITY_OPTIONS: { value: BoardPriorityFilter; label: string }[] = [
  { value: 'all', label: '전체' },
  { value: 'high', label: '높음' },
  { value: 'medium', label: '보통' },
  { value: 'low', label: '낮음' },
];

const sortLabel = (v: BoardSortField) => BOARD_SORT_OPTIONS.find(o => o.value === v)?.label ?? '기본순서';
const priorityLabel = (v: BoardPriorityFilter) =>
  BOARD_PRIORITY_OPTIONS.find(o => o.value === v)?.label ?? '전체';

interface BoardFilterBarProps {
  searchQuery: string;
  onSearchQueryChange: (value: string) => void;
  sortBy: BoardSortField;
  onSortByChange: (value: BoardSortField) => void;
  priorityFilter: BoardPriorityFilter;
  onPriorityFilterChange: (value: BoardPriorityFilter) => void;
  scheduleFilter: ScheduleFilter;
  onScheduleFilterChange: (value: ScheduleFilter) => void;
  /** 검색어/정렬/우선순위/일정 상태를 모두 기본값으로 되돌림 */
  onResetFilters: () => void;
}

/**
 * Board 상단 통합 필터바.
 * 하나의 pill(검색 + 필터·정렬 버튼)로 정리하고, 적용된 정렬/우선순위는 아래 chip 으로 노출.
 * 필터 상태는 영속화하지 않으며(상위에서 관리), 여기서는 표시/입력만 담당한다.
 */
const BoardFilterBar: React.FC<BoardFilterBarProps> = ({
  searchQuery,
  onSearchQueryChange,
  sortBy,
  onSortByChange,
  priorityFilter,
  onPriorityFilterChange,
  scheduleFilter,
  onScheduleFilterChange,
  onResetFilters,
}) => {
  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | null>(null);
  const open = Boolean(anchorEl);

  const filterActive = sortBy !== 'default' || priorityFilter !== 'all' || scheduleFilter !== 'all';
  const showChips = filterActive;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75, minWidth: 0 }}>
      {/* 통합 pill: 검색 + 필터·정렬 */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          height: 38,
          pl: 1.25,
          pr: 0.5,
          bgcolor: planAiColors.background.surface,
          border: `1px solid ${planAiColors.border.normal}`,
          borderRadius: 999,
          boxShadow: planAiShadows.sm,
          transition: 'border-color 0.15s ease, box-shadow 0.15s ease',
          '&:focus-within': {
            borderColor: planAiColors.brand.primary,
            boxShadow: `0 0 0 3px ${planAiColors.brand.primarySoft}`,
          },
        }}
      >
        <SearchIcon sx={{ fontSize: 18, color: planAiColors.text.tertiary, flexShrink: 0 }} />
        <InputBase
          value={searchQuery}
          onChange={e => onSearchQueryChange(e.target.value)}
          placeholder="Task / 담당자 / 서브프로젝트 검색..."
          sx={{
            ml: 1,
            flex: 1,
            minWidth: 120,
            fontSize: '0.82rem',
            '& input': { p: 0 },
          }}
        />
        {searchQuery && (
          <IconButton
            size="small"
            onClick={() => onSearchQueryChange('')}
            sx={{ p: 0.25, mr: 0.25 }}
            aria-label="검색어 지우기"
          >
            <CloseIcon sx={{ fontSize: 15 }} />
          </IconButton>
        )}

        <Divider orientation="vertical" flexItem sx={{ my: 0.75, mx: 0.5 }} />

        {/* 필터 · 정렬 버튼 */}
        <Box
          role="button"
          tabIndex={0}
          onClick={e => setAnchorEl(e.currentTarget)}
          onKeyDown={e => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setAnchorEl(e.currentTarget);
            }
          }}
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 0.5,
            height: 30,
            px: 1.25,
            borderRadius: 999,
            cursor: 'pointer',
            userSelect: 'none',
            color: filterActive ? planAiColors.brand.primary : planAiColors.text.secondary,
            bgcolor: filterActive ? planAiColors.brand.primarySoft : 'transparent',
            fontSize: '0.78rem',
            fontWeight: 600,
            whiteSpace: 'nowrap',
            '&:hover': { bgcolor: filterActive ? planAiColors.brand.primarySoft : planAiColors.background.surfaceAlt },
          }}
        >
          <TuneIcon sx={{ fontSize: 16 }} />
          필터 · 정렬
          <KeyboardArrowDownIcon
            sx={{ fontSize: 16, transition: 'transform 0.15s ease', transform: open ? 'rotate(180deg)' : 'none' }}
          />
        </Box>
      </Box>

      {/* 적용된 필터 chip */}
      {showChips && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, flexWrap: 'wrap', pl: 0.5 }}>
          {scheduleFilter !== 'all' && (
            <Chip
              size="small"
              label={`일정: ${scheduleFilterLabel(scheduleFilter)}`}
              onDelete={() => onScheduleFilterChange('all')}
              sx={{
                height: 24,
                fontSize: '0.72rem',
                fontWeight: 600,
                bgcolor: '#FEF3C7',
                color: '#92400E',
                '& .MuiChip-deleteIcon': { fontSize: 15, color: '#92400E' },
              }}
            />
          )}
          {priorityFilter !== 'all' && (
            <Chip
              size="small"
              label={`우선순위: ${priorityLabel(priorityFilter)}`}
              onDelete={() => onPriorityFilterChange('all')}
              sx={{
                height: 24,
                fontSize: '0.72rem',
                fontWeight: 600,
                bgcolor: planAiColors.brand.primarySoft,
                color: planAiColors.brand.primary,
                '& .MuiChip-deleteIcon': { fontSize: 15, color: planAiColors.brand.primary },
              }}
            />
          )}
          {sortBy !== 'default' && (
            <Chip
              size="small"
              label={`정렬: ${sortLabel(sortBy)}`}
              onDelete={() => onSortByChange('default')}
              sx={{
                height: 24,
                fontSize: '0.72rem',
                fontWeight: 600,
                bgcolor: planAiColors.background.surfaceAlt,
                color: planAiColors.text.secondary,
                '& .MuiChip-deleteIcon': { fontSize: 15, color: planAiColors.text.tertiary },
              }}
            />
          )}
        </Box>
      )}

      {/* 필터 · 정렬 Popover */}
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        slotProps={{
          paper: {
            sx: {
              mt: 1,
              width: 240,
              borderRadius: `${planAiRadius.lg}px`,
              border: `1px solid ${planAiColors.border.soft}`,
              boxShadow: planAiShadows.lg,
            },
          },
        }}
      >
        <Box sx={{ p: 1.5 }}>
          {/* 정렬 */}
          <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: planAiColors.text.tertiary, mb: 0.75, letterSpacing: 0.4 }}>
            정렬
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.25 }}>
            {BOARD_SORT_OPTIONS.map(opt => {
              const selected = sortBy === opt.value;
              return (
                <Box
                  key={opt.value}
                  onClick={() => onSortByChange(opt.value)}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    px: 1,
                    py: 0.75,
                    borderRadius: `${planAiRadius.sm}px`,
                    cursor: 'pointer',
                    fontSize: '0.82rem',
                    fontWeight: selected ? 700 : 500,
                    color: selected ? planAiColors.brand.primary : planAiColors.text.secondary,
                    bgcolor: selected ? planAiColors.brand.primarySoft : 'transparent',
                    '&:hover': { bgcolor: selected ? planAiColors.brand.primarySoft : planAiColors.background.surfaceAlt },
                  }}
                >
                  {opt.label}
                  {selected && <CheckIcon sx={{ fontSize: 16 }} />}
                </Box>
              );
            })}
          </Box>

          <Divider sx={{ my: 1.25 }} />

          {/* 우선순위 */}
          <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: planAiColors.text.tertiary, mb: 0.75, letterSpacing: 0.4 }}>
            우선순위
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {BOARD_PRIORITY_OPTIONS.map(opt => {
              const selected = priorityFilter === opt.value;
              return (
                <Chip
                  key={opt.value}
                  label={opt.label}
                  size="small"
                  onClick={() => onPriorityFilterChange(opt.value)}
                  sx={{
                    height: 28,
                    fontSize: '0.76rem',
                    fontWeight: selected ? 700 : 500,
                    cursor: 'pointer',
                    bgcolor: selected ? planAiColors.brand.primary : planAiColors.background.surfaceAlt,
                    color: selected ? '#fff' : planAiColors.text.secondary,
                    '&:hover': { bgcolor: selected ? planAiColors.brand.primary : planAiColors.border.soft },
                  }}
                />
              );
            })}
          </Box>

          <Divider sx={{ my: 1.25 }} />

          {/* 일정 상태 */}
          <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, color: planAiColors.text.tertiary, mb: 0.75, letterSpacing: 0.4 }}>
            일정 상태
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {SCHEDULE_FILTER_OPTIONS.map(opt => {
              const selected = scheduleFilter === opt.value;
              return (
                <Chip
                  key={opt.value}
                  label={opt.label}
                  size="small"
                  onClick={() => onScheduleFilterChange(opt.value)}
                  sx={{
                    height: 28,
                    fontSize: '0.76rem',
                    fontWeight: selected ? 700 : 500,
                    cursor: 'pointer',
                    bgcolor: selected ? planAiColors.brand.primary : planAiColors.background.surfaceAlt,
                    color: selected ? '#fff' : planAiColors.text.secondary,
                    '&:hover': { bgcolor: selected ? planAiColors.brand.primary : planAiColors.border.soft },
                  }}
                />
              );
            })}
          </Box>

          <Divider sx={{ my: 1.25 }} />

          {/* 초기화 */}
          <Button
            fullWidth
            size="small"
            variant="text"
            onClick={() => {
              onResetFilters();
              setAnchorEl(null);
            }}
            sx={{
              fontSize: '0.78rem',
              fontWeight: 600,
              color: planAiColors.text.secondary,
              '&:hover': { bgcolor: planAiColors.background.surfaceAlt },
            }}
          >
            초기화
          </Button>
        </Box>
      </Popover>
    </Box>
  );
};

export default BoardFilterBar;
