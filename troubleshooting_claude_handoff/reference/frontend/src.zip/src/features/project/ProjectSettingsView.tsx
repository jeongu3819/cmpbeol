import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Button,
  Avatar,
  IconButton,
  Divider,
  Switch,
  FormControlLabel,
  Select,
  FormControl,
  InputLabel,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Checkbox,
  Tooltip,
} from '@mui/material';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import SecurityIcon from '@mui/icons-material/Security';
import EditIcon from '@mui/icons-material/Edit';
import DescriptionIcon from '@mui/icons-material/Description';
import GroupIcon from '@mui/icons-material/Group';
import SearchIcon from '@mui/icons-material/Search';
import PublicIcon from '@mui/icons-material/Public';
import LockIcon from '@mui/icons-material/Lock';
import TextField from '@mui/material/TextField';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, User, MemberGroup } from '../../api/client';
import { useAppStore } from '../../stores/useAppStore';
import { useNavigate } from 'react-router-dom';
import ItemHistorySection from '../../components/ItemHistorySection';

interface ProjectSettingsViewProps {
  projectId: number;
}

const ProjectSettingsView: React.FC<ProjectSettingsViewProps> = ({ projectId }) => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const currentUserId = useAppStore(state => state.currentUserId);

  // Fetch data
  const { data: members = [] } = useQuery<any[]>({
    queryKey: ['projectMembers', projectId],
    queryFn: async () => {
      const res = await api.getProjectMembers(projectId);
      return res;
    },
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['users'],
    queryFn: () => api.getUsers(),
  });

  const { data: projects = [] } = useQuery<any[]>({
    queryKey: ['projects', currentUserId],
    queryFn: () => api.getProjects(currentUserId),
  });

  // 공간 목적별 Settings 분기용 — Sheets 영역은 설비 운영 공간에서만 노출
  const { data: spaces = [] } = useQuery<any[]>({
    queryKey: ['spaces', currentUserId],
    queryFn: () => api.getSpaces(currentUserId),
    enabled: currentUserId > 0,
  });

  const { data: memberGroups = [] } = useQuery<MemberGroup[]>({
    queryKey: ['memberGroups', currentUserId],
    queryFn: () => api.getMemberGroups(currentUserId),
    enabled: currentUserId > 0,
  });

  const project = projects.find((p: any) => p.id === projectId);
  // 프로젝트가 속한 Space의 purpose 조회 (없거나 모르면 'project_management'로 간주 = Sheets 숨김)
  const projectSpace = project?.space_id ? spaces.find((s: any) => s.id === project.space_id) : null;
  const showSheetsSection = projectSpace?.purpose === 'equipment_ops';

  // State
  const [editingName, setEditingName] = useState('');
  const [editingDescription, setEditingDescription] = useState('');
  const [addMemberOpen, setAddMemberOpen] = useState(false);
  const [selectedUserIds, setSelectedUserIds] = useState<number[]>([]);
  const [memberSearch, setMemberSearch] = useState('');
  const [knoxQuery, setKnoxQuery] = useState('');
  const [knoxResults, setKnoxResults] = useState<any[]>([]);
  void knoxQuery; void setKnoxQuery;
  const [visibility, setVisibility] = useState<string>(project?.visibility || 'private');
  const [requireApproval, setRequireApproval] = useState(project?.require_approval ?? false);
  const [permissions, setPermissions] = useState<Record<string, string>>(
    project?.permissions ?? {
      post_write: 'all',
      post_edit: 'all',
      post_view: 'all',
      comment_write: 'all',
      file_view: 'all',
      file_download: 'all',
    }
  );

  // Sync state when project data loads
  React.useEffect(() => {
    if (project) {
      setEditingName(project.name || '');
      setEditingDescription(project.description || '');
      setVisibility(project.visibility || 'private');
      setRequireApproval(project.require_approval ?? false);
      setPermissions(
        project.permissions ?? {
          post_write: 'all',
          post_edit: 'all',
          post_view: 'all',
          comment_write: 'all',
          file_view: 'all',
          file_download: 'all',
        }
      );
    }
  }, [project]);

  // Mutations
  const addMemberMutation = useMutation({
    mutationFn: (userId: number) => api.addProjectMember(projectId, userId, 'member', currentUserId),
  });

  const removeMemberMutation = useMutation({
    mutationFn: (userId: number) => api.removeProjectMember(projectId, userId, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projectMembers', projectId] });
      queryClient.invalidateQueries({ queryKey: ['projects'] });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: (updates: Record<string, any>) => api.updateProject(projectId, updates, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
    },
  });

  const handleSavePermissions = () => {
    updateProjectMutation.mutate({ visibility, require_approval: requireApproval, permissions });
  };

  const deleteProjectMutation = useMutation({
    mutationFn: () => api.deleteProject(projectId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      queryClient.invalidateQueries({ queryKey: ['stats'] });
      navigate('/');
    },
  });

  const handleAddMembers = async () => {
    for (const uid of selectedUserIds) {
      try {
        await addMemberMutation.mutateAsync(uid);
      } catch {
        // 이미 멤버인 경우 무시
      }
    }
    queryClient.invalidateQueries({ queryKey: ['projectMembers', projectId] });
    setSelectedUserIds([]);
    setAddMemberOpen(false);
    setMemberSearch('');
    setKnoxResults([]);
    setKnoxQuery('');
  };

  // Knox 사내 검색 진입점은 1차 구현에서 비활성화. 멤버 추가는 공간 멤버 범위로 제한됨.

  // Create user from Knox result then add as member
  const createAndAddMutation = useMutation({
    mutationFn: async (data: { username: string; loginid: string; deptname?: string; mail?: string }) => {
      const newUser = await api.createUser({ ...data, role: 'member' });
      await api.addProjectMember(projectId, newUser.id, 'member', currentUserId);
      return newUser;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projectMembers', projectId] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: async (err: any) => {
      // User already exists — try adding as member directly
      const detail = err?.response?.data?.detail || '';
      if (detail.includes('already exists') || detail.includes('이미 등록')) {
        const matched = users.find(u => u.loginid === (err as any)._loginid);
        if (matched) {
          try {
            await addMemberMutation.mutateAsync(matched.id);
          } catch { /* ignore */ }
          queryClient.invalidateQueries({ queryKey: ['projectMembers', projectId] });
        }
      }
    },
  });

  const memberUserIds = new Set(members.map((m: any) => m.user_id));
  // 프로젝트 멤버는 반드시 해당 공간 멤버 중에서만 추가 가능.
  // projectSpace.members 가 있으면 그 user_id 집합으로 제한, 없으면(=space 미배정 프로젝트) 전체 사용자 허용.
  const spaceMemberUserIds: Set<number> | null = projectSpace?.members
    ? new Set<number>(projectSpace.members.map((sm: any) => sm.user_id))
    : null;
  const availableUsers = users.filter(u => {
    if (memberUserIds.has(u.id)) return false;
    if (spaceMemberUserIds && !spaceMemberUserIds.has(u.id)) return false;
    return true;
  });
  const isOwner = project?.owner_id === currentUserId;
  const currentUserObj = users.find(u => u.id === currentUserId);
  const isSuperAdmin = currentUserObj?.role === 'super_admin';
  const currentMember = members.find((m: any) => m.user_id === currentUserId);
  // UI 라벨 "담당자" = ProjectMember.role in (manager, member). viewer는 관리 불가.
  const isProjectManager = currentMember?.role === 'manager' || currentMember?.role === 'member';
  const canManage = isOwner || isSuperAdmin || isProjectManager;

  const updateMemberRoleMut = useMutation({
    mutationFn: ({ targetUserId, role }: { targetUserId: number; role: string }) =>
      api.updateProjectMemberRole(projectId, targetUserId, role, currentUserId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['projectMembers', projectId] }),
  });

  return (
    <Box sx={{ maxWidth: 800, mx: 'auto', py: 2 }}>
      {/* ─── Project Name Section (소유자/담당자) ─── */}
      {canManage && (
        <Paper
          sx={{
            p: 3, mb: 3, borderRadius: 3,
            border: '1px solid rgba(0,0,0,0.08)',
            bgcolor: 'rgba(255,255,255,0.7)',
            backdropFilter: 'blur(8px)',
            boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
            <EditIcon sx={{ color: '#2955FF', fontSize: '1.3rem' }} />
            <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem', color: '#1A1D29' }}>
              프로젝트 이름
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center' }}>
            <TextField
              fullWidth
              size="small"
              value={editingName}
              onChange={e => setEditingName(e.target.value)}
              placeholder="프로젝트 이름..."
              sx={{ '& .MuiOutlinedInput-root': { fontSize: '0.9rem' } }}
            />
            <Button
              variant="contained"
              size="small"
              disabled={!editingName.trim() || editingName === project?.name || updateProjectMutation.isPending}
              onClick={() => updateProjectMutation.mutate({ name: editingName.trim() })}
              sx={{ bgcolor: '#2955FF', '&:hover': { bgcolor: '#1E44CC' }, px: 3, whiteSpace: 'nowrap' }}
            >
              변경
            </Button>
          </Box>
        </Paper>
      )}

      {/* ─── Project Description Section (소유자/담당자) ─── */}
      {canManage && (
        <Paper
          sx={{
            p: 3, mb: 3, borderRadius: 3,
            border: '1px solid rgba(0,0,0,0.08)',
            bgcolor: 'rgba(255,255,255,0.7)',
            backdropFilter: 'blur(8px)',
            boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
            <DescriptionIcon sx={{ color: '#2955FF', fontSize: '1.3rem' }} />
            <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem', color: '#1A1D29' }}>
              프로젝트 설명
            </Typography>
          </Box>
          <TextField
            fullWidth
            size="small"
            multiline
            minRows={2}
            maxRows={5}
            value={editingDescription}
            onChange={e => setEditingDescription(e.target.value)}
            placeholder="프로젝트에 대한 간단한 설명을 입력하세요..."
            sx={{ mb: 1.5, '& .MuiOutlinedInput-root': { fontSize: '0.9rem' } }}
          />
          <Button
            variant="contained"
            size="small"
            disabled={editingDescription === (project?.description || '') || updateProjectMutation.isPending}
            onClick={() => updateProjectMutation.mutate({ description: editingDescription.trim() })}
            sx={{ bgcolor: '#2955FF', '&:hover': { bgcolor: '#1E44CC' }, px: 3, whiteSpace: 'nowrap' }}
          >
            저장
          </Button>
        </Paper>
      )}

      {/* ─── Members Section ─── */}
      <Paper
        sx={{
          p: 3,
          mb: 3,
          borderRadius: 3,
          border: '1px solid rgba(0,0,0,0.08)',
          bgcolor: 'rgba(255,255,255,0.7)',
          backdropFilter: 'blur(8px)',
          boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
        }}
      >
        <Box
          sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2.5 }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <GroupIcon sx={{ color: '#2955FF', fontSize: '1.3rem' }} />
            <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem', color: '#1A1D29' }}>
              프로젝트 멤버
            </Typography>
            <Chip
              label={`${members.length}명`}
              size="small"
              sx={{
                bgcolor: '#EEF2FF',
                color: '#2955FF',
                fontWeight: 700,
                fontSize: '0.7rem',
                height: 22,
              }}
            />
          </Box>
          {canManage && (
            <Button
              size="small"
              startIcon={<PersonAddIcon />}
              onClick={() => setAddMemberOpen(true)}
              sx={{ fontWeight: 600, fontSize: '0.8rem', color: '#2955FF' }}
            >
              멤버 추가
            </Button>
          )}
        </Box>

        <Box sx={{ border: '1px solid #E5E7EB', borderRadius: 2, overflow: 'hidden' }}>
          {/* Table Header */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: canManage ? 'minmax(80px, 180px) 1fr 1fr 100px 40px' : 'minmax(80px, 180px) 1fr 1fr 100px',
              gap: 1,
              px: 2,
              py: 1,
              bgcolor: '#F9FAFB',
              borderBottom: '1px solid #E5E7EB',
            }}
          >
            <Typography variant="caption" sx={{ fontWeight: 700, color: '#6B7280', fontSize: '0.7rem' }}>이름</Typography>
            <Typography variant="caption" sx={{ fontWeight: 700, color: '#6B7280', fontSize: '0.7rem' }}>ID</Typography>
            <Typography variant="caption" sx={{ fontWeight: 700, color: '#6B7280', fontSize: '0.7rem' }}>소속</Typography>
            <Typography variant="caption" sx={{ fontWeight: 700, color: '#6B7280', fontSize: '0.7rem' }}>역할</Typography>
            {canManage && <Box />}
          </Box>

          {/* Table Rows */}
          {members.map((m: any) => {
            const isCurrentOwner = m.role === 'owner';
            return (
              <Box
                key={m.user_id}
                sx={{
                  display: 'grid',
                  gridTemplateColumns: canManage ? 'minmax(80px, 180px) 1fr 1fr 100px 40px' : 'minmax(80px, 180px) 1fr 1fr 100px',
                  gap: 1,
                  alignItems: 'center',
                  px: 2,
                  py: 1,
                  borderBottom: '1px solid #F3F4F6',
                  bgcolor: isCurrentOwner ? '#FFFBEB' : 'transparent',
                  '&:hover': { bgcolor: isCurrentOwner ? '#FEF9C3' : '#F9FAFB' },
                  '&:last-child': { borderBottom: 'none' },
                }}
              >
                {/* 이름 */}
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, minWidth: 0 }}>
                  <Avatar
                    sx={{
                      width: 28,
                      height: 28,
                      fontSize: '0.65rem',
                      bgcolor: m.avatar_color || '#2955FF',
                      flexShrink: 0,
                    }}
                  >
                    {(m.username || '?').charAt(0).toUpperCase()}
                  </Avatar>
                  <Typography variant="body2" noWrap sx={{ fontWeight: 600, fontSize: '0.8rem', color: '#374151' }}>
                    {m.username || `User ${m.user_id}`}
                  </Typography>
                </Box>

                {/* ID */}
                <Typography variant="body2" noWrap sx={{ color: m.loginid ? '#374151' : '#9CA3AF', fontSize: '0.75rem' }}>
                  {m.loginid || '-'}
                </Typography>

                {/* 소속 */}
                <Typography variant="body2" noWrap sx={{ color: m.deptname ? '#374151' : '#9CA3AF', fontSize: '0.75rem' }}>
                  {m.deptname || '-'}
                </Typography>

                {/* 역할 */}
                {isCurrentOwner ? (
                  <Chip
                    label="소유자"
                    size="small"
                    sx={{ height: 22, fontSize: '0.65rem', fontWeight: 700, bgcolor: '#FEF3C7', color: '#D97706', width: 'fit-content' }}
                  />
                ) : canManage ? (
                  <Select
                    native
                    value={m.role || 'member'}
                    size="small"
                    onChange={e => updateMemberRoleMut.mutate({ targetUserId: m.user_id, role: e.target.value as string })}
                    sx={{
                      height: 26, fontSize: '0.7rem', fontWeight: 600,
                      bgcolor: m.role === 'manager' ? '#DBEAFE' : m.role === 'viewer' ? '#F3F4F6' : '#DCFCE7',
                      color: m.role === 'manager' ? '#2955FF' : m.role === 'viewer' ? '#6B7280' : '#22C55E',
                      '& .MuiNativeSelect-select': { py: 0.2, px: 1 },
                      '& .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent' },
                      borderRadius: 2,
                    }}
                  >
                    <option value="member" style={{ fontSize: '0.8rem' }}>담당자</option>
                    <option value="viewer" style={{ fontSize: '0.8rem' }}>Viewer</option>
                  </Select>
                ) : (
                  <Chip
                    label={m.role === 'viewer' ? 'Viewer' : '담당자'}
                    size="small"
                    sx={{
                      height: 22, fontSize: '0.65rem', fontWeight: 700, width: 'fit-content',
                      bgcolor: m.role === 'viewer' ? '#F3F4F6' : '#DCFCE7',
                      color: m.role === 'viewer' ? '#6B7280' : '#22C55E',
                    }}
                  />
                )}

                {/* 액션 */}
                {canManage && (
                  <Box>
                    {!isCurrentOwner ? (
                      <Tooltip title="멤버 제거">
                        <IconButton
                          size="small"
                          onClick={() => removeMemberMutation.mutate(m.user_id)}
                          sx={{ color: '#EF4444', '&:hover': { bgcolor: '#FEF2F2' } }}
                        >
                          <DeleteOutlineIcon sx={{ fontSize: '1rem' }} />
                        </IconButton>
                      </Tooltip>
                    ) : <Box />}
                  </Box>
                )}
              </Box>
            );
          })}

          {members.length === 0 && (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <GroupIcon sx={{ fontSize: '2.5rem', color: '#D1D5DB', mb: 1 }} />
              <Typography variant="body2" sx={{ color: '#9CA3AF' }}>
                아직 멤버가 없습니다
              </Typography>
            </Box>
          )}
        </Box>
      </Paper>

      {/* ─── Visibility Section ─── */}
      {canManage && (
        <Paper
          sx={{
            p: 3,
            mb: 3,
            borderRadius: 3,
            border: '1px solid #E5E7EB',
            boxShadow: '0 1px 8px rgba(0,0,0,0.04)',
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
            {visibility === 'public' ? (
              <PublicIcon sx={{ color: '#2955FF', fontSize: '1.3rem' }} />
            ) : (
              <LockIcon sx={{ color: '#6B7280', fontSize: '1.3rem' }} />
            )}
            <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem', color: '#1A1D29' }}>
              공개 범위
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
            {[
              { value: 'private', label: '비공개', desc: '소유자와 프로젝트 멤버만 볼 수 있습니다' },
              { value: 'public', label: '공개', desc: '모든 사용자가 볼 수 있습니다' },
            ].map(opt => (
              <Box
                key={opt.value}
                onClick={() => setVisibility(opt.value)}
                sx={{
                  flex: 1, p: 1.5, borderRadius: 2, cursor: 'pointer',
                  border: visibility === opt.value ? '2px solid #2955FF' : '1px solid #E5E7EB',
                  bgcolor: visibility === opt.value ? '#EEF2FF' : 'transparent',
                  '&:hover': { borderColor: '#2955FF' },
                  transition: 'all 0.15s',
                }}
              >
                <Typography variant="body2" sx={{ fontWeight: 600, fontSize: '0.85rem' }}>{opt.label}</Typography>
                <Typography variant="caption" sx={{ color: '#9CA3AF', fontSize: '0.7rem' }}>{opt.desc}</Typography>
              </Box>
            ))}
          </Box>
          {visibility !== (project?.visibility || 'private') && (
            <Button
              size="small"
              variant="contained"
              onClick={() => updateProjectMutation.mutate({ visibility })}
              disabled={updateProjectMutation.isPending}
              sx={{ bgcolor: '#2955FF', fontWeight: 600, fontSize: '0.8rem', '&:hover': { bgcolor: '#1E44CC' } }}
            >
              공개 범위 저장
            </Button>
          )}
        </Paper>
      )}

      {/* ─── Permissions Section ─── */}
      {canManage && (
        <Paper
          sx={{
            p: 3,
            mb: 3,
            borderRadius: 3,
            border: '1px solid #E5E7EB',
            boxShadow: '0 1px 8px rgba(0,0,0,0.04)',
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2.5 }}>
            <SecurityIcon sx={{ color: '#8B5CF6', fontSize: '1.3rem' }} />
            <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem', color: '#1A1D29' }}>
              권한 설정
            </Typography>
          </Box>

          <FormControlLabel
            control={
              <Switch
                checked={requireApproval}
                onChange={e => setRequireApproval(e.target.checked)}
                color="primary"
              />
            }
            label={
              <Box>
                <Typography variant="body2" sx={{ fontWeight: 600, fontSize: '0.85rem' }}>
                  관리자 승인 후 참여 가능
                </Typography>
                <Typography variant="caption" sx={{ color: '#9CA3AF', fontSize: '0.7rem' }}>
                  {requireApproval
                    ? 'ON: 참여 요청 후 관리자가 승인해야 합니다'
                    : 'OFF: 즉시 참여 가능'}
                </Typography>
              </Box>
            }
            sx={{ mb: 2, ml: 0 }}
          />

          <Divider sx={{ mb: 2 }} />

          {/* Post Permissions */}
          <Typography
            variant="caption"
            sx={{
              fontWeight: 700,
              color: '#6B7280',
              textTransform: 'uppercase',
              fontSize: '0.65rem',
              letterSpacing: '0.05em',
              mb: 1,
              display: 'block',
            }}
          >
            게시글 권한
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 1.5, mb: 2 }}>
            <FormControl size="small" fullWidth>
              <InputLabel sx={{ fontSize: '0.8rem' }}>작성 권한</InputLabel>
              <Select
                native
                value={permissions.post_write || 'all'}
                onChange={e =>
                  setPermissions({ ...permissions, post_write: e.target.value as string })
                }
                label="작성 권한"
                sx={{ fontSize: '0.8rem' }}
              >
                <option value="all">전체</option>
                <option value="super_admin">슈퍼관리자</option>
                <option value="members_only">담당자만</option>
              </Select>
            </FormControl>
            <FormControl size="small" fullWidth>
              <InputLabel sx={{ fontSize: '0.8rem' }}>수정 권한</InputLabel>
              <Select
                native
                value={permissions.post_edit || 'all'}
                onChange={e =>
                  setPermissions({ ...permissions, post_edit: e.target.value as string })
                }
                label="수정 권한"
                sx={{ fontSize: '0.8rem' }}
              >
                <option value="all">전체</option>
                <option value="super_admin">슈퍼관리자</option>
                <option value="members_only">담당자만</option>
              </Select>
            </FormControl>
            <FormControl size="small" fullWidth>
              <InputLabel sx={{ fontSize: '0.8rem' }}>조회 권한</InputLabel>
              <Select
                native
                value={permissions.post_view || 'all'}
                onChange={e =>
                  setPermissions({ ...permissions, post_view: e.target.value as string })
                }
                label="조회 권한"
                sx={{ fontSize: '0.8rem' }}
              >
                <option value="all">전체</option>
                <option value="members_only">담당자만</option>
              </Select>
            </FormControl>
          </Box>

          {/* Comment & File Permissions */}
          <Typography
            variant="caption"
            sx={{
              fontWeight: 700,
              color: '#6B7280',
              textTransform: 'uppercase',
              fontSize: '0.65rem',
              letterSpacing: '0.05em',
              mb: 1,
              display: 'block',
            }}
          >
            댓글 & 파일 권한
          </Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 1.5, mb: 3 }}>
            <FormControl size="small" fullWidth>
              <InputLabel sx={{ fontSize: '0.8rem' }}>댓글 작성</InputLabel>
              <Select
                native
                value={permissions.comment_write || 'all'}
                onChange={e =>
                  setPermissions({ ...permissions, comment_write: e.target.value as string })
                }
                label="댓글 작성"
                sx={{ fontSize: '0.8rem' }}
              >
                <option value="all">전체</option>
                <option value="members_only">담당자만</option>
              </Select>
            </FormControl>
            <FormControl size="small" fullWidth>
              <InputLabel sx={{ fontSize: '0.8rem' }}>파일 조회</InputLabel>
              <Select
                native
                value={permissions.file_view || 'all'}
                onChange={e =>
                  setPermissions({ ...permissions, file_view: e.target.value as string })
                }
                label="파일 조회"
                sx={{ fontSize: '0.8rem' }}
              >
                <option value="all">전체</option>
                <option value="members_only">담당자만</option>
              </Select>
            </FormControl>
            <FormControl size="small" fullWidth>
              <InputLabel sx={{ fontSize: '0.8rem' }}>파일 다운로드</InputLabel>
              <Select
                native
                value={permissions.file_download || 'all'}
                onChange={e =>
                  setPermissions({ ...permissions, file_download: e.target.value as string })
                }
                label="파일 다운로드"
                sx={{ fontSize: '0.8rem' }}
              >
                <option value="all">전체</option>
                <option value="members_only">담당자만</option>
              </Select>
            </FormControl>
          </Box>

          <Button
            variant="contained"
            onClick={handleSavePermissions}
            disabled={updateProjectMutation.isPending}
            sx={{
              bgcolor: '#2955FF',
              fontWeight: 600,
              px: 4,
              '&:hover': { bgcolor: '#1E44CC' },
            }}
          >
            {updateProjectMutation.isPending ? '저장 중...' : '권한 설정 저장'}
          </Button>

          {updateProjectMutation.isSuccess && (
            <Typography variant="caption" sx={{ ml: 2, color: '#22C55E', fontWeight: 600 }}>
              ✓ 저장되었습니다
            </Typography>
          )}
        </Paper>
      )}

      {/* ─── Sheet 연결 섹션 (v3.0) — 설비 운영 공간에서만 노출 ─── */}
      {showSheetsSection && (
        <SheetProjectSection projectId={projectId} currentUserId={currentUserId} />
      )}

      {/* ─── Move to Space Section (소유자/담당자) ─── */}
      {canManage && (
        <SpaceMoveSection projectId={projectId} currentUserId={currentUserId} queryClient={queryClient} />
      )}

      {/* ─── Delete Project Section (소유자/담당자) ─── */}
      {canManage && (
        <Paper
          sx={{
            p: 3,
            mb: 3,
            borderRadius: 3,
            border: '1px solid #FCA5A5',
            bgcolor: '#FEF2F2',
            boxShadow: '0 1px 8px rgba(0,0,0,0.04)',
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
            <DeleteForeverIcon sx={{ color: '#EF4444', fontSize: '1.3rem' }} />
            <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem', color: '#DC2626' }}>
              프로젝트 삭제
            </Typography>
          </Box>
          <Typography variant="body2" sx={{ color: '#6B7280', fontSize: '0.8rem', mb: 2 }}>
            프로젝트를 삭제하면 모든 태스크, 멤버, 파일이 함께 삭제됩니다. 이 작업은 되돌릴 수 없습니다.
          </Typography>
          <Button
            variant="contained"
            startIcon={<DeleteForeverIcon />}
            onClick={() => {
              if (window.confirm(`"${project?.name}" 프로젝트를 삭제하시겠습니까?\n모든 데이터가 삭제됩니다.`)) {
                deleteProjectMutation.mutate();
              }
            }}
            disabled={deleteProjectMutation.isPending}
            sx={{
              bgcolor: '#EF4444',
              fontWeight: 600,
              '&:hover': { bgcolor: '#DC2626' },
            }}
          >
            {deleteProjectMutation.isPending ? '삭제 중...' : '프로젝트 삭제'}
          </Button>
        </Paper>
      )}

      {/* ─── 변경 이력 ─── */}
      <Paper sx={{ p: 3, mb: 3, borderRadius: 2 }} variant="outlined">
        <ItemHistorySection entityType="project" entityId={projectId} itemName={project?.name} />
      </Paper>

      {/* ─── Add Member Dialog (with Knox search) ─── */}
      <Dialog
        open={addMemberOpen}
        onClose={() => {
          setAddMemberOpen(false);
          setSelectedUserIds([]);
          setMemberSearch('');
          setKnoxResults([]);
          setKnoxQuery('');
        }}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <PersonAddIcon sx={{ color: '#2955FF', fontSize: '1.2rem' }} />
            멤버 추가
          </Box>
        </DialogTitle>
        <DialogContent>
          {/* Search bar — 프로젝트 멤버는 해당 공간 멤버 중에서만 추가 가능 */}
          <TextField
            size="small"
            fullWidth
            placeholder="공간 멤버 이름 또는 ID로 검색"
            value={memberSearch}
            onChange={e => setMemberSearch(e.target.value)}
            sx={{ mt: 1, mb: 1.5 }}
            InputProps={{
              endAdornment: <SearchIcon sx={{ fontSize: 18, color: '#9CA3AF' }} />,
            }}
          />
          {spaceMemberUserIds && (
            <Typography variant="caption" sx={{ color: '#6B7280', display: 'block', mb: 1 }}>
              이 프로젝트는 해당 공간의 멤버만 추가할 수 있습니다.
            </Typography>
          )}

          {/* Group quick-add — 공간 멤버 ∩ 그룹 구성원만 추가됨 */}
          {memberGroups.length > 0 && (
            <Box sx={{ mb: 2 }}>
              <Typography variant="caption" sx={{ fontWeight: 700, color: '#2955FF', mb: 0.5, display: 'block' }}>
                그룹으로 추가
              </Typography>
              {spaceMemberUserIds && (
                <Typography variant="caption" sx={{ color: '#6B7280', display: 'block', mb: 0.5 }}>
                  선택한 그룹 구성원 중 현재 공간에 포함된 사용자만 프로젝트에 추가됩니다.
                </Typography>
              )}
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.8 }}>
                {memberGroups.map(g => {
                  const newIds = g.members
                    .map(m => m.user_id)
                    .filter(uid =>
                      !memberUserIds.has(uid) &&
                      !selectedUserIds.includes(uid) &&
                      (!spaceMemberUserIds || spaceMemberUserIds.has(uid))
                    );
                  return (
                    <Chip
                      key={g.id}
                      label={`${g.name} (${g.member_count}명)`}
                      size="small"
                      variant="outlined"
                      onClick={() => {
                        if (newIds.length > 0) {
                          setSelectedUserIds(prev => [...new Set([...prev, ...newIds])]);
                        }
                      }}
                      disabled={newIds.length === 0}
                      sx={{
                        cursor: newIds.length > 0 ? 'pointer' : 'default',
                        fontWeight: 600,
                        fontSize: '0.75rem',
                        borderColor: newIds.length > 0 ? '#2955FF' : '#E5E7EB',
                        color: newIds.length > 0 ? '#2955FF' : '#9CA3AF',
                        '&:hover': newIds.length > 0 ? { bgcolor: '#EEF2FF' } : {},
                      }}
                    />
                  );
                })}
              </Box>
            </Box>
          )}

          {/* Knox search results */}
          {knoxResults.length > 0 && (
            <Box sx={{ mb: 2 }}>
              <Typography variant="caption" sx={{ fontWeight: 700, color: '#5B21B6', mb: 0.5, display: 'block' }}>
                Knox 사내 검색 결과 ({knoxResults.length}명)
              </Typography>
              <Box sx={{ maxHeight: 180, overflowY: 'auto', border: '1px solid #EDE9FE', borderRadius: 1 }}>
                {knoxResults.map((emp: any, idx: number) => {
                  const lid = (emp.loginid || emp.login_id || emp.id || '').toString().toLowerCase();
                  const name = emp.fullName || emp.username || emp.name || lid;
                  const dept = emp.deptName || emp.deptname || emp.department || '';
                  const isAlreadyMember = members.some((m: any) => {
                    const mUser = users.find(u => u.id === m.user_id);
                    return mUser && (mUser.loginid || '').toLowerCase() === lid;
                  });
                  const existingUser = users.find(u => (u.loginid || '').toLowerCase() === lid);
                  return (
                    <Box
                      key={idx}
                      sx={{
                        px: 1.5, py: 0.8,
                        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        borderBottom: '1px solid #F3F4F6',
                        '&:hover': { bgcolor: '#F9FAFB' },
                      }}
                    >
                      <Box>
                        <Typography variant="body2" sx={{ fontWeight: 500, fontSize: '0.85rem' }}>{name}</Typography>
                        <Typography variant="caption" sx={{ color: '#9CA3AF' }}>{lid}{dept ? ` · ${dept}` : ''}</Typography>
                      </Box>
                      {isAlreadyMember ? (
                        <Chip label="멤버" size="small" sx={{ fontSize: '0.65rem', bgcolor: '#DCFCE7', color: '#22C55E' }} />
                      ) : existingUser ? (
                        <Button
                          size="small"
                          variant="outlined"
                          onClick={() => {
                            if (!selectedUserIds.includes(existingUser.id)) {
                              setSelectedUserIds(prev => [...prev, existingUser.id]);
                            }
                          }}
                          disabled={selectedUserIds.includes(existingUser.id)}
                          sx={{ textTransform: 'none', fontSize: '0.7rem', minWidth: 50 }}
                        >
                          {selectedUserIds.includes(existingUser.id) ? '선택됨' : '선택'}
                        </Button>
                      ) : (
                        <Button
                          size="small"
                          variant="contained"
                          onClick={() => createAndAddMutation.mutate({ username: name, loginid: lid, deptname: dept || undefined, mail: (emp.email || emp.mail || '') || undefined })}
                          disabled={createAndAddMutation.isPending}
                          sx={{ textTransform: 'none', fontSize: '0.7rem', minWidth: 80, bgcolor: '#8B5CF6', '&:hover': { bgcolor: '#7C3AED' } }}
                        >
                          등록+추가
                        </Button>
                      )}
                    </Box>
                  );
                })}
              </Box>
            </Box>
          )}

          {/* 검색 결과가 없을 때 안내 */}
          {availableUsers.length === 0 && !memberSearch && (
            <Box sx={{ textAlign: 'center', py: 3 }}>
              <Typography variant="body2" sx={{ color: '#9CA3AF' }}>
                {spaceMemberUserIds
                  ? '이 공간에 포함된 멤버 중 추가할 수 있는 사용자가 없습니다. 먼저 공간 관리에서 구성원을 공간에 추가해 주세요.'
                  : '이름을 검색하여 멤버를 추가하세요.'}
              </Typography>
            </Box>
          )}

          {/* 검색어 입력 시 검색 결과 표시 */}
          {memberSearch && memberSearch.trim().length > 0 && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, maxHeight: 250, overflowY: 'auto' }}>
              {availableUsers
                .filter(u => {
                  const q = memberSearch.toLowerCase();
                  return (u.username || '').toLowerCase().includes(q) || (u.loginid || '').toLowerCase().includes(q);
                })
                .map(user => (
                <Box
                  key={user.id}
                  onClick={() =>
                    setSelectedUserIds(prev =>
                      prev.includes(user.id)
                        ? prev.filter(id => id !== user.id)
                        : [...prev, user.id]
                    )
                  }
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 1.5,
                    py: 1,
                    px: 1.5,
                    borderRadius: 2,
                    cursor: 'pointer',
                    bgcolor: selectedUserIds.includes(user.id) ? '#EEF2FF' : 'transparent',
                    '&:hover': {
                      bgcolor: selectedUserIds.includes(user.id) ? '#E0E7FF' : '#F3F4F6',
                    },
                    transition: 'all 0.15s',
                  }}
                >
                  <Checkbox
                    size="small"
                    checked={selectedUserIds.includes(user.id)}
                    sx={{ p: 0.3 }}
                  />
                  <Avatar
                    sx={{
                      width: 28,
                      height: 28,
                      fontSize: '0.65rem',
                      bgcolor: user.avatar_color || '#2955FF',
                    }}
                  >
                    {(user.username || '?').charAt(0).toUpperCase()}
                  </Avatar>
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="body2" sx={{ fontWeight: 500, fontSize: '0.85rem' }}>
                      {user.username}
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#9CA3AF', fontSize: '0.65rem' }}>
                      {user.loginid}
                    </Typography>
                  </Box>
                </Box>
              ))}
              {availableUsers.filter(u => {
                const q = memberSearch.toLowerCase();
                return (u.username || '').toLowerCase().includes(q) || (u.loginid || '').toLowerCase().includes(q);
              }).length === 0 && (
                <Typography variant="caption" sx={{ textAlign: 'center', py: 2, color: '#9CA3AF' }}>
                  {spaceMemberUserIds
                    ? '검색 결과가 없습니다. 추가하려는 사용자가 이 공간의 멤버인지 확인해 주세요.'
                    : '검색 결과가 없습니다.'}
                </Typography>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            onClick={() => {
              setAddMemberOpen(false);
              setSelectedUserIds([]);
              setMemberSearch('');
              setKnoxResults([]);
            }}
            sx={{ color: '#6B7280' }}
          >
            취소
          </Button>
          <Button
            variant="contained"
            onClick={handleAddMembers}
            disabled={selectedUserIds.length === 0}
            sx={{ bgcolor: '#2955FF' }}
          >
            {selectedUserIds.length > 0 ? `${selectedUserIds.length}명 추가` : '추가'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

// ── Space Move Section ──
import MoveToInboxIcon from '@mui/icons-material/MoveToInbox';
import MenuItem from '@mui/material/MenuItem';
import { useSnackbar } from 'notistack';

const SpaceMoveSection: React.FC<{
  projectId: number;
  currentUserId: number;
  queryClient: any;
}> = ({ projectId, currentUserId, queryClient }) => {
  const { enqueueSnackbar } = useSnackbar();
  const [selectedSpaceId, setSelectedSpaceId] = useState<number | ''>('');

  const { data: spaces = [] } = useQuery<any[]>({
    queryKey: ['spaces', currentUserId],
    queryFn: () => api.getSpaces(currentUserId),
    enabled: currentUserId > 0,
  });

  // Only show spaces where user is owner or admin
  const managedSpaces = spaces.filter((s: any) =>
    s.members?.some((m: any) => m.user_id === currentUserId && (m.role === 'owner' || m.role === 'admin'))
  );

  if (managedSpaces.length === 0) return null;

  const handleMove = async () => {
    if (!selectedSpaceId) return;
    try {
      await api.moveProjectToSpace(projectId, selectedSpaceId as number, currentUserId);
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      queryClient.invalidateQueries({ queryKey: ['stats'] });
      const target = managedSpaces.find((s: any) => s.id === selectedSpaceId);
      enqueueSnackbar(`프로젝트가 "${target?.name}" 공간으로 이동되었습니다`, { variant: 'success' });
      setSelectedSpaceId('');
    } catch (e) {
      enqueueSnackbar('이동에 실패했습니다', { variant: 'error' });
    }
  };

  return (
    <Paper
      sx={{
        p: 3, mb: 3, borderRadius: 3,
        border: '1px solid #C7D2FE',
        bgcolor: '#FAFBFF',
        boxShadow: '0 1px 8px rgba(0,0,0,0.04)',
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
        <MoveToInboxIcon sx={{ color: '#2955FF', fontSize: '1.3rem' }} />
        <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem', color: '#1E40AF' }}>
          공간 이동
        </Typography>
      </Box>
      <Typography variant="body2" sx={{ color: '#6B7280', fontSize: '0.8rem', mb: 2 }}>
        이 프로젝트를 다른 공간으로 이동합니다. 내가 관리자인 공간으로만 이동할 수 있습니다.
      </Typography>
      <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center' }}>
        <TextField
          select
          size="small"
          value={selectedSpaceId}
          onChange={e => setSelectedSpaceId(Number(e.target.value))}
          sx={{ minWidth: 200, '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
          SelectProps={{ displayEmpty: true }}
        >
          <MenuItem value="" disabled>
            <Typography sx={{ color: '#9CA3AF', fontSize: '0.85rem' }}>공간 선택</Typography>
          </MenuItem>
          {managedSpaces.map((s: any) => (
            <MenuItem key={s.id} value={s.id}>
              {s.name}
            </MenuItem>
          ))}
        </TextField>
        <Button
          variant="contained"
          size="small"
          disabled={!selectedSpaceId}
          onClick={handleMove}
          sx={{ bgcolor: '#2955FF', textTransform: 'none', fontWeight: 600, px: 3 }}
        >
          이동
        </Button>
      </Box>
    </Paper>
  );
};

// ── Sheet Project Section (v3.0) ──
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import { LinearProgress } from '@mui/material';
import { useSpaceNav } from '../../hooks/useSpaceNav';
import SheetExecutionPopup from '../../components/sheets/SheetExecutionPopup';

const SheetProjectSection: React.FC<{ projectId: number; currentUserId: number }> = ({ projectId, currentUserId }) => {
  const currentSpaceId = useAppStore(state => state.currentSpaceId); void currentSpaceId;
  const { spaceNav } = useSpaceNav();
  const queryClient = useQueryClient();
  const [popupExecId, setPopupExecId] = useState<number | null>(null);

  const { data } = useQuery({
    queryKey: ['projectSheetSummary', projectId],
    queryFn: () => api.getProjectSheetSummary(projectId),
    enabled: !!projectId,
  });

  const activeExecs = data?.active_executions || [];
  const recentCompleted = data?.recent_completed || [];
  const hasAny = (data?.total_executions || 0) > 0;

  // 미연결(또는 비-진행중) sheet 만 삭제 허용 — 백엔드 가드와 동일 기준.
  // task_id 가 살아있는 task 를 가리키는 진행 중 시트만 차단; archive 된 task 는 사실상 미연결로 본다.
  const canDelete = (exec: any): boolean => {
    if (!exec) return false;
    if (exec.status === 'in_progress' && exec.task_id != null && !exec.task_archived) return false;
    return true;
  };

  const handleDelete = async (exec: any, ev: React.MouseEvent) => {
    ev.stopPropagation();
    if (!canDelete(exec)) return;
    if (!window.confirm(`"${exec.title}" Sheet 실행본을 삭제하시겠습니까?\n삭제 후 복구할 수 없습니다.`)) return;
    try {
      await api.deleteSheetExecution(exec.id, currentUserId);
      queryClient.invalidateQueries({ queryKey: ['projectSheetSummary', projectId] });
    } catch (err: any) {
      const detail = err?.response?.data?.detail || err?.message || '알 수 없는 오류';
      alert(`Sheet 삭제 실패: ${detail}`);
    }
  };

  return (
    <Paper sx={{ p: 3, mb: 3, borderRadius: 2 }} variant="outlined">
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <DescriptionIcon sx={{ color: '#7C3AED', fontSize: 20 }} />
          <Typography variant="subtitle1" fontWeight={700}>Sheets</Typography>
          {hasAny && (
            <Chip label={`전체 ${data?.total_executions}`} size="small" sx={{ height: 20, fontSize: '0.65rem' }} />
          )}
        </Box>
        <Button
          size="small"
          variant="outlined"
          onClick={() => spaceNav('/sheets')}
          sx={{ fontSize: '0.75rem', borderColor: '#7C3AED', color: '#7C3AED' }}
        >
          Sheet 관리
        </Button>
      </Box>

      {!hasAny ? (
        <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8rem' }}>
          이 프로젝트에 연결된 Sheet 실행이 없습니다.{' '}
          <Box
            component="span"
            onClick={() => spaceNav('/sheets')}
            sx={{ color: '#7C3AED', cursor: 'pointer', textDecoration: 'underline' }}
          >
            Sheet 업로드하러 가기
          </Box>
        </Typography>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {/* 진행 중 */}
          {activeExecs.length > 0 && (
            <Box>
              <Typography variant="caption" fontWeight={700} sx={{ color: '#F59E0B', mb: 0.5, display: 'block' }}>
                진행 중 ({activeExecs.length})
              </Typography>
              {activeExecs.map((exec: any) => (
                <Box
                  key={exec.id}
                  onClick={() => setPopupExecId(exec.id)}
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 1.5, py: 0.8, px: 1.5,
                    borderRadius: 1.5, cursor: 'pointer', bgcolor: '#FFFBEB',
                    border: '1px solid #FDE68A', mb: 0.5,
                    '&:hover': { bgcolor: '#FEF3C7' },
                  }}
                >
                  <PlayArrowIcon sx={{ fontSize: 16, color: '#F59E0B', flexShrink: 0 }} />
                  <Typography variant="body2" sx={{ fontSize: '0.8rem', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {exec.title}
                  </Typography>
                  <Box sx={{ width: 60, flexShrink: 0 }}>
                    <LinearProgress
                      variant="determinate" value={exec.progress}
                      sx={{ height: 4, borderRadius: 2, bgcolor: '#FDE68A', '& .MuiLinearProgress-bar': { bgcolor: '#F59E0B' } }}
                    />
                  </Box>
                  <Typography variant="caption" sx={{ fontSize: '0.65rem', color: '#D97706', flexShrink: 0, fontWeight: 700 }}>
                    {exec.progress}%
                  </Typography>
                  {canDelete(exec) && (
                    <IconButton
                      size="small"
                      onClick={(ev) => handleDelete(exec, ev)}
                      title="Task 미연결 Sheet 삭제"
                      sx={{ p: 0.4, color: '#9CA3AF', '&:hover': { color: '#EF4444', bgcolor: '#FEE2E2' } }}
                    >
                      <DeleteOutlineIcon sx={{ fontSize: '1rem' }} />
                    </IconButton>
                  )}
                </Box>
              ))}
            </Box>
          )}

          {/* 최근 완료 */}
          {recentCompleted.length > 0 && (
            <Box>
              <Typography variant="caption" fontWeight={700} sx={{ color: '#22C55E', mb: 0.5, display: 'block' }}>
                최근 완료
              </Typography>
              {recentCompleted.slice(0, 5).map((exec: any) => (
                <Box
                  key={exec.id}
                  onClick={() => setPopupExecId(exec.id)}
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 1.5, py: 0.6, px: 1.5,
                    borderRadius: 1.5, cursor: 'pointer',
                    '&:hover': { bgcolor: '#F9FAFB' },
                  }}
                >
                  <CheckCircleOutlineIcon sx={{ fontSize: 15, color: '#22C55E', flexShrink: 0 }} />
                  <Typography variant="body2" sx={{ fontSize: '0.78rem', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#6B7280' }}>
                    {exec.title}
                  </Typography>
                  <Typography variant="caption" sx={{ fontSize: '0.62rem', color: '#9CA3AF', flexShrink: 0 }}>
                    {exec.completed_at?.slice(0, 10)}
                  </Typography>
                  {canDelete(exec) && (
                    <IconButton
                      size="small"
                      onClick={(ev) => handleDelete(exec, ev)}
                      title="Sheet 실행본 삭제"
                      sx={{ p: 0.4, color: '#9CA3AF', '&:hover': { color: '#EF4444', bgcolor: '#FEE2E2' } }}
                    >
                      <DeleteOutlineIcon sx={{ fontSize: '0.95rem' }} />
                    </IconButton>
                  )}
                </Box>
              ))}
            </Box>
          )}
        </Box>
      )}
      <SheetExecutionPopup
        open={popupExecId != null}
        executionId={popupExecId}
        userId={currentUserId}
        onClose={() => {
          setPopupExecId(null);
          queryClient.invalidateQueries({ queryKey: ['projectSheetSummary', projectId] });
        }}
      />
    </Paper>
  );
};

export default ProjectSettingsView;
