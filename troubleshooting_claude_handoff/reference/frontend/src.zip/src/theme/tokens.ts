/**
 * PLAN-AI design tokens.
 *
 * Single source of truth for color / shadow / radius across the app.
 * Goal: replace scattered hard-coded hex values with semantic tokens so the
 * whole platform shares one design language ("있어 보이는" 업무 플랫폼).
 *
 * NOTE: The user-selectable background palette (BG_PALETTE) and the adaptive
 * sidebar derivation in `utils/colorUtils.ts` are intentionally kept — these
 * tokens sit *on top* of that system (surface / card / dialog / text / border).
 */

// ── Semantic color tokens ──────────────────────────────────────────────
export const planAiColors = {
  background: {
    /** main app canvas — used as a fallback; live value comes from bgColor */
    app: '#EFF3EC',
    appSoft: '#F7FAF7',
    /** elevated white surfaces (cards, dialogs, drawers) */
    surface: '#FFFFFF',
    /** subtle alternate surface (kanban columns, table headers, insets) */
    surfaceAlt: '#F8FAFC',
    /** hover wash on light surfaces */
    surfaceHover: '#EEF5EF',
    elevated: '#FFFFFF',
  },

  brand: {
    primary: '#2563EB',
    primaryHover: '#1D4ED8',
    primarySoft: '#EEF2FF',
    primaryBorder: '#C7D2FE',
  },

  status: {
    success: '#16A34A',
    successSoft: '#DCFCE7',
    warning: '#F59E0B',
    warningSoft: '#FEF3C7',
    danger: '#EF4444',
    dangerSoft: '#FEE2E2',
    info: '#06B6D4',
    infoSoft: '#CFFAFE',
    purple: '#8B5CF6',
    purpleSoft: '#F3E8FF',
  },

  text: {
    primary: '#0F172A',
    secondary: '#334155',
    tertiary: '#64748B',
    muted: '#94A3B8',
    disabled: '#CBD5E1',
    inverse: '#FFFFFF',
  },

  border: {
    soft: '#E5E7EB',
    normal: '#D1D5DB',
    strong: '#CBD5E1',
    focus: '#2563EB',
  },

  /** sidebar fallbacks — actual sidebar colors are derived from bgColor */
  sidebar: {
    bg: '#2F5B3F',
    hover: 'rgba(255,255,255,0.10)',
    active: 'rgba(255,255,255,0.14)',
    text: '#FFFFFF',
    muted: 'rgba(255,255,255,0.65)',
    border: 'rgba(255,255,255,0.14)',
  },
} as const;

// ── Elevation / shadow scale ───────────────────────────────────────────
// Soft, neutral-blue-tinted shadows. Never harsh/black.
export const planAiShadows = {
  none: 'none',
  sm: '0 1px 2px rgba(15, 23, 42, 0.06)',
  md: '0 4px 14px rgba(15, 23, 42, 0.08)',
  lg: '0 12px 32px rgba(15, 23, 42, 0.10)',
  xl: '0 20px 48px rgba(15, 23, 42, 0.12)',
  focus: '0 0 0 4px rgba(37, 99, 235, 0.14)',
} as const;

// ── Border radius scale ────────────────────────────────────────────────
export const planAiRadius = {
  xs: 6,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  pill: 999,
} as const;

// ── Motion ─────────────────────────────────────────────────────────────
export const planAiMotion = {
  fast: '120ms cubic-bezier(0.4, 0, 0.2, 1)',
  base: '180ms cubic-bezier(0.4, 0, 0.2, 1)',
  slow: '240ms cubic-bezier(0.4, 0, 0.2, 1)',
} as const;

export type PlanAiColors = typeof planAiColors;
export type PlanAiStatus = keyof typeof planAiColors.status;
