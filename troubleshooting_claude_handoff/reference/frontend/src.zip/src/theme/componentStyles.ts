/**
 * PLAN-AI reusable component styles (MUI `sx` objects).
 *
 * Import these instead of re-declaring boxShadow / border / borderRadius on
 * every card or dialog. Keeps surfaces consistent across screens.
 *
 *   import { cardSurfaceSx, interactiveCardSx } from '@/theme/componentStyles';
 *   <Box sx={cardSurfaceSx}>...</Box>
 *   <Box sx={interactiveCardSx}>...</Box>
 */
import type { SxProps, Theme } from '@mui/material/styles';
import { planAiColors, planAiShadows, planAiRadius, planAiMotion } from './tokens';

/** Base elevated card/surface — white, soft border, gentle shadow. */
export const cardSurfaceSx: SxProps<Theme> = {
  bgcolor: planAiColors.background.surface,
  border: `1px solid ${planAiColors.border.soft}`,
  borderRadius: `${planAiRadius.lg}px`,
  boxShadow: planAiShadows.sm,
};

/** Hoverable card — lifts slightly + brand-tinted border on hover. */
export const interactiveCardSx: SxProps<Theme> = {
  ...(cardSurfaceSx as object),
  transition: `transform ${planAiMotion.base}, box-shadow ${planAiMotion.base}, border-color ${planAiMotion.base}`,
  cursor: 'pointer',
  '&:hover': {
    transform: 'translateY(-2px)',
    boxShadow: planAiShadows.lg,
    borderColor: 'rgba(37, 99, 235, 0.24)',
  },
  '@media (prefers-reduced-motion: reduce)': {
    transition: 'none',
    '&:hover': { transform: 'none', boxShadow: planAiShadows.md },
  },
};

/** Subtle inset surface — kanban columns, table headers, grouped sections. */
export const softSurfaceSx: SxProps<Theme> = {
  bgcolor: planAiColors.background.surfaceAlt,
  border: `1px solid ${planAiColors.border.soft}`,
  borderRadius: `${planAiRadius.md}px`,
};

/** Section header / metric label style. */
export const sectionLabelSx: SxProps<Theme> = {
  fontSize: '0.65rem',
  fontWeight: 700,
  letterSpacing: '0.05em',
  textTransform: 'uppercase',
  color: planAiColors.text.tertiary,
};

/** Dialog paper styling (matches global theme; use when overriding PaperProps). */
export const dialogPaperSx: SxProps<Theme> = {
  borderRadius: `${planAiRadius.xl}px`,
  border: `1px solid ${planAiColors.border.soft}`,
  boxShadow: planAiShadows.lg,
};

// ── Status chip styling ────────────────────────────────────────────────
type StatusKey = keyof typeof planAiColors.status;

/**
 * Soft status chip — pale background + saturated text. Used for status /
 * priority chips so they read clearly without shouting.
 */
export const statusChipSx = (status: StatusKey): SxProps<Theme> => {
  const soft = planAiColors.status[`${status}Soft` as StatusKey] ?? planAiColors.status[status];
  const solid = planAiColors.status[status];
  return {
    bgcolor: soft,
    color: solid,
    border: 'none',
    fontWeight: 600,
    borderRadius: `${planAiRadius.sm}px`,
  };
};

/** Map common Korean/English status & priority labels to a token key. */
export function statusKeyForLabel(label?: string): StatusKey {
  const v = String(label || '').trim().toLowerCase();
  if (['done', 'completed', '완료', 'low', '낮음'].includes(v)) return 'success';
  if (['in_progress', 'progress', '진행', '진행중', 'medium', '보통', '중간'].includes(v))
    return 'info';
  if (['hold', '보류', 'todo', '대기', 'high', '높음'].includes(v)) return 'warning';
  if (['blocked', 'overdue', '지연', 'urgent', '긴급', 'critical'].includes(v)) return 'danger';
  return 'info';
}
