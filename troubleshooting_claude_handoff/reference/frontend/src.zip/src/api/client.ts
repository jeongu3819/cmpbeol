import axios from 'axios';
import { enqueueSnackbar } from 'notistack';
import {
  Task,
  Note,
  MentionNote,
  MentionDetail,
  NotificationPreference,
  Attachment,
  TaskActivity,
  TaskComment,
  TaskCommentAttachment,
  SubProject,
  RoadmapItem,
  ProjectMember,
  GraphNode,
  GraphEdge,
  ProjectFile,
  SearchResultProject,
  SearchSummaryResult,
  ProjectAiQueryResponse,
  User,
  Project,
  SystemEventLog,
  SystemLogFilters,
  SystemLogFilterSpec,
  SystemLogFilterPreview,
  SystemHealth,
  CalendarEvent,
  ActivityLogEntry,
  SpaceMemberInfo,
  PaginationMeta,
  VocComment,
  WorkflowColumn,
  WorkflowConfig,
  WorkflowModePreview,
  WorkflowMode,
  TaskAutoAdvanceResult,
} from '../types';

// ✅ Vite 환경변수 우선, 없으면 현재 호스트 기준으로 백엔드 접근
// 백엔드 main.py 예시가 8085이므로 기본 fallback을 8085로 둠
const API_URL = import.meta.env.VITE_API_URL || `http://${window.location.hostname}:8085/api`;

const client = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 180000, // 3 minutes for AI requests
});

/** localStorage에 저장된 me에서 user_id 꺼내기 (없으면 undefined) */
function getStoredUserId(): number | undefined {
  try {
    const raw = localStorage.getItem('me');
    if (!raw) return undefined;
    const me = JSON.parse(raw);
    const uid = Number(me?.user_id);
    return Number.isFinite(uid) && uid > 0 ? uid : undefined;
  } catch {
    return undefined;
  }
}

/** userId가 없으면 me.user_id로 자동 채움 */
function resolveUserId(userId?: number): number | undefined {
  if (userId && userId > 0) return userId;
  return getStoredUserId();
}

/**
 * ✅ Request Interceptor
 * - localStorage.session_token 이 있으면 Authorization 자동 부착
 */
client.interceptors.request.use(
  config => {
    const token = localStorage.getItem('session_token');
    if (token) {
      config.headers = config.headers ?? {};
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => Promise.reject(error)
);

/**
 * 서버 과부하/지연 안내 스낵바 — 스팸 방지를 위해 일정 간격(BUSY_TOAST_THROTTLE_MS)으로만 노출.
 * (notistack v3 standalone enqueueSnackbar 사용 — App 의 SnackbarProvider 마운트 후 동작)
 */
const BUSY_TOAST_THROTTLE_MS = 5000;
let _lastBusyToastAt = 0;
function notifyBusy(message: string) {
  const now = Date.now();
  if (now - _lastBusyToastAt < BUSY_TOAST_THROTTLE_MS) return;
  _lastBusyToastAt = now;
  try {
    enqueueSnackbar(message, { variant: 'warning', autoHideDuration: 4000 });
  } catch {
    /* provider 미마운트 등 — 안내 실패는 무시 (요청 흐름에 영향 없음) */
  }
}

/**
 * ✅ Response Interceptor
 * - 세션 만료/서버 재시작 등으로 401 발생 시 토큰 제거 후 SSO 로그인으로 이동
 * - 서버 과부하(429/503/502/504)·응답 지연(timeout)·일시적 네트워크 오류 시 친절한 안내
 *   (에러는 그대로 reject 하여 각 화면의 재시도/에러 처리는 기존대로 동작)
 */
client.interceptors.response.use(
  res => res,
  err => {
    const status = err?.response?.status;
    if (status === 401) {
      localStorage.removeItem('session_token');
      // 백엔드: /api/auth/login
      window.location.href = `${API_URL}/auth/login`;
    }
    if (status === 403) {
      const detail = err?.response?.data?.detail || '';
      if (detail.includes('등록') || detail.includes('접근 권한')) {
        window.location.href = '/access-denied';
      }
    }
    // 과부하/지연 안내 (일반 사용자에게 내부 지표는 숨기고 상태만 안내)
    if (status === 429) {
      notifyBusy('현재 요청이 많아 처리 중입니다. 잠시만 기다려주세요.');
    } else if (status === 502 || status === 503 || status === 504) {
      notifyBusy('서버가 일시적으로 바쁩니다. 잠시 후 다시 시도해주세요.');
    } else if (err?.code === 'ECONNABORTED') {
      // axios timeout (느린 응답)
      notifyBusy('서버 응답이 지연되고 있습니다. 잠시 후 다시 시도해주세요.');
    } else if (!err?.response && err?.message === 'Network Error') {
      notifyBusy('네트워크 연결이 일시적으로 불안정합니다. 잠시 후 다시 시도해주세요.');
    } else if (status === 500) {
      // 서버 내부 오류: stack trace 대신 추적용 오류코드(request_id)만 사용자에게 안내
      const rid =
        err?.response?.data?.request_id ||
        err?.response?.headers?.['x-request-id'] ||
        '';
      notifyBusy(
        rid
          ? `오류가 발생했습니다. 관리자에게 문의하세요. 오류코드: ${rid}`
          : '오류가 발생했습니다. 관리자에게 문의하세요.'
      );
    }
    return Promise.reject(err);
  }
);

// ─── Local API Response Types ───
export interface ProjectStats {
  id: number;
  name: string;
  total: number;
  done: number;
  in_progress: number;
  todo: number;
  progress: number;
}

/** 공간관리 > 프로젝트 가져오기 — 내가 다른 공간으로 이동 가능한 프로젝트 */
export interface MovableProject {
  id: number;
  name: string;
  description?: string | null;
  current_space_id: number | null;
  current_space_name: string | null;
  my_project_role: string | null;
  can_move: boolean;
}

export interface MoveProjectsResult {
  success: { project_id: number; name: string | null }[];
  failed: { project_id: number; name: string | null; reason: string }[];
}

export interface DashboardStats {
  total: number;
  in_progress: number;
  done: number;
  todo: number;
  hold: number;
  project_stats: ProjectStats[];
  all_tasks: Task[];
  overdue: Task[];
  upcoming: Task[];
  my_tasks: Task[];
}

export interface DashboardLayout {
  [key: string]: any;
}

// ── 사내 추천 도구 스트립 ──
export type RecommendationPlacement =
  | 'PROJECT_DASHBOARD_TOP'
  | 'EQUIPMENT_DASHBOARD_AFTER_KPI';

export interface InternalRecommendation {
  id: number;
  target_space_type: 'PROJECT' | 'EQUIPMENT';
  placement: RecommendationPlacement;
  label: string;
  badge?: string | null;
  title: string;
  description?: string | null;
  reason_text?: string | null;
  cta_label?: string | null;
  cta_url?: string | null;
  secondary_label?: string | null;
  order?: number;
}

export interface InternalRecommendationsResponse {
  enabled: boolean;
  recommendations: InternalRecommendation[];
}

export type ShortcutVisibility = 'PRIVATE' | 'PUBLIC' | 'SHARED_USERS' | 'SHARED_GROUPS';

export interface Shortcut {
  id: number;
  name: string;
  url: string;
  icon_text: string;
  icon_color: string;
  order: number;
  open_new_tab: boolean;
  active: boolean;
  created_at?: string;
  owner_id?: number | null;
  visibility?: ShortcutVisibility;
  shared_user_ids?: number[];
  shared_group_ids?: number[];
}

export interface VisitStats {
  summary: {
    today_visits: number;
    today_unique_visitors: number;
    last_7_days_visits: number;
    last_7_days_unique_visitors: number;
    last_30_days_visits: number;
    last_30_days_unique_visitors: number;
    month_unique_visitors: number;
    total_visits: number;
  };
  daily: { date: string; visits: number; unique_visitors: number }[];
  departments: {
    deptname: string;
    visits: number;
    unique_visitors: number;
    last_visit_date: string;
    ratio: number;
  }[];
  recent: {
    timestamp: string;
    username: string;
    deptname: string;
    ip_address: string;
  }[];
  ip_masked: boolean;
  range_days: number;
}

export interface UsageStats {
  summary: {
    today_visits: number;
    today_unique_visitors: number;
    today_projects_created: number;
    today_tasks_created: number;

    last_7_days_visits: number;
    last_7_days_unique_visitors: number;
    last_7_days_projects_created: number;
    last_7_days_tasks_created: number;

    last_30_days_visits: number;
    last_30_days_unique_visitors: number;
    last_30_days_projects_created: number;
    last_30_days_tasks_created: number;

    month_unique_visitors: number;
    month_projects_created: number;
    month_tasks_created: number;

    total_visits: number;
    total_projects: number;
    total_tasks: number;
  };
  daily: {
    date: string;
    visits: number;
    unique_visitors: number;
    projects_created: number;
    tasks_created: number;
  }[];
  departments: {
    deptname: string;
    visits: number;
    unique_visitors: number;
    projects_created: number;
    tasks_created: number | null;
    last_visit_date: string;
    ratio: number;
  }[];
  recent: {
    timestamp: string;
    username: string;
    deptname: string;
    ip_address: string;
  }[];
  ip_masked: boolean;
  range_days: number;
  task_dept_supported: boolean;
}

export interface GeneralUploadPolicy {
  max_file_mb: number;
  max_file_bytes: number;
  max_file_count: number;
  max_total_mb: number;
  max_total_bytes: number;
  allowed_extensions: string[];
  blocked_extensions: string[];
  allow_hwp: boolean;
  allowed_label: string;
}

export interface InlineImagePolicy {
  max_file_mb: number;
  max_file_bytes: number;
  allowed_extensions: string[];
  allowed_label: string;
}

export interface UploadPolicy {
  general: GeneralUploadPolicy;
  inline_image: InlineImagePolicy;
}

export interface UserShortcut {
  id: number;
  user_id: number;
  name: string;
  url: string;
  icon_text?: string;
  icon_color: string;
  order: number;
  open_new_tab: boolean;
  active: boolean;
  created_at?: string;
  visibility?: ShortcutVisibility;
  shared_user_ids?: number[];
  shared_group_ids?: number[];
}

/** Dashboard 위젯용 통합 바로가기. source 로 admin/user 구분. */
export interface MyShortcut {
  id: number;
  name: string;
  url: string;
  icon_text?: string | null;
  icon_color: string;
  order: number;
  open_new_tab: boolean;
  active: boolean;
  visibility?: ShortcutVisibility;
  source: 'admin' | 'user';
  user_id?: number;
  owner_id?: number | null;
  shared_user_ids?: number[];
  shared_group_ids?: number[];
}

export interface Group {
  id: number;
  name: string;
  description?: string;
  is_active?: boolean;
  matched_count?: number;
  created_at?: string;
}

export interface MemberGroupMember {
  user_id: number;
  username: string;
  loginid: string;
  avatar_color?: string;
  deptname?: string;
}

export interface MemberGroup {
  id: number;
  name: string;
  description?: string;
  created_by: number;
  created_at?: string;
  member_count: number;
  members: MemberGroupMember[];
}

/** 통합 검색 결과 항목 (사이트 user / Knox user / member group) */
export type MemberCandidate =
  | {
      type: 'user';
      source: 'site';
      user_id: number;
      login_id: string;
      name: string;
      email?: string | null;
      department?: string | null;
      avatar_color?: string;
    }
  | {
      type: 'user';
      source: 'knox';
      login_id: string;
      name: string;
      email?: string | null;
      department?: string | null;
    }
  | {
      type: 'group';
      group_id: number;
      name: string;
      description?: string | null;
      member_count: number;
    };

/**
 * 멤버 검색/선택의 통일된 표현. UI 표시는 항상 login_id/name 기준으로 유지하고,
 * 내부 식별/전송용 user_id 는 별도 필드로 관리한다(숫자 ID가 화면에 노출되는 버그 방지).
 * - source 'local': 이미 사이트 구성원 (user_id 존재)
 * - source 'knox': 아직 사이트 구성원이 아닌 Knox/사내 디렉토리 사용자 (user_id 없음)
 */
export type MemberOption = {
  user_id?: number;
  login_id: string;
  knox_id?: string;
  name?: string;
  display_name?: string;
  deptname?: string;
  email?: string;
  avatar_color?: string;
  source: 'local' | 'knox';
};

/** 검색 후보(MemberCandidate, user 타입)를 통일된 MemberOption 으로 변환 */
export const candidateToMemberOption = (c: MemberCandidate): MemberOption | null => {
  if (c.type !== 'user') return null;
  if (c.source === 'site') {
    return {
      source: 'local',
      user_id: c.user_id,
      login_id: c.login_id,
      knox_id: c.login_id,
      name: c.name,
      display_name: c.name,
      deptname: c.department || undefined,
      email: c.email || undefined,
      avatar_color: c.avatar_color,
    };
  }
  return {
    source: 'knox',
    login_id: c.login_id,
    knox_id: c.login_id,
    name: c.name,
    display_name: c.name,
    deptname: c.department || undefined,
    email: c.email || undefined,
  };
};

/** MemberOption 표시 라벨 — 절대 숫자 user_id 를 노출하지 않는다. */
export const memberOptionLabel = (m: MemberOption): string => {
  const base = m.display_name || m.name || m.login_id;
  return `${base} · ${m.login_id}${m.deptname ? ' · ' + m.deptname : ''}`;
};

export interface SpaceGroupBulkAddResult {
  group_id: number;
  group_name: string;
  added_count: number;
  skipped_count: number;
  added_users: { user_id: number; login_id: string; name: string }[];
  skipped_users: { user_id: number; login_id: string; name: string }[];
}

export interface SimilarSpace {
  id: number;
  name: string;
  slug: string;
  is_member: boolean;
  exact: boolean;
}

export interface SpaceLimits {
  role: string | null;
  created: number;
  limit: number | null;      // null = 무제한
  remaining: number | null;
  per_day_used: number;
  per_day_limit: number | null;
  can_create: boolean;
  near_limit: boolean;
}

export interface AdminSpaceRow {
  id: number;
  name: string;
  slug: string;
  purpose: string;
  created_by: number | null;
  creator_name: string | null;
  owner_id: number | null;
  owner_name: string | null;
  created_at: string | null;
  days_old: number | null;
  last_activity_at: string | null;
  member_count: number;
  project_count: number;
  task_count: number;
  checksheet_count: number;
  calendar_count: number;
  is_active: boolean;
  archived_at: string | null;
  warned_at: string | null;
  delete_scheduled_at: string | null;
  cleanup_exempt: boolean;
  is_empty: boolean;
  has_project: boolean;
  status: string;
}

export interface AdminSpaceSummary {
  total: number;
  active: number;
  archived: number;
  no_project: number;
  empty: number;
  warned: number;
}

export interface AiProviderOption {
  key: string;        // 'dsllm' | 'openai'
  label: string;
  available: boolean; // 선택 가능 여부 (openai는 env 설정 시에만 true)
}

export interface AiSettings {
  provider: string;                        // 저장/라우팅에 쓰이는 활성 provider ('dsllm' | 'openai')
  view_provider?: string;                  // 상태(BASE URL/API KEY)를 계산한 provider(화면에서 보는 값)
  available_providers: AiProviderOption[];
  openai_warning: string;                  // OpenAI 선택 시 표시할 경고 문구
  model_name: string;
  env_mode: string;
  base_url_configured: boolean;
  base_url_display: string;
  api_key_configured: boolean;
  // 운영자 자가진단용(민감정보 없음) — backend 가 실제 읽은 env 파일/키 감지 여부.
  debug?: {
    env_file: string;
    env_file_exists: boolean;
    openai_key_in_env: boolean;
    openai_provider_selectable: boolean;
  };
}

export interface AiConnectionTestResult {
  ok: boolean;
  provider: string;
  model: string;
  answer?: string;
  error?: string;
  // OpenAI 진단 부가 정보 (실패 원인 파악용)
  stage?: string;           // api_key | models | model_check | responses | done
  status_code?: number | null;
  model_found?: boolean | null;
  models_count?: number | null;
  base_url?: string;
}

// ── Vision AI 설정 (Text AI와 분리, super_admin 전용) ──
// vision_supported: true 지원 / false 미지원 / null 알수없음 / 'candidate' 후보(사내 모델, 미구현)
export type VisionSupport = boolean | null | 'candidate';

export interface VisionModelCapability {
  key: string;
  vision_supported: VisionSupport;
  provider?: string;
  label?: string;
  note?: string;
}

// Vision AI provider 선택지(openai / dsllm). UI 가 provider 전환 시 서버 왕복 없이 모델 목록을 바꾼다.
export interface VisionProviderOption {
  key: string;
  label: string;
  available: boolean;
  models: string[];
  model_capabilities: VisionModelCapability[];
  default_model: string;
}

export interface VisionAiSettings {
  provider: string;
  provider_available?: boolean;
  providers?: VisionProviderOption[];
  model: string;
  models: string[];
  model_capabilities: VisionModelCapability[];
  enabled: boolean;
  max_output_tokens: number;
  batch_size: number;
  timeout_seconds: number;
  using_text_fallback: boolean;
  fallback_reason: string | null;
  models_source?: string;
  default_model_source?: string;
  vision_payload_implemented?: boolean;
  // ── 지연 시 텍스트 전용 fallback (Gemma4 느림/실패 → 사용자 선택) ──
  soft_timeout_seconds?: number;
  fallback_text_enabled?: boolean;
  fallback_text_provider?: string;
  fallback_text_model?: string;
  fallback_policy?: string;
  fallback_text_model_source?: string;
  openai_configured: boolean;
  openai_warning: string;
  base_url_configured: boolean;
  base_url_display: string;
  api_key_configured: boolean;
}

export interface VisionAiSettingsUpdate {
  model_name?: string;
  provider?: string;
  enabled?: boolean;
  max_output_tokens?: number;
  batch_size?: number;
  timeout_seconds?: number;
  // Fallback Text Model (Primary Vision Model 과 별개 저장)
  fallback_text_provider?: string;
  fallback_text_model?: string;
  fallback_text_enabled?: boolean;
  fallback_policy?: string;
  soft_timeout_seconds?: number;
}

export interface VisionAiTestResult {
  ok: boolean;
  model: string;
  answer?: string;
  error?: string | null;
  stage?: string;
  status_code?: number | null;
  models_count?: number | null;
  base_url?: string;
  provider?: string;
  vision_supported?: VisionSupport;
  expected?: string;
  error_type?: string | null;
}

// ── 실제 프로젝트 이미지 Vision 테스트(POST /settings/vision-ai/project-image-test) ──
export interface ProjectImageVisionTestBody {
  user_id: number;
  project_id: number;
  image_id: string;
  model_name?: string;
  provider?: string;
  input_mode?: string;
}

export interface ProjectImageVisionMetrics {
  project_id?: number | null;
  canonical_image_id?: string | null;
  image_count?: number | null;
  image_transport?: string | null;
  original_mime?: string | null;
  mime?: string | null;
  width?: number | null;
  height?: number | null;
  original_width?: number | null;
  original_height?: number | null;
  original_bytes?: number | null;
  processed_bytes?: number | null;
  base64_chars?: number | null;
  payload_bytes?: number | null;
  max_tokens?: number | null;
  timeout_seconds?: number | null;
  elapsed_ms?: number | null;
}

export interface ProjectImageVisionDiagnosis {
  failure_stage?: string;
  failure_stage_label?: string;
  error_type?: string | null;
  provider?: string | null;
  model?: string | null;
  http_status?: number | null;
  message?: string;
  summary?: string;
  likely_cause?: string;
  recommended_action?: string;
  retry_safe?: boolean;
  details?: ProjectImageVisionMetrics;
}

export interface ProjectImageVisionRecognition {
  image_id?: string;
  image_role_hint?: string | null;
  image_type?: string | null;
  visible_facts?: string[];
  interpretation?: string | null;
  uncertainty?: string | null;
  evidence_type?: string | null;
  confidence?: number | null;
  [k: string]: any;
}

export interface ProjectImageVisionTestResult {
  ok: boolean;
  test_type: 'project_image';
  provider: string;
  model: string;
  request_id?: string | null;
  recognition?: ProjectImageVisionRecognition | null;
  diagnosis?: ProjectImageVisionDiagnosis | null;
  metrics?: ProjectImageVisionMetrics;
  project_id?: number | null;
  task_id?: number | null;
  task_title?: string | null;
  canonical_image_id?: string | null;
  raw_present?: boolean;
}

// ── AI Context Inspector (super_admin 전용 디버깅/운영 도구) ──
// GET /api/projects/{id}/ai-context-preview 응답. LLM 미호출, 구조화 메타만.
export interface AiManifestImage {
  image_id: string;
  project_id?: number | null;
  project_name?: string | null;
  sub_project_id?: number | null;
  sub_project_name?: string | null;
  task_id?: number | null;
  task_title?: string | null;
  task_status?: string | null;
  task_priority?: string | null;
  source_entity_type?: string | null;
  source_entity_id?: number | string | null;
  relation_type?: string | null;
  nearby_text?: string | null;
  nearby_text_before?: string | null;
  nearby_text_after?: string | null;
  fallback_context_text?: string | null;
  context_text_source?: string | null;
  user_caption?: string | null;
  filename?: string | null;
  content_type?: string | null;
  content_hash?: string | null;
  file_size?: number | null;
  width?: number | null;
  height?: number | null;
  created_at?: string | null;
  created_by?: number | null;
  image_role?: string | null;
  image_role_source?: string | null;
  image_role_confidence?: string | null;
  image_quality?: {
    width?: number | null;
    height?: number | null;
    megapixels?: number | null;
    aspect_ratio?: number | null;
    readability_status?: string | null;
    recommendation_level?: string | null;
    recommended_for_ai?: boolean | null;
    quality_notes?: string[];
    message?: string | null;
    message_level?: string | null;
    [k: string]: any;
  };
  ai_image_variants?: {
    original?: any;
    preview?: any;
    ai_readable?: { recommended_action?: string; [k: string]: any };
    tiles?: { recommended?: boolean; reason?: string; [k: string]: any };
    [k: string]: any;
  };
  analysis_reuse_policy?: Record<string, any>;
  analysis_identity?: {
    semantic_cache_key_preview?: string | null;
    [k: string]: any;
  };
  reanalysis_triggers?: string[];
  evidence_card?: {
    context_strength?: string | null;
    extraction_target?: string | null;
    model_instruction_key?: string | null;
    model_instruction_text?: string | null;
    quality_warning?: string | null;
    ai_input_strategy?: string | null;
    [k: string]: any;
  };
  [k: string]: any;
}

export interface AiContextPreviewResponse {
  project_id: number;
  project_name: string;
  context_schema_version: string;
  image_manifest_version: string;
  readiness_version: string;
  future_image_analysis_prompt_version: string;
  evidence_card_version?: string;
  counts: Record<string, number>;
  text_context_preview: string;
  image_manifest: AiManifestImage[];
  image_readiness_summary: Record<string, any>;
  analysis_policy_summary: Record<string, any>;
  variant_storage_policy?: Record<string, any>;
  warnings: string[];
  image_scope?: string;
  image_scope_total?: number;
  image_scope_shown?: number;
  max_images_applied?: number;
  max_images_limit?: number;
  not_used_by_llm?: boolean;
}

// Model Compatibility Layer — image_manifest item → 사내 모델 API 입력 패킷.
// (실제 모델 호출 없음. image binary/base64/storage path 미포함)
export interface ModelInputPacket {
  packet_version: string;
  provider: string;
  mode: string;
  input_mode: string;
  task_context: Record<string, any>;
  text_context: {
    nearby_text?: string;
    fallback_context_text?: string;
    context_text_source?: string | null;
    context_strength?: string | null;
  };
  image_context_hints: {
    image_id?: string | null;
    image_role_hint?: string | null;
    role_source?: string | null;
    role_confidence?: string | null;
    readability_status?: string | null;
    recommendation_level?: string | null;
    extraction_target?: string | null;
    model_instruction_key?: string | null;
    ai_input_strategy?: string | null;
    [k: string]: any;
  };
  model_instruction: {
    instruction_strength?: string;
    global_rule?: string;
    role_instruction?: string | null;
    output_schema_hint?: Record<string, any>;
    [k: string]: any;
  };
  safety_policy: Record<string, boolean>;
  [k: string]: any;
}

export interface ModelProviderPayload {
  provider: string;
  messages: { role: string; content: string }[];
  metadata?: Record<string, any>;
  image_ref?: { image_id?: string | null; input_strategy?: string; [k: string]: any };
  [k: string]: any;
}

export interface ModelPacketResponse {
  image_id: string;
  provider: string;
  input_mode: string;
  packet_version: string;
  packet: ModelInputPacket;
  provider_payload: ModelProviderPayload;
  not_used_by_llm?: boolean;
}

// ── Vision Report Test (super_admin 전용 이미지 포함 AI Report PoC) ──
// 기존 텍스트 종합보고서와 분리된 별도 PoC. DB 저장 없음.
export interface VisionReportTestMeta {
  models: string[];
  default_model?: string;
  model_capabilities?: VisionModelCapability[];
  vision_enabled?: boolean;
  using_text_fallback?: boolean;
  fallback_reason?: string | null;
  default_max_images: number;
  hard_max_images: number;
  input_modes: string[];
  default_input_mode?: string;
  image_scopes: string[];
  default_image_scope?: string;
  openai_configured: boolean;
  // ── 지연 시 텍스트 전용 fallback(사용자 선택 modal) 메타 ──
  provider?: string;
  soft_timeout_seconds?: number;
  timeout_seconds?: number;
  fallback_text_enabled?: boolean;
  fallback_text_provider?: string;
  fallback_text_model?: string;
  fallback_policy?: string;
}

export interface VisionReportTestRequestBody {
  user_id: number;
  model?: string;
  provider?: string;
  // 아래는 모두 고급 설정 전용(optional). 기본 호출은 백엔드 기본값을 사용한다:
  //   input_mode=image_with_evidence_card / image_scope=task_images_all(전체) / max_images=안전 상한
  input_mode?: string;
  image_scope?: string;
  max_images?: number | null;
  image_ids?: string[];
  include_text_context?: boolean;
  include_image_evidence?: boolean;
  save_result?: boolean;
}

// Stage 1 이미지 evidence 추출 결과(중간 결과, 개발자용 원본 영역에만 표시)
export interface VisionImageFinding {
  image_id?: string;
  task_id?: number | string;
  task_title?: string;
  image_role_hint?: string;
  visible_facts?: string[];
  interpretation?: string;
  task_relevance?: string;
  uncertainty?: string;
  [k: string]: any;
}

// ── Stage 2: 최종 프로젝트 보고서(DB 사실 + 모델 분석 포인트) ──
export interface VisionReportTask {
  // 사실 데이터(DB, 서버 확정)
  task_id?: number | string;
  task_title?: string;
  status?: string;
  priority?: string;
  progress?: number | string;
  due_date?: string | null;
  assignees?: string[];
  sub_project?: string | null;
  image_count?: number;
  // 근거 자료 수(📷/📝/🔗)
  note_count?: number;
  url_count?: number;
  file_count?: number;
  // 분석 포인트(모델)
  summary_points?: string[];
  risk_points?: string[];
  next_actions?: string[];
  has_visual_evidence?: boolean;
  visual_evidence_summary_points?: string[];
  visual_evidence_confidence?: string | null;
  visual_evidence_limitations?: string[];
  featured_image_id?: string | null;
  // Task 카드 내부 시각 근거(주 표시 위치): 대표 이미지 캡션/판단 의미 + 추가 이미지 요약
  visual_evidence_caption?: string | null;
  visual_evidence_judgment_meaning?: string | null;
  additional_image_count?: number;
  additional_visual_evidence_summary?: string | null;
  // 인수인계 상세 보기용(brief=최상위 필드, detailed=아래 객체)
  detailed?: {
    context_points?: string[];
    summary_points?: string[];
    risk_points?: string[];
    next_actions?: string[];
    visual_evidence_summary_points?: string[];
    handover_notes?: string[];
  };
  // 인수인계 상세 보기용 — Task 에 연결된 이미지 전체(대표 우선). featured 1장에 의존하지 않음.
  visual_evidence?: {
    images?: VisionTaskVisualImage[];
    image_count?: number;
  };
  // legacy(구 스키마 호환) — 문자열 단일 필드
  summary?: string;
  risk_or_issue?: string;
  next_action?: string;
  visual_evidence_summary?: string;
  visual_evidence_used?: (string | number)[];
  [k: string]: any;
}

export interface VisionReportAttachment {
  task_id?: number | string;
  task_title?: string;
  urls?: string[];
  files?: string[];
  image_count?: number;
  // legacy
  filename_or_source?: string;
  type?: string;
  summary?: string;
  [k: string]: any;
}

// 인수인계 상세 보기용 — Task 에 연결된 이미지 1장(대표/추가 공통). 서버가 결정론적으로 채움.
export interface VisionTaskVisualImage {
  image_id: string;
  is_featured?: boolean;
  caption?: string;
  judgment_meaning?: string;
  confidence?: string;
  role?: string;
  rendered?: boolean;
  hidden_reason?: string | null;
  source?: string;
  [k: string]: any;
}

export interface VisionFeaturedEvidence {
  image_id?: string;
  task_id?: number | string;
  task_title?: string;
  image_role_hint?: string;
  importance_score?: number;
  display_reason?: string;
  judgment_meaning?: string;
  caption?: string;
  report_section?: string;
  thumbnail_preview_url?: string | null;
  [k: string]: any;
}

export interface VisionStatusBreakdown {
  total?: number;
  active?: number;
  done?: number;
  in_progress?: number;
  todo?: number;
  hold?: number;
  overall_progress?: number;
}

export interface VisionProjectReport {
  project_overview?: {
    title?: string;
    description?: string;
    team?: string[];
    overall_progress?: number;
    status_breakdown?: VisionStatusBreakdown;
    summary_points?: string[];
    key_message?: string;
    decision_point?: string;
    // legacy
    summary?: string;
  };
  task_analysis?: VisionReportTask[];
  attachment_summary?: VisionReportAttachment[];
  overall_analysis?: {
    summary_points?: string[];
    key_points?: string[];
    visual_insights?: string[];
    risk_points?: string[];
    // legacy
    summary?: string;
    visual_evidence_insights?: string[];
    risk_or_uncertainty?: string[];
  };
  next_steps?: { summary_points?: string[]; actions?: string[]; summary?: string };
  featured_visual_evidence?: VisionFeaturedEvidence[];
  non_featured_visual_summary?: {
    count?: number;
    summary?: string;
    grouped_by_task?: { task_title?: string; count?: number; roles?: string[] }[];
  };
  // 인수인계 상세 보기(ViewMode) 결정론 — Task별 연결 이미지 전체 맵.
  task_visual_evidence_map?: Record<
    string,
    {
      task_id?: number | string;
      task_title?: string;
      featured_image_id?: string | null;
      image_count?: number;
      images?: VisionTaskVisualImage[];
    }
  >;
  debug_metrics?: {
    tasks_total?: number;
    tasks_with_images?: number;
    tasks_with_visual_points?: number;
    visual_evidence_coverage?: number | null;
    featured_image_task_coverage?: number;
    featured_image_task_coverage_ratio?: number | null;
    featured_image_count?: number;
    task_card_visible_image_count?: number;
    // 상세 모드에서 실제 펼쳐질 이미지 총량(간결과 구분되는 지표).
    detailed_visible_image_count?: number;
    // 상세 모드에서 숨긴 이미지(스펙 §8·§9) — rendered=false + hidden_reason.
    hidden_task_images?: {
      task_id?: number | string;
      image_id?: string;
      rendered?: boolean;
      hidden_reason?: string | null;
    }[];
    missing_task_image_mapping?: {
      task_id?: number | string;
      task_title?: string;
      image_count?: number;
      hidden_reason?: string | null;
    }[];
    task_visual_debug?: {
      task_id?: number | string;
      task_title?: string;
      image_count?: number;
      has_visual_evidence?: boolean;
      badge_visible?: boolean;
      resolved_image_id?: string | null;
      resolved_from?: string | null;
      importance_score?: number | null;
      rendered?: boolean;
      hidden_reason?: string | null;
    }[];
  };
  vision_poc_meta?: {
    model?: string;
    images_total?: number;
    images_used?: number;
    images_analyzed?: number;
    images_failed?: number;
    images_excluded?: number;
    batches?: number;
    uncertainty_notes?: string[];
    validation_notes?: string[];
    save_result?: boolean;
  };
  [k: string]: any;
}

export interface VisionReportTestResponse {
  project_id: number;
  model: string;
  provider: string;
  input_mode: string;
  image_scope: string;
  schema_version?: string;
  // 최종 보고서(메인 렌더 대상)
  report?: VisionProjectReport | null;
  report_parse_ok: boolean;
  parse_message?: string | null;
  // Stage 1 중간 결과(개발자용 원본)
  image_evidence_summaries: VisionImageFinding[];
  evidence_count: number;
  // 이미지 사용 현황
  used_image_ids: string[];
  missing_image_ids: string[];
  load_errors: { image_id?: string; error?: string }[];
  image_count: number;
  images_total: number;
  images_used: number;
  images_analyzed?: number;
  images_failed?: number;
  images_excluded: number;
  batches?: number;
  // 2b-2a 캐시 read-through 지표(관리자 디버그 표시용)
  images_from_cache?: number;
  images_context_regenerated?: number; // 2b-2b: Observation 재사용 + ContextLink만 Text 재생성
  images_vision_analyzed?: number;
  vision_model_calls?: number;
  vision_batches?: number;
  cache_read_active?: boolean;
  candidate_total: number;
  excluded_count: number;
  excluded_reason?: string | null;
  featured_visual_evidence?: VisionFeaturedEvidence[];
  max_images_applied: number;
  max_images_limit: number;
  // 진단/원본(개발자용)
  stage1_batches?: number;
  stage1_raw_texts?: string[];
  stage2_raw_text?: string;
  latency_ms: number;
  usage?: Record<string, any> | null;
  truncated?: boolean;
  max_output_tokens?: number | null;
  save_result: boolean;
  not_persisted: boolean;
  // ── 보고서 생성 방식 메타(§8) — vision / text_only_fallback ──
  report_mode?: string;
  primary_vision_model?: string;
  actual_model_used?: string;
  fallback_used?: boolean;
  fallback_reason?: string;
  image_analysis_included?: boolean;
  user_choice?: string;
}

export interface VisionTextFallbackRequestBody {
  user_id: number;
  provider?: string;
  model?: string;
  source?: string;
  user_choice?: string;
}

export interface ReportResponse {
  report: string;
  model: string;
  sections?: {
    overview?: string;
    task_analysis?: string;
    status_analysis?: string;
    next_steps?: string;
  };
  structured?: any;
}

type MeResponse = {
  user_id: number;
  loginid: string;
  username: string;
  role: string;
  is_active: boolean;
  deptname?: string;
  mail?: string;
};

const requireUserId = (userId?: number) => {
  if (!userId || userId <= 0) throw new Error('user_id is required');
  return userId;
};

/**
 * 진행률 기준 자동 이동 결과가 응답에 있으면 toast 로 안내한다.
 * (Board/TaskDrawer/WorkNote 등 진행률을 바꾸는 모든 호출 경로 공통 처리)
 * Board 갱신은 realtime task_auto_advanced 이벤트가 담당한다.
 */
function maybeToastAutoAdvance(adv: TaskAutoAdvanceResult | null | undefined): void {
  if (!adv) return;
  const base = `진행률 기준을 충족하여 '${adv.to_column_label}' 단계로 자동 이동되었습니다.`;
  const msg =
    adv.moved_child_task_count > 0
      ? `${base} 하위 Task ${adv.moved_child_task_count}개도 함께 이동되었습니다.`
      : base;
  enqueueSnackbar(msg, { variant: 'info' });
}

// ─── API ───
export const api = {
  // =========================
  // Auth (SSO)
  // =========================
  getMe: async (): Promise<MeResponse> => {
    const res = await client.get('/auth/user/me');
    return res.data;
  },
  // 필요하면 프론트에서 로그인 이동용으로 사용
  getLoginUrl: (): string => `${API_URL}/auth/login`,

  // =========================
  // Realtime sync (SSE)
  // =========================
  /** EventSource 접속용 단발성 ticket 발급 (세션 토큰을 URL 에 노출하지 않기 위함). */
  createEventsTicket: async (spaceId: number): Promise<{ ticket: string; expires_in: number }> => {
    const res = await client.post('/events/ticket', null, { params: { space_id: spaceId } });
    return res.data;
  },

  // =========================
  // Stats
  // =========================
  getStats: async (userId: number, spaceId?: number | null): Promise<DashboardStats> => {
    const params: Record<string, any> = { user_id: requireUserId(userId) };
    if (spaceId) params.space_id = spaceId;
    const res = await client.get('/stats', { params });
    return res.data;
  },

  // =========================
  // Projects
  // =========================
  getProjects: async (userId: number, spaceId?: number | null): Promise<Project[]> => {
    const params: Record<string, any> = { user_id: requireUserId(userId) };
    if (spaceId) params.space_id = spaceId;
    const res = await client.get('/projects', { params });
    return res.data.projects || [];
  },
  createProject: async (project: {
    name: string;
    description?: string;
    owner_id?: number;
    visibility?: string;
    require_approval?: boolean;
    permissions?: Record<string, string>;
    member_ids?: number[];
    space_id?: number;
  }, opts?: { suppressRealtime?: boolean }): Promise<Project> => {
    // 대량 import 시 개별 realtime 이벤트를 막고 완료 후 bulk event 1개만 발행한다.
    const params = opts?.suppressRealtime ? { suppress_realtime: true } : undefined;
    const res = await client.post('/projects', project, { params });
    return res.data;
  },
  updateProject: async (id: number, updates: Partial<Project>, callerUserId?: number): Promise<Project> => {
    const params = callerUserId ? { caller_user_id: callerUserId } : {};
    const res = await client.patch(`/projects/${id}`, updates, { params });
    return res.data;
  },
  deleteProject: async (id: number): Promise<void> => {
    await client.delete(`/projects/${id}`);
  },
  restoreProject: async (id: number): Promise<void> => {
    await client.post(`/projects/${id}/restore`);
  },
  getTrash: async (): Promise<{ projects: any[]; tasks: any[] }> => {
    const res = await client.get('/trash');
    return res.data;
  },

  // =========================
  // Project Hiding (per-user)
  // =========================
  toggleHiddenProject: async (userId: number, projectId: number): Promise<{ action: string; hidden_projects: number[] }> => {
    const res = await client.post(`/users/${requireUserId(userId)}/hidden-projects/${projectId}`);
    return res.data;
  },

  getHiddenProjects: async (userId: number): Promise<number[]> => {
    const res = await client.get(`/users/${requireUserId(userId)}/hidden-projects`);
    return res.data.hidden_projects || [];
  },

  // =========================
  // Users (DB)
  // =========================
  getUsers: async (): Promise<User[]> => {
    const res = await client.get('/users');
    return res.data.users || [];
  },

  /**
   * ⚠️ 백엔드에 /api/users POST가 존재 (현재 권한 체크 없음)
   * - 일단 기존 프론트 호환을 위해 유지
   * - loginid는 소문자 강제
   */
  createUser: async (user: {
    username: string;
    loginid: string;
    role?: string;
    avatar_color?: string;
    deptname?: string;
    mail?: string;
  }): Promise<User> => {
    const payload = {
      ...user,
      loginid: user.loginid.trim().toLowerCase(),
    };
    const res = await client.post('/users', payload);
    return res.data;
  },

  updateUser: async (id: number, updates: Partial<User>): Promise<User> => {
    const res = await client.patch(`/users/${id}`, updates);
    return res.data;
  },

  deleteUser: async (id: number): Promise<void> => {
    await client.delete(`/users/${id}`);
  },

  // =========================
  // User Preferences / Layout
  // =========================
  getUserLayout: async (userId: number): Promise<DashboardLayout | null> => {
    const res = await client.get(`/users/${requireUserId(userId)}/preferences`);
    return res.data.layout || null;
  },
  saveUserLayout: async (userId: number, layout: DashboardLayout): Promise<void> => {
    await client.put(`/users/${requireUserId(userId)}/preferences/layout`, { layout });
  },

  // =========================
  // Tasks
  // =========================
  getTasks: async (projectId: number | undefined, userId: number): Promise<Task[]> => {
    const params: Record<string, any> = { user_id: requireUserId(userId) };
    if (projectId) params.project_id = projectId;

    const res = await client.get('/tasks', { params });
    const tasks: Task[] = res.data.tasks || [];
    return tasks.filter(t => !t.archived_at);
  },

  createTask: async (task: Omit<Task, 'id'>, opts?: { suppressRealtime?: boolean }): Promise<Task> => {
    // 대량 import 시 개별 realtime 이벤트를 막고 완료 후 bulk event 1개만 발행한다.
    const params = opts?.suppressRealtime ? { suppress_realtime: true } : undefined;
    const res = await client.post('/tasks', task, { params });
    return res.data;
  },

  /** 대량 작업(CSV/XLSX import 등) 완료 후 bulk realtime event 1개 발행. */
  emitRealtimeBulkEvent: async (
    spaceId: number,
    userId: number,
    body: {
      event_type?: 'task_bulk_changed' | 'project_bulk_changed' | 'space_bulk_changed';
      project_id?: number | null;
      summary?: {
        projects_created?: number;
        tasks_created?: number;
        notes_created?: number;
        text_notes_created?: number;
        checklist_notes_created?: number;
      };
    },
  ): Promise<{ emitted: boolean; event_type?: string; summary?: Record<string, number> }> => {
    const res = await client.post(`/spaces/${spaceId}/realtime/bulk-event`, body, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  // 캘린더 단발 일정 — 공간별 [시스템] 단발 업무 프로젝트 하위 task 로 생성
  createOneoffTask: async (
    spaceId: number,
    userId: number,
    payload: {
      title: string;
      description?: string;
      start_date?: string | null;
      due_date?: string | null;
      status?: string;
      priority?: string;
      assignee_ids?: number[];
    },
  ): Promise<Task> => {
    const res = await client.post(`/spaces/${spaceId}/oneoff-tasks`, payload, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  // =========================
  // Calendar Events (Phase 2)
  // =========================
  getCalendarEvents: async (
    spaceId: number,
    userId: number,
    range?: { date_from?: string; date_to?: string },
  ): Promise<CalendarEvent[]> => {
    const res = await client.get(`/spaces/${spaceId}/calendar-events`, {
      params: { user_id: requireUserId(userId), ...(range || {}) },
    });
    return res.data.events;
  },

  createCalendarEvent: async (
    spaceId: number,
    userId: number,
    payload: {
      title: string;
      description?: string;
      start_date?: string | null;
      end_date?: string | null;
      all_day?: boolean;
      status?: string;
      event_type?: string;
      assignee_id?: number | null;
    },
  ): Promise<CalendarEvent> => {
    const res = await client.post(`/spaces/${spaceId}/calendar-events`, payload, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  updateCalendarEvent: async (
    eventId: number,
    userId: number,
    updates: Partial<{
      title: string;
      description: string;
      start_date: string | null;
      end_date: string | null;
      all_day: boolean;
      status: string;
      event_type: string;
      assignee_id: number | null;
    }>,
  ): Promise<CalendarEvent> => {
    const res = await client.patch(`/calendar-events/${eventId}`, updates, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  deleteCalendarEvent: async (eventId: number, userId: number): Promise<void> => {
    await client.delete(`/calendar-events/${eventId}`, {
      params: { user_id: requireUserId(userId) },
    });
  },

  convertEventToTask: async (
    eventId: number,
    userId: number,
  ): Promise<{ event: CalendarEvent; task: Task }> => {
    const res = await client.post(`/calendar-events/${eventId}/convert-to-task`, null, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  updateTask: async (id: number, updates: Partial<Task>): Promise<Task> => {
    const res = await client.patch(`/tasks/${id}`, updates);
    maybeToastAutoAdvance(res.data?.auto_advanced);
    return res.data;
  },

  // 상위 작업(Parent) 연결/해제 전용 경량 endpoint (Board/Graph DnD·컨텍스트 메뉴).
  // parentTaskId=null → 연결 해제. 백엔드가 권한/같은프로젝트/같은단계/순환을 검증한다.
  updateTaskParent: async (id: number, parentTaskId: number | null): Promise<Task> => {
    const res = await client.patch(`/tasks/${id}/parent`, { parent_task_id: parentTaskId });
    return res.data;
  },

  // 4차: 사용자 '단계 완료 선언' — 현재 단계 완료 체크/해제. 자동 이동 발생 시 toast.
  declareStageCompletion: async (taskId: number, completed: boolean): Promise<Task & { auto_advanced?: TaskAutoAdvanceResult; current_stage_completed?: boolean }> => {
    const res = await client.post(`/tasks/${taskId}/stage-completion`, { completed });
    maybeToastAutoAdvance(res.data?.auto_advanced);
    return res.data;
  },

  deleteTask: async (id: number): Promise<void> => {
    await client.delete(`/tasks/${id}`);
  },

  restoreTask: async (id: number): Promise<void> => {
    await client.post(`/tasks/${id}/restore`);
  },

  // Task 를 같은 Space 안의 다른 Project 로 이동
  moveTask: async (
    id: number,
    targetProjectId: number,
    targetSubProjectId?: number | null,
  ): Promise<Task> => {
    const res = await client.post(`/tasks/${id}/move`, {
      target_project_id: targetProjectId,
      target_sub_project_id: targetSubProjectId ?? null,
    });
    return res.data;
  },

  // =========================
  // Task Comments (담당자 외 인원 의견 제시 / 논의 기록)
  // =========================
  getTaskComments: async (taskId: number): Promise<{ items: TaskComment[]; can_comment: boolean }> => {
    const res = await client.get(`/tasks/${taskId}/comments`);
    return res.data;
  },
  createTaskComment: async (
    taskId: number,
    content: string,
    attachmentIds: number[] = [],
    opts?: { mentionedUserIds?: number[]; sendMentionEmail?: boolean },
  ): Promise<TaskComment> => {
    const res = await client.post(`/tasks/${taskId}/comments`, {
      content,
      attachment_ids: attachmentIds,
      ...(opts?.mentionedUserIds !== undefined ? { mentioned_user_ids: opts.mentionedUserIds } : {}),
      ...(opts?.sendMentionEmail !== undefined ? { send_mention_email: opts.sendMentionEmail } : {}),
    });
    return res.data;
  },
  /** 댓글 이미지 업로드(Ctrl+V). 댓글 등록 전 pending 으로 저장하고 attachment.id 를 반환. */
  uploadTaskCommentImage: async (taskId: number, file: File): Promise<TaskCommentAttachment> => {
    const form = new FormData();
    form.append('file', file);
    const res = await client.post(`/tasks/${taskId}/comment-images`, form, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },
  updateTaskComment: async (
    taskId: number,
    commentId: number,
    content: string,
    opts?: { mentionedUserIds?: number[]; sendMentionEmail?: boolean },
  ): Promise<TaskComment> => {
    const res = await client.patch(`/tasks/${taskId}/comments/${commentId}`, {
      content,
      ...(opts?.mentionedUserIds !== undefined ? { mentioned_user_ids: opts.mentionedUserIds } : {}),
      ...(opts?.sendMentionEmail !== undefined ? { send_mention_email: opts.sendMentionEmail } : {}),
    });
    return res.data;
  },
  deleteTaskComment: async (taskId: number, commentId: number): Promise<void> => {
    await client.delete(`/tasks/${taskId}/comments/${commentId}`);
  },

  // =========================
  // Workflow Columns (프로젝트별 커스텀 Board 단계)
  // =========================
  getWorkflowColumns: async (projectId: number): Promise<WorkflowConfig> => {
    const res = await client.get(`/projects/${projectId}/workflow-columns`);
    return res.data;
  },

  saveWorkflowColumns: async (
    projectId: number,
    columns: { id?: number; label: string; description?: string | null; color?: string | null; sort_order: number; mapped_status?: string | null; is_checkpoint?: boolean; checkpoint_label?: string | null; checkpoint_description?: string | null; auto_advance_enabled?: boolean; auto_advance_threshold?: number | null; completion_rule_type?: string; auto_move_on_complete?: boolean }[],
  ): Promise<{ columns: WorkflowColumn[] }> => {
    const res = await client.put(`/projects/${projectId}/workflow-columns`, { columns });
    return res.data;
  },

  previewWorkflowMode: async (projectId: number, targetMode: WorkflowMode): Promise<WorkflowModePreview> => {
    const res = await client.post(`/projects/${projectId}/workflow-mode/preview`, { target_mode: targetMode });
    return res.data;
  },

  changeWorkflowMode: async (
    projectId: number,
    targetMode: WorkflowMode,
  ): Promise<WorkflowConfig & { snapshot_id: number }> => {
    const res = await client.put(`/projects/${projectId}/workflow-mode`, { target_mode: targetMode });
    return res.data;
  },

  undoWorkflowMode: async (projectId: number): Promise<WorkflowConfig> => {
    const res = await client.post(`/projects/${projectId}/workflow-mode/undo`);
    return res.data;
  },

  // =========================
  // SubProjects (sidecar)
  // =========================
  getSubProjects: async (projectId: number): Promise<SubProject[]> => {
    const res = await client.get(`/projects/${projectId}/subprojects`);
    return res.data.sub_projects || [];
  },
  createSubProject: async (
    projectId: number,
    sub: { name: string; description?: string; parent_id?: number | null }
  ): Promise<SubProject> => {
    const res = await client.post(`/projects/${projectId}/subprojects`, sub);
    return res.data;
  },
  updateSubProject: async (subId: number, updates: Partial<SubProject>): Promise<SubProject> => {
    const res = await client.patch(`/subprojects/${subId}`, updates);
    return res.data;
  },
  deleteSubProject: async (id: number): Promise<void> => {
    await client.delete(`/subprojects/${id}`);
  },

  // =========================
  // Notes (sidecar)
  // =========================
  getNotes: async (projectId: number, userId: number): Promise<Note[]> => {
    // 백엔드: user_id 있으면 프로젝트 접근 체크 수행
    const res = await client.get(`/projects/${projectId}/notes`, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data.notes || [];
  },

  createNote: async (
    projectId: number,
    content: string,
    userId: number
  ): Promise<Note & { message: string }> => {
    const res = await client.post(
      `/projects/${projectId}/notes`,
      { content },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },

  deleteNote: async (id: number): Promise<void> => {
    await client.delete(`/notes/${id}`);
  },

  // =========================
  // Mentions
  // ✅ v1.2: Backend /api/mentions endpoint implemented
  // =========================
  getMentions: async (userId: number): Promise<MentionNote[]> => {
    const res = await client.get('/mentions', { params: { user_id: requireUserId(userId) } });
    return res.data.mentions || [];
  },

  /** 딥링크(/mentions?mentionId=ref)용 단건 조회. ref = 'comment-{id}' | 'activity-{id}'. */
  getMentionDetail: async (mentionRef: string): Promise<MentionDetail> => {
    const res = await client.get(`/mentions/${encodeURIComponent(mentionRef)}`);
    return res.data;
  },

  getNotificationPreferences: async (userId: number): Promise<NotificationPreference> => {
    const res = await client.get('/users/me/notification-preferences', {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  updateNotificationPreferences: async (
    userId: number,
    patch: Partial<Omit<NotificationPreference, 'user_id'>>,
  ): Promise<NotificationPreference> => {
    const res = await client.patch('/users/me/notification-preferences', patch, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  // =========================
  // Attachments (sidecar)
  // =========================
  getAttachments: async (taskId: number): Promise<Attachment[]> => {
    const res = await client.get(`/tasks/${taskId}/attachments`);
    return res.data.attachments || [];
  },
  createAttachment: async (
    taskId: number,
    attachment: { url: string; filename?: string; type?: string }
  ): Promise<Attachment> => {
    const res = await client.post(`/tasks/${taskId}/attachments`, attachment);
    return res.data;
  },
  updateAttachment: async (
    id: number,
    userId: number,
    patch: { url?: string; filename?: string }
  ): Promise<Attachment> => {
    const res = await client.patch(`/attachments/${id}`, patch, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },
  deleteAttachment: async (id: number): Promise<void> => {
    await client.delete(`/attachments/${id}`);
  },

  uploadTaskFile: async (taskId: number, file: File, userId: number): Promise<Attachment> => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await client.post(`/tasks/${taskId}/files`, formData, {
      params: { user_id: requireUserId(userId) },
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },

  /** 공간 단위 이미지 업로드 (task 없는 리치 에디터용 — 캘린더 단발 일정 설명 등). */
  uploadSpaceImage: async (
    spaceId: number,
    file: File,
    userId: number,
  ): Promise<{ url: string; stored_name: string; filename: string }> => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await client.post(`/spaces/${spaceId}/images`, formData, {
      params: { user_id: requireUserId(userId) },
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },

  // =========================
  // Task Activities (Checklist)
  // =========================
  getTaskActivities: async (taskId: number): Promise<TaskActivity[]> => {
    const res = await client.get(`/tasks/${taskId}/activities`);
    return res.data.activities || [];
  },
  createTaskActivity: async (taskId: number, data: { content: string; block_type?: string; checked?: boolean; style?: any; is_stage_checkpoint?: boolean; checkpoint_required?: boolean; checkpoint_stage_id?: number | null; order_index?: number; author_id?: number | null; mentioned_user_ids?: number[]; send_mention_email?: boolean }): Promise<TaskActivity> => {
    const res = await client.post(`/tasks/${taskId}/activities`, data);
    return res.data;
  },
  updateTaskActivity: async (activityId: number, data: Partial<TaskActivity>): Promise<TaskActivity> => {
    const res = await client.patch(`/activities/${activityId}`, data);
    maybeToastAutoAdvance(res.data?.auto_advanced);
    return res.data;
  },
  deleteTaskActivity: async (activityId: number): Promise<void> => {
    await client.delete(`/activities/${activityId}`);
  },
  reorderTaskActivities: async (taskId: number, order: number[]): Promise<void> => {
    await client.put(`/tasks/${taskId}/activities/reorder`, { order });
  },

  // =========================
  // Activity Logs (변경 이력 / item history)
  // =========================
  getActivityLogs: async (
    entityType: 'project' | 'task' | 'calendar_event',
    entityId: number,
    limit = 50,
  ): Promise<ActivityLogEntry[]> => {
    const res = await client.get('/activity-logs', {
      params: { entity_type: entityType, entity_id: entityId, limit },
    });
    return res.data.logs || [];
  },

  // =========================
  // Roadmap
  // =========================
  getRoadmap: async (params: {
    project_id: number;
    view?: string;
    from?: string;
    to?: string;
    assignee_id?: number;
    status?: string;
  }): Promise<{ view: string; items: RoadmapItem[] }> => {
    // 백엔드: from/to는 alias="from"/"to"
    const res = await client.get('/roadmap', { params });
    return res.data;
  },

  // =========================
  // Project Members / Join Requests
  // =========================
  getProjectMembers: async (projectId: number): Promise<ProjectMember[]> => {
    const res = await client.get(`/projects/${projectId}/members`);
    return res.data.members || [];
  },

  addProjectMember: async (
    projectId: number,
    userId: number,
    role: string = 'member',
    callerUserId?: number
  ): Promise<any> => {
    const params = callerUserId ? { caller_user_id: requireUserId(callerUserId) } : undefined;
    const res = await client.post(`/projects/${projectId}/members`, { user_id: userId, role }, { params });
    return res.data;
  },

  removeProjectMember: async (projectId: number, userId: number, callerUserId?: number): Promise<void> => {
    const params = callerUserId ? { caller_user_id: requireUserId(callerUserId) } : undefined;
    await client.delete(`/projects/${projectId}/members/${userId}`, { params });
  },

  updateProjectMemberRole: async (projectId: number, targetUserId: number, role: string, callerUserId: number): Promise<any> => {
    const res = await client.patch(`/projects/${projectId}/members/${targetUserId}/role`, { role }, { params: { user_id: requireUserId(callerUserId) } });
    return res.data;
  },

  requestJoin: async (projectId: number, userId: number): Promise<any> => {
    const res = await client.post(`/projects/${projectId}/join-request`, null, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  getJoinRequests: async (projectId: number): Promise<any[]> => {
    const res = await client.get(`/projects/${projectId}/join-requests`);
    return res.data.join_requests || [];
  },

  approveJoinRequest: async (projectId: number, userId: number, action: string): Promise<any> => {
    const res = await client.post(`/projects/${projectId}/join-requests/approve`, {
      user_id: userId,
      action,
    });
    return res.data;
  },

  // =========================
  // Graph
  // =========================
  getProjectGraph: async (
    projectId: number
  ): Promise<{ nodes: GraphNode[]; edges: GraphEdge[] }> => {
    const res = await client.get(`/projects/${projectId}/graph`);
    return res.data;
  },

  // =========================
  // Report
  // =========================
  getReportData: async (projectId: number, userId?: number): Promise<any> => {
    const uid = resolveUserId(userId);
    const res = await client.get(`/report/data/${projectId}`, {
      params: uid ? { user_id: uid } : {},
    });
    return res.data;
  },

  deleteReportData: async (projectId: number, userId?: number): Promise<any> => {
    const uid = resolveUserId(userId);
    const res = await client.delete(`/report/data/${projectId}`, {
      params: uid ? { user_id: uid } : {},
    });
    return res.data;
  },

  generateReport: async (projectId: number): Promise<ReportResponse> => {
    // generate는 보통 권한체크를 내부에서 project access로 하니까 params 없어도 되는데,
    // 통일하고 싶으면 uid 붙여도 됨(백엔드가 받게 만들었을 때)
    const res = await client.post('/report/generate', { project_id: projectId });
    return res.data;
  },
  
  // =========================
  // Project Files (sidecar metadata + 실제 업로드)
  // =========================
  getProjectFiles: async (projectId: number, userId: number): Promise<ProjectFile[]> => {
    const res = await client.get(`/projects/${projectId}/files`, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data.files || [];
  },

  uploadProjectFile: async (
    projectId: number,
    file: File,
    userId: number
  ): Promise<ProjectFile> => {
    const formData = new FormData();
    formData.append('file', file);

    const res = await client.post(`/projects/${projectId}/files`, formData, {
      params: { user_id: requireUserId(userId) }, // ✅ default=1 쓰지 말고 반드시 넣기
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },

  downloadProjectFile: (projectId: number, fileId: number, userId: number): string => {
    // ✅ 백엔드는 user_id 있으면 권한 체크 수행 -> URL에도 user_id 포함 권장
    return `${API_URL}/projects/${projectId}/files/${fileId}/download?user_id=${requireUserId(userId)}`;
  },

  deleteProjectFile: async (projectId: number, fileId: number): Promise<void> => {
    await client.delete(`/projects/${projectId}/files/${fileId}`);
  },

  // =========================
  // Global Roadmap
  // =========================
  getGlobalRoadmap: async (
    userId: number,
    view: string = 'month',
    spaceId?: number | null
  ): Promise<{ view: string; items: RoadmapItem[] }> => {
    const params: Record<string, any> = { user_id: requireUserId(userId), view };
    if (spaceId) params.space_id = spaceId;
    const res = await client.get('/roadmap/global', { params });
    return res.data;
  },

  // ⚠️ saveGlobalRoadmapOrder endpoint는 백엔드 코드에 아직 안 보임(있다면 유지)
  saveGlobalRoadmapOrder: async (
    userId: number,
    order: string[],
    parentKey?: string
  ): Promise<void> => {
    await client.put(
      `/roadmap/global/order`,
      {
        order,
        parent_key: parentKey || null,
      },
      { params: { user_id: requireUserId(userId) } }
    );
  },

  saveRoadmapOrder: async (
    projectId: number,
    order: string[],
    parentKey?: string
  ): Promise<void> => {
    await client.put(
      `/projects/${projectId}/roadmap/order`,
      {
        order,
        parent_key: parentKey || null,
      }
    );
  },

  // =========================
  // Shortcuts (sidecar) - admin required (require_admin)
  // =========================
  getShortcuts: async (userId?: number): Promise<Shortcut[]> => {
    const res = await client.get('/shortcuts', userId ? { params: { user_id: userId } } : undefined);
    return res.data.shortcuts || [];
  },

  /** Dashboard 위젯용: 현재 사용자가 볼 수 있는 admin + user 바로가기 통합 조회 */
  getMyShortcuts: async (userId: number): Promise<MyShortcut[]> => {
    const res = await client.get('/shortcuts/my', { params: { user_id: requireUserId(userId) } });
    return res.data.shortcuts || [];
  },

  createShortcut: async (
    data: {
      name: string;
      url: string;
      icon_text?: string;
      icon_color?: string;
      order?: number;
      open_new_tab?: boolean;
      visibility?: ShortcutVisibility;
      shared_user_ids?: number[];
      shared_group_ids?: number[];
    },
    userId: number
  ): Promise<Shortcut> => {
    const res = await client.post('/shortcuts', data, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  updateShortcut: async (
    id: number,
    data: Partial<Shortcut>,
    userId: number
  ): Promise<Shortcut> => {
    const res = await client.patch(`/shortcuts/${id}`, data, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  deleteShortcut: async (id: number, userId: number): Promise<void> => {
    await client.delete(`/shortcuts/${id}`, {
      params: { user_id: requireUserId(userId) },
    });
  },

  // =========================
  // Admin Users (require_admin)
  // =========================
  getAdminUsers: async (
    userId: number,
    opts?: {
      page?: number;
      page_size?: number;
      search?: string;
      role?: string;
      active?: boolean;
      sort_by?: string;
      sort_order?: 'asc' | 'desc';
    }
  ): Promise<{ items: User[]; pagination: PaginationMeta }> => {
    const params: Record<string, any> = { user_id: requireUserId(userId) };
    if (opts?.page) params.page = opts.page;
    if (opts?.page_size) params.page_size = opts.page_size;
    if (opts?.search) params.search = opts.search;
    if (opts?.role) params.role = opts.role;
    if (typeof opts?.active === 'boolean') params.active = opts.active;
    if (opts?.sort_by) params.sort_by = opts.sort_by;
    if (opts?.sort_order) params.sort_order = opts.sort_order;
    const res = await client.get('/admin/users', { params });
    return { items: res.data.items || res.data.users || [], pagination: res.data.pagination };
  },

  // =========================
  // Admin System Logs (운영 확인용 요약 로그)
  // =========================
  getSystemLogs: async (
    userId: number,
    filters?: SystemLogFilters
  ): Promise<{
    items: SystemEventLog[];
    total: number;
    limit: number;
    offset: number;
    pagination: PaginationMeta;
  }> => {
    const params: Record<string, any> = { user_id: requireUserId(userId) };
    if (filters) {
      if (filters.level) params.level = filters.level;
      if (filters.category) params.category = filters.category;
      if (filters.date_from) params.date_from = filters.date_from;
      if (filters.date_to) params.date_to = filters.date_to;
      if (typeof filters.resolved === 'boolean') params.resolved = filters.resolved;
      if (filters.keyword) params.keyword = filters.keyword;
      if (filters.endpoint) params.endpoint = filters.endpoint;
      if (typeof filters.status_code === 'number') params.status_code = filters.status_code;
      if (typeof filters.page === 'number') params.page = filters.page;
      if (typeof filters.page_size === 'number') params.page_size = filters.page_size;
    }
    const res = await client.get('/admin/system-logs', { params });
    return res.data;
  },

  getRecentSystemLogs: async (userId: number, limit = 50): Promise<SystemEventLog[]> => {
    const res = await client.get('/admin/system-logs/recent', {
      params: { user_id: requireUserId(userId), limit },
    });
    return res.data.items || [];
  },

  resolveSystemLog: async (
    logId: number,
    userId: number,
    resolved = true
  ): Promise<SystemEventLog> => {
    const res = await client.patch(`/admin/system-logs/${logId}/resolve`, null, {
      params: { user_id: requireUserId(userId), resolved },
    });
    return res.data;
  },

  deleteSystemLog: async (logId: number, userId: number): Promise<{ deleted: number }> => {
    const res = await client.delete(`/admin/system-logs/${logId}`, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  bulkDeleteSystemLogs: async (
    userId: number,
    ids: number[],
    reason?: string
  ): Promise<{ deleted: number }> => {
    const res = await client.post(
      '/admin/system-logs/bulk-delete',
      { ids, reason },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },

  bulkResolveSystemLogs: async (
    userId: number,
    ids: number[],
    resolved: boolean,
    opts?: { resolution_note?: string; reason?: string }
  ): Promise<{ updated: number }> => {
    const res = await client.post(
      '/admin/system-logs/bulk-resolve',
      { ids, resolved, ...(opts || {}) },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },

  filterResolveSystemLogs: async (
    userId: number,
    filters: SystemLogFilterSpec,
    opts?: { resolution_note?: string; reason?: string }
  ): Promise<{ updated: number }> => {
    const res = await client.post(
      '/admin/system-logs/filter-resolve',
      { filters, ...(opts || {}) },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },

  filterDeletePreviewSystemLogs: async (
    userId: number,
    filters: SystemLogFilterSpec
  ): Promise<SystemLogFilterPreview> => {
    const res = await client.post(
      '/admin/system-logs/filter-delete-preview',
      { filters },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },

  filterDeleteSystemLogs: async (
    userId: number,
    filters: SystemLogFilterSpec,
    confirmText: string,
    reason?: string
  ): Promise<{ deleted: number }> => {
    const res = await client.post(
      '/admin/system-logs/filter-delete',
      { filters, confirm_text: confirmText, reason },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },

  getSystemHealth: async (userId: number): Promise<SystemHealth> => {
    const res = await client.get('/admin/system-health', {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  getVisitStats: async (userId: number, days = 30): Promise<VisitStats> => {
    const res = await client.get('/admin/visit-stats', {
      params: { user_id: requireUserId(userId), days },
    });
    return res.data;
  },

  getUsageStats: async (userId: number, days = 30): Promise<UsageStats> => {
    const res = await client.get('/admin/usage-stats', {
      params: { user_id: requireUserId(userId), days },
    });
    return res.data;
  },

  getUploadPolicy: async (): Promise<UploadPolicy> => {
    const res = await client.get('/upload-policy');
    return res.data;
  },

  toggleUserActive: async (targetId: number, userId: number): Promise<User> => {
    const res = await client.patch(`/admin/users/${targetId}/toggle-active`, null, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  deleteAdminUser: async (targetId: number, adminUserId: number): Promise<void> => {
    await client.delete(`/admin/users/${targetId}`, { params: { user_id: requireUserId(adminUserId) } });
  },

  /**
   * ⚠️ 백엔드 코드에 /api/admin/users/{id}/role 이 아직 안 보임
   * - 우선 admin endpoint를 시도하고, 404면 /api/users/{id} patch로 fallback
   */
  updateUserRole: async (targetId: number, role: string, adminUserId: number): Promise<User> => {
    try {
      const res = await client.patch(
        `/admin/users/${targetId}/role`,
        { role },
        {
          params: { user_id: requireUserId(adminUserId) },
        }
      );
      return res.data;
    } catch (e: any) {
      if (e?.response?.status === 404) {
        const res2 = await client.patch(`/users/${targetId}`, { role });
        return res2.data;
      }
      throw e;
    }
  },

  // =========================
  // Groups (sidecar)
  // =========================
  getGroups: async (adminUserId: number): Promise<Group[]> => {
    const res = await client.get('/admin/groups', {
      params: { user_id: requireUserId(adminUserId) },
    });
    return res.data.groups || [];
  },

  createGroup: async (
    data: { name: string; description?: string },
    adminUserId: number
  ): Promise<Group> => {
    const res = await client.post('/admin/groups', data, {
      params: { user_id: requireUserId(adminUserId) },
    });
    return res.data;
  },

  deleteGroup: async (groupId: number, adminUserId: number): Promise<void> => {
    await client.delete(`/admin/groups/${groupId}`, {
      params: { user_id: requireUserId(adminUserId) },
    });
  },

  applyGroup: async (groupId: number, adminUserId: number): Promise<any> => {
    const res = await client.post(`/admin/groups/${groupId}/apply`, null, {
      params: { user_id: requireUserId(adminUserId) },
    });
    return res.data;
  },

  // =========================
  // Search & AI Summary / AI Query
  // ⚠️ 이 파트는 너가 올린 main.py 일부에 아직 안 보임(있다면 유지)
  // =========================
  searchProjects: async (
    params: {
      query?: string;
      status?: string;
      from_date?: string;
      to_date?: string;
      sort?: string;
    },
    userId: number
  ): Promise<{ projects: SearchResultProject[]; total: number }> => {
    const res = await client.post('/search', params, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  generateSearchSummary: async (
    data: { project_ids: number[]; query?: string },
    userId: number
  ): Promise<SearchSummaryResult> => {
    const res = await client.post('/search/ai-summary', data, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  getSearchSummaries: async (userId: number): Promise<{ summaries: SearchSummaryResult[] }> => {
    const res = await client.get('/search/summaries', {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  submitSummaryFeedback: async (
    data: { summary_id: number; rating: string; comment?: string },
    userId: number
  ): Promise<any> => {
    const res = await client.post('/search/feedback', data, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  saveSummaryCorrection: async (
    data: { summary_id: number; corrected_text: string },
    userId: number
  ): Promise<any> => {
    const res = await client.post('/search/correction', data, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  queryProjectAi: async (
    projectId: number,
    query: string,
    userId: number
  ): Promise<ProjectAiQueryResponse> => {
    const res = await client.post(
      `/projects/${projectId}/ai-query`,
      { query },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },

  // =========================
  // Member Groups (DB)
  // =========================
  getMemberGroups: async (userId: number): Promise<MemberGroup[]> => {
    const res = await client.get('/member-groups', {
      params: { user_id: requireUserId(userId) },
    });
    return res.data.groups || [];
  },

  createMemberGroup: async (
    data: {
      name: string;
      description?: string;
      member_user_ids?: number[];
      knox_members?: { loginid: string; name?: string; email?: string; deptname?: string }[];
    },
    userId: number
  ): Promise<MemberGroup> => {
    const res = await client.post('/member-groups', data, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  updateMemberGroup: async (
    groupId: number,
    data: {
      name?: string;
      description?: string;
      member_user_ids?: number[];
      knox_members?: { loginid: string; name?: string; email?: string; deptname?: string }[];
    },
    userId: number
  ): Promise<MemberGroup> => {
    const res = await client.patch(`/member-groups/${groupId}`, data, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },

  deleteMemberGroup: async (groupId: number, userId: number): Promise<void> => {
    await client.delete(`/member-groups/${groupId}`, {
      params: { user_id: requireUserId(userId) },
    });
  },

  /** 그룹 생성/수정용 통합 검색 — 사이트 users + Knox */
  getGroupMemberCandidates: async (
    query: string,
    userId: number
  ): Promise<MemberCandidate[]> => {
    const res = await client.get('/member-groups/member-candidates', {
      params: { q: query, user_id: requireUserId(userId) },
    });
    return res.data.items || [];
  },

  // pagination 지원 버전 — 같은 이름이 많아도 page 단위로 끝까지 탐색
  getGroupMemberCandidatesPaged: async (
    query: string,
    userId: number,
    page: number = 1,
    pageSize: number = 50
  ): Promise<{ items: MemberCandidate[]; pagination: { page: number; page_size: number; total: number; total_pages: number; has_next: boolean } }> => {
    const res = await client.get('/member-groups/member-candidates', {
      params: { q: query, user_id: requireUserId(userId), page, page_size: pageSize },
    });
    return {
      items: res.data.items || [],
      pagination: res.data.pagination || { page, page_size: pageSize, total: (res.data.items || []).length, total_pages: 1, has_next: false },
    };
  },

  // =========================
  // Org Admin (v1.2)
  // =========================
  getOrgTree: async (userId: number) => {
    const res = await client.get('/admin/org/tree', { params: { user_id: requireUserId(userId) } });
    return res.data.tree || [];
  },

  createOrgGroup: async (data: any, userId: number) => {
    const res = await client.post('/admin/org/groups', data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  updateOrgGroup: async (groupId: number, data: any, userId: number) => {
    const res = await client.patch(`/admin/org/groups/${groupId}`, data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  deleteOrgGroup: async (groupId: number, userId: number) => {
    const res = await client.delete(`/admin/org/groups/${groupId}`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  assignUserToPart: async (targetUserId: number, data: any, userId: number) => {
    const res = await client.post(`/admin/org/users/${targetUserId}/assign`, data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  assignProjectPart: async (projectId: number, data: any, userId: number) => {
    const res = await client.post(`/admin/org/projects/${projectId}/assign-part`, data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  // =========================
  // AI Settings
  // =========================
  getAiSettings: async (userId: number, provider?: string): Promise<AiSettings> => {
    const res = await client.get('/settings/ai', {
      params: { user_id: requireUserId(userId), ...(provider ? { provider } : {}) },
    });
    return res.data;
  },
  saveAiSettings: async (
    data: { model_name: string; provider?: string },
    userId: number,
  ): Promise<any> => {
    const res = await client.put('/settings/ai', data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  getAiModels: async (userId: number, provider?: string): Promise<{
    provider: string;
    models: string[];
    default_model: string;
    model_details: { key: string; model: string; name: string; description: string }[];
  }> => {
    const res = await client.get('/settings/ai/models', {
      params: { user_id: requireUserId(userId), ...(provider ? { provider } : {}) },
    });
    return res.data;
  },
  testAiConnection: async (
    data: { model_name: string; provider?: string },
    userId: number,
  ): Promise<AiConnectionTestResult> => {
    const res = await client.post('/settings/ai/test', data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  // ── Vision AI 설정 (Text AI와 분리) ──
  getVisionAiSettings: async (userId: number): Promise<VisionAiSettings> => {
    const res = await client.get('/settings/vision-ai', { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  saveVisionAiSettings: async (
    data: VisionAiSettingsUpdate,
    userId: number,
  ): Promise<{ message: string; settings: VisionAiSettings }> => {
    const res = await client.put('/settings/vision-ai', data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  testVisionAiConnection: async (
    data: VisionAiSettingsUpdate,
    userId: number,
  ): Promise<VisionAiTestResult> => {
    const res = await client.post('/settings/vision-ai/test', data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  testVisionAiVisionInput: async (
    data: VisionAiSettingsUpdate,
    userId: number,
  ): Promise<VisionAiTestResult> => {
    const res = await client.post('/settings/vision-ai/vision-test', data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  // =========================
  // List Order (B-1)
  // =========================
  getListOrder: async (projectId: number): Promise<{ order: number[] }> => {
    const res = await client.get(`/projects/${projectId}/list/order`);
    return res.data;
  },
  getAllListOrders: async (projectId: number): Promise<Record<string, number[]>> => {
    const res = await client.get(`/projects/${projectId}/list/all-orders`);
    return res.data;
  },
  saveListOrder: async (projectId: number, order: number[]): Promise<void> => {
    await client.put(`/projects/${projectId}/list/order`, { order });
  },
  getSubProjectOrder: async (projectId: number): Promise<{ order: number[] }> => {
    const res = await client.get(`/projects/${projectId}/subprojects/order`);
    return res.data;
  },
  saveSubProjectOrder: async (projectId: number, order: number[]): Promise<void> => {
    await client.put(`/projects/${projectId}/subprojects/order`, { order });
  },
  getSpTaskOrder: async (subId: number): Promise<{ order: number[] }> => {
    const res = await client.get(`/subprojects/${subId}/tasks/order`);
    return res.data;
  },
  saveSpTaskOrder: async (subId: number, order: number[]): Promise<void> => {
    await client.put(`/subprojects/${subId}/tasks/order`, { order });
  },

  // =========================
  // Knox Employee Search (D-2)
  // =========================
  // =========================
  // User Shortcuts (per-user, DB)
  // =========================
  getUserShortcuts: async (userId: number): Promise<UserShortcut[]> => {
    const res = await client.get('/user-shortcuts', { params: { user_id: requireUserId(userId) } });
    return res.data.shortcuts || [];
  },

  createUserShortcut: async (
    userId: number,
    data: {
      name: string;
      url: string;
      icon_text?: string;
      icon_color?: string;
      order?: number;
      open_new_tab?: boolean;
      visibility?: ShortcutVisibility;
      shared_user_ids?: number[];
      shared_group_ids?: number[];
    }
  ): Promise<UserShortcut> => {
    const res = await client.post('/user-shortcuts', data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  updateUserShortcut: async (
    shortcutId: number,
    userId: number,
    data: Partial<UserShortcut>
  ): Promise<UserShortcut> => {
    const res = await client.patch(`/user-shortcuts/${shortcutId}`, data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  deleteUserShortcut: async (shortcutId: number, userId: number): Promise<void> => {
    await client.delete(`/user-shortcuts/${shortcutId}`, { params: { user_id: requireUserId(userId) } });
  },

  searchKnoxEmployees: async (params: { fullName?: string; userIds?: string; query?: string }): Promise<any[]> => {
    const res = await client.get('/employees', { params });
    return res.data.employees || res.data || [];
  },

  getUnassignedUsers: async (userId: number) => {
    const res = await client.get('/admin/org/unassigned-users', { params: { user_id: requireUserId(userId) } });
    return res.data.users || [];
  },

  // =========================
  // Spaces
  // =========================
  getSpaces: async (userId: number): Promise<any[]> => {
    const res = await client.get('/spaces', { params: { user_id: requireUserId(userId) } });
    return res.data.spaces || [];
  },
  /** 현재 공간의 멤버 목록 (담당자 후보 등). 공간 멤버만 조회 가능. */
  getSpaceMembers: async (spaceId: number, userId: number): Promise<SpaceMemberInfo[]> => {
    const res = await client.get(`/spaces/${spaceId}`, { params: { user_id: requireUserId(userId) } });
    return res.data.members || [];
  },
  getAllSpaces: async (userId: number): Promise<any[]> => {
    const res = await client.get('/spaces/all', { params: { user_id: requireUserId(userId) } });
    return res.data.spaces || [];
  },
  searchUsers: async (query: string, userId: number): Promise<any[]> => {
    const res = await client.get('/users/search', { params: { q: query, user_id: requireUserId(userId) } });
    return res.data.users || [];
  },
  createSpace: async (data: { name: string; slug?: string; description?: string; member_user_ids?: number[]; knox_members?: { loginid: string; name?: string; email?: string; deptname?: string }[]; purpose?: string }, userId: number): Promise<any> => {
    const res = await client.post('/spaces', data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  /** 공간 생성 가능 개수/한도 (생성 화면 사용량 표시용) */
  getSpaceLimits: async (userId: number): Promise<SpaceLimits> => {
    const res = await client.get('/spaces/limits', { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  /** 비슷한 이름의 공간이 이미 있는지 확인 (생성 차단 아님, 경고용) */
  checkSpaceName: async (name: string, userId: number): Promise<SimilarSpace[]> => {
    const res = await client.get('/spaces/name-check', { params: { name, user_id: requireUserId(userId) } });
    return res.data.similar || [];
  },
  // ── 관리자: 공간 사용 현황 / 빈 공간 관리 ──
  adminGetSpaces: async (
    userId: number,
    opts?: { filter?: string; q?: string; creator_id?: number; purpose?: string; page?: number; page_size?: number }
  ): Promise<{ spaces: AdminSpaceRow[]; summary: AdminSpaceSummary; filter: string; pagination: PaginationMeta }> => {
    const params: Record<string, any> = { user_id: requireUserId(userId), filter: opts?.filter || 'all' };
    if (opts?.q) params.q = opts.q;
    if (opts?.creator_id) params.creator_id = opts.creator_id;
    if (opts?.purpose) params.purpose = opts.purpose;
    if (opts?.page) params.page = opts.page;
    if (opts?.page_size) params.page_size = opts.page_size;
    const res = await client.get('/admin/spaces', { params });
    return res.data;
  },
  // ── AI Context Inspector (super_admin 전용) — LLM 미호출, 구조화 메타 preview ──
  getProjectAiContextPreview: async (
    projectId: number,
    userId: number,
    opts?: { include_images?: boolean; max_images?: number; image_scope?: string }
  ): Promise<AiContextPreviewResponse> => {
    const params: Record<string, any> = {
      user_id: requireUserId(userId),
      include_images: opts?.include_images ?? true,
      max_images: opts?.max_images ?? 50,
    };
    if (opts?.image_scope) params.image_scope = opts.image_scope;
    const res = await client.get(`/projects/${projectId}/ai-context-preview`, { params });
    return res.data;
  },
  // 단일 이미지 preview (lazy, 1장). image_id 만 넘기면 백엔드가 내부에서 파일을 찾아 반환.
  getProjectAiContextPreviewImage: async (
    projectId: number,
    imageId: string,
    userId: number,
    signal?: AbortSignal
  ): Promise<Blob> => {
    const res = await client.get(`/projects/${projectId}/ai-context-preview/image`, {
      params: { image_id: imageId, user_id: requireUserId(userId) },
      responseType: 'blob',
      signal,
    });
    return res.data;
  },
  // Model Compatibility Layer preview — image_id 1개의 model_input_packet + provider_payload.
  // vision/OCR/LLM 미호출. input_mode: image_only / image_with_nearby_text / image_with_evidence_card.
  getProjectAiContextModelPacket: async (
    projectId: number,
    imageId: string,
    userId: number,
    opts?: { provider?: string; input_mode?: string }
  ): Promise<ModelPacketResponse> => {
    const res = await client.get(`/projects/${projectId}/ai-context-preview/model-packet`, {
      params: {
        image_id: imageId,
        user_id: requireUserId(userId),
        provider: opts?.provider ?? 'generic',
        input_mode: opts?.input_mode ?? 'image_with_evidence_card',
      },
    });
    return res.data;
  },
  // ── Vision Report Test (super_admin 전용 이미지 포함 AI Report PoC) ──
  // 메타(모델 목록/제한/모드). 실제 모델 호출 없음.
  getVisionReportTestMeta: async (
    projectId: number,
    userId: number
  ): Promise<VisionReportTestMeta> => {
    const res = await client.get(`/projects/${projectId}/ai-report/vision-test/meta`, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },
  // 이미지 포함 vision 모델 호출. 이미지 바이트는 서버 내부에서 로딩(프론트는 image_id만 전송).
  runVisionReportTest: async (
    projectId: number,
    body: VisionReportTestRequestBody,
    signal?: AbortSignal
  ): Promise<VisionReportTestResponse> => {
    const res = await client.post(
      `/projects/${projectId}/ai-report/vision-test`,
      { ...body, user_id: requireUserId(body.user_id) },
      { signal }
    );
    return res.data;
  },
  // AI 설정 "실제 프로젝트 이미지 테스트" — Vision Report Stage 1과 동일 경로로 이미지 1장 진단.
  // 캐시 read/write 없음, Stage 2 없음. super_admin 전용.
  runProjectImageVisionTest: async (
    body: ProjectImageVisionTestBody,
    signal?: AbortSignal
  ): Promise<ProjectImageVisionTestResult> => {
    const res = await client.post(
      '/settings/vision-ai/project-image-test',
      { ...body, user_id: requireUserId(body.user_id) },
      { signal }
    );
    return res.data;
  },
  // Gemma4 Vision 지연/실패 시 사용자가 선택하는 텍스트 전용 fallback 보고서.
  // ⚠️ 일회성 실행 — AI Settings 저장값을 바꾸지 않는다.
  runVisionTextFallbackReport: async (
    projectId: number,
    body: VisionTextFallbackRequestBody
  ): Promise<VisionReportTestResponse> => {
    const res = await client.post(`/projects/${projectId}/ai-report/text-fallback`, {
      ...body,
      user_id: requireUserId(body.user_id),
    });
    return res.data;
  },
  adminArchiveSpace: async (spaceId: number, userId: number): Promise<any> => {
    const res = await client.post(`/admin/spaces/${spaceId}/archive`, null, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  adminRestoreSpace: async (spaceId: number, userId: number): Promise<any> => {
    const res = await client.post(`/admin/spaces/${spaceId}/restore`, null, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  adminNotifySpaceOwner: async (spaceId: number, userId: number): Promise<any> => {
    const res = await client.post(`/admin/spaces/${spaceId}/notify-owner`, null, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  adminToggleSpaceExempt: async (spaceId: number, userId: number): Promise<any> => {
    const res = await client.post(`/admin/spaces/${spaceId}/toggle-exempt`, null, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  adminExtendSpaceDelete: async (spaceId: number, userId: number, days = 30): Promise<any> => {
    const res = await client.post(`/admin/spaces/${spaceId}/extend-delete`, null, { params: { user_id: requireUserId(userId), days } });
    return res.data;
  },
  adminHardDeleteSpace: async (spaceId: number, userId: number, confirm: string): Promise<any> => {
    const res = await client.delete(`/admin/spaces/${spaceId}/hard-delete`, {
      params: { user_id: requireUserId(userId) },
      data: { confirm },
    });
    return res.data;
  },
  deleteSpace: async (spaceId: number, userId: number): Promise<any> => {
    const res = await client.delete(`/spaces/${spaceId}`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  getUnassignedProjects: async (userId: number): Promise<Project[]> => {
    const res = await client.get('/projects/unassigned', { params: { user_id: requireUserId(userId) } });
    return res.data.projects || [];
  },
  moveProjectToSpace: async (projectId: number, spaceId: number, userId: number): Promise<any> => {
    const res = await client.patch(`/projects/${projectId}/move-space`, null, { params: { space_id: spaceId, user_id: requireUserId(userId) } });
    return res.data;
  },
  /** 내가 다른 공간으로 이동시킬 수 있는 프로젝트 목록 (소유자/담당자/admin) */
  getMovableProjects: async (userId: number): Promise<MovableProject[]> => {
    const res = await client.get('/projects/movable', { params: { user_id: requireUserId(userId) } });
    return res.data.projects || [];
  },
  /** 선택한 프로젝트들을 대상 공간으로 일괄 이동 (프로젝트별 성공/실패 결과 반환) */
  moveProjectsToSpace: async (projectIds: number[], targetSpaceId: number, userId: number): Promise<MoveProjectsResult> => {
    const res = await client.post('/projects/move-space', { project_ids: projectIds, target_space_id: targetSpaceId }, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  updateSpace: async (spaceId: number, data: { name?: string; description?: string; purpose?: string }, userId: number): Promise<any> => {
    const res = await client.patch(`/spaces/${spaceId}`, data, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  addSpaceMember: async (spaceId: number, targetUserId: number, userId: number, role: string = 'member'): Promise<any> => {
    const res = await client.post(`/spaces/${spaceId}/members`, null, { params: { user_id: requireUserId(userId), target_user_id: targetUserId, role } });
    return res.data;
  },
  /** 공간 멤버 추가 모달용 통합 검색 — 사이트 users + Knox + member groups */
  getSpaceMemberCandidates: async (
    spaceId: number,
    query: string,
    userId: number
  ): Promise<MemberCandidate[]> => {
    const res = await client.get(`/spaces/${spaceId}/member-candidates`, {
      params: { q: query, user_id: requireUserId(userId) },
    });
    return res.data.items || [];
  },
  /** Knox 사용자를 공간 멤버로 추가 (필요 시 users 테이블 upsert) */
  addSpaceMemberFromKnox: async (
    spaceId: number,
    knoxUser: { loginid: string; name?: string; email?: string; deptname?: string; role?: string },
    userId: number
  ): Promise<{ message: string; user_id: number; skipped: boolean }> => {
    const res = await client.post(`/spaces/${spaceId}/members/knox`, knoxUser, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },
  /** MemberGroup 구성원을 공간 멤버로 일괄 추가 */
  addSpaceMembersFromGroup: async (
    spaceId: number,
    groupId: number,
    userId: number,
    role: string = 'member'
  ): Promise<SpaceGroupBulkAddResult> => {
    const res = await client.post(
      `/spaces/${spaceId}/members/groups`,
      { group_id: groupId, role },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },
  removeSpaceMember: async (spaceId: number, targetUserId: number, userId: number): Promise<any> => {
    const res = await client.delete(`/spaces/${spaceId}/members/${targetUserId}`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  updateSpaceMemberRole: async (spaceId: number, targetUserId: number, role: string, userId: number): Promise<any> => {
    const res = await client.patch(`/spaces/${spaceId}/members/${targetUserId}/role`, null, { params: { user_id: requireUserId(userId), role } });
    return res.data;
  },
  getSpaceBySlug: async (slug: string, userId?: number): Promise<any> => {
    const params: Record<string, any> = {};
    if (userId) params.user_id = userId;
    const res = await client.get(`/spaces/by-slug/${encodeURIComponent(slug)}`, { params });
    return res.data;
  },
  requestJoinSpace: async (spaceId: number, userId: number, message?: string): Promise<any> => {
    const res = await client.post(`/spaces/${spaceId}/join-request`, null, { params: { user_id: requireUserId(userId), message } });
    return res.data;
  },
  getSpaceJoinRequests: async (spaceId: number, userId: number): Promise<any[]> => {
    const res = await client.get(`/spaces/${spaceId}/join-requests-safe`, { params: { user_id: requireUserId(userId) } });
    return res.data.requests || [];
  },
  approveSpaceJoinRequest: async (spaceId: number, requestId: number, action: string, userId: number): Promise<any> => {
    const res = await client.post(`/spaces/${spaceId}/join-requests/${requestId}/approve`, null, { params: { user_id: requireUserId(userId), action } });
    return res.data;
  },

  // ========================================
  // v3.0 공간 목적 + Overview
  // ========================================
  getSpaceOverview: async (spaceId: number, userId: number): Promise<any> => {
    const res = await client.get(`/spaces/${spaceId}/overview`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  // ========================================
  // v3.0 Sheet Templates
  // ========================================
  inspectSheetFile: async (file: File): Promise<{ multi: boolean; sheet_names: string[]; suggested: string | null; suggested_type?: 'inspection' | 'assignment_mapping' }> => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await client.post('/sheet-templates/inspect', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
    return res.data;
  },
  uploadSheetTemplate: async (file: File, spaceId: number, userId: number, opts?: { name?: string; description?: string; category?: string; sheet_name?: string; sheet_type?: string }): Promise<any> => {
    const formData = new FormData();
    formData.append('file', file);
    const params: Record<string, any> = { space_id: spaceId, user_id: requireUserId(userId) };
    if (opts?.name) params.name = opts.name;
    if (opts?.description) params.description = opts.description;
    if (opts?.category) params.category = opts.category;
    if (opts?.sheet_name) params.sheet_name = opts.sheet_name;
    if (opts?.sheet_type) params.sheet_type = opts.sheet_type;
    const res = await client.post('/sheet-templates/upload', formData, { params, headers: { 'Content-Type': 'multipart/form-data' } });
    return res.data;
  },
  getSheetTemplates: async (spaceId: number, category?: string): Promise<any> => {
    const params: Record<string, any> = { space_id: spaceId };
    if (category) params.category = category;
    const res = await client.get('/sheet-templates', { params });
    return res.data;
  },
  getSheetTemplate: async (templateId: number): Promise<any> => {
    const res = await client.get(`/sheet-templates/${templateId}`);
    return res.data;
  },
  deleteSheetTemplate: async (templateId: number, userId: number): Promise<any> => {
    const res = await client.delete(`/sheet-templates/${templateId}`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  // ========================================
  // v3.0 Sheet Executions
  // ========================================
  createSheetExecution: async (body: { template_id: number; project_id?: number; task_id?: number; title?: string; equipment_name?: string }, spaceId: number, userId: number): Promise<any> => {
    const res = await client.post('/sheet-executions', body, { params: { space_id: spaceId, user_id: requireUserId(userId) } });
    return res.data;
  },
  getSheetExecutions: async (spaceId: number, filters?: { project_id?: number; task_id?: number; template_id?: number; status?: string; user_id?: number; equipment_name?: string; date_from?: string; date_to?: string }): Promise<any> => {
    const params: Record<string, any> = { space_id: spaceId, ...filters };
    const res = await client.get('/sheet-executions', { params });
    return res.data;
  },
  getSheetExecution: async (executionId: number): Promise<any> => {
    const res = await client.get(`/sheet-executions/${executionId}`);
    return res.data;
  },
  updateSheetExecutionItem: async (executionId: number, itemId: number, body: { checked?: boolean; value?: string; memo?: string }, userId: number): Promise<any> => {
    const res = await client.patch(`/sheet-executions/${executionId}/items/${itemId}`, body, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  upsertSheetExecutionCell: async (executionId: number, cellRef: string, body: { checked?: boolean; value?: string; memo?: string }, userId: number): Promise<any> => {
    const res = await client.patch(`/sheet-executions/${executionId}/cells/${cellRef}`, body, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  updateSheetHiddenCols: async (executionId: number, hiddenCols: number[], userId: number): Promise<{ hidden_cols: number[] }> => {
    const res = await client.patch(
      `/sheet-executions/${executionId}/hidden-cols`,
      { hidden_cols: hiddenCols },
      { params: { user_id: requireUserId(userId) } },
    );
    return res.data;
  },
  updateSheetHiddenRows: async (executionId: number, hiddenRows: number[], userId: number): Promise<{ hidden_rows: number[] }> => {
    const res = await client.patch(
      `/sheet-executions/${executionId}/hidden-rows`,
      { hidden_rows: hiddenRows },
      { params: { user_id: requireUserId(userId) } },
    );
    return res.data;
  },
  updateSheetStructureOverlay: async (
    executionId: number,
    overlay: {
      added_columns: { col_idx: number; header: string; kind?: 'equipment' | 'plain' }[];
      added_rows: { row_idx: number }[];
      renamed_headers: Record<string, string>;
      added_columns_order?: number[];
      added_rows_order?: number[];
      column_order?: number[];
      row_order?: number[];
    },
    userId: number,
  ): Promise<{ structure_overlay: typeof overlay }> => {
    const res = await client.patch(
      `/sheet-executions/${executionId}/structure-overlay`,
      overlay,
      { params: { user_id: requireUserId(userId) } },
    );
    return res.data;
  },
  copySheetExecution: async (executionId: number, title: string, includeData: boolean, userId: number): Promise<any> => {
    const res = await client.post(`/sheet-executions/${executionId}/copy`, null, { params: { title, include_data: includeData, user_id: requireUserId(userId) } });
    return res.data;
  },
  completeSheetExecution: async (executionId: number, userId: number): Promise<any> => {
    const res = await client.patch(`/sheet-executions/${executionId}/complete`, null, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  unlinkSheetExecutionTask: async (executionId: number, userId: number): Promise<any> => {
    const res = await client.patch(`/sheet-executions/${executionId}/unlink-task`, null, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  /** v3.9: unlinked / cancelled / completed / (task 미연결)in_progress 시트 영구 삭제. */
  deleteSheetExecution: async (executionId: number, userId: number): Promise<any> => {
    const res = await client.delete(`/sheet-executions/${executionId}`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  /** v3.10: 시트의 모든 미진행 항목을 일괄 진행 처리. keep_na=true 면 N/A 항목은 건너뜀. */
  markAllSheetProgress: async (executionId: number, keepNa: boolean, userId: number): Promise<any> => {
    const res = await client.post(
      `/sheet-executions/${executionId}/mark-all-progress`,
      { keep_na: keepNa },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },
  /** 현재 웹에서 수정한 최신 상태를 xlsx로 받아옴. 브라우저 다운로드 트리거. */
  downloadSheetExecutionXlsx: async (executionId: number, suggestedName?: string): Promise<void> => {
    const res = await client.get(`/sheet-executions/${executionId}/export`, { responseType: 'blob' });
    const url = URL.createObjectURL(res.data);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(suggestedName || 'sheet')}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },
  getSheetExecutionLogs: async (executionId: number): Promise<any> => {
    const res = await client.get(`/sheet-executions/${executionId}/logs`);
    return res.data;
  },
  getProjectSheetSummary: async (projectId: number): Promise<any> => {
    const res = await client.get(`/projects/${projectId}/sheet-summary`);
    return res.data;
  },
  getTaskSheetSummary: async (taskId: number): Promise<any> => {
    const res = await client.get(`/tasks/${taskId}/sheet-summary`);
    return res.data;
  },

  // ========================================
  // v3.1 Sheet Column Roles
  // ========================================
  confirmSheetRoles: async (templateId: number, roles: any, userId: number): Promise<any> => {
    const res = await client.post(`/sheet-templates/${templateId}/confirm-roles`, roles, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },

  // ========================================
  // v3.2 Sheet Execution Mappings (assignment_mapping type)
  // ========================================
  listSheetMappings: async (executionId: number): Promise<any[]> => {
    const res = await client.get(`/sheet-executions/${executionId}/mappings`);
    return res.data.mappings || [];
  },
  addSheetMapping: async (
    executionId: number,
    body: { master_name: string; assigned_entity: string },
    userId: number
  ): Promise<any> => {
    const res = await client.post(`/sheet-executions/${executionId}/mappings`, body, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  updateSheetMapping: async (
    executionId: number,
    mappingId: number,
    body: { master_name?: string; assigned_entity?: string; manager?: string; note?: string },
    userId: number
  ): Promise<any> => {
    const res = await client.patch(`/sheet-executions/${executionId}/mappings/${mappingId}`, body, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  deleteSheetMapping: async (executionId: number, mappingId: number, userId: number): Promise<void> => {
    await client.delete(`/sheet-executions/${executionId}/mappings/${mappingId}`, { params: { user_id: requireUserId(userId) } });
  },

  // =========================
  // VOC / 개선 요청 (전역 피드백)
  // =========================
  createVoc: async (
    payload: { title: string; category: string; content: string; related_screen?: string | null; priority?: string; visibility?: string },
    userId: number
  ): Promise<any> => {
    const res = await client.post('/voc', payload, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  listVoc: async (
    userId: number,
    opts?: {
      scope?: 'mine' | 'all';
      status?: string;
      category?: string;
      search?: string;
      page?: number;
      page_size?: number;
    }
  ): Promise<{ items: any[]; is_admin: boolean; pagination: PaginationMeta }> => {
    const params: Record<string, any> = { user_id: requireUserId(userId) };
    if (opts?.scope) params.scope = opts.scope;
    if (opts?.status) params.status = opts.status;
    if (opts?.category) params.category = opts.category;
    if (opts?.search) params.search = opts.search;
    if (opts?.page) params.page = opts.page;
    if (opts?.page_size) params.page_size = opts.page_size;
    const res = await client.get('/voc', { params });
    return res.data;
  },
  getVoc: async (vocId: number, userId: number): Promise<any> => {
    const res = await client.get(`/voc/${vocId}`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  updateVoc: async (
    vocId: number,
    body: {
      title?: string;
      category?: string;
      content?: string;
      related_screen?: string | null;
      status?: string;
      priority?: string;
      admin_note?: string;
      /** 관리자 메모 저장 시 작성자에게 메일 알림 발송 여부(기본 false). admin_note 변경 시에만 의미. */
      send_mail?: boolean;
      visibility?: string;
      remove_attachment_ids?: number[];
    },
    userId: number
  ): Promise<any> => {
    const res = await client.patch(`/voc/${vocId}`, body, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  deleteVoc: async (vocId: number, userId: number): Promise<void> => {
    await client.delete(`/voc/${vocId}`, { params: { user_id: requireUserId(userId) } });
  },
  addVocVote: async (
    vocId: number,
    userId: number
  ): Promise<{ voc_id: number; vote_count: number; voted_by_me: boolean }> => {
    const res = await client.post(`/voc/${vocId}/vote`, null, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  removeVocVote: async (
    vocId: number,
    userId: number
  ): Promise<{ voc_id: number; vote_count: number; voted_by_me: boolean }> => {
    const res = await client.delete(`/voc/${vocId}/vote`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  getVocStats: async (userId: number): Promise<any> => {
    const res = await client.get('/voc/stats', { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  listVocAttachments: async (vocId: number, userId: number): Promise<{ attachments: any[] }> => {
    const res = await client.get(`/voc/${vocId}/attachments`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  uploadVocAttachment: async (vocId: number, file: File, userId: number): Promise<any> => {
    const form = new FormData();
    form.append('file', file);
    const res = await client.post(`/voc/${vocId}/attachments`, form, {
      params: { user_id: requireUserId(userId) },
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },
  /** VOC 댓글/추가 문의에 붙이는 이미지 업로드 (본문 첨부와 분리: comment_scoped=True). */
  uploadVocCommentImage: async (vocId: number, file: File, userId: number): Promise<any> => {
    const form = new FormData();
    form.append('file', file);
    const res = await client.post(`/voc/${vocId}/comment-images`, form, {
      params: { user_id: requireUserId(userId) },
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return res.data;
  },
  deleteVocAttachment: async (vocId: number, attachmentId: number, userId: number): Promise<void> => {
    await client.delete(`/voc/${vocId}/attachments/${attachmentId}`, {
      params: { user_id: requireUserId(userId) },
    });
  },

  // ── VOC 댓글 / 추가 문의 ──
  listVocComments: async (
    vocId: number,
    userId: number
  ): Promise<{ items: VocComment[]; can_comment: boolean; is_admin: boolean }> => {
    const res = await client.get(`/voc/${vocId}/comments`, { params: { user_id: requireUserId(userId) } });
    return res.data;
  },
  createVocComment: async (
    vocId: number,
    content: string,
    userId: number,
  ): Promise<VocComment> => {
    // 추가 문의/댓글 저장은 메일 알림을 발생시키지 않는다(작성자→관리자 메일 발송 경로 제거).
    const res = await client.post(
      `/voc/${vocId}/comments`,
      { content },
      { params: { user_id: requireUserId(userId) } }
    );
    return res.data;
  },
  deleteVocComment: async (vocId: number, commentId: number, userId: number): Promise<void> => {
    await client.delete(`/voc/${vocId}/comments/${commentId}`, {
      params: { user_id: requireUserId(userId) },
    });
  },

  // =========================
  // 사내 추천 도구 스트립 (Internal Service Recommendations)
  // 모든 호출은 실패해도 Dashboard 가 깨지지 않도록 호출부에서 방어한다.
  // =========================
  getInternalRecommendations: async (
    placement: RecommendationPlacement,
    userId?: number,
  ): Promise<InternalRecommendationsResponse> => {
    const res = await client.get('/internal-recommendations', {
      params: { placement, user_id: resolveUserId(userId) },
    });
    return res.data;
  },
  dismissInternalRecommendation: async (
    itemId: number,
    mode: 'today' | 'later',
    userId?: number,
  ): Promise<void> => {
    await client.post(`/internal-recommendations/${itemId}/dismiss`, null, {
      params: { user_id: requireUserId(userId), mode },
    });
  },
  logInternalRecommendationEvent: async (
    itemId: number,
    type: 'impression' | 'click' | 'dismiss',
    userId?: number,
  ): Promise<void> => {
    await client.post('/internal-recommendations/events', {
      item_id: itemId,
      user_id: resolveUserId(userId) ?? null,
      type,
    });
  },
  // ── 관리자 ──
  adminGetInternalRecommendations: async (
    userId: number,
  ): Promise<{ enabled: boolean; recommendations: (InternalRecommendation & { active: boolean })[] }> => {
    const res = await client.get('/admin/internal-recommendations', {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },
  adminSetInternalRecommendationFlag: async (
    enabled: boolean,
    userId: number,
  ): Promise<{ enabled: boolean }> => {
    const res = await client.put('/admin/internal-recommendations/flag', { enabled }, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },
  adminUpdateInternalRecommendation: async (
    itemId: number,
    updates: Partial<InternalRecommendation & { active: boolean }>,
    userId: number,
  ): Promise<any> => {
    const res = await client.patch(`/admin/internal-recommendations/${itemId}`, updates, {
      params: { user_id: requireUserId(userId) },
    });
    return res.data;
  },
};

export { client, API_URL };
export type { User, Project };
