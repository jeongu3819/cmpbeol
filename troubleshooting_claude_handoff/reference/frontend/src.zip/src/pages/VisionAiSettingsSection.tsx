// src/pages/VisionAiSettingsSection.tsx
// AI Settings 페이지 안의 "Vision AI 설정" 섹션 — Text AI 설정과 완전 분리.
// 이미지 포함 AI Report(Vision Report) 전용. 여기서 모델을 바꿔도 Text AI(종합보고서/자유질문)에는
// 영향이 없고, Text AI를 바꿔도 Vision AI는 바뀌지 않는다. super_admin 전용 페이지 내부 섹션.
import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Paper,
  Alert,
  CircularProgress,
  Select,
  MenuItem,
  FormControl,
  Switch,
  FormControlLabel,
  Chip,
} from '@mui/material';
import ImageSearchIcon from '@mui/icons-material/ImageSearch';
import SaveIcon from '@mui/icons-material/Save';
import ScienceIcon from '@mui/icons-material/Science';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, VisionAiTestResult, VisionModelCapability, VisionSupport } from '../api/client';
import ProjectImageVisionTestDialog from '../components/ProjectImageVisionTestDialog';

interface Props {
  userId: number;
}

// capability → 칩 색/라벨
const capabilityChip = (cap?: VisionSupport) => {
  if (cap === true) return { label: 'vision 지원', bg: '#DCFCE7', color: '#15803D' };
  if (cap === 'candidate') return { label: 'vision 후보 / 사내 모델', bg: '#F3E8FF', color: '#7C3AED' };
  if (cap === false) return { label: 'vision 미지원', bg: '#FEE2E2', color: '#B91C1C' };
  return { label: 'vision 미상', bg: '#FEF3C7', color: '#B45309' };
};

const VisionAiSettingsSection: React.FC<Props> = ({ userId }) => {
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: ['vision-ai-settings', userId],
    queryFn: () => api.getVisionAiSettings(userId),
    enabled: userId > 0,
  });

  const [provider, setProvider] = useState('openai');
  const [modelName, setModelName] = useState('');
  const [enabled, setEnabled] = useState(true);
  const [maxTokens, setMaxTokens] = useState<number>(8000);
  const [batchSize, setBatchSize] = useState<number>(6);
  const [timeoutSeconds, setTimeoutSeconds] = useState<number>(120);
  // ── Fallback Text Model (Gemma4 지연/실패 시 텍스트 전용 보고서) — Primary 와 별개 ──
  const [fallbackEnabled, setFallbackEnabled] = useState(true);
  const [fallbackProvider, setFallbackProvider] = useState('dsllm');
  const [fallbackModel, setFallbackModel] = useState('');
  const [softTimeout, setSoftTimeout] = useState<number>(45);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<VisionAiTestResult | null>(null);
  // "vision 입력 테스트" 버튼은 이제 실제 프로젝트 이미지 진단 Modal 을 연다(내장 빨강 테스트는 Modal 내 탭).
  const [visionDialogOpen, setVisionDialogOpen] = useState(false);

  // 서버 effective config 로 폼 초기화
  useEffect(() => {
    if (!settings) return;
    setProvider(settings.provider || 'openai');
    setModelName(settings.model || '');
    setEnabled(settings.enabled);
    setMaxTokens(settings.max_output_tokens);
    setBatchSize(settings.batch_size);
    setTimeoutSeconds(settings.timeout_seconds);
    setFallbackEnabled(settings.fallback_text_enabled ?? true);
    setFallbackProvider(settings.fallback_text_provider || 'dsllm');
    setFallbackModel(settings.fallback_text_model || '');
    setSoftTimeout(settings.soft_timeout_seconds ?? 60);
  }, [settings]);

  const saveMutation = useMutation({
    mutationFn: () =>
      api.saveVisionAiSettings(
        {
          provider,
          model_name: modelName,
          enabled,
          max_output_tokens: maxTokens,
          batch_size: batchSize,
          timeout_seconds: timeoutSeconds,
          fallback_text_enabled: fallbackEnabled,
          fallback_text_provider: fallbackProvider,
          fallback_text_model: fallbackModel,
          soft_timeout_seconds: softTimeout,
        },
        userId
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vision-ai-settings'] });
      // Vision Report Test 패널의 meta(기본 모델)도 갱신되도록 무효화.
      queryClient.invalidateQueries({ queryKey: ['vision-report-test-meta'] });
      setSaveError(null);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
    onError: (err: any) => {
      // 백엔드 provider/model 조합 검증 실패(400) 등을 그대로 노출.
      setSaveError(err?.response?.data?.detail || 'Vision AI 설정 저장에 실패했습니다.');
    },
  });

  // ── Fallback Text Model 목록 — 기존 Text AI 모델 목록 소스(/settings/ai/models) 재사용(하드코딩 금지) ──
  const {
    data: fallbackModelsData,
    isLoading: fbModelsLoading,
    isError: fbModelsError,
  } = useQuery({
    queryKey: ['ai-models', 'fallback', fallbackProvider, userId],
    queryFn: () => api.getAiModels(userId, fallbackProvider),
    enabled: userId > 0 && fallbackEnabled,
  });
  const fallbackModelOptions: string[] = fallbackModelsData?.models || [];
  // 저장된 모델이 현재 provider 목록에 없으면 "사용 불가" 상태(가짜 옵션으로 추가하지 않음).
  const fallbackModelInvalid =
    !!fallbackModel && !fbModelsLoading && !fbModelsError &&
    fallbackModelOptions.length > 0 && !fallbackModelOptions.includes(fallbackModel);

  const handleFallbackProviderChange = (next: string) => {
    setFallbackProvider(next);
    setFallbackModel(''); // Provider 변경 시 잘못된 모델 선택 제거 → 사용자가 다시 선택
    setSaveError(null);
  };

  const testConnMutation = useMutation({
    mutationFn: () => api.testVisionAiConnection({ provider, model_name: modelName }, userId),
    onSuccess: res => setTestResult(res),
    onError: () =>
      setTestResult({ ok: false, model: modelName, error: '연결 실패: 요청 중 오류가 발생했습니다.' }),
  });


  if (isLoading) {
    return (
      <Box sx={{ textAlign: 'center', py: 3 }}>
        <CircularProgress size={24} />
      </Box>
    );
  }

  const apiKeyConfigured = settings?.api_key_configured;
  const providerOptions = settings?.providers || [];
  const activeProvider = providerOptions.find(p => p.key === provider);
  // provider 별 모델 목록/capability (없으면 서버 effective 값으로 fallback).
  const capabilities: VisionModelCapability[] =
    activeProvider?.model_capabilities || settings?.model_capabilities || [];
  const selectedCapMeta = capabilities.find(c => c.key === modelName);
  const selectedCap = selectedCapMeta?.vision_supported ?? null;
  const isDsllm = provider === 'dsllm';
  // dsllm(사내)은 OpenAI key 불필요. openai 만 key 필요.
  const disabledActions = !modelName || (!isDsllm && !apiKeyConfigured);

  const handleProviderChange = (next: string) => {
    setProvider(next);
    const block = providerOptions.find(p => p.key === next);
    setModelName(block?.default_model || '');
    setTestResult(null);
  };

  return (
    <Paper sx={{ p: 3, borderRadius: 3, border: '1px solid #E5E7EB', mt: 2.5 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
        <ImageSearchIcon sx={{ color: '#8B5CF6' }} />
        <Typography variant="h6" sx={{ fontWeight: 800, color: '#1A1D29', fontSize: '1rem' }}>
          Vision AI 설정
        </Typography>
      </Box>
      <Typography variant="body2" sx={{ color: '#6B7280', fontSize: '0.8rem', mb: 2 }}>
        이미지 포함 AI Report(Vision Report) 전용 설정입니다. Text AI 설정과 분리되어 있어 한쪽을 바꿔도
        다른 쪽에 영향이 없습니다.
      </Typography>

      {saved && (
        <Alert severity="success" sx={{ mb: 2, borderRadius: 2 }}>
          Vision AI 설정이 저장되었습니다.
        </Alert>
      )}
      {saveError && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }} onClose={() => setSaveError(null)}>
          {saveError}
        </Alert>
      )}

      {/* fallback 경고 (Vision 전용 설정 없음 → Text 모델 fallback) */}
      {settings?.using_text_fallback && (
        <Alert severity="warning" icon={<WarningAmberIcon fontSize="inherit" />} sx={{ mb: 2, borderRadius: 2, fontSize: '0.8rem' }}>
          {settings.fallback_reason ||
            'Vision 전용 모델 설정이 없어 Text AI 모델을 fallback으로 사용 중입니다. 이미지 인식이 실패할 수 있습니다.'}{' '}
          backend env에 <code>VISION_AI_MODEL</code> / <code>VISION_AI_MODELS</code>를 설정하면 경고가 사라집니다.
        </Alert>
      )}

      {!isDsllm && !apiKeyConfigured && (
        <Alert severity="info" sx={{ mb: 2, borderRadius: 2, fontSize: '0.8rem' }}>
          OpenAI API Key가 설정되어 있지 않습니다. backend env(OPENAI_API_KEY)를 설정한 뒤 사용하세요.
        </Alert>
      )}

      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
        {/* Provider (OpenAI 외부 / DSLLM 사내) */}
        <Box>
          <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.5, color: '#374151', fontSize: '0.85rem' }}>
            Provider
          </Typography>
          {providerOptions.length > 0 ? (
            <FormControl fullWidth size="small">
              <Select
                value={provider}
                onChange={e => handleProviderChange(e.target.value as string)}
                sx={{ borderRadius: 2, fontSize: '0.85rem' }}
              >
                {providerOptions.map(p => (
                  <MenuItem key={p.key} value={p.key} disabled={!p.available} sx={{ fontSize: '0.85rem' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography sx={{ fontWeight: 600, fontSize: '0.85rem' }}>{p.label}</Typography>
                      {!p.available && (
                        <Chip size="small" label="설정 필요" sx={{ height: 18, fontSize: '0.6rem', bgcolor: '#FEF3C7', color: '#B45309' }} />
                      )}
                    </Box>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          ) : (
            <Chip label={(settings?.provider || 'openai').toUpperCase()} sx={{ bgcolor: '#F3E8FF', color: '#8B5CF6', fontWeight: 700 }} />
          )}
          <Typography variant="caption" sx={{ color: '#9CA3AF', mt: 0.5, display: 'block' }}>
            {isDsllm
              ? 'DSLLM / 사내 모델 — DS/Gemma4는 Vision 후보입니다(사내 Gemma4 vision adapter 구현 후 사용 가능).'
              : 'OpenAI / 외부 vision 모델. 회사 내부 민감정보는 외부 API로 전송하지 마세요.'}
          </Typography>
        </Box>

        {/* Model (vision 후보만 노출) */}
        <Box>
          <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.5, color: '#374151', fontSize: '0.85rem' }}>
            Model
          </Typography>
          {capabilities.length > 0 ? (
            <FormControl fullWidth size="small">
              <Select
                value={capabilities.some(c => c.key === modelName) ? modelName : (activeProvider?.default_model || settings?.model || '')}
                onChange={e => {
                  setModelName(e.target.value as string);
                  setTestResult(null);
                }}
                sx={{ borderRadius: 2, fontSize: '0.85rem' }}
              >
                {capabilities.map(c => {
                  const chip = capabilityChip(c.vision_supported);
                  return (
                    <MenuItem key={c.key} value={c.key} sx={{ fontSize: '0.85rem' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography sx={{ fontWeight: 600, fontSize: '0.85rem' }}>{c.key}</Typography>
                        <Chip size="small" label={chip.label} sx={{ height: 18, fontSize: '0.6rem', bgcolor: chip.bg, color: chip.color }} />
                      </Box>
                    </MenuItem>
                  );
                })}
              </Select>
            </FormControl>
          ) : (
            <TextField
              fullWidth
              size="small"
              placeholder="gpt-5.4-mini, gpt-5.4, gpt-5.5"
              value={modelName}
              onChange={e => setModelName(e.target.value)}
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2, fontSize: '0.85rem' } }}
            />
          )}
          {/* 선택 모델 capability 경고/안내 */}
          {selectedCap === 'candidate' && (
            <Alert severity="info" icon={<ScienceIcon fontSize="inherit" />} sx={{ mt: 1, borderRadius: 2, fontSize: '0.78rem' }}>
              {selectedCapMeta?.note ||
                'DS/Gemma4는 사내 Vision 모델입니다. chat/completions 멀티모달(image_url) 입력으로 이미지 포함 AI Report에 사용할 수 있습니다.'}{' '}
              게이트웨이 버전에 따라 멀티모달 지원이 다를 수 있으니, 저장 전에 'vision 입력 테스트'로 이미지 인식이 되는지 먼저 확인하세요.
            </Alert>
          )}
          {selectedCap === false && (
            <Alert severity="error" sx={{ mt: 1, borderRadius: 2, fontSize: '0.78rem' }}>
              선택한 모델 <b>{modelName}</b>은 vision(이미지) 입력을 지원하지 않습니다. 이미지 포함 보고서가 실패할 수
              있습니다.
            </Alert>
          )}
          {selectedCap === null && modelName && (
            <Alert severity="warning" sx={{ mt: 1, borderRadius: 2, fontSize: '0.78rem' }}>
              선택한 모델 <b>{modelName}</b>의 vision 지원 여부를 확인할 수 없습니다. 저장 전에 'vision 입력 테스트'로
              확인하세요.
            </Alert>
          )}
        </Box>

        {/* enabled */}
        <FormControlLabel
          control={<Switch checked={enabled} onChange={e => setEnabled(e.target.checked)} />}
          label={
            <Typography sx={{ fontSize: '0.85rem', color: '#374151' }}>
              Vision Report 활성화 {enabled ? '' : '(비활성 시 이미지 포함 보고서 생성 차단)'}
            </Typography>
          }
        />

        {/* 숫자 파라미터 */}
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <TextField
            size="small"
            type="number"
            label="max output tokens"
            value={maxTokens}
            onChange={e => setMaxTokens(Math.max(1, parseInt(e.target.value, 10) || 0))}
            sx={{ width: 180 }}
          />
          <TextField
            size="small"
            type="number"
            label="batch size"
            value={batchSize}
            onChange={e => setBatchSize(Math.max(1, parseInt(e.target.value, 10) || 0))}
            sx={{ width: 140 }}
          />
          <TextField
            size="small"
            type="number"
            label="timeout seconds (hard)"
            value={timeoutSeconds}
            onChange={e => setTimeoutSeconds(Math.max(1, parseInt(e.target.value, 10) || 0))}
            sx={{ width: 180 }}
          />
        </Box>

        {/* ── Fallback Text Model (Gemma4 지연/실패 시 텍스트 전용 보고서) ── */}
        <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, borderColor: '#E9D5FF', bgcolor: '#FAF5FF' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
            <Typography sx={{ fontWeight: 700, fontSize: '0.85rem', color: '#6D28D9' }}>
              Fallback Text Model (지연 시 텍스트 전용)
            </Typography>
            <Chip size="small" label="일회성 실행 · 저장값 미변경" sx={{ height: 18, fontSize: '0.6rem', bgcolor: '#EDE9FE', color: '#6D28D9' }} />
          </Box>
          <Typography sx={{ fontSize: '0.75rem', color: '#6B7280', mb: 1.5 }}>
            Primary Vision Model(<b>{modelName || '미설정'}</b>)이 이미지 분석에 오래 걸리면, 사용자가 이 Text 모델로
            텍스트 전용 보고서를 빠르게 생성하도록 선택지를 제공합니다. 자동 전환은 하지 않으며, 선택해도 이 설정은 바뀌지 않습니다.
          </Typography>
          <FormControlLabel
            control={<Switch checked={fallbackEnabled} onChange={e => setFallbackEnabled(e.target.checked)} />}
            label={
              <Typography sx={{ fontSize: '0.82rem', color: '#374151' }}>
                Fallback 사용 {fallbackEnabled ? '' : '(비활성 시 지연되어도 선택지 미표시)'}
              </Typography>
            }
          />
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mt: 1, alignItems: 'flex-start' }}>
            <FormControl size="small" sx={{ minWidth: 150 }} disabled={!fallbackEnabled}>
              <Select value={fallbackProvider} onChange={e => handleFallbackProviderChange(e.target.value as string)}>
                <MenuItem value="dsllm">DSLLM / 사내</MenuItem>
                <MenuItem value="openai" disabled={!apiKeyConfigured}>
                  OpenAI / 외부{!apiKeyConfigured ? ' (API Key 필요)' : ''}
                </MenuItem>
              </Select>
            </FormControl>
            {/* Fallback Text Model — Provider 별 Text 모델 목록에서 선택(자유 입력 제거) */}
            <FormControl size="small" sx={{ flex: 1, minWidth: 240 }} disabled={!fallbackEnabled}>
              <Select
                displayEmpty
                value={fallbackModelOptions.includes(fallbackModel) ? fallbackModel : ''}
                onChange={e => { setFallbackModel(e.target.value as string); setSaveError(null); }}
                renderValue={(val) =>
                  val ? <span>{val as string}</span>
                      : <Typography sx={{ color: '#9CA3AF', fontSize: '0.85rem' }}>Fallback Text 모델을 선택하세요</Typography>
                }
              >
                {fbModelsLoading && <MenuItem disabled value=""><em>모델 목록을 불러오는 중...</em></MenuItem>}
                {fbModelsError && <MenuItem disabled value=""><em>모델 목록을 불러오지 못했습니다.</em></MenuItem>}
                {!fbModelsLoading && !fbModelsError && fallbackModelOptions.length === 0 && (
                  <MenuItem disabled value=""><em>사용 가능한 Text 모델이 없습니다.</em></MenuItem>
                )}
                {fallbackModelOptions.map(m => (
                  <MenuItem key={m} value={m} sx={{ fontSize: '0.85rem' }}>{m}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              size="small"
              type="number"
              label="soft timeout(초)"
              value={softTimeout}
              onChange={e => setSoftTimeout(Math.max(1, parseInt(e.target.value, 10) || 0))}
              disabled={!fallbackEnabled}
              helperText="이 시간 초과 시 선택 modal"
              sx={{ width: 170 }}
            />
          </Box>
          {/* 저장된 모델이 현재 provider 목록에 없을 때 — 가짜 옵션 추가 없이 재선택 안내 */}
          {fallbackModelInvalid && (
            <Alert severity="warning" sx={{ mt: 1, borderRadius: 2, fontSize: '0.78rem' }}>
              현재 저장된 Fallback 모델 <b>{fallbackModel}</b>은(는) <b>{fallbackProvider === 'dsllm' ? 'DSLLM / 사내' : 'OpenAI / 외부'}</b>에서 사용할 수 없습니다. 목록에서 모델을 다시 선택하세요.
            </Alert>
          )}
          <Typography sx={{ fontSize: '0.72rem', color: '#9CA3AF', mt: 1 }}>
            Primary Vision Model = <b>{modelName || '미설정'}</b> (이미지 분석) · Fallback Text Model ={' '}
            <b>{fallbackModel || '미설정'}</b> (텍스트 전용). 둘 다 저장되지만 둘 다 메인이라는 뜻은 아닙니다.
          </Typography>
        </Paper>

        {/* 테스트 결과 */}
        {testResult && (
          <Alert severity={testResult.ok ? 'success' : 'error'} sx={{ borderRadius: 2, fontSize: '0.78rem' }}>
            {testResult.ok ? (
              <>연결 성공 ({testResult.model}){testResult.answer && <Box sx={{ mt: 0.5, color: '#374151' }}>응답: {testResult.answer}</Box>}</>
            ) : (
              <>{testResult.error || '연결 실패'}{testResult.stage && <Box sx={{ mt: 0.5, color: '#6B7280', fontSize: '0.72rem' }}>단계: {testResult.stage}{testResult.status_code != null && <> · status {testResult.status_code}</>}</Box>}</>
            )}
          </Alert>
        )}
        {/* 액션 */}
        <Box sx={{ display: 'flex', gap: 1.5, mt: 1, flexWrap: 'wrap' }}>
          <Button
            variant="contained"
            startIcon={saveMutation.isPending ? <CircularProgress size={16} color="inherit" /> : <SaveIcon />}
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending || !modelName}
            sx={{ bgcolor: '#8B5CF6', textTransform: 'none', fontWeight: 700, borderRadius: 2, '&:hover': { bgcolor: '#7C3AED' } }}
          >
            {saveMutation.isPending ? 'Saving...' : 'Save Vision 설정'}
          </Button>
          <Button
            variant="outlined"
            startIcon={testConnMutation.isPending ? <CircularProgress size={16} /> : <ScienceIcon />}
            onClick={() => {
              setTestResult(null);
              testConnMutation.mutate();
            }}
            disabled={testConnMutation.isPending || disabledActions}
            sx={{ textTransform: 'none', fontWeight: 700, borderRadius: 2, borderColor: '#DDD6FE', color: '#7C3AED', '&:hover': { borderColor: '#8B5CF6', bgcolor: '#F5F3FF' } }}
          >
            {testConnMutation.isPending ? '테스트 중...' : '연결 테스트'}
          </Button>
          <Button
            variant="outlined"
            startIcon={<ImageSearchIcon />}
            onClick={() => setVisionDialogOpen(true)}
            disabled={disabledActions}
            sx={{ textTransform: 'none', fontWeight: 700, borderRadius: 2, borderColor: '#DDD6FE', color: '#7C3AED', '&:hover': { borderColor: '#8B5CF6', bgcolor: '#F5F3FF' } }}
          >
            vision 입력 테스트
          </Button>
        </Box>
      </Box>

      <ProjectImageVisionTestDialog
        open={visionDialogOpen}
        onClose={() => setVisionDialogOpen(false)}
        userId={userId}
        provider={provider}
        model={modelName}
      />
    </Paper>
  );
};

export default VisionAiSettingsSection;
