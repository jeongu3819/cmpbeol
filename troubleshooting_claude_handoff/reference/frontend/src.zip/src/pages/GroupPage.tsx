import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Button,
  Avatar,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Tooltip,
  CircularProgress,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import GroupIcon from '@mui/icons-material/Group';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, MemberGroup, MemberOption } from '../api/client';
import { useAppStore } from '../stores/useAppStore';
import MemberSearchSelect from '../components/MemberSearchSelect';

const GroupPage: React.FC = () => {
  const queryClient = useQueryClient();
  const currentUserId = useAppStore(s => s.currentUserId);

  const { data: groups = [], isLoading } = useQuery<MemberGroup[]>({
    queryKey: ['memberGroups', currentUserId],
    queryFn: () => api.getMemberGroups(currentUserId),
    enabled: currentUserId > 0,
  });

  // Dialog state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<MemberGroup | null>(null);
  const [groupName, setGroupName] = useState('');
  const [groupDescription, setGroupDescription] = useState('');
  // 선택된 멤버 — local(user_id)/knox 통합 object 배열 (숫자 id 노출 방지)
  const [selectedMembers, setSelectedMembers] = useState<MemberOption[]>([]);

  const openCreateDialog = () => {
    setEditingGroup(null);
    setGroupName('');
    setGroupDescription('');
    setSelectedMembers([]);
    setDialogOpen(true);
  };

  const openEditDialog = (g: MemberGroup) => {
    setEditingGroup(g);
    setGroupName(g.name);
    setGroupDescription(g.description || '');
    setSelectedMembers(
      g.members.map((m): MemberOption => ({
        source: 'local',
        user_id: m.user_id,
        login_id: m.loginid,
        knox_id: m.loginid,
        name: m.username,
        display_name: m.username,
        deptname: m.deptname || undefined,
        avatar_color: m.avatar_color,
      }))
    );
    setDialogOpen(true);
  };

  const createMut = useMutation({
    mutationFn: (data: Parameters<typeof api.createMemberGroup>[0]) =>
      api.createMemberGroup(data, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['memberGroups', currentUserId] });
      setDialogOpen(false);
    },
  });

  const updateMut = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Parameters<typeof api.updateMemberGroup>[1] }) =>
      api.updateMemberGroup(id, data, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['memberGroups', currentUserId] });
      setDialogOpen(false);
    },
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => api.deleteMemberGroup(id, currentUserId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['memberGroups'] }),
  });

  const handleSave = () => {
    const member_user_ids = selectedMembers
      .filter(m => m.source === 'local' && typeof m.user_id === 'number')
      .map(m => m.user_id as number);
    const knox_members = selectedMembers
      .filter(m => m.source === 'knox')
      .map(m => ({
        loginid: m.login_id,
        name: m.name,
        email: m.email || undefined,
        deptname: m.deptname || undefined,
      }));
    const data = {
      name: groupName.trim(),
      description: groupDescription.trim() || undefined,
      member_user_ids,
      knox_members: knox_members.length > 0 ? knox_members : undefined,
    };
    if (editingGroup) {
      updateMut.mutate({ id: editingGroup.id, data });
    } else {
      createMut.mutate(data);
    }
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ maxWidth: 900, mx: 'auto', py: 2 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <GroupIcon sx={{ color: '#2955FF', fontSize: '1.8rem' }} />
          <Typography variant="h5" sx={{ fontWeight: 700, color: '#1A1D29' }}>
            그룹 관리
          </Typography>
          <Chip
            label={`${groups.length}개`}
            size="small"
            sx={{ bgcolor: '#EEF2FF', color: '#2955FF', fontWeight: 700, fontSize: '0.75rem' }}
          />
        </Box>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={openCreateDialog}
          sx={{ bgcolor: '#2955FF', fontWeight: 600, '&:hover': { bgcolor: '#1E44CC' } }}
        >
          새 그룹
        </Button>
      </Box>

      <Typography variant="body2" sx={{ color: '#6B7280', mb: 3, fontSize: '0.85rem' }}>
        구성원들을 그룹으로 묶어서 프로젝트 생성이나 설정에서 한 번에 추가할 수 있습니다.
      </Typography>

      {/* Group Cards */}
      {groups.length === 0 ? (
        <Paper
          sx={{
            p: 6,
            textAlign: 'center',
            borderRadius: 3,
            border: '1px solid #E5E7EB',
            bgcolor: 'rgba(255,255,255,0.7)',
          }}
        >
          <GroupIcon sx={{ fontSize: '3rem', color: '#D1D5DB', mb: 1 }} />
          <Typography variant="body1" sx={{ color: '#9CA3AF', fontWeight: 500 }}>
            아직 생성된 그룹이 없습니다
          </Typography>
          <Typography variant="body2" sx={{ color: '#D1D5DB', mt: 0.5, mb: 2 }}>
            "새 그룹" 버튼을 눌러 그룹을 만들어보세요
          </Typography>
          <Button variant="outlined" startIcon={<AddIcon />} onClick={openCreateDialog} sx={{ color: '#2955FF', borderColor: '#2955FF' }}>
            그룹 만들기
          </Button>
        </Paper>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {groups.map(g => (
            <Paper
              key={g.id}
              sx={{
                p: 2.5,
                borderRadius: 3,
                border: '1px solid rgba(0,0,0,0.08)',
                bgcolor: 'rgba(255,255,255,0.7)',
                backdropFilter: 'blur(8px)',
                boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
                transition: 'all 0.15s',
                '&:hover': { boxShadow: '0 4px 20px rgba(0,0,0,0.08)' },
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                  <Avatar sx={{ bgcolor: '#2955FF', width: 36, height: 36, fontSize: '0.85rem', fontWeight: 700 }}>
                    {g.name.charAt(0).toUpperCase()}
                  </Avatar>
                  <Box>
                    <Typography variant="subtitle1" sx={{ fontWeight: 700, fontSize: '0.95rem', color: '#1A1D29' }}>
                      {g.name}
                    </Typography>
                    {g.description && (
                      <Typography variant="caption" sx={{ color: '#9CA3AF', fontSize: '0.75rem' }}>
                        {g.description}
                      </Typography>
                    )}
                  </Box>
                  <Chip
                    label={`${g.member_count}명`}
                    size="small"
                    sx={{ bgcolor: '#EEF2FF', color: '#2955FF', fontWeight: 700, fontSize: '0.7rem', height: 22 }}
                  />
                </Box>
                <Box sx={{ display: 'flex', gap: 0.5 }}>
                  <Tooltip title="편집">
                    <IconButton size="small" onClick={() => openEditDialog(g)} sx={{ color: '#6B7280' }}>
                      <EditIcon sx={{ fontSize: '1.1rem' }} />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="삭제">
                    <IconButton
                      size="small"
                      onClick={() => {
                        if (window.confirm(`"${g.name}" 그룹을 삭제하시겠습니까?`)) {
                          deleteMut.mutate(g.id);
                        }
                      }}
                      sx={{ color: '#EF4444' }}
                    >
                      <DeleteOutlineIcon sx={{ fontSize: '1.1rem' }} />
                    </IconButton>
                  </Tooltip>
                </Box>
              </Box>

              {/* Member avatars */}
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.8 }}>
                {g.members.map(m => (
                  <Tooltip key={m.user_id} title={`${m.username}${m.deptname ? ` (${m.deptname})` : ''}`}>
                    <Chip
                      avatar={
                        <Avatar sx={{ bgcolor: m.avatar_color || '#2955FF', width: 22, height: 22, fontSize: '0.6rem' }}>
                          {(m.username || '?').charAt(0).toUpperCase()}
                        </Avatar>
                      }
                      label={m.username}
                      size="small"
                      sx={{
                        height: 26,
                        fontSize: '0.75rem',
                        fontWeight: 500,
                        bgcolor: '#F9FAFB',
                        border: '1px solid #F3F4F6',
                      }}
                    />
                  </Tooltip>
                ))}
                {g.member_count === 0 && (
                  <Typography variant="caption" sx={{ color: '#D1D5DB', fontStyle: 'italic' }}>
                    멤버 없음
                  </Typography>
                )}
              </Box>
            </Paper>
          ))}
        </Box>
      )}

      {/* Create / Edit Dialog */}
      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <GroupIcon sx={{ color: '#2955FF', fontSize: '1.2rem' }} />
            {editingGroup ? '그룹 편집' : '새 그룹 만들기'}
          </Box>
        </DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            fullWidth
            label="그룹 이름 *"
            placeholder="예: 마케팅팀"
            value={groupName}
            onChange={e => setGroupName(e.target.value)}
            sx={{ mt: 1, mb: 2 }}
          />
          <TextField
            fullWidth
            label="설명 (선택)"
            placeholder="그룹에 대한 설명"
            value={groupDescription}
            onChange={e => setGroupDescription(e.target.value)}
            sx={{ mb: 2 }}
          />

          {/* Member selection — 공통 컴포넌트 (사이트 + Knox 통합, pagination) */}
          <MemberSearchSelect
            currentUserId={currentUserId}
            selected={selectedMembers}
            onChange={setSelectedMembers}
            label="그룹 멤버 선택"
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDialogOpen(false)} sx={{ color: '#6B7280' }}>
            취소
          </Button>
          <Button
            variant="contained"
            onClick={handleSave}
            disabled={!groupName.trim() || createMut.isPending || updateMut.isPending}
            sx={{ bgcolor: '#2955FF', '&:hover': { bgcolor: '#1E44CC' } }}
          >
            {createMut.isPending || updateMut.isPending ? '저장 중...' : editingGroup ? '저장' : '생성'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default GroupPage;
