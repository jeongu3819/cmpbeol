import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Paper,
  Alert,
  CircularProgress,
  Select,
  MenuItem,
  FormControl,
} from '@mui/material';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import SaveIcon from '@mui/icons-material/Save';
import BlockIcon from '@mui/icons-material/Block';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import ScienceIcon from '@mui/icons-material/Science';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, User, AiConnectionTestResult } from '../api/client';
import { useAppStore } from '../stores/useAppStore';
import { useNavigate } from 'react-router-dom';
import VisionAiSettingsSection from './VisionAiSettingsSection';

const AiSettingsPage: React.FC = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const currentUserId = useAppStore(state => state.currentUserId);
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['users'],
    queryFn: () => api.getUsers(),
  });
  const currentUser = users.find(u => u.id === currentUserId) || users[0];
  const isSuperAdmin = currentUser?.role === 'super_admin';

  const [provider, setProvider] = useState('dsllm');
  const [modelName, setModelName] = useState('');
  const [saved, setSaved] = useState(false);
  const [testResult, setTestResult] = useState<AiConnectionTestResult | null>(null);

  // 연결 상태(BASE URL/API KEY)는 "지금 드롭다운에서 보고 있는 provider" 기준으로 조회한다.
  //   → provider 를 바꾸면 상태 표시가 그 provider 에 맞게 갱신된다(표시 불일치 방지).
  const { data: settings, isLoading } = useQuery({
    queryKey: ['ai-settings', currentUserId, provider],
    queryFn: () => api.getAiSettings(currentUserId, provider),
    enabled: isSuperAdmin && currentUserId > 0,
  });

  // 모델 목록은 선택된 provider 기준으로 다시 조회한다.
  const { data: modelOptions } = useQuery({
    queryKey: ['ai-models', currentUserId, provider],
    queryFn: () => api.getAiModels(currentUserId, provider),
    staleTime: 5 * 60 * 1000,
    enabled: isSuperAdmin && currentUserId > 0,
  });

  // 서버에서 받은 "저장된" provider/model 로 최초 1회만 초기화한다.
  //   이후 refetch(provider 변경) 마다 덮어쓰면 사용자의 드롭다운 선택이 되돌아가므로 guard.
  const initializedRef = useRef(false);
  useEffect(() => {
    if (settings && !initializedRef.current) {
      initializedRef.current = true;
      setProvider(settings.provider || 'dsllm');
      setModelName(settings.model_name || '');
    }
  }, [settings]);

  // provider 변경/모델 목록 로드 시, 현재 model이 목록에 없으면 기본 모델로 보정
  useEffect(() => {
    if (!modelOptions) return;
    if (!modelOptions.models.includes(modelName) && modelOptions.default_model) {
      setModelName(modelOptions.default_model);
    }
  }, [modelOptions]); // eslint-disable-line react-hooks/exhaustive-deps

  const saveMutation = useMutation({
    mutationFn: () => api.saveAiSettings({ model_name: modelName, provider }, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ai-settings'] });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
  });

  const testMutation = useMutation({
    mutationFn: () => api.testAiConnection({ model_name: modelName, provider }, currentUserId),
    onSuccess: (res) => setTestResult(res),
    onError: () =>
      setTestResult({
        ok: false,
        provider,
        model: modelName,
        error: '연결 실패: 요청 중 오류가 발생했습니다.',
      }),
  });

  // Admin guard – block non-admin direct URL access
  if (currentUser && !isSuperAdmin) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <BlockIcon sx={{ fontSize: 48, color: '#EF4444', mb: 2 }} />
        <Typography variant="h6" sx={{ fontWeight: 700, mb: 1, color: '#1A1D29' }}>
          접근 권한이 없습니다
        </Typography>
        <Typography variant="body2" sx={{ color: '#6B7280', mb: 3 }}>
          AI Settings는 Super Admin만 접근할 수 있습니다.
        </Typography>
        <Button
          variant="contained"
          onClick={() => navigate('/')}
          sx={{
            textTransform: 'none',
            fontWeight: 600,
            borderRadius: 2,
            bgcolor: '#2955FF',
            '&:hover': { bgcolor: '#1E3FCC' },
          }}
        >
          Dashboard로 돌아가기
        </Button>
      </Box>
    );
  }

  if (isLoading) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <CircularProgress size={32} />
      </Box>
    );
  }

  const providers = settings?.available_providers || [
    { key: 'dsllm', label: 'DSLLM / 사내 모델', available: true },
  ];
  const isOpenAI = provider === 'openai';
  const apiKeyConfigured = settings?.api_key_configured;

  return (
    <Box sx={{ maxWidth: 600 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 3 }}>
        <AutoAwesomeIcon sx={{ color: '#2955FF', fontSize: '1.8rem' }} />
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 800, color: '#1A1D29' }}>
            AI Settings
          </Typography>
          <Typography variant="body2" sx={{ color: '#6B7280', fontSize: '0.8rem' }}>
            Text AI(종합보고서·자유질문)와 Vision AI(이미지 포함 보고서) 설정을 분리해서 관리합니다.
            접속 정보(API Key 등)는 환경변수에서만 관리됩니다.
          </Typography>
        </Box>
      </Box>

      {saved && (
        <Alert severity="success" sx={{ mb: 2, borderRadius: 2 }}>
          Settings saved successfully!
        </Alert>
      )}

      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
        <Typography variant="h6" sx={{ fontWeight: 800, color: '#1A1D29', fontSize: '1rem' }}>
          Text AI 설정
        </Typography>
        <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
          — 종합보고서 생성 · AI 자유질문
        </Typography>
      </Box>
      <Paper sx={{ p: 3, borderRadius: 3, border: '1px solid #E5E7EB' }}>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
          {/* ── 연결 정보 (환경변수) ── */}
          <Box
            sx={{
              p: 2,
              borderRadius: 2,
              bgcolor: '#F9FAFB',
              border: '1px solid #E5E7EB',
              display: 'flex',
              flexDirection: 'column',
              gap: 0.75,
            }}
          >
            <Typography sx={{ fontWeight: 700, fontSize: '0.8rem', color: '#374151' }}>
              연결 정보 (환경변수)
            </Typography>
            <Typography sx={{ fontSize: '0.78rem', color: '#6B7280' }}>
              ENV: <b>{settings?.env_mode || '-'}</b>
            </Typography>
            <Typography sx={{ fontSize: '0.78rem', color: '#6B7280' }}>
              Provider: <b style={{ color: '#1A1D29' }}>{isOpenAI ? 'OpenAI' : 'DSLLM'}</b>
            </Typography>
            <Typography sx={{ fontSize: '0.78rem', color: '#6B7280' }}>
              BASE URL:{' '}
              {settings?.base_url_configured
                ? <b style={{ color: '#1A1D29' }}>{settings.base_url_display || '설정됨'}</b>
                : <span style={{ color: '#EF4444' }}>미설정</span>}
            </Typography>
            <Typography sx={{ fontSize: '0.78rem', color: '#6B7280' }}>
              API KEY:{' '}
              {apiKeyConfigured
                ? <b style={{ color: '#10B981' }}>설정됨</b>
                : <span style={{ color: '#EF4444' }}>미설정</span>}
            </Typography>
            <Typography sx={{ fontSize: '0.72rem', color: '#9CA3AF', mt: 0.5 }}>
              {isOpenAI
                ? 'OpenAI API Key / BASE URL / MODEL은 backend의 .env.local 또는 .env.production에서만 관리됩니다. (화면 입력·저장 없음)'
                : 'BASE_URL / API_KEY는 .env.local 또는 .env.production에서만 관리됩니다.'}
            </Typography>

            {/* ── 자가진단(디버그) — backend 가 실제 읽은 env 파일 / 키 감지 여부 ── */}
            {settings?.debug && (
              <Box sx={{ mt: 0.5, pt: 0.75, borderTop: '1px dashed #E5E7EB' }}>
                <Typography sx={{ fontSize: '0.72rem', color: '#9CA3AF' }}>
                  읽은 env 파일:{' '}
                  <b style={{ color: settings.debug.env_file_exists ? '#374151' : '#EF4444' }}>
                    {settings.debug.env_file || '-'}
                  </b>{' '}
                  {settings.debug.env_file_exists ? '' : '(파일 없음 — OS 환경변수만 사용)'}
                </Typography>
                <Typography sx={{ fontSize: '0.72rem', color: '#9CA3AF' }}>
                  OPENAI_API_KEY 환경변수 감지:{' '}
                  {settings.debug.openai_key_in_env
                    ? <b style={{ color: '#10B981' }}>확인됨</b>
                    : <span style={{ color: '#EF4444' }}>미확인</span>}
                </Typography>
                {/* env 에는 키가 있는데 provider 로 잡히지 않는 불일치 힌트 */}
                {isOpenAI && settings.debug.openai_key_in_env && !apiKeyConfigured && (
                  <Typography sx={{ fontSize: '0.72rem', color: '#D97706', mt: 0.25 }}>
                    환경변수에는 OPENAI_API_KEY가 있는데 설정에 반영되지 않았습니다. backend 재시작 또는 변수명을 확인해주세요.
                  </Typography>
                )}
              </Box>
            )}
          </Box>

          {/* ── AI Provider 선택 ── */}
          <Box>
            <Typography
              variant="body2"
              sx={{ fontWeight: 600, mb: 0.5, color: '#374151', fontSize: '0.85rem' }}
            >
              AI Provider
            </Typography>
            <FormControl fullWidth size="small">
              <Select
                value={provider}
                onChange={e => {
                  setProvider(e.target.value as string);
                  setTestResult(null);
                }}
                sx={{ borderRadius: 2, fontSize: '0.85rem' }}
              >
                {providers.map(p => (
                  <MenuItem
                    key={p.key}
                    value={p.key}
                    disabled={!p.available}
                    sx={{ fontSize: '0.85rem' }}
                  >
                    {p.label}
                    {!p.available && (
                      <Typography component="span" sx={{ color: '#9CA3AF', fontSize: '0.72rem', ml: 1 }}>
                        (미설정 — env에 OPENAI_API_KEY 필요)
                      </Typography>
                    )}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Typography variant="caption" sx={{ color: '#9CA3AF', mt: 0.5, display: 'block' }}>
              운영/사내 환경 기본값은 DSLLM입니다. OpenAI는 외부 API 테스트용입니다.
            </Typography>
          </Box>

          {/* ── OpenAI 경고 / 상태 안내 ── */}
          {isOpenAI && (
            <>
              <Alert
                severity="warning"
                icon={<WarningAmberIcon fontSize="inherit" />}
                sx={{ borderRadius: 2, fontSize: '0.78rem', alignItems: 'flex-start' }}
              >
                {settings?.openai_warning ||
                  '외부 OpenAI API 사용 시 입력 데이터가 외부 서비스로 전송될 수 있습니다. 회사 내부 정보·설비명·공정 조건·사람 이름 등 민감한 데이터는 보내지 말고, 비식별 테스트 데이터에서만 사용하세요.'}
              </Alert>
              {!apiKeyConfigured && (
                <Alert severity="info" sx={{ borderRadius: 2, fontSize: '0.78rem' }}>
                  OpenAI API Key가 backend 환경변수에서 확인되지 않았습니다. 현재 backend가 읽고 있는 env
                  파일과 변수명(OPENAI_API_KEY)을 확인해주세요.
                  {settings?.debug?.env_file && (
                    <Box sx={{ mt: 0.5, color: '#6B7280', fontSize: '0.72rem' }}>
                      읽은 env 파일: {settings.debug.env_file}
                      {settings.debug.env_file_exists ? '' : ' (파일 없음)'}
                    </Box>
                  )}
                </Alert>
              )}
            </>
          )}

          {/* ── Model Name ── */}
          <Box>
            <Typography
              variant="body2"
              sx={{ fontWeight: 600, mb: 0.5, color: '#374151', fontSize: '0.85rem' }}
            >
              Model Name
            </Typography>
            {modelOptions && modelOptions.models.length > 0 ? (
              <>
                <FormControl fullWidth size="small">
                  <Select
                    value={
                      modelOptions.models.includes(modelName)
                        ? modelName
                        : (modelOptions.default_model || '')
                    }
                    onChange={e => setModelName(e.target.value as string)}
                    displayEmpty
                    sx={{ borderRadius: 2, fontSize: '0.85rem' }}
                  >
                    {modelOptions.model_details.map(m => (
                      <MenuItem key={m.key} value={m.key} sx={{ fontSize: '0.85rem' }}>
                        <Box>
                          <Typography sx={{ fontWeight: 600, fontSize: '0.85rem' }}>
                            {m.name}
                          </Typography>
                          {m.description && (
                            <Typography sx={{ color: '#9CA3AF', fontSize: '0.72rem' }}>
                              {m.description}
                            </Typography>
                          )}
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <Typography variant="caption" sx={{ color: '#9CA3AF', mt: 0.5, display: 'block' }}>
                  {isOpenAI
                    ? 'OpenAI 모델 (.env의 OPENAI_MODEL / OPENAI_MODELS)'
                    : '사내 DSLLM Gateway 모델 (.env.local / .env.production의 LLM_MODEL_1~4)'}
                </Typography>
              </>
            ) : (
              <TextField
                fullWidth
                size="small"
                placeholder={isOpenAI ? 'gpt-4.1-mini, gpt-4.1, etc.' : 'gpt-4, llama-3, gemma-2, etc.'}
                value={modelName}
                onChange={e => setModelName(e.target.value)}
                sx={{
                  '& .MuiOutlinedInput-root': { borderRadius: 2, fontSize: '0.85rem' },
                }}
              />
            )}
          </Box>

          {/* ── 연결 테스트 결과 ── */}
          {testResult && (
            <Alert
              severity={testResult.ok ? 'success' : 'error'}
              sx={{ borderRadius: 2, fontSize: '0.78rem' }}
            >
              {testResult.ok ? (
                <>
                  연결 성공 ({testResult.provider} / {testResult.model})
                  {typeof testResult.models_count === 'number' && (
                    <Box sx={{ mt: 0.25, color: '#6B7280', fontSize: '0.72rem' }}>
                      접근 가능한 모델 {testResult.models_count}개 · 선택 모델 확인됨
                    </Box>
                  )}
                  {testResult.answer && (
                    <Box sx={{ mt: 0.5, color: '#374151' }}>응답: {testResult.answer}</Box>
                  )}
                </>
              ) : (
                <>
                  {testResult.error || '연결 실패: 호출에 실패했습니다.'}
                  {/* 진단 메타 (민감정보 없음) */}
                  {(testResult.status_code != null ||
                    testResult.stage ||
                    testResult.base_url) && (
                    <Box sx={{ mt: 0.5, color: '#6B7280', fontSize: '0.72rem' }}>
                      {testResult.status_code != null && <>status: {testResult.status_code} · </>}
                      {testResult.stage && <>단계: {testResult.stage} · </>}
                      model: {testResult.model}
                      {testResult.base_url && <> · {testResult.base_url}</>}
                    </Box>
                  )}
                </>
              )}
            </Alert>
          )}

          {/* ── 액션 버튼 ── */}
          <Box sx={{ display: 'flex', gap: 1.5, mt: 1 }}>
            <Button
              variant="contained"
              startIcon={
                saveMutation.isPending ? <CircularProgress size={16} color="inherit" /> : <SaveIcon />
              }
              onClick={() => saveMutation.mutate()}
              disabled={saveMutation.isPending || !modelName || (isOpenAI && !apiKeyConfigured)}
              sx={{
                bgcolor: '#2955FF',
                textTransform: 'none',
                fontWeight: 700,
                borderRadius: 2,
                boxShadow: '0 2px 8px rgba(41,85,255,0.25)',
                '&:hover': { bgcolor: '#1E3FCC' },
              }}
            >
              {saveMutation.isPending ? 'Saving...' : 'Save Settings'}
            </Button>
            <Button
              variant="outlined"
              startIcon={
                testMutation.isPending ? <CircularProgress size={16} color="inherit" /> : <ScienceIcon />
              }
              onClick={() => {
                setTestResult(null);
                testMutation.mutate();
              }}
              disabled={testMutation.isPending || !modelName || (isOpenAI && !apiKeyConfigured)}
              sx={{
                textTransform: 'none',
                fontWeight: 700,
                borderRadius: 2,
                borderColor: '#C7D2FE',
                color: '#2955FF',
                '&:hover': { borderColor: '#2955FF', bgcolor: '#EEF2FF' },
              }}
            >
              {testMutation.isPending ? '테스트 중...' : '연결 테스트'}
            </Button>
          </Box>
        </Box>
      </Paper>

      {/* ── Vision AI 설정 (Text AI와 분리) ── */}
      <VisionAiSettingsSection userId={currentUserId} />
    </Box>
  );
};

export default AiSettingsPage;
