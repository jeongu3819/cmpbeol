import React, { useEffect, useRef, useState } from 'react';
import {
  Box, Typography, Paper, Avatar, Chip, CircularProgress,
  Switch, FormControlLabel, Divider, Collapse, IconButton,
} from '@mui/material';
import AlternateEmailIcon from '@mui/icons-material/AlternateEmail';
import NotificationsOutlinedIcon from '@mui/icons-material/NotificationsOutlined';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useSnackbar } from 'notistack';
import { api } from '../api/client';
import { MentionNote, NotificationPreference } from '../types';
import { useAppStore } from '../stores/useAppStore';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { keyframes } from '@mui/system';
import { format } from 'date-fns';

const HIGHLIGHT_MS = 4500;

// 메일에서 이동한 카드가 확실히 눈에 띄도록 잠깐 pulse (깊은 그림자 + 파란 링)
const mentionPulse = keyframes`
  0%   { box-shadow: 0 12px 30px rgba(37,99,235,0.18), 0 0 0 0 rgba(37,99,235,0.45); }
  70%  { box-shadow: 0 12px 30px rgba(37,99,235,0.18), 0 0 0 12px rgba(37,99,235,0); }
  100% { box-shadow: 0 12px 30px rgba(37,99,235,0.18), 0 0 0 0 rgba(37,99,235,0); }
`;

const MentionsPage: React.FC = () => {
  const currentUserId = useAppStore(state => state.currentUserId);
  const spaceSlug = useAppStore(state => state.currentSpaceSlug);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const [searchParams] = useSearchParams();
  const mentionId = searchParams.get('mentionId');

  const { data: mentions = [], isLoading } = useQuery<MentionNote[]>({
    queryKey: ['mentions', currentUserId],
    queryFn: () => api.getMentions(currentUserId),
  });

  // ── 알림 설정 ──
  const [prefsOpen, setPrefsOpen] = useState(false);
  const { data: prefs } = useQuery<NotificationPreference>({
    queryKey: ['notificationPrefs', currentUserId],
    queryFn: () => api.getNotificationPreferences(currentUserId),
    enabled: !!currentUserId,
  });
  const prefMut = useMutation({
    mutationFn: (patch: Partial<Omit<NotificationPreference, 'user_id'>>) =>
      api.updateNotificationPreferences(currentUserId, patch),
    onSuccess: (data) => {
      queryClient.setQueryData(['notificationPrefs', currentUserId], data);
    },
    onError: () => enqueueSnackbar('알림 설정 저장에 실패했습니다.', { variant: 'error' }),
  });

  // ── 딥링크(?mentionId=) 스크롤/highlight ──
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [highlightedId, setHighlightedId] = useState<string | null>(null);
  const handledRef = useRef<string | null>(null);

  const openMention = (m: {
    source?: MentionNote['source'];
    // detail API 의 source_type 도 함께 허용
    source_type?: 'task_comment' | 'task_work_note';
    project_id?: number;
    task_id?: number;
    space_slug?: string | null;
  }) => {
    // 현재 sidebar 에서 선택된 space 가 아니라, 멘션이 속한 space 로 이동해야 한다.
    // MainLayout 이 URL slug 를 보고 active space 를 동기화하므로 slug 만 정확하면 됨.
    const slug = m.space_slug || spaceSlug;
    const base = slug ? `/space/${slug}` : '';
    const kind = m.source_type || m.source;
    if ((kind === 'task_comment') && m.task_id) {
      navigate(`${base}/project/${m.project_id}?openTask=${m.task_id}&openComments=1`);
    } else if ((kind === 'activity' || kind === 'task_work_note') && m.task_id) {
      navigate(`${base}/project/${m.project_id}?openTask=${m.task_id}&openWorkNote=1`);
    } else if (m.project_id) {
      navigate(`${base}/project/${m.project_id}?tab=messenger`);
    }
  };

  useEffect(() => {
    if (!mentionId || isLoading) return;
    if (handledRef.current === mentionId) return;
    handledRef.current = mentionId;

    const found = mentions.find(m => String(m.id) === mentionId);
    if (found) {
      setHighlightedId(mentionId);
      requestAnimationFrame(() => {
        cardRefs.current[mentionId]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
      const t = setTimeout(() => setHighlightedId(null), HIGHLIGHT_MS);
      return () => clearTimeout(t);
    }
    // 목록에 없으면 단건 조회 후 해당 Task 로 이동 (권한/삭제는 API 가 판단)
    api.getMentionDetail(mentionId)
      .then((detail) => {
        openMention({
          source_type: detail.source_type,
          project_id: detail.project_id ?? undefined,
          task_id: detail.task_id ?? undefined,
          space_slug: detail.space_slug ?? undefined,
        });
      })
      .catch((err) => {
        const code = err?.response?.status;
        const msg = code === 403
          ? '이 항목에 접근할 권한이 없습니다.'
          : code === 404
            ? '해당 언급을 찾을 수 없거나 삭제되었습니다.'
            : '언급을 여는 중 오류가 발생했습니다.';
        enqueueSnackbar(msg, { variant: 'warning' });
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mentionId, isLoading, mentions]);

  const renderContent = (content: string) => {
    return content.split(/(@\S+)/g).map((part, i) =>
      part.match(/^@\S+/) ? (
        <span key={i} style={{ color: '#2955FF', fontWeight: 600 }}>
          {part}
        </span>
      ) : (
        <React.Fragment key={i}>{part}</React.Fragment>
      )
    );
  };

  const master = prefs?.mention_email_enabled ?? true;

  return (
    <Box sx={{ maxWidth: 800, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
        <AlternateEmailIcon sx={{ fontSize: '1.8rem', color: '#2955FF' }} />
        <Typography variant="h5" sx={{ fontWeight: 800 }}>
          @나를 언급
        </Typography>
      </Box>

      {/* ── 멘션 메일 알림 설정 ── */}
      {prefs && (
        <Paper
          elevation={0}
          sx={{ mb: 2.5, borderRadius: 2, border: '1px solid #E5E7EB', overflow: 'hidden' }}
        >
          <Box
            onClick={() => setPrefsOpen(o => !o)}
            sx={{
              display: 'flex', alignItems: 'center', gap: 1, px: 2, py: 1.2, cursor: 'pointer',
              '&:hover': { bgcolor: '#FAFAFB' },
            }}
          >
            <NotificationsOutlinedIcon sx={{ fontSize: '1.1rem', color: '#6B7280' }} />
            <Typography sx={{ fontWeight: 700, fontSize: '0.85rem', color: '#1A1D29' }}>
              멘션 메일 알림 설정
            </Typography>
            <Chip
              label={master ? '켜짐' : '꺼짐'}
              size="small"
              sx={{
                height: 20, fontSize: '0.65rem', fontWeight: 700,
                bgcolor: master ? '#DCFCE7' : '#F3F4F6',
                color: master ? '#15803D' : '#6B7280',
              }}
            />
            <IconButton size="small" sx={{ ml: 'auto', transform: prefsOpen ? 'rotate(180deg)' : 'none', transition: 'transform .15s' }}>
              <ExpandMoreIcon fontSize="small" />
            </IconButton>
          </Box>
          <Collapse in={prefsOpen}>
            <Divider />
            <Box sx={{ px: 2, py: 1.5 }}>
              <FormControlLabel
                control={
                  <Switch
                    size="small"
                    checked={master}
                    onChange={(e) => prefMut.mutate({ mention_email_enabled: e.target.checked })}
                  />
                }
                label={<Typography sx={{ fontSize: '0.82rem' }}>멘션 메일 알림 받기</Typography>}
              />
              <Box sx={{ pl: 1.5, mt: 0.5, opacity: master ? 1 : 0.45, pointerEvents: master ? 'auto' : 'none' }}>
                <FormControlLabel
                  control={
                    <Switch
                      size="small"
                      checked={prefs.task_mention_email_enabled}
                      onChange={(e) => prefMut.mutate({ task_mention_email_enabled: e.target.checked })}
                    />
                  }
                  label={<Typography sx={{ fontSize: '0.8rem' }}>댓글에서 멘션될 때</Typography>}
                />
                <br />
                <FormControlLabel
                  control={
                    <Switch
                      size="small"
                      checked={prefs.work_note_mention_email_enabled}
                      onChange={(e) => prefMut.mutate({ work_note_mention_email_enabled: e.target.checked })}
                    />
                  }
                  label={<Typography sx={{ fontSize: '0.8rem' }}>작업노트에서 멘션될 때</Typography>}
                />
              </Box>
              <Typography sx={{ fontSize: '0.7rem', color: '#9CA3AF', mt: 0.5 }}>
                설정을 꺼도 이 페이지의 멘션 목록에는 계속 표시됩니다.
              </Typography>
            </Box>
          </Collapse>
        </Paper>
      )}

      {isLoading ? (
        <Box sx={{ textAlign: 'center', py: 6 }}>
          <CircularProgress size={28} />
        </Box>
      ) : mentions.length === 0 ? (
        <Paper
          sx={{ p: 6, textAlign: 'center', borderRadius: 2, border: '1px solid #E5E7EB' }}
          elevation={0}
        >
          <AlternateEmailIcon sx={{ fontSize: '3rem', color: '#D1D5DB', mb: 1 }} />
          <Typography variant="body1" sx={{ color: '#6B7280', mb: 0.5 }}>
            아직 멘션된 메모가 없습니다
          </Typography>
          <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
            다른 사용자가 @이름으로 멘션하면 여기에 표시됩니다
          </Typography>
        </Paper>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {mentions.map(note => {
            const isHighlighted = highlightedId === String(note.id);
            return (
            <Paper
              key={note.id}
              ref={(el: HTMLDivElement | null) => { cardRefs.current[String(note.id)] = el; }}
              onClick={() => openMention(note)}
              sx={{
                p: 2.5,
                borderRadius: 2,
                // 2px border 로 인한 1px 밀림 방지: 평소에도 2px(투명) 유지
                border: isHighlighted ? '2px solid #2563EB' : '2px solid #E5E7EB',
                bgcolor: isHighlighted ? 'rgba(239,246,255,0.98)' : '#fff',
                boxShadow: isHighlighted ? '0 12px 30px rgba(37,99,235,0.18)' : 'none',
                animation: isHighlighted ? `${mentionPulse} 1.4s ease-out 2` : 'none',
                cursor: 'pointer',
                transition: 'border-color 0.25s, background-color 0.25s, transform 0.15s',
                '&:hover': {
                  borderColor: isHighlighted ? '#2563EB' : '#C7D2FE',
                  transform: 'translateY(-1px)',
                },
              }}
              elevation={0}
            >
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
                <Avatar
                  sx={{
                    bgcolor: note.author_color || '#2955FF',
                    width: 32,
                    height: 32,
                    fontSize: '0.75rem',
                    mt: 0.3,
                  }}
                >
                  {(note.author_name || 'U').charAt(0).toUpperCase()}
                </Avatar>
                <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 1,
                      mb: 0.5,
                      flexWrap: 'wrap',
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{ fontWeight: 600, fontSize: '0.85rem', color: '#1A1D29' }}
                    >
                      {note.author_name || 'Unknown'}
                    </Typography>
                    {isHighlighted && (
                      <Chip
                        icon={<AlternateEmailIcon sx={{ fontSize: '0.7rem !important', color: '#fff !important' }} />}
                        label="메일에서 이동한 언급"
                        size="small"
                        sx={{
                          height: 20,
                          fontSize: '0.6rem',
                          fontWeight: 700,
                          bgcolor: '#2563EB',
                          color: '#fff',
                          '& .MuiChip-icon': { ml: '4px' },
                        }}
                      />
                    )}
                    <Chip
                      label={note.project_name || 'Project'}
                      size="small"
                      sx={{
                        height: 20,
                        fontSize: '0.65rem',
                        fontWeight: 600,
                        bgcolor: '#EEF2FF',
                        color: '#2955FF',
                      }}
                    />
                    {note.source === 'activity' && (
                      <Chip
                        label="작업노트"
                        size="small"
                        sx={{
                          height: 20,
                          fontSize: '0.6rem',
                          fontWeight: 600,
                          bgcolor: '#F3E8FF',
                          color: '#7C3AED',
                        }}
                      />
                    )}
                    {note.source === 'task_comment' && (
                      <Chip
                        label={note.source_label || '작업댓글'}
                        size="small"
                        sx={{
                          height: 20,
                          fontSize: '0.6rem',
                          fontWeight: 600,
                          bgcolor: '#DBEAFE',
                          color: '#2563EB',
                        }}
                      />
                    )}
                    <Typography
                      variant="caption"
                      sx={{ color: '#9CA3AF', fontSize: '0.7rem', ml: 'auto' }}
                    >
                      {note.created_at ? format(new Date(note.created_at), 'yyyy-MM-dd HH:mm') : ''}
                    </Typography>
                  </Box>
                  <Typography
                    variant="body2"
                    component="div"
                    sx={{
                      color: '#374151',
                      fontSize: '0.88rem',
                      lineHeight: 1.6,
                      whiteSpace: 'pre-wrap',
                      display: '-webkit-box',
                      WebkitLineClamp: 4,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden',
                    }}
                  >
                    {renderContent(note.content)}
                  </Typography>
                </Box>
              </Box>
            </Paper>
            );
          })}
        </Box>
      )}
    </Box>
  );
};

export default MentionsPage;
