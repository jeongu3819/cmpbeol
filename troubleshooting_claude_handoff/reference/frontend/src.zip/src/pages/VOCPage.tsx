import React, { useMemo, useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Box,
  Typography,
  Paper,
  CircularProgress,
  Button,
  Chip,
  IconButton,
  Stack,
  TextField,
  MenuItem,
  Tooltip,
  Avatar,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tabs,
  Tab,
  FormControlLabel,
  Checkbox,
} from '@mui/material';
import FeedbackIcon from '@mui/icons-material/Feedback';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import EditNoteIcon from '@mui/icons-material/EditNote';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import HistoryIcon from '@mui/icons-material/History';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import PublicIcon from '@mui/icons-material/Public';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import FavoriteIcon from '@mui/icons-material/Favorite';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useSnackbar } from 'notistack';
import { format } from 'date-fns';
import { api } from '../api/client';
import { useAppStore } from '../stores/useAppStore';
import { planAiColors } from '../theme/tokens';
import PaginationBar from '../components/common/PaginationBar';
import { VocItem, VocStatus, VocPriority, VocVisibility, VocStats, PaginationMeta } from '../types';
import FeedbackModal from '../components/FeedbackModal';
import ImageLightbox, { LightboxImage } from '../components/voc/ImageLightbox';
import { stripHtmlToText } from '../utils/htmlText';
import VocContentRenderer from '../components/voc/VocContentRenderer';
import VocCommentThread from '../components/voc/VocCommentThread';
import DeveloperOperatorBadge from '../components/voc/DeveloperOperatorBadge';
import {
  VOC_CATEGORY_LABEL,
  VOC_RELATED_SCREEN_LABEL,
  VOC_PRIORITY_LABEL,
  VOC_STATUS_LABEL,
  VOC_STATUS_COLOR,
  VOC_PRIORITY_COLOR,
  VOC_STATUS_OPTIONS,
  VOC_PRIORITY_OPTIONS,
  VOC_CATEGORY_OPTIONS,
  VOC_VISIBILITY_LABEL,
} from '../components/voc/vocLabels';

const VOCPage: React.FC = () => {
  const currentUserId = useAppStore(state => state.currentUserId);
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();

  const [scope, setScope] = useState<'mine' | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<VocStatus | ''>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [editingVoc, setEditingVoc] = useState<VocItem | null>(null);
  const [noteEditor, setNoteEditor] = useState<{ id: number; value: string; sendMail: boolean } | null>(null);
  const [lightbox, setLightbox] = useState<{ images: LightboxImage[]; index: number } | null>(null);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);

  // ── 메일 딥링크(?vocId=) — 해당 VOC 카드로 스크롤/highlight + 답변 영역 자동 펼침 ──
  const [searchParams] = useSearchParams();
  const deepLinkVocId = useMemo(() => {
    const raw = searchParams.get('vocId');
    const n = raw ? parseInt(raw, 10) : NaN;
    return Number.isFinite(n) ? n : null;
  }, [searchParams]);
  const [highlightVocId, setHighlightVocId] = useState<number | null>(null);
  const cardRefs = useRef<Record<number, HTMLDivElement | null>>({});
  const deepLinkHandledRef = useRef<number | null>(null);

  // 검색어 debounce (300ms)
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), 300);
    return () => clearTimeout(t);
  }, [searchInput]);

  // 검색/필터/탭/페이지크기 변경 시 page 1로 초기화
  useEffect(() => {
    setPage(1);
  }, [scope, statusFilter, categoryFilter, search, pageSize]);

  const { data: statsData } = useQuery<VocStats>({
    queryKey: ['voc-stats', currentUserId],
    queryFn: () => api.getVocStats(currentUserId),
    enabled: !!currentUserId,
  });

  const { data, isLoading } = useQuery<{ items: VocItem[]; is_admin: boolean; pagination: PaginationMeta }>({
    queryKey: ['voc-list', currentUserId, scope, statusFilter, categoryFilter, search, page, pageSize],
    queryFn: () =>
      api.listVoc(currentUserId, {
        scope,
        status: statusFilter || undefined,
        category: categoryFilter || undefined,
        search: search || undefined,
        page,
        page_size: pageSize,
      }),
    enabled: !!currentUserId,
  });

  const items = data?.items ?? [];
  const isAdmin = !!data?.is_admin;
  const pagination = data?.pagination;

  // 딥링크 대상 VOC 가 현재 목록에 있으면 스크롤 + highlight (best-effort — 다른 페이지면 목록만 표시)
  useEffect(() => {
    if (!deepLinkVocId || isLoading) return;
    if (deepLinkHandledRef.current === deepLinkVocId) return;
    if (!items.some(it => it.id === deepLinkVocId)) return;
    deepLinkHandledRef.current = deepLinkVocId;
    setHighlightVocId(deepLinkVocId);
    const el = cardRefs.current[deepLinkVocId];
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    const t = setTimeout(() => setHighlightVocId(null), 3000);
    return () => clearTimeout(t);
  }, [deepLinkVocId, isLoading, items]);

  const updateMut = useMutation({
    mutationFn: ({ id, body }: { id: number; body: { status?: string; priority?: string; admin_note?: string; send_mail?: boolean; visibility?: string } }) =>
      api.updateVoc(id, body, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['voc-list'] });
      queryClient.invalidateQueries({ queryKey: ['voc-stats'] });
    },
    onError: (err: any) => {
      enqueueSnackbar(err?.response?.data?.detail || '수정에 실패했습니다.', { variant: 'error' });
    },
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => api.deleteVoc(id, currentUserId),
    onSuccess: () => {
      enqueueSnackbar('삭제되었습니다.', { variant: 'success' });
      queryClient.invalidateQueries({ queryKey: ['voc-list'] });
      queryClient.invalidateQueries({ queryKey: ['voc-stats'] });
    },
    onError: (err: any) => {
      enqueueSnackbar(err?.response?.data?.detail || '삭제에 실패했습니다.', { variant: 'error' });
    },
  });

  const handleStatusChange = (id: number, status: VocStatus) => {
    updateMut.mutate({ id, body: { status } });
  };

  const handlePriorityChange = (id: number, priority: VocPriority) => {
    updateMut.mutate({ id, body: { priority } });
  };

  const handleVisibilityToggle = (id: number, current: VocVisibility | undefined) => {
    const next: VocVisibility = current === 'public' ? 'private' : 'public';
    updateMut.mutate({ id, body: { visibility: next } });
  };

  const voteMut = useMutation({
    mutationFn: ({ id, voted }: { id: number; voted: boolean }) =>
      voted ? api.removeVocVote(id, currentUserId) : api.addVocVote(id, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['voc-list'] });
    },
    onError: (err: any) => {
      enqueueSnackbar(err?.response?.data?.detail || '처리에 실패했습니다.', { variant: 'error' });
    },
  });

  const handleSaveNote = () => {
    if (!noteEditor) return;
    updateMut.mutate(
      { id: noteEditor.id, body: { admin_note: noteEditor.value, send_mail: noteEditor.sendMail } },
      {
        onSuccess: () => {
          if (noteEditor.sendMail) {
            enqueueSnackbar('관리자 메모를 저장하고 작성자에게 메일 알림을 발송 요청했습니다.', { variant: 'success' });
          }
          setNoteEditor(null);
        },
      }
    );
  };

  // 상태별 건수는 현재 page(items)가 아니라 서버 집계(statsData.by_status) 기준 — pagination 무관 전체 집계
  const stats = useMemo(() => {
    const src = statsData?.by_status;
    const c: Record<VocStatus, number> = {
      received: Number(src?.received || 0),
      reviewing: Number(src?.reviewing || 0),
      in_progress: Number(src?.in_progress || 0),
      completed: Number(src?.completed || 0),
      on_hold: Number(src?.on_hold || 0),
    };
    return c;
  }, [statsData]);

  return (
    <Box sx={{ maxWidth: 1100, mx: 'auto' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3, gap: 2, flexWrap: 'wrap' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <FeedbackIcon sx={{ fontSize: '1.8rem', color: planAiColors.brand.primary }} />
          <Typography variant="h5" sx={{ fontWeight: 800 }}>
            개선 요청
          </Typography>
          {isAdmin && (
            <Chip
              size="small"
              label="관리자 보기"
              sx={{ ml: 1, bgcolor: planAiColors.brand.primarySoft, color: planAiColors.brand.primary, fontWeight: 600 }}
            />
          )}
        </Box>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setFeedbackOpen(true)}
          sx={{ bgcolor: planAiColors.brand.primary, textTransform: 'none', fontWeight: 600 }}
        >
          새 개선 요청
        </Button>
      </Box>

      {/* Operation Notice */}
      <Paper
        elevation={0}
        sx={{
          mb: 2,
          p: 2,
          borderRadius: 2,
          bgcolor: planAiColors.brand.primarySoft,
          border: `1px solid ${planAiColors.brand.primaryBorder}`,
        }}
      >
        <Stack
          direction={{ xs: 'column', md: 'row' }}
          gap={{ xs: 1.5, md: 2 }}
          alignItems={{ xs: 'stretch', md: 'center' }}
          justifyContent="space-between"
        >
          <Box sx={{ display: 'flex', gap: 1.2, alignItems: 'flex-start', flex: 1, minWidth: 0 }}>
            <InfoOutlinedIcon sx={{ color: planAiColors.brand.primary, fontSize: '1.25rem', mt: '2px' }} />
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, color: planAiColors.brand.primaryHover, mb: 0.6 }}>
                운영 안내
              </Typography>
              <Typography
                variant="body2"
                sx={{ color: planAiColors.text.secondary, whiteSpace: 'pre-line', lineHeight: 1.7 }}
              >
                {`PLAN-AI는 현업 업무를 더 편하게 만들기 위해 직접 개발·운영 중인 플랫폼입니다.
현재 1인 개발로 운영 중이라 모든 요청을 바로 반영하기는 어렵지만, 남겨주신 의견은 우선순위와 영향도를 검토해 순차적으로 반영하겠습니다.
불편한 점이나 추가되면 좋을 기능이 있다면 편하게 남겨주세요.`}
              </Typography>
            </Box>
          </Box>
          <Box
            sx={{
              display: 'flex',
              justifyContent: { xs: 'flex-end', md: 'flex-start' },
              flexShrink: 0,
            }}
          >
            <DeveloperOperatorBadge name="jimi.lee" />
          </Box>
        </Stack>
      </Paper>

      {/* Scope Tabs — 전체 / 내 VOC / 반영완료(해결된 VOC 모아보기). 반영완료는 statusFilter 재사용 */}
      <Tabs
        value={scope === 'mine' ? 'mine' : statusFilter === 'completed' ? 'resolved' : 'all'}
        onChange={(_e, v) => {
          if (v === 'mine') {
            setScope('mine');
            setStatusFilter('');
          } else if (v === 'resolved') {
            setScope('all');
            setStatusFilter('completed');
          } else {
            setScope('all');
            setStatusFilter('');
          }
        }}
        sx={{ mb: 2, minHeight: 40, '& .MuiTab-root': { minHeight: 40, textTransform: 'none', fontWeight: 600 } }}
        TabIndicatorProps={{ sx: { bgcolor: planAiColors.brand.primary } }}
      >
        <Tab value="all" label={isAdmin ? '전체 VOC (비공개 포함)' : '전체 VOC'} />
        <Tab value="mine" label="내 VOC" />
        <Tab value="resolved" label="반영완료" />
      </Tabs>

      {/* 처리율 요약 — 전체(관리자) 또는 공개+본인(일반) 기준 서버 집계 */}
      {statsData && statsData.total > 0 && (
        <Paper
          elevation={0}
          sx={{
            mb: 2,
            p: 1.5,
            borderRadius: 2,
            border: `1px solid ${planAiColors.border.soft}`,
            display: 'flex',
            alignItems: 'center',
            gap: 2,
            flexWrap: 'wrap',
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 0.8 }}>
            <Typography variant="caption" sx={{ color: planAiColors.text.tertiary }}>
              처리율
            </Typography>
            <Typography variant="h6" sx={{ fontWeight: 800, color: planAiColors.brand.primary }}>
              {statsData.completion_rate}%
            </Typography>
          </Box>
          <Box sx={{ flex: 1, minWidth: 160 }}>
            <Box
              sx={{
                height: 8,
                borderRadius: 4,
                bgcolor: planAiColors.background.surfaceAlt,
                overflow: 'hidden',
              }}
            >
              <Box
                sx={{
                  width: `${statsData.completion_rate}%`,
                  height: '100%',
                  bgcolor: planAiColors.status.success,
                  transition: 'width 0.3s',
                }}
              />
            </Box>
          </Box>
          <Typography variant="caption" sx={{ color: planAiColors.text.tertiary }}>
            총 {statsData.total}건 · 반영완료 {statsData.completed}건
          </Typography>
        </Paper>
      )}

      {/* Stats Strip */}
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 1.5, mb: 2 }}>
        {VOC_STATUS_OPTIONS.map(opt => (
          <Paper
            key={opt.value}
            elevation={0}
            sx={{
              p: 1.2,
              borderRadius: 2,
              border: `1px solid ${planAiColors.border.soft}`,
              textAlign: 'center',
              cursor: 'pointer',
              bgcolor: statusFilter === opt.value ? VOC_STATUS_COLOR[opt.value].bg : '#fff',
            }}
            onClick={() => setStatusFilter(prev => (prev === opt.value ? '' : opt.value))}
          >
            <Typography variant="caption" sx={{ color: planAiColors.text.tertiary, display: 'block' }}>
              {opt.label}
            </Typography>
            <Typography variant="h6" sx={{ fontWeight: 800, color: VOC_STATUS_COLOR[opt.value].fg }}>
              {stats[opt.value]}
            </Typography>
          </Paper>
        ))}
      </Box>

      {/* Filters */}
      <Paper
        elevation={0}
        sx={{ p: 1.5, mb: 2, borderRadius: 2, border: `1px solid ${planAiColors.border.soft}`, display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center' }}
      >
        <TextField
          select
          size="small"
          label="분류"
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
          sx={{ minWidth: 140 }}
        >
          <MenuItem value="">전체</MenuItem>
          {VOC_CATEGORY_OPTIONS.map(o => (
            <MenuItem key={o.value} value={o.value}>
              {o.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          select
          size="small"
          label="상태"
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value as VocStatus | '')}
          sx={{ minWidth: 140 }}
        >
          <MenuItem value="">전체</MenuItem>
          {VOC_STATUS_OPTIONS.map(o => (
            <MenuItem key={o.value} value={o.value}>
              {o.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          size="small"
          label="검색"
          placeholder="제목/내용 검색"
          value={searchInput}
          onChange={e => setSearchInput(e.target.value)}
          sx={{ minWidth: 220, flex: 1 }}
        />
      </Paper>

      {isLoading ? (
        <Box sx={{ textAlign: 'center', py: 6 }}>
          <CircularProgress size={28} />
        </Box>
      ) : items.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center', borderRadius: 2, border: `1px solid ${planAiColors.border.soft}` }} elevation={0}>
          <FeedbackIcon sx={{ fontSize: '3rem', color: planAiColors.border.normal, mb: 1 }} />
          <Typography variant="body1" sx={{ color: planAiColors.text.tertiary, mb: 0.5 }}>
            등록된 개선 요청이 없습니다
          </Typography>
          <Typography variant="caption" sx={{ color: planAiColors.text.muted }}>
            상단의 "새 개선 요청" 버튼으로 등록할 수 있습니다.
          </Typography>
        </Paper>
      ) : (
        <Stack spacing={1.2}>
          {items.map(item => {
            const canEditMeta = isAdmin;
            const canDelete = isAdmin || item.author_id === currentUserId;
            const canEditContent = isAdmin || item.author_id === currentUserId;
            return (
              <Paper
                key={item.id}
                ref={(el: HTMLDivElement | null) => { cardRefs.current[item.id] = el; }}
                elevation={0}
                sx={{
                  p: 2,
                  borderRadius: 2,
                  border: `1px solid ${highlightVocId === item.id ? planAiColors.brand.primary : planAiColors.border.soft}`,
                  boxShadow: highlightVocId === item.id ? `0 0 0 2px ${planAiColors.brand.primarySoft}` : 'none',
                  transition: 'border-color 0.3s, box-shadow 0.3s',
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5 }}>
                  <Avatar
                    sx={{
                      width: 32,
                      height: 32,
                      bgcolor: item.author_color || planAiColors.text.muted,
                      fontSize: '0.85rem',
                      fontWeight: 700,
                    }}
                  >
                    {(item.author_name || '?').slice(0, 1)}
                  </Avatar>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                      <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                        {item.title}
                      </Typography>
                      <Chip
                        size="small"
                        label={VOC_CATEGORY_LABEL[item.category] || item.category}
                        sx={{ bgcolor: planAiColors.background.surfaceAlt, color: planAiColors.text.secondary, fontWeight: 600 }}
                      />
                      {item.related_screen && (
                        <Chip
                          size="small"
                          label={VOC_RELATED_SCREEN_LABEL[item.related_screen] || item.related_screen}
                          sx={{ bgcolor: planAiColors.brand.primarySoft, color: planAiColors.brand.primaryHover }}
                        />
                      )}
                      {item.visibility === 'private' && (
                        <Chip
                          size="small"
                          icon={<LockOutlinedIcon sx={{ fontSize: '0.85rem !important' }} />}
                          label={VOC_VISIBILITY_LABEL.private}
                          sx={{ bgcolor: planAiColors.background.surfaceAlt, color: planAiColors.text.tertiary, fontWeight: 600 }}
                        />
                      )}
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.3, flexWrap: 'wrap' }}>
                      <Typography variant="caption" sx={{ color: planAiColors.text.tertiary }}>
                        {item.author_name || '익명'}
                      </Typography>
                      <Typography variant="caption" sx={{ color: planAiColors.text.muted }}>
                        ·
                      </Typography>
                      <Typography variant="caption" sx={{ color: planAiColors.text.muted }}>
                        {item.created_at ? format(new Date(item.created_at), 'yyyy-MM-dd HH:mm') : ''}
                      </Typography>
                      {item.edited_at && (
                        <Tooltip
                          title={`${item.editor_name || ''} 님이 ${format(new Date(item.edited_at), 'yyyy-MM-dd HH:mm')}에 수정`}
                        >
                          <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.3, color: planAiColors.text.muted }}>
                            <HistoryIcon sx={{ fontSize: '0.85rem' }} />
                            <Typography variant="caption" sx={{ color: planAiColors.text.muted }}>
                              수정됨
                            </Typography>
                          </Box>
                        </Tooltip>
                      )}
                    </Box>
                    <VocContentRenderer
                      content={item.content}
                      onImageClick={(src, allSrcs) => {
                        const images: LightboxImage[] = allSrcs.map(s => ({ url: s }));
                        const idx = Math.max(0, allSrcs.indexOf(src));
                        setLightbox({ images, index: idx });
                      }}
                    />

                    {item.admin_note && (
                      <Box
                        sx={{
                          mt: 1.2,
                          p: 1.2,
                          borderRadius: 1.5,
                          bgcolor: planAiColors.status.warningSoft,
                          border: '1px solid #FDE68A',
                        }}
                      >
                        <Typography variant="caption" sx={{ color: planAiColors.status.warning, fontWeight: 700 }}>
                          관리자 메모{item.resolver_name ? ` · ${item.resolver_name}` : ''}
                        </Typography>
                        <Typography
                          variant="body2"
                          sx={{ color: planAiColors.status.warning, whiteSpace: 'pre-wrap', mt: 0.3 }}
                        >
                          {stripHtmlToText(item.admin_note)}
                        </Typography>
                      </Box>
                    )}

                    {/* 공개 VOC 에서만 '나도 필요해요'(우선순위 판단용 공감)를 표시. 비공개 VOC 는 작성자/관리자만 보므로 액션 영역 없음. */}
                    {item.visibility !== 'private' && (
                      <Box sx={{ mt: 1.4, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                        <Button
                          size="small"
                          variant={item.voted_by_me ? 'contained' : 'outlined'}
                          disableElevation
                          startIcon={
                            item.voted_by_me ? (
                              <FavoriteIcon sx={{ fontSize: '0.95rem' }} />
                            ) : (
                              <FavoriteBorderIcon sx={{ fontSize: '0.95rem' }} />
                            )
                          }
                          onClick={() => voteMut.mutate({ id: item.id, voted: !!item.voted_by_me })}
                          disabled={voteMut.isPending}
                          sx={{
                            textTransform: 'none',
                            borderRadius: 5,
                            px: 1.6,
                            fontWeight: 600,
                            color: item.voted_by_me ? '#fff' : planAiColors.brand.primary,
                            bgcolor: item.voted_by_me ? planAiColors.brand.primary : 'transparent',
                            borderColor: planAiColors.brand.primaryBorder,
                            '&:hover': {
                              bgcolor: item.voted_by_me
                                ? planAiColors.brand.primaryHover
                                : planAiColors.brand.primarySoft,
                              borderColor: planAiColors.brand.primary,
                            },
                          }}
                        >
                          나도 필요해요{item.vote_count ? ` ${item.vote_count}` : ''}
                        </Button>
                      </Box>
                    )}

                    <VocCommentThread
                      vocId={item.id}
                      vocAuthorId={item.author_id}
                      currentUserId={currentUserId}
                      isAdmin={isAdmin}
                      autoOpen={deepLinkVocId === item.id}
                    />
                  </Box>

                  <Stack spacing={0.8} sx={{ minWidth: 200, alignItems: 'flex-end' }}>
                    {canEditMeta ? (
                      <TextField
                        select
                        size="small"
                        value={item.status}
                        onChange={e => handleStatusChange(item.id, e.target.value as VocStatus)}
                        sx={{
                          minWidth: 140,
                          '& .MuiOutlinedInput-root': {
                            bgcolor: VOC_STATUS_COLOR[item.status].bg,
                            color: VOC_STATUS_COLOR[item.status].fg,
                            fontWeight: 700,
                          },
                        }}
                      >
                        {VOC_STATUS_OPTIONS.map(o => (
                          <MenuItem key={o.value} value={o.value}>
                            {o.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    ) : (
                      <Chip
                        size="small"
                        label={VOC_STATUS_LABEL[item.status]}
                        sx={{
                          bgcolor: VOC_STATUS_COLOR[item.status].bg,
                          color: VOC_STATUS_COLOR[item.status].fg,
                          fontWeight: 700,
                        }}
                      />
                    )}

                    {canEditMeta ? (
                      <TextField
                        select
                        size="small"
                        value={item.priority}
                        onChange={e => handlePriorityChange(item.id, e.target.value as VocPriority)}
                        sx={{
                          minWidth: 140,
                          '& .MuiOutlinedInput-root': {
                            bgcolor: VOC_PRIORITY_COLOR[item.priority].bg,
                            color: VOC_PRIORITY_COLOR[item.priority].fg,
                            fontWeight: 700,
                          },
                        }}
                      >
                        {VOC_PRIORITY_OPTIONS.map(o => (
                          <MenuItem key={o.value} value={o.value}>
                            {o.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    ) : (
                      <Chip
                        size="small"
                        label={`우선순위: ${VOC_PRIORITY_LABEL[item.priority]}`}
                        sx={{
                          bgcolor: VOC_PRIORITY_COLOR[item.priority].bg,
                          color: VOC_PRIORITY_COLOR[item.priority].fg,
                          fontWeight: 700,
                        }}
                      />
                    )}

                    <Stack direction="row" spacing={0.5}>
                      {canEditContent && (
                        <Tooltip title="수정">
                          <IconButton
                            size="small"
                            onClick={() => setEditingVoc(item)}
                            sx={{ color: planAiColors.brand.primary }}
                          >
                            <EditOutlinedIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      {isAdmin && (
                        <Tooltip title={item.visibility === 'private' ? '공개로 전환' : '비공개로 전환'}>
                          <IconButton
                            size="small"
                            onClick={() => handleVisibilityToggle(item.id, item.visibility)}
                            sx={{ color: item.visibility === 'private' ? planAiColors.text.tertiary : planAiColors.brand.primary }}
                          >
                            {item.visibility === 'private' ? (
                              <LockOutlinedIcon fontSize="small" />
                            ) : (
                              <PublicIcon fontSize="small" />
                            )}
                          </IconButton>
                        </Tooltip>
                      )}
                      {isAdmin && (
                        <Tooltip title="관리자 메모">
                          <IconButton
                            size="small"
                            onClick={() => setNoteEditor({ id: item.id, value: item.admin_note || '', sendMail: false })}
                            sx={{ color: planAiColors.text.tertiary }}
                          >
                            <EditNoteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      {canDelete && (
                        <Tooltip title="삭제">
                          <IconButton
                            size="small"
                            onClick={() => {
                              if (window.confirm('이 개선 요청을 삭제할까요?')) {
                                deleteMut.mutate(item.id);
                              }
                            }}
                            sx={{ color: planAiColors.status.danger }}
                          >
                            <DeleteOutlineIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                    </Stack>
                  </Stack>
                </Box>
              </Paper>
            );
          })}
        </Stack>
      )}

      {pagination && pagination.total > 0 && (
        <PaginationBar
          page={pagination.page}
          pageSize={pagination.page_size}
          total={pagination.total}
          totalPages={pagination.total_pages}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
          unitLabel="건"
        />
      )}

      <FeedbackModal
        open={feedbackOpen}
        onClose={() => setFeedbackOpen(false)}
        currentUserId={currentUserId}
      />

      <FeedbackModal
        open={!!editingVoc}
        onClose={() => setEditingVoc(null)}
        currentUserId={currentUserId}
        editingVoc={editingVoc}
      />

      {lightbox && (
        <ImageLightbox
          open={!!lightbox}
          onClose={() => setLightbox(null)}
          images={lightbox.images}
          initialIndex={lightbox.index}
        />
      )}

      <Dialog
        open={!!noteEditor}
        onClose={() => setNoteEditor(null)}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <DialogTitle sx={{ fontWeight: 700 }}>관리자 메모</DialogTitle>
        <DialogContent>
          <Divider sx={{ mb: 2 }} />
          <TextField
            value={noteEditor?.value ?? ''}
            onChange={e => setNoteEditor(prev => (prev ? { ...prev, value: e.target.value } : prev))}
            multiline
            minRows={4}
            maxRows={12}
            fullWidth
            size="small"
            placeholder="처리 사유, 진행 상황, 예상 일정 등을 남길 수 있습니다."
          />
          <FormControlLabel
            sx={{ mt: 1.5, ml: 0 }}
            control={
              <Checkbox
                size="small"
                checked={noteEditor?.sendMail ?? false}
                onChange={e =>
                  setNoteEditor(prev => (prev ? { ...prev, sendMail: e.target.checked } : prev))
                }
              />
            }
            label={
              <Typography variant="caption" sx={{ color: planAiColors.text.secondary }}>
                작성자에게 메일로 관리자 메모 알림 보내기
              </Typography>
            }
          />
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setNoteEditor(null)} sx={{ color: planAiColors.text.tertiary }}>
            취소
          </Button>
          <Button
            variant="contained"
            onClick={handleSaveNote}
            disabled={updateMut.isPending}
            sx={{ bgcolor: planAiColors.brand.primary }}
          >
            저장
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default VOCPage;
