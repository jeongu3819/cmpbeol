import React, { useEffect, useMemo, useState } from 'react';
import {
  Box,
  Typography,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Switch,
  Checkbox,
  Chip,
  TextField,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tooltip,
  Alert,
  FormControlLabel,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import GroupsIcon from '@mui/icons-material/Groups';
import LinkIcon from '@mui/icons-material/Link';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import SearchIcon from '@mui/icons-material/Search';
import CircularProgress from '@mui/material/CircularProgress';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api, User, Shortcut, Group, ShortcutVisibility, MemberGroup as MemberGroupT, UsageStats } from '../api/client';
import type {
  SystemEventLog,
  SystemHealth,
  SystemLogFilterSpec,
  SystemLogFilterPreview,
  VisionDiagnostic,
  PaginationMeta,
} from '../types';
import PaginationBar from '../components/common/PaginationBar';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Legend,
} from 'recharts';
import { useAppStore } from '../stores/useAppStore';
import { useUser } from '../context/UserContext'; // ✅ 현재 store에 me/loginid가 없으니 UserContext 사용
import AiContextInspector from '../components/admin/AiContextInspector'; // super_admin 전용 AI Context Inspector

const ICON_COLORS = [
  '#2955FF',
  '#22C55E',
  '#F59E0B',
  '#EF4444',
  '#8B5CF6',
  '#EC4899',
  '#14B8A6',
  '#F97316',
  '#6366F1',
  '#0EA5E9',
];

const ROLE_CONFIG: Record<string, { label: string; color: string; bgcolor: string }> = {
  super_admin: { label: 'Super Admin', color: '#9333EA', bgcolor: '#F3E8FF' },
  admin: { label: 'Admin', color: '#2955FF', bgcolor: '#DBEAFE' },
  manager: { label: '중간관리자', color: '#F59E0B', bgcolor: '#FEF3C7' },
  member: { label: 'Member', color: '#6B7280', bgcolor: '#F3F4F6' },
};

const normalize = (v?: string) =>
  String(v || '')
    .trim()
    .toLowerCase();

// ── 공간 현황(Tab 6) 표시용 헬퍼 ──
const SPACE_PURPOSE_LABELS: Record<string, string> = {
  project_management: '프로젝트 관리',
  equipment_ops: '설비 운영',
  process_change: '프로세스 변경',
  sw_dev: 'SW 개발',
  integrated_ops: '통합 운영',
  custom: '사용자 지정',
};

const fmtAdminDate = (iso?: string | null): string => {
  if (!iso) return '-';
  try {
    return new Date(iso).toLocaleDateString('ko-KR', { year: '2-digit', month: '2-digit', day: '2-digit' });
  } catch {
    return '-';
  }
};

const spaceStatusChipSx = (status: string): { color: string; bgcolor: string } => {
  switch (status) {
    case '활성': return { color: '#16A34A', bgcolor: '#DCFCE7' };
    case '빈 공간': return { color: '#B45309', bgcolor: '#FEF3C7' };
    case '경고 발송됨': return { color: '#B91C1C', bgcolor: '#FEE2E2' };
    case '보관됨': return { color: '#6B7280', bgcolor: '#F3F4F6' };
    default: return { color: '#6B7280', bgcolor: '#F3F4F6' };
  }
};

const LOG_LEVEL_COLOR: Record<string, { color: string; bgcolor: string }> = {
  INFO: { color: '#2563EB', bgcolor: '#DBEAFE' },
  WARNING: { color: '#B45309', bgcolor: '#FEF3C7' },
  ERROR: { color: '#B91C1C', bgcolor: '#FEE2E2' },
  CRITICAL: { color: '#FFFFFF', bgcolor: '#DC2626' },
};

const LOG_CATEGORY_COLOR: Record<string, string> = {
  API: '#6366F1',
  DB: '#0EA5E9',
  S3: '#14B8A6',
  KNOX: '#F59E0B',
  DSLLM: '#8B5CF6',
  BACKUP: '#22C55E',
  AUTH: '#EC4899',
  FRONTEND: '#6B7280',
  ADMIN: '#0F766E',
  VISION_AI: '#7C3AED',
};

const LOG_LEVELS = ['INFO', 'WARNING', 'ERROR', 'CRITICAL'];
const LOG_CATEGORIES = ['API', 'DB', 'S3', 'KNOX', 'DSLLM', 'BACKUP', 'AUTH', 'FRONTEND', 'ADMIN', 'VISION_AI'];

// VISION_AI 진단 요청 지표 표시 순서/라벨(§8-3). 값이 있는 항목만 노출.
const VISION_METRIC_FIELDS: Array<{ key: keyof NonNullable<VisionDiagnostic['details']>; label: string }> = [
  { key: 'project_id', label: 'project_id' },
  { key: 'canonical_image_id', label: 'canonical_image_id' },
  { key: 'image_count', label: 'image_count' },
  { key: 'mime', label: 'MIME' },
  { key: 'width', label: 'width' },
  { key: 'height', label: 'height' },
  { key: 'original_bytes', label: 'original_bytes' },
  { key: 'processed_bytes', label: 'processed_bytes' },
  { key: 'base64_chars', label: 'base64_chars' },
  { key: 'payload_bytes', label: 'payload_bytes' },
  { key: 'max_tokens', label: 'max_tokens' },
  { key: 'timeout_seconds', label: 'timeout_seconds' },
  { key: 'elapsed_ms', label: 'elapsed_ms' },
  { key: 'batch_index', label: 'batch_index' },
];

// §9 진단 정보 복사 텍스트(비민감 필드만). 백엔드 build_copy_text 와 형식을 맞춘다.
const buildVisionDiagCopyText = (log: SystemEventLog): string => {
  const d = log.diagnostic;
  if (!d) return '';
  const det = d.details || {};
  const dims =
    det.width != null && det.height != null ? `${det.width}x${det.height}` : null;
  const lines: Array<string | null> = [
    'Vision Report 진단',
    log.created_at ? `time=${log.created_at}` : null,
    log.request_id ? `request_id=${log.request_id}` : null,
    det.project_id != null ? `project_id=${det.project_id}` : null,
    `stage=${d.failure_stage ?? ''}`,
    `provider=${d.provider ?? ''}`,
    `model=${d.model ?? ''}`,
    `error_type=${d.error_type ?? ''}`,
    `http_status=${d.http_status != null ? d.http_status : 'none'}`,
    det.image_count != null ? `image_count=${det.image_count}` : null,
    det.mime ? `mime=${det.mime}` : null,
    dims ? `dimensions=${dims}` : null,
    det.processed_bytes != null ? `processed_bytes=${det.processed_bytes}` : null,
    det.payload_bytes != null ? `payload_bytes=${det.payload_bytes}` : null,
    det.timeout_seconds != null ? `timeout_seconds=${det.timeout_seconds}` : null,
    det.elapsed_ms != null ? `elapsed_ms=${det.elapsed_ms}` : null,
    d.summary ? `summary=${d.summary}` : null,
    d.recommended_action ? `recommended_action=${d.recommended_action}` : null,
  ];
  return lines.filter((l): l is string => !!l).join('\n');
};

const fmtDateTime = (iso?: string | null) => {
  if (!iso) return '-';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
};

const AdminPage: React.FC = () => {
  const queryClient = useQueryClient();
  const [tabIndex, setTabIndex] = useState(0);

  // ✅ 실제 로그인 사용자(UserContext) 기준
  const { user: me, loading: meLoading } = useUser();

  // ✅ store에는 currentUserId만 있음
  const storedCurrentUserId = useAppStore(state => state.currentUserId);
  const setCurrentUserId = useAppStore(state => state.setCurrentUserId);

  // ✅ users 목록은 화면 렌더 + loginid → id 매핑용
  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ['users'],
    queryFn: () => api.getUsers(),
    enabled: !meLoading, // me가 준비되면 호출
  });

  // ✅ 핵심: store id 우선, 없으면 me.loginid로 users에서 id 매핑
  const resolvedCurrentUserId = useMemo(() => {
    if (storedCurrentUserId && storedCurrentUserId > 0) return storedCurrentUserId;

    const myLogin = normalize(me?.loginid);
    if (!myLogin) return 0;

    const matched = users.find(u => normalize(u.loginid) === myLogin);
    return matched?.id ?? 0;
  }, [storedCurrentUserId, users, me?.loginid]);

  // ✅ 한번 매핑되면 store에 확정 저장(다음부터는 매핑 불필요)
  useEffect(() => {
    if (resolvedCurrentUserId > 0 && storedCurrentUserId !== resolvedCurrentUserId) {
      setCurrentUserId(resolvedCurrentUserId);
    }
  }, [resolvedCurrentUserId, storedCurrentUserId, setCurrentUserId]);

  // ✅ 권한 판단은 me.role 기반(가장 안전)
  const effectiveRole = normalize((me as any)?.role);
  const isAdminAccess = effectiveRole === 'admin' || effectiveRole === 'super_admin';
  const canChangeRoles = isAdminAccess;
  const isSuperAdmin = effectiveRole === 'super_admin';

  const requireAdminUserId = () => {
    if (!isAdminAccess) throw new Error('관리자 권한이 없습니다.');
    if (resolvedCurrentUserId <= 0)
      throw new Error('관리자 사용자 ID를 확인할 수 없습니다. (loginid → id 매핑 실패)');
    return resolvedCurrentUserId;
  };

  // ─── 구성원 관리 pagination/필터 상태 ───
  const [userListSearch, setUserListSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<string>('');
  const [userActiveFilter, setUserActiveFilter] = useState<'' | 'true' | 'false'>('');
  const [userPage, setUserPage] = useState(1);
  const [userPageSize, setUserPageSize] = useState(20);

  // 검색/필터/페이지크기 변경 시 page 1로 초기화
  useEffect(() => {
    setUserPage(1);
  }, [userListSearch, userRoleFilter, userActiveFilter, userPageSize]);

  // ─── Data queries ───
  const { data: adminUsersResp } = useQuery({
    queryKey: [
      'adminUsers',
      resolvedCurrentUserId,
      userListSearch,
      userRoleFilter,
      userActiveFilter,
      userPage,
      userPageSize,
    ],
    queryFn: () =>
      api.getAdminUsers(resolvedCurrentUserId, {
        page: userPage,
        page_size: userPageSize,
        search: userListSearch || undefined,
        role: userRoleFilter || undefined,
        active: userActiveFilter === '' ? undefined : userActiveFilter === 'true',
      }),
    enabled: isAdminAccess && resolvedCurrentUserId > 0, // ✅ 권한 + id 확인 후 호출
  });
  const adminUsers = adminUsersResp?.items ?? [];
  const userPagination = adminUsersResp?.pagination;

  const { data: groups = [] } = useQuery<Group[]>({
    queryKey: ['adminGroups', resolvedCurrentUserId],
    queryFn: () => api.getGroups(resolvedCurrentUserId),
    enabled: isAdminAccess && resolvedCurrentUserId > 0,
  });

  const { data: shortcuts = [] } = useQuery<Shortcut[]>({
    queryKey: ['shortcuts'],
    queryFn: () => api.getShortcuts(),
    enabled: isAdminAccess && resolvedCurrentUserId > 0,
  });

  // ─── Mutations ───
  const toggleActiveMut = useMutation({
    mutationFn: (targetId: number) => api.toggleUserActive(targetId, requireAdminUserId()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminUsers'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (err: any) => {
      alert(err?.response?.data?.detail || err?.message || '활성/비활성 변경 실패');
    },
  });

  const updateRoleMut = useMutation({
    mutationFn: ({ targetId, role }: { targetId: number; role: string }) =>
      api.updateUserRole(targetId, role, requireAdminUserId()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminUsers'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '역할 변경 실패');
    },
  });

  const deleteUserMut = useMutation({
    mutationFn: (targetId: number) => api.deleteAdminUser(targetId, requireAdminUserId()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminUsers'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '사용자 삭제 실패');
    },
  });

  const createGroupMut = useMutation({
    mutationFn: (data: { name: string }) => api.createGroup(data, requireAdminUserId()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['adminGroups'] }),
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '그룹 생성 실패');
    },
  });

  const deleteGroupMut = useMutation({
    mutationFn: (id: number) => api.deleteGroup(id, requireAdminUserId()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['adminGroups'] }),
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '그룹 삭제 실패');
    },
  });

  const applyGroupMut = useMutation({
    mutationFn: (id: number) => api.applyGroup(id, requireAdminUserId()),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['adminUsers'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
      if (data) alert(`${data.activated}명 활성화 (총 매칭: ${data.total_matched}명)`);
    },
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '그룹 적용 실패');
    },
  });

  const createShortcutMut = useMutation({
    mutationFn: (data: {
      name: string;
      url: string;
      icon_text?: string;
      icon_color?: string;
      order?: number;
      open_new_tab?: boolean;
      visibility?: ShortcutVisibility;
      shared_user_ids?: number[];
      shared_group_ids?: number[];
    }) => api.createShortcut(data, requireAdminUserId()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['shortcuts'] }),
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '바로가기 추가 실패');
    },
  });

  const updateShortcutMut = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<Shortcut> }) =>
      api.updateShortcut(id, data, requireAdminUserId()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['shortcuts'] }),
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '바로가기 수정 실패');
    },
  });

  const deleteShortcutMut = useMutation({
    mutationFn: (id: number) => api.deleteShortcut(id, requireAdminUserId()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['shortcuts'] }),
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '바로가기 삭제 실패');
    },
  });

  // ─── D-1: Create user mutation ───
  const createUserMut = useMutation({
    mutationFn: (data: { username: string; loginid: string; role?: string; deptname?: string; mail?: string }) =>
      api.createUser(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminUsers'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setCreateUserDialogOpen(false);
      setNewUsername('');
      setNewLoginId('');
      setNewUserRole('member');
      setNewDeptname('');
      setNewMail('');
    },
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '사용자 추가 실패');
    },
  });

  // ─── 시스템 로그 (Tab 3) state ───
  const [logLevel, setLogLevel] = useState('');
  const [logCategory, setLogCategory] = useState('');
  const [logDateFrom, setLogDateFrom] = useState('');
  const [logDateTo, setLogDateTo] = useState('');
  const [logUnresolvedOnly, setLogUnresolvedOnly] = useState(false);
  const [logKeyword, setLogKeyword] = useState('');
  const [logEndpoint, setLogEndpoint] = useState('');
  const [logStatusCode, setLogStatusCode] = useState('');
  const [logPage, setLogPage] = useState(1);
  const [logPageSize, setLogPageSize] = useState(50);
  const [selectedLog, setSelectedLog] = useState<SystemEventLog | null>(null);
  const [diagCopied, setDiagCopied] = useState(false);

  const copyVisionDiagnostic = async (log: SystemEventLog) => {
    try {
      await navigator.clipboard.writeText(buildVisionDiagCopyText(log));
      setDiagCopied(true);
      setTimeout(() => setDiagCopied(false), 1800);
    } catch {
      /* 클립보드 권한 없음 등 — 무시 */
    }
  };

  // 선택(체크박스) 상태
  const [selectedLogIds, setSelectedLogIds] = useState<number[]>([]);
  // 일괄 작업 모달: 'bulk-delete' | 'bulk-resolve' | 'filter-resolve' | 'filter-delete'
  const [logActionDialog, setLogActionDialog] = useState<null | {
    type: 'bulk-delete' | 'bulk-resolve' | 'filter-resolve' | 'filter-delete';
  }>(null);
  const [logActionReason, setLogActionReason] = useState('');
  const [filterDeleteConfirm, setFilterDeleteConfirm] = useState('');
  const [filterPreview, setFilterPreview] = useState<SystemLogFilterPreview | null>(null);
  const [filterPreviewLoading, setFilterPreviewLoading] = useState(false);

  const { data: systemHealth } = useQuery<SystemHealth>({
    queryKey: ['systemHealth', resolvedCurrentUserId],
    queryFn: () => api.getSystemHealth(resolvedCurrentUserId),
    enabled: tabIndex === 3 && isAdminAccess && resolvedCurrentUserId > 0,
    refetchInterval: tabIndex === 3 ? 30000 : false,
  });

  // ─── 사용 통계 (Tab 4): 방문 + 프로젝트/Task 생성 활동 ───
  const { data: visitStats, isLoading: visitStatsLoading } = useQuery<UsageStats>({
    queryKey: ['usageStats', resolvedCurrentUserId],
    queryFn: () => api.getUsageStats(resolvedCurrentUserId, 30),
    enabled: tabIndex === 4 && isAdminAccess && resolvedCurrentUserId > 0,
  });

  // ── 사내 추천 도구 (Tab 5) ──
  const { data: recoConfig } = useQuery({
    queryKey: ['adminInternalRecommendations', resolvedCurrentUserId],
    queryFn: () => api.adminGetInternalRecommendations(resolvedCurrentUserId),
    enabled: tabIndex === 5 && isAdminAccess && resolvedCurrentUserId > 0,
  });

  const recoFlagMut = useMutation({
    mutationFn: (enabled: boolean) =>
      api.adminSetInternalRecommendationFlag(enabled, resolvedCurrentUserId),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ['adminInternalRecommendations', resolvedCurrentUserId] }),
  });

  const recoItemMut = useMutation({
    mutationFn: ({ id, updates }: { id: number; updates: any }) =>
      api.adminUpdateInternalRecommendation(id, updates, resolvedCurrentUserId),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ['adminInternalRecommendations', resolvedCurrentUserId] }),
  });

  // ── 공간 현황 (Tab 6) ──
  const [spaceFilter, setSpaceFilter] = useState<string>('all');
  const [spaceSearch, setSpaceSearch] = useState('');
  const [spacePage, setSpacePage] = useState(1);
  const [spacePageSize, setSpacePageSize] = useState(20);
  const [spaceDeleteTarget, setSpaceDeleteTarget] = useState<import('../api/client').AdminSpaceRow | null>(null);
  const [spaceDeleteConfirm, setSpaceDeleteConfirm] = useState('');
  const [spaceActionError, setSpaceActionError] = useState<string | null>(null);

  // 필터/검색/페이지크기 변경 시 page 1로 초기화
  useEffect(() => {
    setSpacePage(1);
  }, [spaceFilter, spaceSearch, spacePageSize]);

  const { data: adminSpacesResp, isLoading: adminSpacesLoading } = useQuery({
    queryKey: ['adminSpaces', resolvedCurrentUserId, spaceFilter, spaceSearch, spacePage, spacePageSize],
    queryFn: () =>
      api.adminGetSpaces(resolvedCurrentUserId, {
        filter: spaceFilter,
        q: spaceSearch || undefined,
        page: spacePage,
        page_size: spacePageSize,
      }),
    enabled: tabIndex === 6 && isAdminAccess && resolvedCurrentUserId > 0,
  });
  const spacePagination = adminSpacesResp?.pagination;

  const invalidateSpaces = () =>
    queryClient.invalidateQueries({ queryKey: ['adminSpaces'] });

  const spaceActionMut = useMutation({
    mutationFn: async (args: { action: string; spaceId: number; confirm?: string }) => {
      const uid = resolvedCurrentUserId;
      switch (args.action) {
        case 'archive': return api.adminArchiveSpace(args.spaceId, uid);
        case 'restore': return api.adminRestoreSpace(args.spaceId, uid);
        case 'notify': return api.adminNotifySpaceOwner(args.spaceId, uid);
        case 'exempt': return api.adminToggleSpaceExempt(args.spaceId, uid);
        case 'extend': return api.adminExtendSpaceDelete(args.spaceId, uid, 30);
        case 'hard-delete': return api.adminHardDeleteSpace(args.spaceId, uid, args.confirm || '');
        default: throw new Error('unknown action');
      }
    },
    onSuccess: () => {
      invalidateSpaces();
      setSpaceDeleteTarget(null);
      setSpaceDeleteConfirm('');
      setSpaceActionError(null);
    },
    onError: (e: any) => {
      setSpaceActionError(e?.response?.data?.detail || '작업을 처리하지 못했습니다.');
    },
  });

  // 로그 필터/페이지크기 변경 시 page 1로 초기화
  useEffect(() => {
    setLogPage(1);
  }, [
    logLevel,
    logCategory,
    logDateFrom,
    logDateTo,
    logUnresolvedOnly,
    logKeyword,
    logEndpoint,
    logStatusCode,
    logPageSize,
  ]);

  const {
    data: systemLogsResp,
    isLoading: systemLogsLoading,
  } = useQuery<{ items: SystemEventLog[]; total: number; pagination: PaginationMeta }>({
    queryKey: [
      'systemLogs',
      resolvedCurrentUserId,
      logLevel,
      logCategory,
      logDateFrom,
      logDateTo,
      logUnresolvedOnly,
      logKeyword,
      logEndpoint,
      logStatusCode,
      logPage,
      logPageSize,
    ],
    queryFn: () =>
      api.getSystemLogs(resolvedCurrentUserId, {
        level: logLevel || undefined,
        category: logCategory || undefined,
        date_from: logDateFrom || undefined,
        date_to: logDateTo || undefined,
        resolved: logUnresolvedOnly ? false : undefined,
        keyword: logKeyword.trim() || undefined,
        endpoint: logEndpoint.trim() || undefined,
        status_code: logStatusCode.trim() ? Number(logStatusCode.trim()) : undefined,
        page: logPage,
        page_size: logPageSize,
      }),
    enabled: tabIndex === 3 && isAdminAccess && resolvedCurrentUserId > 0,
  });

  const systemLogs = systemLogsResp?.items || [];
  const logPagination = systemLogsResp?.pagination;

  // 현재 필터 바 → 서버 필터 스펙 (filter-resolve / filter-delete 공용)
  const currentLogFilterSpec = (): SystemLogFilterSpec => ({
    level: logLevel || undefined,
    category: logCategory || undefined,
    endpoint: logEndpoint.trim() || undefined,
    status_code: logStatusCode.trim() ? Number(logStatusCode.trim()) : undefined,
    search: logKeyword.trim() || undefined,
    date_from: logDateFrom || undefined,
    date_to: logDateTo || undefined,
    resolved: logUnresolvedOnly ? false : undefined,
  });

  const hasAnyLogFilter =
    !!(logLevel || logCategory || logEndpoint.trim() || logStatusCode.trim() ||
       logKeyword.trim() || logDateFrom || logDateTo || logUnresolvedOnly);

  const resetLogSelection = () => setSelectedLogIds([]);
  const closeLogActionDialog = () => {
    setLogActionDialog(null);
    setLogActionReason('');
    setFilterDeleteConfirm('');
    setFilterPreview(null);
  };

  const resolveLogMut = useMutation({
    mutationFn: ({ id, resolved }: { id: number; resolved: boolean }) =>
      api.resolveSystemLog(id, requireAdminUserId(), resolved),
    onSuccess: updated => {
      queryClient.invalidateQueries({ queryKey: ['systemLogs'] });
      queryClient.invalidateQueries({ queryKey: ['systemHealth'] });
      setSelectedLog(prev => (prev && prev.id === updated.id ? updated : prev));
    },
    onError: (err: any) => {
      alert(err?.response?.data?.detail || '처리 상태 변경 실패');
    },
  });

  const afterLogMutation = (msg?: string) => {
    queryClient.invalidateQueries({ queryKey: ['systemLogs'] });
    queryClient.invalidateQueries({ queryKey: ['systemHealth'] });
    resetLogSelection();
    closeLogActionDialog();
    if (msg) alert(msg);
  };

  const bulkResolveMut = useMutation({
    mutationFn: () =>
      api.bulkResolveSystemLogs(requireAdminUserId(), selectedLogIds, true, {
        resolution_note: logActionReason.trim() || undefined,
      }),
    onSuccess: res => afterLogMutation(`${res.updated}건을 해결 처리했습니다.`),
    onError: (err: any) => alert(err?.response?.data?.detail || '해결 처리 실패'),
  });

  const bulkDeleteMut = useMutation({
    mutationFn: () =>
      api.bulkDeleteSystemLogs(requireAdminUserId(), selectedLogIds, logActionReason.trim() || undefined),
    onSuccess: res => afterLogMutation(`${res.deleted}건을 삭제했습니다.`),
    onError: (err: any) => alert(err?.response?.data?.detail || '삭제 실패'),
  });

  const filterResolveMut = useMutation({
    mutationFn: () =>
      api.filterResolveSystemLogs(requireAdminUserId(), currentLogFilterSpec(), {
        resolution_note: logActionReason.trim() || undefined,
      }),
    onSuccess: res => afterLogMutation(`${res.updated}건을 해결 처리했습니다.`),
    onError: (err: any) => alert(err?.response?.data?.detail || '해결 처리 실패'),
  });

  const filterDeleteMut = useMutation({
    mutationFn: () =>
      api.filterDeleteSystemLogs(
        requireAdminUserId(),
        currentLogFilterSpec(),
        filterDeleteConfirm.trim(),
        logActionReason.trim() || undefined
      ),
    onSuccess: res => afterLogMutation(`${res.deleted}건을 삭제했습니다.`),
    onError: (err: any) => alert(err?.response?.data?.detail || '삭제 실패'),
  });

  const deleteSingleMut = useMutation({
    mutationFn: (id: number) => api.deleteSystemLog(id, requireAdminUserId()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['systemLogs'] });
      queryClient.invalidateQueries({ queryKey: ['systemHealth'] });
      setSelectedLogIds(prev => prev.filter(id => id !== selectedLog?.id));
      setSelectedLog(null);
    },
    onError: (err: any) => alert(err?.response?.data?.detail || '삭제 실패'),
  });

  // 필터 결과 삭제 모달 열 때 preview count 먼저 조회
  const openFilterDeleteDialog = async () => {
    if (!hasAnyLogFilter) {
      alert('필터를 1개 이상 지정해야 필터 결과 삭제를 사용할 수 있습니다.');
      return;
    }
    setLogActionDialog({ type: 'filter-delete' });
    setFilterPreviewLoading(true);
    setFilterPreview(null);
    try {
      const preview = await api.filterDeletePreviewSystemLogs(
        requireAdminUserId(),
        currentLogFilterSpec()
      );
      setFilterPreview(preview);
    } catch (err: any) {
      alert(err?.response?.data?.detail || '미리보기 조회 실패');
      closeLogActionDialog();
    } finally {
      setFilterPreviewLoading(false);
    }
  };

  // ─── Local state ───
  const [userSearch, setUserSearch] = useState('');
  const [groupDialogOpen, setGroupDialogOpen] = useState(false);
  const [groupName, setGroupName] = useState('');

  // D-1: Create user dialog state
  const [createUserDialogOpen, setCreateUserDialogOpen] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newLoginId, setNewLoginId] = useState('');
  const [newUserRole, setNewUserRole] = useState('member');
  const [newDeptname, setNewDeptname] = useState('');
  const [newMail, setNewMail] = useState('');

  // D-2: Knox search state (Tab 0 inline)
  const [knoxSearch, setKnoxSearch] = useState('');
  const [knoxResults, setKnoxResults] = useState<any[]>([]);
  const [knoxSearching, setKnoxSearching] = useState(false);

  // Knox search in create user dialog
  const [dialogKnoxQuery, setDialogKnoxQuery] = useState('');
  const [dialogKnoxResults, setDialogKnoxResults] = useState<any[]>([]);
  const [dialogKnoxSearching, setDialogKnoxSearching] = useState(false);

  const handleDialogKnoxSearch = async () => {
    if (!dialogKnoxQuery.trim()) return;
    setDialogKnoxSearching(true);
    try {
      const results = await api.searchKnoxEmployees({ query: dialogKnoxQuery.trim() });
      setDialogKnoxResults(results);
    } catch {
      setDialogKnoxResults([]);
    } finally {
      setDialogKnoxSearching(false);
    }
  };

  // Knox search for group management (Tab 1)
  const [groupKnoxQuery, setGroupKnoxQuery] = useState('');
  const [groupKnoxResults, setGroupKnoxResults] = useState<any[]>([]);
  const [groupKnoxSearching, setGroupKnoxSearching] = useState(false);

  const handleGroupKnoxSearch = async () => {
    if (!groupKnoxQuery.trim()) return;
    setGroupKnoxSearching(true);
    try {
      const results = await api.searchKnoxEmployees({ query: groupKnoxQuery.trim() });
      // Extract unique department names from results
      setGroupKnoxResults(results);
    } catch {
      setGroupKnoxResults([]);
    } finally {
      setGroupKnoxSearching(false);
    }
  };

  const handleKnoxSearch = async (searchOverride?: string) => {
    const query = searchOverride || knoxSearch || userSearch;
    if (!query.trim()) return;
    setKnoxSearch(query.trim());
    setKnoxSearching(true);
    try {
      const results = await api.searchKnoxEmployees({ query: query.trim() });
      setKnoxResults(results);
    } catch (err: any) {
      alert(err?.response?.data?.detail || 'Knox 검색 실패');
      setKnoxResults([]);
    } finally {
      setKnoxSearching(false);
    }
  };

  const addFromKnoxMut = useMutation({
    mutationFn: (data: { username: string; loginid: string; deptname?: string; mail?: string }) =>
      api.createUser({ ...data, role: 'member' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminUsers'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
    onError: (err: any) => {
      alert(err?.response?.data?.detail || 'Knox 사용자 추가 실패');
    },
  });
  const [shortcutDialogOpen, setShortcutDialogOpen] = useState(false);
  const [editingShortcut, setEditingShortcut] = useState<Shortcut | null>(null);
  const [scName, setScName] = useState('');
  const [scUrl, setScUrl] = useState('');
  const [scIconColor, setScIconColor] = useState('#2955FF');
  const [scIconText, setScIconText] = useState('');
  const [scOpenNewTab, setScOpenNewTab] = useState(true);
  const [scVisibility, setScVisibility] = useState<ShortcutVisibility>('PRIVATE');
  const [scSharedUserIds, setScSharedUserIds] = useState<number[]>([]);
  const [scSharedGroupIds, setScSharedGroupIds] = useState<number[]>([]);
  const [scUserSearch, setScUserSearch] = useState('');
  const [scUserResults, setScUserResults] = useState<any[]>([]);
  const [scUserSearchTimer, setScUserSearchTimer] = useState<any>(null);

  const adminUserId = (me as any)?.user_id;
  const { data: memberGroupsForSc = [] } = useQuery<MemberGroupT[]>({
    queryKey: ['memberGroups', adminUserId],
    queryFn: () => api.getMemberGroups(adminUserId),
    enabled: !!adminUserId,
  });

  const debouncedScUserSearch = (q: string) => {
    setScUserSearch(q);
    if (scUserSearchTimer) clearTimeout(scUserSearchTimer);
    if (q.trim().length < 2) { setScUserResults([]); return; }
    setScUserSearchTimer(setTimeout(async () => {
      try {
        const results = await api.searchUsers(q.trim(), adminUserId);
        setScUserResults(results);
      } catch { setScUserResults([]); }
    }, 250));
  };

  // 검색어 입력 → server-side 목록 검색으로 debounce 전달 (Enter 는 Knox 사내 검색용으로 별도 유지)
  useEffect(() => {
    const t = setTimeout(() => setUserListSearch(userSearch.trim()), 300);
    return () => clearTimeout(t);
  }, [userSearch]);

  const openShortcutDialog = (sc?: Shortcut) => {
    if (sc) {
      setEditingShortcut(sc);
      setScName(sc.name);
      setScUrl(sc.url);
      setScIconColor(sc.icon_color || '#2955FF');
      setScIconText(sc.icon_text || '');
      setScOpenNewTab(sc.open_new_tab !== false);
      setScVisibility((sc.visibility as ShortcutVisibility) || 'PRIVATE');
      setScSharedUserIds(sc.shared_user_ids || []);
      setScSharedGroupIds(sc.shared_group_ids || []);
    } else {
      setEditingShortcut(null);
      setScName('');
      setScUrl('');
      setScIconColor(ICON_COLORS[Math.floor(Math.random() * ICON_COLORS.length)]);
      setScIconText('');
      setScOpenNewTab(true);
      setScVisibility('PRIVATE');
      setScSharedUserIds([]);
      setScSharedGroupIds([]);
    }
    setScUserSearch('');
    setScUserResults([]);
    setShortcutDialogOpen(true);
  };

  const handleSaveShortcut = () => {
    if (!scName.trim() || !scUrl.trim()) return;
    const url = scUrl.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      alert('URL은 http:// 또는 https://로 시작해야 합니다.');
      return;
    }
    const visPayload: {
      visibility: ShortcutVisibility;
      shared_user_ids?: number[];
      shared_group_ids?: number[];
    } = {
      visibility: scVisibility,
      shared_user_ids: scVisibility === 'SHARED_USERS' ? scSharedUserIds : [],
      shared_group_ids: scVisibility === 'SHARED_GROUPS' ? scSharedGroupIds : [],
    };
    if (editingShortcut) {
      updateShortcutMut.mutate({
        id: editingShortcut.id,
        data: {
          name: scName.trim(),
          url,
          icon_text: scIconText.trim() || scName.trim()[0].toUpperCase(),
          icon_color: scIconColor,
          open_new_tab: scOpenNewTab,
          ...visPayload,
        },
      });
    } else {
      createShortcutMut.mutate({
        name: scName.trim(),
        url,
        icon_text: scIconText.trim() || undefined,
        icon_color: scIconColor,
        open_new_tab: scOpenNewTab,
        ...visPayload,
      });
    }
    setShortcutDialogOpen(false);
  };

  const handleCreateGroup = () => {
    if (!groupName.trim()) return;
    createGroupMut.mutate({ name: groupName.trim() });
    setGroupDialogOpen(false);
    setGroupName('');
  };

  // ✅ 로딩 처리
  if (meLoading || usersLoading) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <Typography variant="body2" sx={{ color: '#6B7280' }}>
          사용자 정보 확인 중...
        </Typography>
      </Box>
    );
  }

  // ✅ me 없으면 (UserProvider가 리다이렉트 처리하는 경우)
  if (!me) return null;

  // ✅ 매핑 실패 알림
  const mappingFailed = normalize(me?.loginid) && users.length > 0 && resolvedCurrentUserId <= 0;

  // ✅ 권한 없는 경우 안내
  if (!isAdminAccess) {
    return (
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <Alert severity="warning" sx={{ maxWidth: 520, mx: 'auto', textAlign: 'left' }}>
          관리자 권한이 없습니다. (role: <strong>{String((me as any)?.role || '')}</strong>)
        </Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3, width: '100%', maxWidth: '100%', minWidth: 0, boxSizing: 'border-box' }}>
      <Typography variant="h5" sx={{ fontWeight: 800, mb: 0.5, color: '#1A1D29' }}>
        관리자 페이지
      </Typography>
      <Typography variant="body2" sx={{ color: '#6B7280', mb: 2 }}>
        사이트 구성원, 그룹, 바로가기를 관리합니다.
      </Typography>

      {mappingFailed && (
        <Alert severity="error" sx={{ borderRadius: 2, mb: 2 }}>
          현재 로그인 사용자(loginid)와 users 목록 매핑에 실패했습니다. <br />
          <strong>me.loginid</strong> / <strong>users.loginid</strong> 값 확인이 필요합니다.
        </Alert>
      )}

      <Tabs
        value={tabIndex}
        onChange={(_, v) => setTabIndex(v)}
        variant="scrollable"
        scrollButtons="auto"
        allowScrollButtonsMobile
        sx={{
          mb: 3,
          '& .MuiTab-root': { textTransform: 'none', fontWeight: 600, fontSize: '0.9rem' },
        }}
      >
        <Tab label="구성원 관리" />
        <Tab label="그룹 관리" />
        <Tab label="바로가기 관리" />
        <Tab label="시스템 로그" />
        <Tab label="사용 통계" />
        <Tab label="추천 도구" />
        <Tab label="공간 현황" />
        {isSuperAdmin && <Tab label="AI Context" />}
      </Tabs>

      {/* ── Tab 0: User Management ── */}
      {tabIndex === 0 && (
        <Box>
          {/* D-1: Role descriptions */}
          <Alert severity="info" sx={{ borderRadius: 2, mb: 2, fontSize: '0.85rem' }}>
            <strong>역할 설명:</strong><br />
            <strong>Super Admin</strong> — 전체 시스템 관리 (사용자/그룹/설정 등 모든 권한)<br />
            <strong>Admin</strong> — 사이트 관리 (프로젝트/구성원 관리)<br />
            <strong>Member</strong> — 일반 사용자 (프로젝트별 역할은 프로젝트 Settings에서 관리)
          </Alert>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2, flexWrap: 'wrap' }}>
            <TextField
              size="small"
              placeholder="이름 또는 ID로 검색 (Enter: Knox 사내 검색)"
              value={userSearch}
              onChange={e => setUserSearch(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && userSearch.trim()) {
                  handleKnoxSearch();
                }
              }}
              sx={{ width: 380 }}
            />
            <Button
              variant="outlined"
              size="small"
              startIcon={knoxSearching ? <CircularProgress size={16} /> : <SearchIcon />}
              onClick={() => { if (userSearch.trim()) handleKnoxSearch(userSearch.trim()); }}
              disabled={knoxSearching || !userSearch.trim()}
              sx={{ textTransform: 'none', fontWeight: 600 }}
            >
              Knox 검색
            </Button>
            <TextField
              select
              size="small"
              label="역할"
              value={userRoleFilter}
              onChange={e => setUserRoleFilter(e.target.value)}
              sx={{ minWidth: 130 }}
            >
              <MenuItem value="">전체 역할</MenuItem>
              <MenuItem value="super_admin">Super Admin</MenuItem>
              <MenuItem value="admin">Admin</MenuItem>
              <MenuItem value="manager">중간관리자</MenuItem>
              <MenuItem value="member">Member</MenuItem>
            </TextField>
            <TextField
              select
              size="small"
              label="상태"
              value={userActiveFilter}
              onChange={e => setUserActiveFilter(e.target.value as '' | 'true' | 'false')}
              sx={{ minWidth: 120 }}
            >
              <MenuItem value="">전체 상태</MenuItem>
              <MenuItem value="true">활성</MenuItem>
              <MenuItem value="false">비활성</MenuItem>
            </TextField>
            <Box sx={{ flexGrow: 1 }} />
            <Button
              variant="contained"
              size="small"
              startIcon={<PersonAddIcon />}
              onClick={() => setCreateUserDialogOpen(true)}
              sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
            >
              구성원 추가
            </Button>
          </Box>

          <TableContainer
            component={Paper}
            sx={{ borderRadius: 2, border: '1px solid #E5E7EB' }}
            elevation={0}
          >
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: '#F9FAFB' }}>
                  <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>사용자</TableCell>
                  <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>Login ID</TableCell>
                  <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>소속그룹</TableCell>
                  <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>메일</TableCell>
                  <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>역할</TableCell>
                  <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>상태</TableCell>
                  <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }} align="center">
                    활성/비활성
                  </TableCell>
                  <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }} align="center">
                    삭제
                  </TableCell>
                </TableRow>
              </TableHead>

              <TableBody>
                {adminUsers.map(user => (
                  <TableRow key={user.id} hover>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Box
                          sx={{
                            width: 28,
                            height: 28,
                            borderRadius: '50%',
                            bgcolor: user.avatar_color || '#2955FF',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: '#fff',
                            fontSize: '0.7rem',
                            fontWeight: 700,
                          }}
                        >
                          {String(user.username || '?')
                            .charAt(0)
                            .toUpperCase()}
                        </Box>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>
                          {user.username}
                        </Typography>
                      </Box>
                    </TableCell>

                    <TableCell>
                      <Typography variant="body2" sx={{ color: '#6B7280' }}>
                        {user.loginid}
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography
                        variant="body2"
                        sx={{ color: user.deptname ? '#374151' : '#9CA3AF', fontSize: '0.8rem' }}
                      >
                        {user.deptname || '-'}
                      </Typography>
                    </TableCell>

                    <TableCell>
                      <Typography
                        variant="body2"
                        sx={{ color: user.mail ? '#374151' : '#9CA3AF', fontSize: '0.8rem' }}
                      >
                        {user.mail || '-'}
                      </Typography>
                    </TableCell>

                    <TableCell>
                      {canChangeRoles && user.id !== resolvedCurrentUserId ? (
                        <Select
                          value={user.role || 'member'}
                          size="small"
                          onChange={e =>
                            updateRoleMut.mutate({
                              targetId: user.id,
                              role: String(e.target.value),
                            })
                          }
                          sx={{
                            height: 28,
                            fontSize: '0.75rem',
                            fontWeight: 600,
                            bgcolor: ROLE_CONFIG[user.role || 'member']?.bgcolor || '#F3F4F6',
                            color: ROLE_CONFIG[user.role || 'member']?.color || '#6B7280',
                            '& .MuiSelect-select': { py: 0.3, px: 1 },
                            '& .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent' },
                            '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#C7D2FE' },
                            borderRadius: 2,
                          }}
                        >
                          <MenuItem value="member" sx={{ fontSize: '0.8rem' }}>
                            Member
                          </MenuItem>
                          {isSuperAdmin && (
                            <MenuItem value="admin" sx={{ fontSize: '0.8rem' }}>
                              Admin
                            </MenuItem>
                          )}
                          {isSuperAdmin && (
                            <MenuItem value="super_admin" sx={{ fontSize: '0.8rem' }}>
                              Super Admin
                            </MenuItem>
                          )}
                        </Select>
                      ) : (
                        <Chip
                          label={ROLE_CONFIG[user.role || 'member']?.label || user.role || 'member'}
                          size="small"
                          sx={{
                            fontWeight: 600,
                            fontSize: '0.7rem',
                            bgcolor: ROLE_CONFIG[user.role || 'member']?.bgcolor || '#F3F4F6',
                            color: ROLE_CONFIG[user.role || 'member']?.color || '#6B7280',
                          }}
                        />
                      )}
                    </TableCell>

                    <TableCell>
                      <Chip
                        label={user.is_active !== false ? '활성' : '비활성'}
                        size="small"
                        sx={{
                          fontWeight: 600,
                          fontSize: '0.7rem',
                          bgcolor: user.is_active !== false ? '#DCFCE7' : '#FEE2E2',
                          color: user.is_active !== false ? '#22C55E' : '#EF4444',
                        }}
                      />
                    </TableCell>

                    <TableCell align="center">
                      <Switch
                        checked={user.is_active !== false}
                        onChange={() => toggleActiveMut.mutate(user.id)}
                        disabled={
                          user.role === 'admin' ||
                          user.role === 'super_admin' ||
                          user.id === resolvedCurrentUserId
                        }
                        size="small"
                      />
                    </TableCell>
                    <TableCell align="center">
                      <Tooltip title="비활성화 (접근 차단)">
                        <span>
                          <IconButton
                            size="small"
                            color="error"
                            disabled={
                              user.role === 'super_admin' ||
                              user.id === resolvedCurrentUserId ||
                              deleteUserMut.isPending
                            }
                            onClick={() => {
                              if (window.confirm(`"${user.username}" 사용자를 삭제하시겠습니까?\n관련 데이터가 모두 삭제됩니다.`)) {
                                deleteUserMut.mutate(user.id);
                              }
                            }}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </span>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {userPagination && userPagination.total > 0 && (
            <PaginationBar
              page={userPagination.page}
              pageSize={userPagination.page_size}
              total={userPagination.total}
              totalPages={userPagination.total_pages}
              onPageChange={setUserPage}
              onPageSizeChange={setUserPageSize}
              unitLabel="명"
            />
          )}

          {/* Knox 검색 결과 (사용자 테이블 바로 아래) */}
          {knoxResults.length > 0 && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#5B21B6' }}>
                Knox 사내 검색 결과 ({knoxResults.length}명) — "{knoxSearch}"
              </Typography>
              <TableContainer
                component={Paper}
                sx={{ borderRadius: 2, border: '1px solid #E5E7EB' }}
                elevation={0}
              >
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ bgcolor: '#F5F3FF' }}>
                      <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>이름</TableCell>
                      <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>ID</TableCell>
                      <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>부서</TableCell>
                      <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }} align="center">작업</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {knoxResults.map((emp: any, idx: number) => {
                      const loginid = (emp.loginid || emp.login_id || emp.id || '').toString().toLowerCase();
                      const isRegistered = users.some(
                        u => (u.loginid || '').toLowerCase() === loginid
                      );
                      return (
                        <TableRow key={idx} hover>
                          <TableCell>
                            <Typography variant="body2" sx={{ fontWeight: 500 }}>
                              {emp.fullName || emp.username || emp.name || '-'}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" sx={{ color: '#6B7280' }}>
                              {loginid}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" sx={{ color: '#6B7280', fontSize: '0.8rem' }}>
                              {emp.deptName || emp.deptname || emp.department || '-'}
                            </Typography>
                          </TableCell>
                          <TableCell align="center">
                            {isRegistered ? (
                              <Chip
                                label="등록됨"
                                size="small"
                                sx={{ fontSize: '0.7rem', fontWeight: 600, bgcolor: '#DCFCE7', color: '#22C55E' }}
                              />
                            ) : (
                              <Button
                                size="small"
                                variant="outlined"
                                startIcon={<AddIcon />}
                                onClick={() =>
                                  addFromKnoxMut.mutate({
                                    username: emp.fullName || emp.username || emp.name || loginid,
                                    loginid,
                                    deptname: emp.deptName || emp.deptname || emp.department || undefined,
                                    mail: emp.email || emp.mail || undefined,
                                  })
                                }
                                disabled={addFromKnoxMut.isPending}
                                sx={{ textTransform: 'none', fontSize: '0.75rem' }}
                              >
                                추가
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          )}
        </Box>
      )}

      {/* ── Tab 1: Group Management ── */}
      {tabIndex === 1 && (
        <Box>
          <Alert severity="info" sx={{ borderRadius: 2, mb: 2, fontSize: '0.85rem' }}>
            <strong>부서 기반 자동 접근 허용:</strong> 부서명(예: ETCH기술팀)을 등록하면,
            해당 부서 소속 사용자가 SSO 로그인 시 자동으로 계정이 생성되고 접근 권한이 부여됩니다.<br />
            사용자의 SSO <strong>deptname</strong> 필드와 등록된 그룹명이 일치하면 자동 매칭됩니다.
            개별 사용자는 &quot;구성원 관리&quot; 탭에서 별도로 등록할 수 있습니다.
          </Alert>

          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
              등록된 그룹 목록
            </Typography>
            <Button
              startIcon={<AddIcon />}
              variant="contained"
              size="small"
              onClick={() => setGroupDialogOpen(true)}
              sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
            >
              그룹 등록
            </Button>
          </Box>

          {/* Knox 부서/그룹 검색 */}
          <Paper sx={{ p: 2, mb: 2, borderRadius: 2, border: '1px solid #E5E7EB' }} elevation={0}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#5B21B6' }}>
              Knox 사내 부서 검색
            </Typography>
            <Typography variant="body2" sx={{ color: '#6B7280', fontSize: '0.8rem', mb: 1.5 }}>
              사내 구성원을 검색하여 부서명을 확인한 뒤, 해당 부서를 그룹으로 등록하세요.
              등록된 부서 소속 사용자는 SSO 로그인 시 자동으로 접근이 허용됩니다.
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
              <TextField
                size="small"
                placeholder="사내 이름으로 검색..."
                value={groupKnoxQuery}
                onChange={e => setGroupKnoxQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleGroupKnoxSearch()}
                sx={{ width: 300 }}
              />
              <Button
                variant="outlined"
                size="small"
                startIcon={groupKnoxSearching ? <CircularProgress size={14} /> : <SearchIcon />}
                onClick={handleGroupKnoxSearch}
                disabled={groupKnoxSearching || !groupKnoxQuery.trim()}
                sx={{ textTransform: 'none', fontWeight: 600 }}
              >
                검색
              </Button>
            </Box>
            {groupKnoxResults.length > 0 && (() => {
              // Extract unique departments
              const deptSet = new Map<string, number>();
              groupKnoxResults.forEach((emp: any) => {
                const dept = emp.deptName || emp.deptname || emp.department || '';
                if (dept) deptSet.set(dept, (deptSet.get(dept) || 0) + 1);
              });
              const depts = Array.from(deptSet.entries());
              return (
                <Box>
                  <Typography variant="caption" sx={{ color: '#6B7280', mb: 1, display: 'block' }}>
                    검색된 부서 ({depts.length}개)
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 1.5 }}>
                    {depts.map(([dept, count]) => {
                      const alreadyExists = groups.some(g => g.name === dept);
                      return (
                        <Chip
                          key={dept}
                          label={`${dept} (${count}명)`}
                          size="small"
                          onClick={() => {
                            if (!alreadyExists) {
                              setGroupName(dept);
                              setGroupDialogOpen(true);
                            }
                          }}
                          sx={{
                            cursor: alreadyExists ? 'default' : 'pointer',
                            fontWeight: 600,
                            fontSize: '0.75rem',
                            bgcolor: alreadyExists ? '#DCFCE7' : '#EDE9FE',
                            color: alreadyExists ? '#22C55E' : '#7C3AED',
                            border: alreadyExists ? '1px solid #22C55E40' : '1px solid #8B5CF640',
                            '&:hover': alreadyExists ? {} : { bgcolor: '#DDD6FE' },
                          }}
                          deleteIcon={alreadyExists ? undefined : <AddIcon sx={{ fontSize: '14px !important' }} />}
                          onDelete={alreadyExists ? undefined : () => {
                            setGroupName(dept);
                            setGroupDialogOpen(true);
                          }}
                        />
                      );
                    })}
                  </Box>
                  <Typography variant="caption" sx={{ color: '#6B7280', mb: 1, display: 'block' }}>
                    검색된 구성원 ({groupKnoxResults.length}명)
                  </Typography>
                  <TableContainer component={Paper} sx={{ borderRadius: 1, border: '1px solid #E5E7EB', maxHeight: 200 }} elevation={0}>
                    <Table size="small">
                      <TableHead>
                        <TableRow sx={{ bgcolor: '#F5F3FF' }}>
                          <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>이름</TableCell>
                          <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>ID</TableCell>
                          <TableCell sx={{ fontWeight: 600, fontSize: '0.75rem' }}>부서</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {groupKnoxResults.slice(0, 20).map((emp: any, idx: number) => (
                          <TableRow key={idx}>
                            <TableCell sx={{ fontSize: '0.8rem' }}>{emp.fullName || emp.username || emp.name || '-'}</TableCell>
                            <TableCell sx={{ fontSize: '0.8rem', color: '#6B7280' }}>{(emp.loginid || emp.login_id || emp.id || '').toString().toLowerCase()}</TableCell>
                            <TableCell sx={{ fontSize: '0.8rem', color: '#6B7280' }}>{emp.deptName || emp.deptname || emp.department || '-'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              );
            })()}
          </Paper>

          {groups.length === 0 ? (
            <Alert severity="warning" sx={{ borderRadius: 2 }}>
              등록된 그룹이 없습니다. 회사 조직/그룹명을 등록하세요.
            </Alert>
          ) : (
            <TableContainer
              component={Paper}
              sx={{ borderRadius: 2, border: '1px solid #E5E7EB' }}
              elevation={0}
            >
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: '#F9FAFB' }}>
                    <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>그룹명</TableCell>
                    <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }} align="center">
                      매칭 인원
                    </TableCell>
                    <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }}>등록일</TableCell>
                    <TableCell sx={{ fontWeight: 600, fontSize: '0.8rem' }} align="center">
                      작업
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {groups.map(group => (
                    <TableRow key={group.id} hover>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <GroupsIcon sx={{ color: '#8B5CF6', fontSize: 20 }} />
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {group.name}
                          </Typography>
                        </Box>
                      </TableCell>

                      <TableCell align="center">
                        <Chip
                          label={`${group.matched_count || 0}명`}
                          size="small"
                          sx={{
                            fontWeight: 600,
                            fontSize: '0.7rem',
                            bgcolor: (group.matched_count || 0) > 0 ? '#DCFCE7' : '#FEF3C7',
                            color: (group.matched_count || 0) > 0 ? '#22C55E' : '#D97706',
                          }}
                        />
                      </TableCell>

                      <TableCell>
                        <Typography variant="body2" sx={{ color: '#9CA3AF', fontSize: '0.8rem' }}>
                          {group.created_at
                            ? new Date(group.created_at).toLocaleDateString('ko-KR')
                            : '-'}
                        </Typography>
                      </TableCell>

                      <TableCell align="center">
                        <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center' }}>
                          <Tooltip title="그룹 소속 사용자 일괄 활성화">
                            <IconButton
                              size="small"
                              onClick={() => applyGroupMut.mutate(group.id)}
                              color="primary"
                            >
                              <PlayArrowIcon sx={{ fontSize: 18 }} />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title="삭제">
                            <IconButton
                              size="small"
                              onClick={() => deleteGroupMut.mutate(group.id)}
                              color="error"
                            >
                              <DeleteIcon sx={{ fontSize: 18 }} />
                            </IconButton>
                          </Tooltip>
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Box>
      )}

      {/* ── Tab 2: Shortcut Management ── */}
      {tabIndex === 2 && (
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
              바로가기 목록
            </Typography>
            <Button
              startIcon={<AddIcon />}
              variant="contained"
              size="small"
              onClick={() => openShortcutDialog()}
              sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
            >
              바로가기 추가
            </Button>
          </Box>

          {shortcuts.length === 0 ? (
            <Alert severity="info" sx={{ borderRadius: 2 }}>
              등록된 바로가기가 없습니다.
            </Alert>
          ) : (
            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              {shortcuts
                .slice()
                .sort((a, b) => (a.order || 0) - (b.order || 0))
                .map(sc => (
                  <Paper
                    key={sc.id}
                    sx={{
                      p: 2,
                      borderRadius: 2,
                      border: '1px solid #E5E7EB',
                      width: 200,
                      position: 'relative',
                    }}
                    elevation={0}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
                      <Box
                        sx={{
                          width: 44,
                          height: 44,
                          borderRadius: 2,
                          bgcolor: sc.icon_color || '#2955FF',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: '#fff',
                          fontWeight: 800,
                          fontSize: '1.1rem',
                        }}
                      >
                        {sc.icon_text || sc.name.charAt(0).toUpperCase()}
                      </Box>

                      <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                        <Typography
                          variant="body2"
                          sx={{ fontWeight: 600, fontSize: '0.85rem' }}
                          noWrap
                        >
                          {sc.name}
                        </Typography>
                        <Typography
                          variant="caption"
                          sx={{
                            color: '#9CA3AF',
                            fontSize: '0.6rem',
                            display: 'flex',
                            alignItems: 'center',
                            gap: 0.3,
                          }}
                        >
                          <LinkIcon sx={{ fontSize: 10 }} />{' '}
                          {sc.url.replace(/^https?:\/\//, '').substring(0, 20)}
                        </Typography>
                      </Box>
                    </Box>

                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 0.5 }}>
                      <Chip
                        label={sc.active ? '활성' : '비활성'}
                        size="small"
                        sx={{
                          fontSize: '0.6rem',
                          fontWeight: 600,
                          bgcolor: sc.active ? '#DCFCE7' : '#FEE2E2',
                          color: sc.active ? '#22C55E' : '#EF4444',
                        }}
                      />
                      <IconButton size="small" onClick={() => openShortcutDialog(sc)}>
                        <EditIcon sx={{ fontSize: 16 }} />
                      </IconButton>
                      <IconButton
                        size="small"
                        onClick={() => deleteShortcutMut.mutate(sc.id)}
                        color="error"
                      >
                        <DeleteIcon sx={{ fontSize: 16 }} />
                      </IconButton>
                    </Box>
                  </Paper>
                ))}
            </Box>
          )}
        </Box>
      )}

      {/* ── Group Dialog ── */}
      <Dialog
        open={groupDialogOpen}
        onClose={() => setGroupDialogOpen(false)}
        maxWidth="xs"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <DialogTitle sx={{ fontWeight: 700 }}>그룹 등록</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ color: '#6B7280', mb: 2, fontSize: '0.85rem' }}>
            회사 내부 조직/그룹명을 입력하세요. (예: ETCH기술팀, 개발1팀)
          </Typography>
          <TextField
            fullWidth
            label="그룹명 *"
            value={groupName}
            onChange={e => setGroupName(e.target.value)}
            placeholder="예: ETCH기술팀"
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setGroupDialogOpen(false)} sx={{ textTransform: 'none' }}>
            취소
          </Button>
          <Button
            variant="contained"
            onClick={handleCreateGroup}
            disabled={!groupName.trim()}
            sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
          >
            등록
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Shortcut Dialog ── */}
      <Dialog
        open={shortcutDialogOpen}
        onClose={() => setShortcutDialogOpen(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <DialogTitle sx={{ fontWeight: 700 }}>
          {editingShortcut ? '바로가기 수정' : '바로가기 추가'}
        </DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="이름 *"
            value={scName}
            onChange={e => setScName(e.target.value)}
            sx={{ mt: 1, mb: 2 }}
          />
          <TextField
            fullWidth
            label="URL *"
            placeholder="https://example.com"
            value={scUrl}
            onChange={e => setScUrl(e.target.value)}
            sx={{ mb: 2 }}
          />
          <TextField
            fullWidth
            label="아이콘 텍스트 (기본: 이름 첫글자)"
            value={scIconText}
            onChange={e => setScIconText(e.target.value)}
            sx={{ mb: 2 }}
          />

          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
            아이콘 배경색
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
            {ICON_COLORS.map(color => (
              <Box
                key={color}
                onClick={() => setScIconColor(color)}
                sx={{
                  width: 32,
                  height: 32,
                  borderRadius: 1.5,
                  bgcolor: color,
                  cursor: 'pointer',
                  border: scIconColor === color ? '3px solid #1A1D29' : '2px solid transparent',
                  transition: 'all 0.15s',
                  '&:hover': { transform: 'scale(1.1)' },
                }}
              />
            ))}
          </Box>

          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
            미리보기
          </Typography>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1.5,
              p: 1.5,
              bgcolor: '#F9FAFB',
              borderRadius: 2,
            }}
          >
            <Box
              sx={{
                width: 48,
                height: 48,
                borderRadius: 2,
                bgcolor: scIconColor,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#fff',
                fontWeight: 800,
                fontSize: '1.2rem',
              }}
            >
              {(scIconText || scName || '?').charAt(0).toUpperCase()}
            </Box>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              {scName || '이름'}
            </Typography>
          </Box>

          <FormControlLabel
            control={
              <Switch
                checked={scOpenNewTab}
                onChange={e => setScOpenNewTab(e.target.checked)}
                size="small"
              />
            }
            label={
              <Typography variant="body2" sx={{ fontSize: '0.85rem' }}>
                새 탭에서 열기
              </Typography>
            }
            sx={{ mt: 2 }}
          />

          {/* 공개 범위 */}
          <FormControl size="small" fullWidth sx={{ mt: 2 }}>
            <InputLabel>공개 범위</InputLabel>
            <Select
              label="공개 범위"
              value={scVisibility}
              onChange={e => setScVisibility(e.target.value as ShortcutVisibility)}
            >
              <MenuItem value="PRIVATE">나만 보기</MenuItem>
              <MenuItem value="SHARED_USERS">구성원 공유</MenuItem>
              <MenuItem value="SHARED_GROUPS">그룹 공유</MenuItem>
              <MenuItem value="PUBLIC">전체 공개</MenuItem>
            </Select>
          </FormControl>

          {/* 구성원 검색 + 칩 */}
          {scVisibility === 'SHARED_USERS' && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mt: 2 }}>
              <TextField
                label="구성원 검색 (이름/loginid)"
                value={scUserSearch}
                onChange={e => debouncedScUserSearch(e.target.value)}
                size="small"
                fullWidth
                placeholder="2자 이상 입력"
              />
              {scUserResults.length > 0 && (
                <Box sx={{ maxHeight: 140, overflowY: 'auto', border: '1px solid #E5E7EB', borderRadius: 1, p: 0.5 }}>
                  {scUserResults.map((u: any) => {
                    const already = scSharedUserIds.includes(u.id);
                    return (
                      <Box
                        key={u.id}
                        onClick={() => {
                          if (already) return;
                          setScSharedUserIds([...scSharedUserIds, u.id]);
                        }}
                        sx={{
                          px: 1, py: 0.5, fontSize: '0.8rem', cursor: already ? 'default' : 'pointer',
                          opacity: already ? 0.4 : 1,
                          borderRadius: 0.5,
                          '&:hover': already ? {} : { bgcolor: '#F3F4F6' },
                        }}
                      >
                        {u.username || u.loginid} <span style={{ color: '#9CA3AF', fontSize: '0.7rem' }}>({u.loginid})</span>
                      </Box>
                    );
                  })}
                </Box>
              )}
              {scSharedUserIds.length > 0 && (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {scSharedUserIds.map(uid => {
                    const u = scUserResults.find((r: any) => r.id === uid);
                    const label = u ? (u.username || u.loginid) : `#${uid}`;
                    return (
                      <Chip
                        key={uid}
                        label={label}
                        size="small"
                        onDelete={() => setScSharedUserIds(scSharedUserIds.filter(id => id !== uid))}
                        sx={{ fontSize: '0.7rem' }}
                      />
                    );
                  })}
                </Box>
              )}
            </Box>
          )}

          {/* 그룹 선택 칩 */}
          {scVisibility === 'SHARED_GROUPS' && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mt: 2 }}>
              {memberGroupsForSc.length === 0 ? (
                <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
                  그룹이 없습니다. 먼저 그룹 페이지에서 그룹을 만들어주세요.
                </Typography>
              ) : (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {memberGroupsForSc.map(g => {
                    const selected = scSharedGroupIds.includes(g.id);
                    return (
                      <Chip
                        key={g.id}
                        label={g.name}
                        size="small"
                        onClick={() => {
                          setScSharedGroupIds(
                            selected
                              ? scSharedGroupIds.filter(id => id !== g.id)
                              : [...scSharedGroupIds, g.id],
                          );
                        }}
                        sx={{
                          fontSize: '0.7rem',
                          bgcolor: selected ? '#2955FF' : '#F3F4F6',
                          color: selected ? '#fff' : '#6B7280',
                          cursor: 'pointer',
                        }}
                      />
                    );
                  })}
                </Box>
              )}
            </Box>
          )}
        </DialogContent>

        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setShortcutDialogOpen(false)} sx={{ textTransform: 'none' }}>
            취소
          </Button>
          <Button
            variant="contained"
            onClick={handleSaveShortcut}
            disabled={!scName.trim() || !scUrl.trim()}
            sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
          >
            {editingShortcut ? '수정' : '추가'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── D-1: Create User Dialog (with Knox search) ── */}
      <Dialog
        open={createUserDialogOpen}
        onClose={() => { setCreateUserDialogOpen(false); setDialogKnoxResults([]); setDialogKnoxQuery(''); }}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <DialogTitle sx={{ fontWeight: 700 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <PersonAddIcon sx={{ color: '#2955FF' }} />
            구성원 추가
          </Box>
        </DialogTitle>
        <DialogContent>
          {/* Knox 사내 검색 */}
          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1, mt: 1, color: '#5B21B6' }}>
            Knox 사내 검색으로 추가
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, mb: 1.5 }}>
            <TextField
              size="small"
              fullWidth
              placeholder="사내 이름으로 검색..."
              value={dialogKnoxQuery}
              onChange={e => setDialogKnoxQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleDialogKnoxSearch()}
            />
            <Button
              variant="outlined"
              size="small"
              startIcon={dialogKnoxSearching ? <CircularProgress size={14} /> : <SearchIcon />}
              onClick={handleDialogKnoxSearch}
              disabled={dialogKnoxSearching || !dialogKnoxQuery.trim()}
              sx={{ textTransform: 'none', minWidth: 80 }}
            >
              검색
            </Button>
          </Box>
          {dialogKnoxResults.length > 0 && (
            <Box sx={{ maxHeight: 200, overflowY: 'auto', mb: 2, border: '1px solid #E5E7EB', borderRadius: 1 }}>
              {dialogKnoxResults.map((emp: any, idx: number) => {
                const lid = (emp.loginid || emp.login_id || emp.id || '').toString().toLowerCase();
                const name = emp.fullName || emp.username || emp.name || lid;
                const dept = emp.deptName || emp.deptname || emp.department || '';
                const isRegistered = users.some(u => (u.loginid || '').toLowerCase() === lid);
                return (
                  <Box
                    key={idx}
                    sx={{
                      px: 1.5, py: 0.8,
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      borderBottom: '1px solid #F3F4F6',
                      '&:hover': { bgcolor: '#F9FAFB' },
                      cursor: isRegistered ? 'default' : 'pointer',
                    }}
                    onClick={() => {
                      if (!isRegistered) {
                        setNewUsername(name);
                        setNewLoginId(lid);
                        setNewDeptname(dept);
                        setNewMail(emp.email || emp.mail || '');
                        setDialogKnoxResults([]);
                      }
                    }}
                  >
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: 500, fontSize: '0.85rem' }}>{name}</Typography>
                      <Typography variant="caption" sx={{ color: '#9CA3AF' }}>{lid} {dept ? `· ${dept}` : ''}</Typography>
                    </Box>
                    {isRegistered ? (
                      <Chip label="등록됨" size="small" sx={{ fontSize: '0.65rem', bgcolor: '#DCFCE7', color: '#22C55E' }} />
                    ) : (
                      <Typography variant="caption" sx={{ color: '#2955FF', fontWeight: 600 }}>선택</Typography>
                    )}
                  </Box>
                );
              })}
            </Box>
          )}

          {/* 직접 입력 */}
          <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1, color: '#374151' }}>
            직접 입력
          </Typography>
          <TextField
            fullWidth
            label="이름 *"
            size="small"
            value={newUsername}
            onChange={e => setNewUsername(e.target.value)}
            placeholder="예: 홍길동"
            sx={{ mb: 1.5 }}
          />
          <TextField
            fullWidth
            label="Login ID *"
            size="small"
            value={newLoginId}
            onChange={e => setNewLoginId(e.target.value)}
            placeholder="예: gildong.hong"
            sx={{ mb: 1.5 }}
          />
          <Select
            fullWidth
            value={newUserRole}
            onChange={e => setNewUserRole(e.target.value as string)}
            size="small"
            sx={{ mb: 1 }}
          >
            <MenuItem value="member">Member — 일반 사용자</MenuItem>
            <MenuItem value="manager">중간관리자 — 소속 프로젝트 관리</MenuItem>
            {isSuperAdmin && <MenuItem value="admin">Admin — 사이트 관리</MenuItem>}
          </Select>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button
            onClick={() => { setCreateUserDialogOpen(false); setDialogKnoxResults([]); setDialogKnoxQuery(''); }}
            sx={{ textTransform: 'none' }}
          >
            취소
          </Button>
          <Button
            variant="contained"
            onClick={() => {
              if (!newUsername.trim() || !newLoginId.trim()) return;
              createUserMut.mutate({
                username: newUsername.trim(),
                loginid: newLoginId.trim(),
                role: newUserRole,
                deptname: newDeptname.trim() || undefined,
                mail: newMail.trim() || undefined,
              });
            }}
            disabled={!newUsername.trim() || !newLoginId.trim() || createUserMut.isPending}
            sx={{ textTransform: 'none', fontWeight: 600, borderRadius: 2 }}
          >
            {createUserMut.isPending ? '추가 중...' : '추가'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── Tab 3: 시스템 로그 ── */}
      {tabIndex === 3 && (
        <Box>
          <Alert severity="info" sx={{ borderRadius: 2, mb: 2, fontSize: '0.85rem' }}>
            운영 확인용 <strong>요약 로그</strong>입니다. 모든 요청이 아니라 오류/경고·백업·외부연동(S3/Knox/DSLLM) 실패 등 장애 이력만 기록됩니다.
            상세 원문(stack trace 등)은 서버 콘솔에 남고, 민감정보(토큰/비밀번호/요청 본문)는 저장하지 않습니다.
          </Alert>

          {/* 운영 요약 카드 */}
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 3 }}>
            <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, flex: '1 1 240px', minWidth: 240 }}>
              <Typography sx={{ fontSize: '0.8rem', color: '#6B7280', fontWeight: 600, mb: 1 }}>
                최근 24시간 이벤트
              </Typography>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                {LOG_LEVELS.map(lv => (
                  <Chip
                    key={lv}
                    label={`${lv} ${systemHealth?.counts_24h?.[lv as keyof typeof systemHealth.counts_24h] ?? 0}`}
                    size="small"
                    sx={{
                      fontWeight: 700,
                      fontSize: '0.72rem',
                      color: LOG_LEVEL_COLOR[lv].color,
                      bgcolor: LOG_LEVEL_COLOR[lv].bgcolor,
                    }}
                  />
                ))}
              </Box>
              <Typography sx={{ fontSize: '0.78rem', color: '#B91C1C', fontWeight: 700, mt: 1.5 }}>
                미처리 오류: {systemHealth?.unresolved_errors ?? 0}건
              </Typography>
            </Paper>

            <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, flex: '1 1 320px', minWidth: 280 }}>
              <Typography sx={{ fontSize: '0.8rem', color: '#6B7280', fontWeight: 600, mb: 1 }}>
                최근 DB 백업 상태
              </Typography>
              {systemHealth?.last_db_backup ? (
                <Box sx={{ fontSize: '0.8rem', lineHeight: 1.8 }}>
                  <div>
                    상태:{' '}
                    <Chip
                      label={systemHealth.last_db_backup.success ? '성공' : '실패'}
                      size="small"
                      color={systemHealth.last_db_backup.success ? 'success' : 'error'}
                      sx={{ height: 20, fontSize: '0.7rem', fontWeight: 700 }}
                    />
                  </div>
                  <div>시간: {fmtDateTime(systemHealth.last_db_backup.time)}</div>
                  {systemHealth.last_db_backup.s3_key && (
                    <div style={{ wordBreak: 'break-all', color: '#6B7280' }}>
                      S3 key: {systemHealth.last_db_backup.s3_key}
                    </div>
                  )}
                  <div style={{ color: '#6B7280' }}>{systemHealth.last_db_backup.message}</div>
                </Box>
              ) : (
                <Typography sx={{ fontSize: '0.8rem', color: '#9CA3AF' }}>백업 기록 없음</Typography>
              )}
              {systemHealth?.last_backup_cleanup && (
                <Typography sx={{ fontSize: '0.76rem', color: '#6B7280', mt: 1, borderTop: '1px solid #F3F4F6', pt: 1 }}>
                  cleanup: {fmtDateTime(systemHealth.last_backup_cleanup.time)} — {systemHealth.last_backup_cleanup.message}
                </Typography>
              )}
            </Paper>
          </Box>

          {/* 필터 바 */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2, flexWrap: 'wrap' }}>
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel>레벨</InputLabel>
              <Select label="레벨" value={logLevel} onChange={e => setLogLevel(e.target.value)}>
                <MenuItem value="">전체</MenuItem>
                {LOG_LEVELS.map(lv => (
                  <MenuItem key={lv} value={lv}>{lv}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel>카테고리</InputLabel>
              <Select label="카테고리" value={logCategory} onChange={e => setLogCategory(e.target.value)}>
                <MenuItem value="">전체</MenuItem>
                {LOG_CATEGORIES.map(c => (
                  <MenuItem key={c} value={c}>{c}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              size="small"
              type="date"
              label="시작일"
              InputLabelProps={{ shrink: true }}
              value={logDateFrom}
              onChange={e => setLogDateFrom(e.target.value)}
              sx={{ width: 160 }}
            />
            <TextField
              size="small"
              type="date"
              label="종료일"
              InputLabelProps={{ shrink: true }}
              value={logDateTo}
              onChange={e => setLogDateTo(e.target.value)}
              sx={{ width: 160 }}
            />
            <TextField
              size="small"
              placeholder="메시지/endpoint 검색"
              value={logKeyword}
              onChange={e => setLogKeyword(e.target.value)}
              sx={{ width: 200 }}
            />
            <TextField
              size="small"
              label="Endpoint (정확히)"
              placeholder="/api/tasks"
              InputLabelProps={{ shrink: true }}
              value={logEndpoint}
              onChange={e => setLogEndpoint(e.target.value)}
              sx={{ width: 180 }}
            />
            <TextField
              size="small"
              type="number"
              label="상태코드"
              placeholder="500"
              InputLabelProps={{ shrink: true }}
              value={logStatusCode}
              onChange={e => setLogStatusCode(e.target.value)}
              sx={{ width: 110 }}
            />
            <FormControlLabel
              control={
                <Switch
                  checked={logUnresolvedOnly}
                  onChange={e => setLogUnresolvedOnly(e.target.checked)}
                  size="small"
                />
              }
              label={<Typography sx={{ fontSize: '0.82rem' }}>미처리만</Typography>}
            />
            <Button
              variant="outlined"
              size="small"
              onClick={() => {
                setLogLevel('');
                setLogCategory('');
                setLogDateFrom('');
                setLogDateTo('');
                setLogKeyword('');
                setLogEndpoint('');
                setLogStatusCode('');
                setLogUnresolvedOnly(false);
                resetLogSelection();
              }}
              sx={{ textTransform: 'none' }}
            >
              초기화
            </Button>
          </Box>

          {/* 일괄 작업 바 */}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              mb: 1.5,
              flexWrap: 'wrap',
              p: 1.25,
              borderRadius: 2,
              bgcolor: '#F9FAFB',
              border: '1px solid #EEF0F3',
            }}
          >
            <Typography sx={{ fontSize: '0.8rem', color: '#374151', fontWeight: 600, mr: 0.5 }}>
              선택 {selectedLogIds.length}건
            </Typography>
            <Button
              size="small"
              variant="outlined"
              color="success"
              disabled={selectedLogIds.length === 0}
              onClick={() => setLogActionDialog({ type: 'bulk-resolve' })}
              sx={{ textTransform: 'none' }}
            >
              선택 해결 처리
            </Button>
            <Button
              size="small"
              variant="outlined"
              color="error"
              disabled={selectedLogIds.length === 0}
              onClick={() => setLogActionDialog({ type: 'bulk-delete' })}
              sx={{ textTransform: 'none' }}
            >
              선택 삭제
            </Button>
            <Box sx={{ width: 1, height: 22, bgcolor: '#E5E7EB', mx: 0.5 }} />
            <Button
              size="small"
              variant="outlined"
              color="success"
              disabled={!hasAnyLogFilter}
              onClick={() => setLogActionDialog({ type: 'filter-resolve' })}
              sx={{ textTransform: 'none' }}
            >
              필터 결과 해결 처리
            </Button>
            <Button
              size="small"
              variant="contained"
              color="error"
              disabled={!hasAnyLogFilter || !isSuperAdmin}
              onClick={openFilterDeleteDialog}
              sx={{ textTransform: 'none' }}
              title={!isSuperAdmin ? 'super_admin 권한이 필요합니다.' : undefined}
            >
              필터 결과 삭제{!isSuperAdmin ? ' (super_admin)' : ''}
            </Button>
            <Typography sx={{ fontSize: '0.74rem', color: '#9CA3AF', ml: 'auto' }}>
              삭제보다 <strong>해결 처리</strong>를 먼저 권장합니다.
            </Typography>
          </Box>

          <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2 }}>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ bgcolor: '#F9FAFB' }}>
                  <TableCell padding="checkbox">
                    <Checkbox
                      size="small"
                      checked={systemLogs.length > 0 && selectedLogIds.length === systemLogs.length}
                      indeterminate={selectedLogIds.length > 0 && selectedLogIds.length < systemLogs.length}
                      onChange={e =>
                        setSelectedLogIds(e.target.checked ? systemLogs.map(l => l.id) : [])
                      }
                    />
                  </TableCell>
                  {['시간', '레벨', '카테고리', '메시지', 'Endpoint', '상태', 'Login', 'Request ID', '처리', ''].map(h => (
                    <TableCell key={h} sx={{ fontWeight: 600, fontSize: '0.78rem' }}>{h}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {systemLogsLoading && (
                  <TableRow>
                    <TableCell colSpan={11} align="center" sx={{ py: 4 }}>
                      <CircularProgress size={22} />
                    </TableCell>
                  </TableRow>
                )}
                {!systemLogsLoading && systemLogs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={11} align="center" sx={{ py: 4, color: '#9CA3AF', fontSize: '0.85rem' }}>
                      조건에 맞는 로그가 없습니다.
                    </TableCell>
                  </TableRow>
                )}
                {systemLogs.map(log => (
                  <TableRow key={log.id} hover sx={{ opacity: log.resolved ? 0.55 : 1 }} selected={selectedLogIds.includes(log.id)}>
                    <TableCell padding="checkbox">
                      <Checkbox
                        size="small"
                        checked={selectedLogIds.includes(log.id)}
                        onChange={e =>
                          setSelectedLogIds(prev =>
                            e.target.checked ? [...prev, log.id] : prev.filter(id => id !== log.id)
                          )
                        }
                      />
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.76rem', whiteSpace: 'nowrap' }}>{fmtDateTime(log.created_at)}</TableCell>
                    <TableCell>
                      <Chip
                        label={log.level}
                        size="small"
                        sx={{
                          height: 20,
                          fontSize: '0.68rem',
                          fontWeight: 700,
                          color: LOG_LEVEL_COLOR[log.level]?.color,
                          bgcolor: LOG_LEVEL_COLOR[log.level]?.bgcolor,
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={log.category}
                        size="small"
                        variant="outlined"
                        sx={{
                          height: 20,
                          fontSize: '0.68rem',
                          fontWeight: 700,
                          color: LOG_CATEGORY_COLOR[log.category] || '#6B7280',
                          borderColor: LOG_CATEGORY_COLOR[log.category] || '#6B7280',
                        }}
                      />
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.78rem', maxWidth: 320 }}>
                      <Box sx={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {log.message}
                      </Box>
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.74rem', color: '#6B7280', maxWidth: 180 }}>
                      <Box sx={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {log.method ? `${log.method} ` : ''}{log.endpoint || '-'}
                      </Box>
                    </TableCell>
                    <TableCell sx={{ fontSize: '0.76rem' }}>{log.status_code ?? '-'}</TableCell>
                    <TableCell sx={{ fontSize: '0.76rem' }}>{log.login_id || '-'}</TableCell>
                    <TableCell sx={{ fontSize: '0.72rem', color: '#6B7280', whiteSpace: 'nowrap' }}>{log.request_id || '-'}</TableCell>
                    <TableCell>
                      <Chip
                        label={log.resolved ? '완료' : '미처리'}
                        size="small"
                        color={log.resolved ? 'default' : 'warning'}
                        sx={{ height: 20, fontSize: '0.68rem', fontWeight: 700 }}
                      />
                    </TableCell>
                    <TableCell>
                      <Button size="small" sx={{ textTransform: 'none', minWidth: 0 }} onClick={() => setSelectedLog(log)}>
                        상세
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {logPagination && logPagination.total > 0 && (
            <PaginationBar
              page={logPagination.page}
              pageSize={logPagination.page_size}
              total={logPagination.total}
              totalPages={logPagination.total_pages}
              onPageChange={setLogPage}
              onPageSizeChange={setLogPageSize}
              pageSizeOptions={[50, 100]}
              unitLabel="건"
            />
          )}

          {/* 상세 보기 Modal */}
          <Dialog open={!!selectedLog} onClose={() => setSelectedLog(null)} maxWidth="md" fullWidth>
            <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>시스템 로그 상세</DialogTitle>
            <DialogContent dividers>
              {selectedLog && (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.2, fontSize: '0.85rem' }}>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Chip
                      label={selectedLog.level}
                      size="small"
                      sx={{
                        fontWeight: 700,
                        color: LOG_LEVEL_COLOR[selectedLog.level]?.color,
                        bgcolor: LOG_LEVEL_COLOR[selectedLog.level]?.bgcolor,
                      }}
                    />
                    <Chip
                      label={selectedLog.category}
                      size="small"
                      variant="outlined"
                      sx={{
                        fontWeight: 700,
                        color: LOG_CATEGORY_COLOR[selectedLog.category] || '#6B7280',
                        borderColor: LOG_CATEGORY_COLOR[selectedLog.category] || '#6B7280',
                      }}
                    />
                  </Box>
                  <div><strong>시간:</strong> {fmtDateTime(selectedLog.created_at)}</div>
                  <div><strong>메시지:</strong> {selectedLog.message}</div>
                  <div>
                    <strong>Endpoint:</strong> {selectedLog.method ? `${selectedLog.method} ` : ''}{selectedLog.endpoint || '-'}
                    {selectedLog.status_code ? ` (${selectedLog.status_code})` : ''}
                  </div>
                  <div><strong>Login ID:</strong> {selectedLog.login_id || '-'}</div>
                  <div><strong>Request ID:</strong> {selectedLog.request_id || '-'}</div>
                  {selectedLog.resolved && (
                    <div>
                      <strong>처리:</strong> 완료
                      {selectedLog.resolved_at ? ` (${fmtDateTime(selectedLog.resolved_at)})` : ''}
                      {selectedLog.resolution_note ? ` — ${selectedLog.resolution_note}` : ''}
                    </div>
                  )}

                  {/* VISION_AI: 구조화 진단(요약 → 판단 → 요청 지표 → 원본 JSON). 다른 카테고리는 미표시. */}
                  {selectedLog.category === 'VISION_AI' && selectedLog.diagnostic && (
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.2, mt: 0.3 }}>
                      <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 1, bgcolor: '#FAF5FF' }}>
                        <Typography sx={{ fontWeight: 700, fontSize: '0.82rem', mb: 0.6, color: '#6B21A8' }}>
                          진단 요약
                        </Typography>
                        <Box sx={{ display: 'grid', gridTemplateColumns: '130px 1fr', rowGap: 0.4, fontSize: '0.8rem' }}>
                          <div>실패 단계</div>
                          <div>{selectedLog.diagnostic.failure_stage_label || selectedLog.diagnostic.failure_stage || '-'}</div>
                          <div>Provider / Model</div>
                          <div>{selectedLog.diagnostic.provider || '-'} / {selectedLog.diagnostic.model || '-'}</div>
                          <div>오류 유형</div>
                          <div>{selectedLog.diagnostic.error_type || '-'}</div>
                          <div>HTTP 상태</div>
                          <div>{selectedLog.diagnostic.http_status != null ? selectedLog.diagnostic.http_status : 'none'}</div>
                          <div>Request ID</div>
                          <div>{selectedLog.request_id || '-'}</div>
                          <div>발생 시간</div>
                          <div>{fmtDateTime(selectedLog.created_at)}</div>
                        </Box>
                      </Paper>

                      <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 1 }}>
                        <Typography sx={{ fontWeight: 700, fontSize: '0.82rem', mb: 0.6 }}>판단 / 권장 대응</Typography>
                        <Box sx={{ fontSize: '0.8rem', lineHeight: 1.7 }}>
                          <div><strong>요약:</strong> {selectedLog.diagnostic.summary || '-'}</div>
                          <div><strong>추정 원인:</strong> {selectedLog.diagnostic.likely_cause || '-'}</div>
                          <div><strong>권장 대응:</strong> {selectedLog.diagnostic.recommended_action || '-'}</div>
                          <div>
                            <strong>재시도 안전:</strong> {selectedLog.diagnostic.retry_safe ? '예' : '아니오'}
                            {selectedLog.diagnostic.recovery_event ? ' · 복구 이벤트' : ''}
                          </div>
                        </Box>
                      </Paper>

                      {selectedLog.diagnostic.details && (
                        <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 1 }}>
                          <Typography sx={{ fontWeight: 700, fontSize: '0.82rem', mb: 0.6 }}>요청 지표</Typography>
                          <Box sx={{ display: 'grid', gridTemplateColumns: '160px 1fr', rowGap: 0.3, fontSize: '0.78rem', fontFamily: 'monospace' }}>
                            {VISION_METRIC_FIELDS.map(f => {
                              const v = (selectedLog.diagnostic?.details as Record<string, unknown> | null | undefined)?.[f.key];
                              if (v == null) return null;
                              return (
                                <React.Fragment key={String(f.key)}>
                                  <div>{f.label}</div>
                                  <div style={{ wordBreak: 'break-all' }}>{String(v)}</div>
                                </React.Fragment>
                              );
                            })}
                          </Box>
                        </Paper>
                      )}

                      <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                        <Button size="small" variant="outlined" onClick={() => copyVisionDiagnostic(selectedLog)}>
                          {diagCopied ? '복사됨' : '진단 정보 복사'}
                        </Button>
                        <Typography sx={{ fontSize: '0.72rem', color: '#9CA3AF' }}>
                          (API 키·이미지·프롬프트 미포함)
                        </Typography>
                      </Box>

                      <details>
                        <summary style={{ cursor: 'pointer', fontSize: '0.8rem', fontWeight: 600 }}>원본 진단 JSON</summary>
                        <Paper
                          variant="outlined"
                          sx={{
                            mt: 0.5, p: 1.2, bgcolor: '#F9FAFB', borderRadius: 1,
                            fontFamily: 'monospace', fontSize: '0.72rem', whiteSpace: 'pre-wrap',
                            wordBreak: 'break-all', maxHeight: 260, overflow: 'auto',
                          }}
                        >
                          {JSON.stringify(selectedLog.diagnostic, null, 2)}
                        </Paper>
                      </details>
                    </Box>
                  )}

                  <div>
                    <strong>상세:</strong>
                    <Paper
                      variant="outlined"
                      sx={{
                        mt: 0.5,
                        p: 1.2,
                        bgcolor: '#F9FAFB',
                        borderRadius: 1,
                        fontFamily: 'monospace',
                        fontSize: '0.74rem',
                        whiteSpace: 'pre-wrap',
                        wordBreak: 'break-all',
                        maxHeight: 320,
                        overflow: 'auto',
                      }}
                    >
                      {selectedLog.detail || '(상세 없음)'}
                    </Paper>
                  </div>
                </Box>
              )}
            </DialogContent>
            <DialogActions>
              {selectedLog && (
                <>
                  <Button
                    variant="contained"
                    color={selectedLog.resolved ? 'inherit' : 'primary'}
                    disabled={resolveLogMut.isPending}
                    onClick={() =>
                      resolveLogMut.mutate({ id: selectedLog.id, resolved: !selectedLog.resolved })
                    }
                    sx={{ textTransform: 'none', fontWeight: 600 }}
                  >
                    {selectedLog.resolved ? '미처리로 되돌리기' : '처리 완료로 표시'}
                  </Button>
                  <Button
                    variant="outlined"
                    color="error"
                    disabled={deleteSingleMut.isPending}
                    onClick={() => {
                      if (
                        window.confirm(
                          '이 시스템 로그 1건을 삭제하시겠습니까?\n삭제된 로그는 관리자 화면에서 다시 볼 수 없습니다.'
                        )
                      ) {
                        deleteSingleMut.mutate(selectedLog.id);
                      }
                    }}
                    sx={{ textTransform: 'none', fontWeight: 600 }}
                  >
                    이 로그 삭제
                  </Button>
                </>
              )}
              <Button onClick={() => setSelectedLog(null)} sx={{ textTransform: 'none' }}>닫기</Button>
            </DialogActions>
          </Dialog>

          {/* 일괄 작업 확인 Modal */}
          <Dialog open={!!logActionDialog} onClose={closeLogActionDialog} maxWidth="sm" fullWidth>
            {logActionDialog?.type === 'bulk-resolve' && (
              <>
                <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>선택 로그 해결 처리</DialogTitle>
                <DialogContent dividers>
                  <Typography sx={{ fontSize: '0.88rem', mb: 1.5 }}>
                    선택한 시스템 로그 <strong>{selectedLogIds.length}건</strong>을 해결 처리합니다.
                    삭제와 달리 이력은 보존되며, 기본적으로 목록에서 숨길 수 있습니다(미처리만 토글).
                  </Typography>
                  <TextField
                    fullWidth
                    multiline
                    minRows={2}
                    size="small"
                    label="처리 사유 (선택)"
                    placeholder="예: task_type 모델/DB 불일치 해결 후 정리"
                    value={logActionReason}
                    onChange={e => setLogActionReason(e.target.value)}
                  />
                </DialogContent>
                <DialogActions>
                  <Button onClick={closeLogActionDialog} sx={{ textTransform: 'none' }}>취소</Button>
                  <Button
                    variant="contained"
                    color="success"
                    disabled={bulkResolveMut.isPending || selectedLogIds.length === 0}
                    onClick={() => bulkResolveMut.mutate()}
                    sx={{ textTransform: 'none', fontWeight: 600 }}
                  >
                    {selectedLogIds.length}건 해결 처리
                  </Button>
                </DialogActions>
              </>
            )}

            {logActionDialog?.type === 'bulk-delete' && (
              <>
                <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', color: '#B91C1C' }}>선택 로그 삭제</DialogTitle>
                <DialogContent dividers>
                  <Typography sx={{ fontSize: '0.88rem', mb: 1.5, whiteSpace: 'pre-line' }}>
                    {`선택한 시스템 로그 ${selectedLogIds.length}건을 삭제하시겠습니까?\n삭제된 로그는 관리자 화면에서 다시 볼 수 없습니다.\n원인 해결 여부를 확인한 뒤 삭제하는 것을 권장합니다.`}
                  </Typography>
                  <TextField
                    fullWidth
                    multiline
                    minRows={2}
                    size="small"
                    label="삭제 사유 (선택, audit 로그에 기록)"
                    value={logActionReason}
                    onChange={e => setLogActionReason(e.target.value)}
                  />
                </DialogContent>
                <DialogActions>
                  <Button onClick={closeLogActionDialog} sx={{ textTransform: 'none' }}>취소</Button>
                  <Button
                    variant="contained"
                    color="error"
                    disabled={bulkDeleteMut.isPending || selectedLogIds.length === 0}
                    onClick={() => bulkDeleteMut.mutate()}
                    sx={{ textTransform: 'none', fontWeight: 600 }}
                  >
                    {selectedLogIds.length}건 삭제
                  </Button>
                </DialogActions>
              </>
            )}

            {logActionDialog?.type === 'filter-resolve' && (
              <>
                <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>필터 결과 해결 처리</DialogTitle>
                <DialogContent dividers>
                  <Typography sx={{ fontSize: '0.88rem', mb: 1.5 }}>
                    현재 필터 조건에 해당하는 <strong>모든</strong> 시스템 로그를 해결 처리합니다.
                    (현재 페이지에 보이는 {systemLogs.length}건 외에도 조건에 맞는 로그 전체가 대상입니다.)
                  </Typography>
                  <TextField
                    fullWidth
                    multiline
                    minRows={2}
                    size="small"
                    label="처리 사유 (선택)"
                    value={logActionReason}
                    onChange={e => setLogActionReason(e.target.value)}
                  />
                </DialogContent>
                <DialogActions>
                  <Button onClick={closeLogActionDialog} sx={{ textTransform: 'none' }}>취소</Button>
                  <Button
                    variant="contained"
                    color="success"
                    disabled={filterResolveMut.isPending}
                    onClick={() => filterResolveMut.mutate()}
                    sx={{ textTransform: 'none', fontWeight: 600 }}
                  >
                    필터 결과 해결 처리
                  </Button>
                </DialogActions>
              </>
            )}

            {logActionDialog?.type === 'filter-delete' && (
              <>
                <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', color: '#B91C1C' }}>
                  필터 결과 삭제 (되돌릴 수 없음)
                </DialogTitle>
                <DialogContent dividers>
                  {filterPreviewLoading && (
                    <Box sx={{ py: 3, textAlign: 'center' }}>
                      <CircularProgress size={22} />
                    </Box>
                  )}
                  {!filterPreviewLoading && filterPreview && (
                    <>
                      <Alert severity="error" sx={{ fontSize: '0.84rem', mb: 1.5 }}>
                        현재 필터 조건에 해당하는 시스템 로그{' '}
                        <strong>{filterPreview.matched_count}건</strong>을 삭제합니다.
                        이 작업은 되돌릴 수 없습니다. 계속하려면 <strong>DELETE</strong>를 입력하세요.
                      </Alert>
                      <Typography sx={{ fontSize: '0.78rem', color: '#6B7280', mb: 1 }}>
                        기간: {fmtDateTime(filterPreview.oldest)} ~ {fmtDateTime(filterPreview.newest)}
                      </Typography>
                      {filterPreview.sample.length > 0 && (
                        <Paper
                          variant="outlined"
                          sx={{ p: 1, mb: 1.5, bgcolor: '#F9FAFB', maxHeight: 160, overflow: 'auto' }}
                        >
                          {filterPreview.sample.map(s => (
                            <Box key={s.id} sx={{ fontSize: '0.72rem', color: '#374151', mb: 0.5 }}>
                              <span style={{ color: '#9CA3AF' }}>#{s.id}</span>{' '}
                              [{s.level}] {s.endpoint || '-'}
                              {s.status_code ? ` (${s.status_code})` : ''} — {s.message}
                            </Box>
                          ))}
                        </Paper>
                      )}
                      <TextField
                        fullWidth
                        size="small"
                        label="확인 문구"
                        placeholder="DELETE"
                        value={filterDeleteConfirm}
                        onChange={e => setFilterDeleteConfirm(e.target.value)}
                        sx={{ mb: 1.5 }}
                      />
                      <TextField
                        fullWidth
                        multiline
                        minRows={2}
                        size="small"
                        label="삭제 사유 (선택, audit 로그에 기록)"
                        value={logActionReason}
                        onChange={e => setLogActionReason(e.target.value)}
                      />
                    </>
                  )}
                </DialogContent>
                <DialogActions>
                  <Button onClick={closeLogActionDialog} sx={{ textTransform: 'none' }}>취소</Button>
                  <Button
                    variant="contained"
                    color="error"
                    disabled={
                      filterDeleteMut.isPending ||
                      filterPreviewLoading ||
                      filterDeleteConfirm.trim().toUpperCase() !== 'DELETE' ||
                      (filterPreview?.matched_count ?? 0) === 0
                    }
                    onClick={() => filterDeleteMut.mutate()}
                    sx={{ textTransform: 'none', fontWeight: 600 }}
                  >
                    {filterPreview?.matched_count ?? 0}건 영구 삭제
                  </Button>
                </DialogActions>
              </>
            )}
          </Dialog>
        </Box>
      )}

      {/* ── Tab 4: 사용 통계 (방문 + 프로젝트/Task 생성 활동) ── */}
      {tabIndex === 4 && (
        <Box>
          <Alert severity="info" sx={{ borderRadius: 2, mb: 2, fontSize: '0.85rem' }}>
            <strong>방문 수</strong>는 총 접속 기록 수, <strong>순 방문자 수</strong>는 사용자(로그인ID/이름/IP) 기준 중복을 제거한 실제 인원입니다.
            <strong> 프로젝트/Task 생성 수</strong>는 실제 플랫폼 활동량이며, 시스템 프로젝트(단발 업무)와 보관된 항목은 제외합니다.
            홍보·보고에는 순 방문자 수와 생성 활동량을 함께 보는 것이 좋습니다.
          </Alert>

          {visitStatsLoading && (
            <Box sx={{ py: 6, textAlign: 'center' }}>
              <CircularProgress size={26} />
            </Box>
          )}

          {!visitStatsLoading && visitStats && (() => {
            const s = visitStats.summary;
            const avg7 = Math.round((s.last_7_days_visits || 0) / 7);
            type CardT = { label: string; value: number; sub?: string; color: string; bg: string };
            const visitCards: CardT[] = [
              { label: '오늘 방문', value: s.today_visits, color: '#2563EB', bg: '#EFF6FF' },
              { label: '오늘 순 방문자', value: s.today_unique_visitors, color: '#7C3AED', bg: '#F5F3FF' },
              { label: '최근 7일 순 방문자', value: s.last_7_days_unique_visitors, sub: `일 평균 방문 ${avg7}`, color: '#0EA5E9', bg: '#ECFEFF' },
              { label: '최근 30일 순 방문자', value: s.last_30_days_unique_visitors, sub: `방문 ${s.last_30_days_visits.toLocaleString()}회`, color: '#22C55E', bg: '#F0FDF4' },
              { label: '이번 달 순 방문자', value: s.month_unique_visitors, color: '#F59E0B', bg: '#FFFBEB' },
              { label: '누적 방문', value: s.total_visits, color: '#1A1D29', bg: '#F9FAFB' },
            ];
            const activityCards: CardT[] = [
              { label: '오늘 프로젝트', value: s.today_projects_created, color: '#0D9488', bg: '#F0FDFA' },
              { label: '오늘 Task', value: s.today_tasks_created, color: '#DB2777', bg: '#FDF2F8' },
              { label: '최근 30일 프로젝트', value: s.last_30_days_projects_created, sub: `이번 달 ${s.month_projects_created.toLocaleString()}개`, color: '#0D9488', bg: '#F0FDFA' },
              { label: '최근 30일 Task', value: s.last_30_days_tasks_created, sub: `이번 달 ${s.month_tasks_created.toLocaleString()}개`, color: '#DB2777', bg: '#FDF2F8' },
              { label: '누적 프로젝트', value: s.total_projects, color: '#115E59', bg: '#F9FAFB' },
              { label: '누적 Task', value: s.total_tasks, color: '#9D174D', bg: '#F9FAFB' },
            ];
            const renderCards = (cards: CardT[]) => (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
                {cards.map(c => (
                  <Paper
                    key={c.label}
                    variant="outlined"
                    sx={{ p: 2, borderRadius: 2, flex: '1 1 160px', minWidth: 160, bgcolor: c.bg }}
                  >
                    <Typography sx={{ fontSize: '0.78rem', color: '#6B7280', fontWeight: 600, mb: 0.5 }}>
                      {c.label}
                    </Typography>
                    <Typography sx={{ fontSize: '1.6rem', fontWeight: 800, color: c.color, lineHeight: 1.1 }}>
                      {(c.value ?? 0).toLocaleString()}
                    </Typography>
                    {c.sub && (
                      <Typography sx={{ fontSize: '0.7rem', color: '#9CA3AF', mt: 0.3 }}>{c.sub}</Typography>
                    )}
                  </Paper>
                ))}
              </Box>
            );
            return (
              <>
                {/* 방문 요약 카드 */}
                <Typography sx={{ fontSize: '0.8rem', fontWeight: 700, color: '#374151', mb: 1 }}>방문 지표</Typography>
                <Box sx={{ mb: 2.5 }}>{renderCards(visitCards)}</Box>

                {/* 활동 요약 카드 (프로젝트/Task 생성) */}
                <Typography sx={{ fontSize: '0.8rem', fontWeight: 700, color: '#374151', mb: 1 }}>활동 지표 (생성 수)</Typography>
                <Box sx={{ mb: 3 }}>{renderCards(activityCards)}</Box>

                {/* 일별 방문 그래프 */}
                <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, mb: 3 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5 }}>
                    최근 30일 일별 방문 추이
                  </Typography>
                  <Box sx={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={visitStats.daily} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
                        <XAxis
                          dataKey="date"
                          tickFormatter={(d: string) => (d ? d.slice(5) : d)}
                          tick={{ fontSize: 11, fill: '#6B7280' }}
                          interval="preserveStartEnd"
                          minTickGap={20}
                        />
                        <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#6B7280' }} />
                        <RechartsTooltip />
                        <Legend wrapperStyle={{ fontSize: '0.8rem' }} />
                        <Bar dataKey="visits" name="방문 수" fill="#93C5FD" radius={[3, 3, 0, 0]} maxBarSize={26} />
                        <Line type="monotone" dataKey="unique_visitors" name="순 방문자 수" stroke="#7C3AED" strokeWidth={2} dot={false} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </Box>
                </Paper>

                {/* 일별 생성 활동 그래프 */}
                <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, mb: 3 }}>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5 }}>
                    최근 30일 생성 활동 추이
                  </Typography>
                  <Box sx={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={visitStats.daily} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
                        <XAxis
                          dataKey="date"
                          tickFormatter={(d: string) => (d ? d.slice(5) : d)}
                          tick={{ fontSize: 11, fill: '#6B7280' }}
                          interval="preserveStartEnd"
                          minTickGap={20}
                        />
                        <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#6B7280' }} />
                        <RechartsTooltip />
                        <Legend wrapperStyle={{ fontSize: '0.8rem' }} />
                        <Bar dataKey="tasks_created" name="Task 생성" fill="#FBCFE8" radius={[3, 3, 0, 0]} maxBarSize={26} />
                        <Line type="monotone" dataKey="projects_created" name="프로젝트 생성" stroke="#0D9488" strokeWidth={2} dot={false} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </Box>
                </Paper>

                {/* 부서별 TOP 10 + 최근 방문 기록 */}
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                  <Box sx={{ flex: '1 1 460px', minWidth: 320 }}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>
                      부서별 사용 TOP 10 (최근 30일)
                    </Typography>
                    <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2 }}>
                      <Table size="small">
                        <TableHead>
                          <TableRow sx={{ bgcolor: '#F9FAFB' }}>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem' }}>부서명</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem' }} align="right">순 방문자</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem' }} align="right">방문 수</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem' }} align="right">프로젝트</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem' }} align="right">비율</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem' }}>마지막 방문</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {visitStats.departments.length === 0 && (
                            <TableRow>
                              <TableCell colSpan={6} align="center" sx={{ py: 3, color: '#9CA3AF', fontSize: '0.85rem' }}>
                                방문 기록이 없습니다.
                              </TableCell>
                            </TableRow>
                          )}
                          {visitStats.departments.map(d => (
                            <TableRow key={d.deptname} hover>
                              <TableCell sx={{ fontSize: '0.82rem', fontWeight: 500 }}>{d.deptname}</TableCell>
                              <TableCell align="right" sx={{ fontSize: '0.82rem', fontWeight: 700, color: '#7C3AED' }}>
                                {d.unique_visitors.toLocaleString()}
                              </TableCell>
                              <TableCell align="right" sx={{ fontSize: '0.82rem', color: '#6B7280' }}>
                                {d.visits.toLocaleString()}
                              </TableCell>
                              <TableCell align="right" sx={{ fontSize: '0.82rem', fontWeight: 700, color: '#0D9488' }}>
                                {d.projects_created.toLocaleString()}
                              </TableCell>
                              <TableCell align="right" sx={{ fontSize: '0.78rem', color: '#6B7280' }}>{d.ratio}%</TableCell>
                              <TableCell sx={{ fontSize: '0.78rem', color: '#9CA3AF' }}>{d.last_visit_date}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    <Typography sx={{ fontSize: '0.7rem', color: '#9CA3AF', mt: 0.8 }}>
                      ※ 프로젝트는 생성자(없으면 소유자) 부서 기준입니다. 부서별 Task 생성 수는 생성자 정보가 없어 제공하지 않습니다(전역 카운트만).
                    </Typography>
                  </Box>

                  <Box sx={{ flex: '1 1 420px', minWidth: 320 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>최근 방문 기록</Typography>
                      {visitStats.ip_masked && (
                        <Chip label="IP 마스킹" size="small" sx={{ height: 18, fontSize: '0.62rem', bgcolor: '#FEF3C7', color: '#B45309' }} />
                      )}
                    </Box>
                    <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2, maxHeight: 420 }}>
                      <Table size="small" stickyHeader>
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem', bgcolor: '#F9FAFB' }}>방문 시간</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem', bgcolor: '#F9FAFB' }}>사용자</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem', bgcolor: '#F9FAFB' }}>부서</TableCell>
                            <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem', bgcolor: '#F9FAFB' }}>IP</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {visitStats.recent.length === 0 && (
                            <TableRow>
                              <TableCell colSpan={4} align="center" sx={{ py: 3, color: '#9CA3AF', fontSize: '0.85rem' }}>
                                방문 기록이 없습니다.
                              </TableCell>
                            </TableRow>
                          )}
                          {visitStats.recent.map((r, idx) => (
                            <TableRow key={idx} hover>
                              <TableCell sx={{ fontSize: '0.76rem', whiteSpace: 'nowrap' }}>{r.timestamp}</TableCell>
                              <TableCell sx={{ fontSize: '0.78rem' }}>{r.username}</TableCell>
                              <TableCell sx={{ fontSize: '0.76rem', color: '#6B7280' }}>{r.deptname}</TableCell>
                              <TableCell sx={{ fontSize: '0.74rem', color: '#9CA3AF', fontFamily: 'monospace' }}>{r.ip_address}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </Box>
                </Box>
              </>
            );
          })()}
        </Box>
      )}

      {/* ── Tab 5: 사내 추천 도구 ── */}
      {tabIndex === 5 && (
        <Box>
          <Alert severity="info" sx={{ borderRadius: 2, mb: 2, fontSize: '0.85rem' }}>
            대시보드에 표시되는 <strong>사내 추천 도구 스트립</strong>을 관리합니다.
            아래 스위치가 <strong>OFF</strong>인 동안에는 어떤 사용자 화면에도 노출되지 않습니다(기본값 OFF).
            개별 항목을 켜고, <strong>바로가기 URL</strong>을 입력한 뒤 전체 노출을 켜주세요.
          </Alert>

          <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2, mb: 3 }}>
            <FormControlLabel
              control={
                <Switch
                  checked={!!recoConfig?.enabled}
                  onChange={e => recoFlagMut.mutate(e.target.checked)}
                  disabled={recoFlagMut.isPending}
                />
              }
              label={
                <Box>
                  <Typography sx={{ fontWeight: 700, fontSize: '0.9rem' }}>
                    추천 도구 스트립 전체 노출
                  </Typography>
                  <Typography sx={{ fontSize: '0.75rem', color: '#6B7280' }}>
                    internal_service_recommendations_enabled
                  </Typography>
                </Box>
              }
            />
          </Paper>

          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {(recoConfig?.recommendations || []).map(item => (
              <Paper key={item.id} variant="outlined" sx={{ p: 2.5, borderRadius: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
                  <Box>
                    <Typography sx={{ fontWeight: 800, fontSize: '0.95rem' }}>{item.title}</Typography>
                    <Typography sx={{ fontSize: '0.74rem', color: '#9CA3AF' }}>
                      {item.target_space_type} · {item.placement}
                    </Typography>
                  </Box>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={!!item.active}
                        onChange={e => recoItemMut.mutate({ id: item.id, updates: { active: e.target.checked } })}
                        disabled={recoItemMut.isPending}
                      />
                    }
                    label={<Typography sx={{ fontSize: '0.8rem', fontWeight: 600 }}>활성</Typography>}
                  />
                </Box>
                <Typography sx={{ fontSize: '0.8rem', color: '#6B7280', mb: 1.5 }}>
                  {item.label} · {item.description}
                </Typography>
                <TextField
                  size="small"
                  fullWidth
                  label="바로가기 URL (외부 https:// 또는 내부 /경로)"
                  defaultValue={item.cta_url || ''}
                  onBlur={e => {
                    const next = e.target.value.trim();
                    if (next !== (item.cta_url || '')) {
                      recoItemMut.mutate({ id: item.id, updates: { cta_url: next } });
                    }
                  }}
                  placeholder="https://..."
                />
              </Paper>
            ))}
            {(recoConfig?.recommendations || []).length === 0 && (
              <Typography sx={{ fontSize: '0.85rem', color: '#9CA3AF', textAlign: 'center', py: 4 }}>
                등록된 추천 항목이 없습니다.
              </Typography>
            )}
          </Box>
        </Box>
      )}

      {/* ── Tab 6: 공간 현황 ── */}
      {tabIndex === 6 && (
        <Box>
          <Alert severity="info" sx={{ borderRadius: 2, mb: 2, fontSize: '0.85rem' }}>
            공간별 <strong>프로젝트/활동 사용 현황</strong>을 확인하고 빈 공간을 안전하게 정리합니다.
            <strong> 완전 빈 공간</strong>(프로젝트·Task·체크시트·Calendar 모두 0)만 정리 대상입니다.
            삭제는 <strong>보관</strong> 후 수동 확인을 거쳐야 하며, 자동 삭제는 수행되지 않습니다.
            (VOC는 공간에 묶이지 않는 전역 데이터라 표에서 제외됩니다.)
          </Alert>

          {/* 요약 */}
          {adminSpacesResp?.summary && (
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
              {([
                ['전체', adminSpacesResp.summary.total],
                ['활성', adminSpacesResp.summary.active],
                ['프로젝트 없음', adminSpacesResp.summary.no_project],
                ['완전 빈 공간', adminSpacesResp.summary.empty],
                ['경고 발송됨', adminSpacesResp.summary.warned],
                ['보관됨', adminSpacesResp.summary.archived],
              ] as [string, number][]).map(([label, n]) => (
                <Chip key={label} label={`${label} ${n}`} size="small" sx={{ fontWeight: 600, fontSize: '0.72rem' }} />
              ))}
            </Box>
          )}

          {/* 필터 + 검색 */}
          <Box sx={{ display: 'flex', gap: 1.5, mb: 2, alignItems: 'center', flexWrap: 'wrap' }}>
            <FormControl size="small" sx={{ minWidth: 200 }}>
              <InputLabel>필터</InputLabel>
              <Select label="필터" value={spaceFilter} onChange={e => setSpaceFilter(e.target.value)}>
                <MenuItem value="all">활성 공간 전체</MenuItem>
                <MenuItem value="no_project">프로젝트 없는 공간</MenuItem>
                <MenuItem value="empty">완전 빈 공간</MenuItem>
                <MenuItem value="inactive_7d">7일 이상 빈 공간</MenuItem>
                <MenuItem value="archived">보관된 공간</MenuItem>
              </Select>
            </FormControl>
            <TextField
              size="small"
              placeholder="공간 이름 검색..."
              value={spaceSearch}
              onChange={e => setSpaceSearch(e.target.value)}
              InputProps={{ startAdornment: <SearchIcon sx={{ fontSize: 18, color: '#9CA3AF', mr: 0.5 }} /> }}
              sx={{ minWidth: 220 }}
            />
          </Box>

          {spaceActionError && (
            <Alert severity="error" sx={{ mb: 2, fontSize: '0.8rem' }} onClose={() => setSpaceActionError(null)}>
              {spaceActionError}
            </Alert>
          )}

          {adminSpacesLoading ? (
            <Box sx={{ textAlign: 'center', py: 6 }}><CircularProgress size={28} /></Box>
          ) : (
            <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2 }}>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ '& th': { fontWeight: 700, fontSize: '0.74rem', whiteSpace: 'nowrap' } }}>
                    <TableCell>공간명</TableCell>
                    <TableCell>유형</TableCell>
                    <TableCell>생성자</TableCell>
                    <TableCell>생성일</TableCell>
                    <TableCell>마지막 활동</TableCell>
                    <TableCell align="center">멤버</TableCell>
                    <TableCell align="center">프로젝트</TableCell>
                    <TableCell align="center">Task</TableCell>
                    <TableCell align="center">체크시트</TableCell>
                    <TableCell align="center">Calendar</TableCell>
                    <TableCell align="center">상태</TableCell>
                    <TableCell align="right">관리</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {(adminSpacesResp?.spaces || []).map(s => (
                    <TableRow key={s.id} hover>
                      <TableCell sx={{ fontWeight: 600, fontSize: '0.78rem' }}>
                        {s.name}
                        {s.cleanup_exempt && (
                          <Chip label="정리 제외" size="small" color="info" sx={{ ml: 0.5, height: 18, fontSize: '0.6rem' }} />
                        )}
                      </TableCell>
                      <TableCell sx={{ fontSize: '0.72rem', color: '#6B7280' }}>{SPACE_PURPOSE_LABELS[s.purpose] || s.purpose}</TableCell>
                      <TableCell sx={{ fontSize: '0.72rem' }}>{s.owner_name || s.creator_name || '-'}</TableCell>
                      <TableCell sx={{ fontSize: '0.72rem', whiteSpace: 'nowrap' }}>{fmtAdminDate(s.created_at)}</TableCell>
                      <TableCell sx={{ fontSize: '0.72rem', whiteSpace: 'nowrap' }}>{fmtAdminDate(s.last_activity_at)}</TableCell>
                      <TableCell align="center" sx={{ fontSize: '0.72rem' }}>{s.member_count}</TableCell>
                      <TableCell align="center" sx={{ fontSize: '0.72rem', fontWeight: s.project_count === 0 ? 700 : 400, color: s.project_count === 0 ? '#EF4444' : 'inherit' }}>{s.project_count}</TableCell>
                      <TableCell align="center" sx={{ fontSize: '0.72rem' }}>{s.task_count}</TableCell>
                      <TableCell align="center" sx={{ fontSize: '0.72rem' }}>{s.checksheet_count}</TableCell>
                      <TableCell align="center" sx={{ fontSize: '0.72rem' }}>{s.calendar_count}</TableCell>
                      <TableCell align="center">
                        <Chip label={s.status} size="small" sx={{ height: 20, fontSize: '0.64rem', fontWeight: 600, ...spaceStatusChipSx(s.status) }} />
                      </TableCell>
                      <TableCell align="right">
                        <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'flex-end', flexWrap: 'wrap' }}>
                          {s.is_active ? (
                            <>
                              <Tooltip title="소유자에게 빈 공간 경고 발송">
                                <span><Button size="small" variant="outlined" sx={{ minWidth: 0, fontSize: '0.64rem', px: 0.8 }} disabled={spaceActionMut.isPending} onClick={() => spaceActionMut.mutate({ action: 'notify', spaceId: s.id })}>알림</Button></span>
                              </Tooltip>
                              <Tooltip title="공간 보관(소프트, 멤버 보존)">
                                <span><Button size="small" variant="outlined" color="warning" sx={{ minWidth: 0, fontSize: '0.64rem', px: 0.8 }} disabled={spaceActionMut.isPending} onClick={() => spaceActionMut.mutate({ action: 'archive', spaceId: s.id })}>보관</Button></span>
                              </Tooltip>
                              <Tooltip title={s.cleanup_exempt ? '자동 정리 대상으로 되돌리기' : '자동 정리에서 제외'}>
                                <span><Button size="small" variant="text" sx={{ minWidth: 0, fontSize: '0.64rem', px: 0.6 }} disabled={spaceActionMut.isPending} onClick={() => spaceActionMut.mutate({ action: 'exempt', spaceId: s.id })}>{s.cleanup_exempt ? '제외해제' : '정리제외'}</Button></span>
                              </Tooltip>
                            </>
                          ) : (
                            <>
                              <Tooltip title="보관된 공간 복구">
                                <span><Button size="small" variant="outlined" color="success" sx={{ minWidth: 0, fontSize: '0.64rem', px: 0.8 }} disabled={spaceActionMut.isPending} onClick={() => spaceActionMut.mutate({ action: 'restore', spaceId: s.id })}>복구</Button></span>
                              </Tooltip>
                              <Tooltip title="완전 삭제(빈 공간만, 확인 필요)">
                                <span><IconButton size="small" color="error" onClick={() => { setSpaceDeleteTarget(s); setSpaceDeleteConfirm(''); setSpaceActionError(null); }}><DeleteIcon sx={{ fontSize: 16 }} /></IconButton></span>
                              </Tooltip>
                            </>
                          )}
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                  {(adminSpacesResp?.spaces || []).length === 0 && (
                    <TableRow>
                      <TableCell colSpan={12} sx={{ textAlign: 'center', py: 4, color: '#9CA3AF', fontSize: '0.82rem' }}>
                        조건에 해당하는 공간이 없습니다.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}

          {spacePagination && spacePagination.total > 0 && (
            <PaginationBar
              page={spacePagination.page}
              pageSize={spacePagination.page_size}
              total={spacePagination.total}
              totalPages={spacePagination.total_pages}
              onPageChange={setSpacePage}
              onPageSizeChange={setSpacePageSize}
              unitLabel="개"
            />
          )}

          {/* 하드 삭제 확인 모달 */}
          <Dialog open={!!spaceDeleteTarget} onClose={() => setSpaceDeleteTarget(null)} maxWidth="xs" fullWidth>
            <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>공간 완전 삭제</DialogTitle>
            <DialogContent>
              {spaceDeleteTarget && (
                <>
                  <Typography sx={{ fontSize: '0.85rem', mb: 1 }}>
                    <strong>{spaceDeleteTarget.name}</strong> 공간을 완전히 삭제하시겠습니까?
                  </Typography>
                  <Typography sx={{ fontSize: '0.78rem', color: '#6B7280', mb: 1.5 }}>
                    프로젝트 {spaceDeleteTarget.project_count}개, Task {spaceDeleteTarget.task_count}개,
                    체크시트 {spaceDeleteTarget.checksheet_count}개, Calendar {spaceDeleteTarget.calendar_count}개입니다.
                    삭제 후 복구할 수 없습니다.
                  </Typography>
                  {spaceActionError && <Alert severity="error" sx={{ mb: 1.5, fontSize: '0.78rem' }}>{spaceActionError}</Alert>}
                  <TextField
                    fullWidth size="small"
                    label="계속하려면 DELETE 를 입력"
                    value={spaceDeleteConfirm}
                    onChange={e => setSpaceDeleteConfirm(e.target.value)}
                  />
                </>
              )}
            </DialogContent>
            <DialogActions sx={{ px: 3, pb: 2 }}>
              <Button onClick={() => setSpaceDeleteTarget(null)} sx={{ color: '#6B7280' }}>취소</Button>
              <Button
                variant="contained" color="error"
                disabled={spaceDeleteConfirm !== 'DELETE' || spaceActionMut.isPending}
                onClick={() => spaceDeleteTarget && spaceActionMut.mutate({ action: 'hard-delete', spaceId: spaceDeleteTarget.id, confirm: spaceDeleteConfirm })}
              >
                완전 삭제
              </Button>
            </DialogActions>
          </Dialog>
        </Box>
      )}

      {/* ── Tab 7: AI Context Inspector (super_admin 전용) ── */}
      {isSuperAdmin && tabIndex === 7 && (
        <AiContextInspector userId={resolvedCurrentUserId} />
      )}
    </Box>
  );
};

export default AdminPage;
