/**
 * SpaceManagePage — 공간 관리 페이지
 * - 전체 공간 목록 (메인 영역, 접근 가능 여부 표시)
 * - 최근 사용한 공간 / 즐겨찾기 공간 (오른쪽 사이드)
 * - 공간 생성/수정/멤버관리 통합
 * - 검색 기반 멤버 추가 (전체 목록 노출 안 함)
 * - 멤버별 역할(owner/operator/member) 관리
 */

import React, { useState, useCallback, useEffect } from 'react';
import {
  Box, Typography, Paper, TextField, Chip, IconButton, Button,
  Tooltip, Dialog, DialogTitle, DialogContent, DialogActions, Pagination,
  Avatar, Select, MenuItem, FormControl, Checkbox, InputLabel, InputAdornment,
  Alert,
} from '@mui/material';
import { useSnackbar } from 'notistack';
import { useUser } from '../context/UserContext';
import SearchIcon from '@mui/icons-material/Search';
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import SettingsIcon from '@mui/icons-material/Settings';
import MoveToInboxIcon from '@mui/icons-material/MoveToInbox';
import WorkspacesIcon from '@mui/icons-material/Workspaces';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import PersonRemoveIcon from '@mui/icons-material/PersonRemove';
import CloseIcon from '@mui/icons-material/Close';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { api, MemberCandidate, MemberOption, MovableProject, SpaceLimits, SimilarSpace } from '../api/client';
import { useAppStore } from '../stores/useAppStore';
import { planAiColors } from '../theme/tokens';
import { useNavigate } from 'react-router-dom';
import MemberSearchSelect from '../components/MemberSearchSelect';
import SpacePurposeSelector from '../components/space/SpacePurposeSelector';
import SpaceEmptyWarningBanner from '../components/space/SpaceEmptyWarningBanner';
import type { SpacePurpose } from '../types';

const SPACES_PER_PAGE = 24;

const ROLE_LABELS: Record<string, string> = {
  owner: '소유자',
  admin: '관리자',
  operator: '공간운영',
  member: '멤버',
};

// 프로젝트 가져오기 모달 — 내 프로젝트 역할 라벨
const PROJECT_ROLE_LABELS: Record<string, string> = {
  owner: '소유자',
  manager: '담당자',
  member: '멤버',
  admin: '관리자',
};

const ROLE_COLORS: Record<string, string> = {
  owner: planAiColors.brand.primary,
  admin: planAiColors.status.purple,
  operator: planAiColors.status.warning,
  member: planAiColors.text.tertiary,
};

const SpaceManagePage: React.FC = () => {
  const currentUserId = useAppStore(state => state.currentUserId);
  const currentSpaceId = useAppStore(state => state.currentSpaceId);
  const setCurrentSpace = useAppStore(state => state.setCurrentSpace);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const { user } = useUser();
  const isAdminUser = user?.role === 'admin' || user?.role === 'super_admin';

  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [deleteConfirm, setDeleteConfirm] = useState<any>(null);

  // 프로젝트 가져오기(공간 이동) 모달 상태
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [importSearch, setImportSearch] = useState('');
  const [selectedProjectIds, setSelectedProjectIds] = useState<number[]>([]);
  const [targetSpaceId, setTargetSpaceId] = useState<number | ''>('');
  const [movingProjects, setMovingProjects] = useState(false);

  // Space create/edit dialog
  const [spaceDialogOpen, setSpaceDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<'create' | 'edit'>('create');
  const [editingSpace, setEditingSpace] = useState<any>(null);
  const [spaceName, setSpaceName] = useState('');
  const [spaceDesc, setSpaceDesc] = useState('');
  const [spacePurpose, setSpacePurpose] = useState<SpacePurpose>('project_management');
  // 공간 생성/수정 중복 제출 방지 (생성 핸들러가 mutation이 아니라 raw async이므로 수동 가드)
  const [savingSpace, setSavingSpace] = useState(false);
  // 공간 생성 시 추가할 멤버 — local(site)/knox 통합 object 배열로 관리 (숫자 id 노출 방지)
  const [createSelectedMembers, setCreateSelectedMembers] = useState<MemberOption[]>([]);
  const [createError, setCreateError] = useState<string | null>(null);
  const [similarSpaces, setSimilarSpaces] = useState<SimilarSpace[]>([]);

  // Member management dialog
  const [memberDialogOpen, setMemberDialogOpen] = useState(false);
  const [managingSpace, setManagingSpace] = useState<any>(null);
  const [memberSearch, setMemberSearch] = useState('');
  const [searchResults, setSearchResults] = useState<MemberCandidate[]>([]);
  const [searching, setSearching] = useState(false);
  const [pendingGroupAdd, setPendingGroupAdd] = useState<Extract<MemberCandidate, { type: 'group' }> | null>(null);
  const [bulkAddMsg, setBulkAddMsg] = useState<string | null>(null);

  // Favorites & recent from localStorage
  const [favoriteIds, setFavoriteIds] = useState<number[]>(() => {
    try { return JSON.parse(localStorage.getItem('plan-a-fav-spaces') || '[]'); } catch { return []; }
  });
  const recentIds: number[] = (() => {
    try { return JSON.parse(localStorage.getItem('plan-a-recent-spaces') || '[]'); } catch { return []; }
  })();

  const toggleFav = (id: number) => {
    setFavoriteIds(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      localStorage.setItem('plan-a-fav-spaces', JSON.stringify(next));
      return next;
    });
  };

  // Fetch ALL spaces (not just user's) with is_member flag
  const { data: allSpaces = [] } = useQuery<any[]>({
    queryKey: ['allSpaces', currentUserId],
    queryFn: () => api.getAllSpaces(currentUserId),
    enabled: currentUserId > 0,
  });

  // 공간 생성 가능 개수 (생성 다이얼로그 사용량 표시)
  const { data: spaceLimits } = useQuery<SpaceLimits>({
    queryKey: ['spaceLimits', currentUserId],
    queryFn: () => api.getSpaceLimits(currentUserId),
    enabled: currentUserId > 0 && spaceDialogOpen && dialogMode === 'create',
  });

  // 중복/유사 공간명 경고 (생성 모드, 디바운스 350ms)
  useEffect(() => {
    if (!spaceDialogOpen || dialogMode !== 'create') { setSimilarSpaces([]); return; }
    const name = spaceName.trim();
    if (name.length < 2) { setSimilarSpaces([]); return; }
    const t = setTimeout(async () => {
      try { setSimilarSpaces(await api.checkSpaceName(name, currentUserId)); }
      catch { setSimilarSpaces([]); }
    }, 350);
    return () => clearTimeout(t);
  }, [spaceName, spaceDialogOpen, dialogMode, currentUserId]);

  const { data: movableProjects = [], isLoading: movableLoading } = useQuery<MovableProject[]>({
    queryKey: ['movableProjects', currentUserId],
    queryFn: () => api.getMovableProjects(currentUserId),
    enabled: currentUserId > 0 && importDialogOpen,
  });

  // Join requests for managing space
  const { data: joinRequests = [] } = useQuery<any[]>({
    queryKey: ['spaceJoinRequests', managingSpace?.id, currentUserId],
    queryFn: () => api.getSpaceJoinRequests(managingSpace!.id, currentUserId),
    enabled: !!managingSpace && memberDialogOpen && currentUserId > 0,
    retry: false,
  });

  const q = search.trim().toLowerCase();
  const filtered = q ? allSpaces.filter((s: any) => s.name.toLowerCase().includes(q) || s.slug.toLowerCase().includes(q)) : allSpaces;

  // 정렬 우선순위: 내가 속한(소유 포함) 공간 → 참여 요청 중 → 그 외 공간.
  // 같은 그룹 안에서는 즐겨찾기 우선, 그다음 이름순. 검색 결과에도 동일하게 적용된다.
  const getSpaceSortPriority = (s: any): number => {
    if (s.is_member) return 0;       // 멤버/소유자 (owner도 SpaceMember이므로 is_member=true)
    if (s.pending_request) return 1; // 참여 요청 중
    return 2;                        // 미참여 공간
  };
  const sortedFiltered = [...filtered].sort((a: any, b: any) => {
    const pa = getSpaceSortPriority(a);
    const pb = getSpaceSortPriority(b);
    if (pa !== pb) return pa - pb;
    const aFav = favoriteIds.includes(a.id);
    const bFav = favoriteIds.includes(b.id);
    if (aFav !== bFav) return aFav ? -1 : 1;
    return String(a.name).localeCompare(String(b.name), 'ko');
  });

  const totalPages = Math.ceil(sortedFiltered.length / SPACES_PER_PAGE);
  const pageSpaces = sortedFiltered.slice(page * SPACES_PER_PAGE, (page + 1) * SPACES_PER_PAGE);

  const favSpaces = allSpaces.filter((s: any) => favoriteIds.includes(s.id));
  const recentSpaces = recentIds.map(id => allSpaces.find((s: any) => s.id === id)).filter((s: any) => s && s.is_member).slice(0, 8);

  // Search candidates (site users + Knox + member groups) for member addition
  const handleMemberSearch = useCallback(async (query: string) => {
    if (!managingSpace || query.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    setSearching(true);
    try {
      const results = await api.getSpaceMemberCandidates(managingSpace.id, query.trim(), currentUserId);
      setSearchResults(results);
    } catch { setSearchResults([]); }
    setSearching(false);
  }, [currentUserId, managingSpace]);

  // Debounced search
  const [searchTimer, setSearchTimer] = useState<any>(null);
  const debouncedSearch = (query: string) => {
    setMemberSearch(query);
    if (searchTimer) clearTimeout(searchTimer);
    if (query.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    setSearchTimer(setTimeout(() => handleMemberSearch(query), 300));
  };

  const handleDeleteSpace = async () => {
    if (!deleteConfirm) return;
    try {
      await api.deleteSpace(deleteConfirm.id, currentUserId);
      queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
      queryClient.invalidateQueries({ queryKey: ['spaces'] });
      if (currentSpaceId === deleteConfirm.id) {
        setCurrentSpace(null, null, null);
      }
      setDeleteConfirm(null);
    } catch (e) { console.error(e); }
  };

  // 대상 공간 선택지: admin/super_admin은 전체 공간, 그 외엔 내가 참여 중인 공간
  // (getAllSpaces 는 활성 공간만 반환하므로 삭제/비활성 공간은 자동 제외)
  const targetSpaceOptions = allSpaces.filter((s: any) => isAdminUser || s.is_member);

  const importQ = importSearch.trim().toLowerCase();
  const filteredMovable = importQ
    ? movableProjects.filter(p => p.name.toLowerCase().includes(importQ))
    : movableProjects;

  const openImportDialog = () => {
    setImportSearch('');
    setSelectedProjectIds([]);
    // 공간관리 페이지가 특정 공간에서 열려 있으면 기본 대상은 현재 공간
    const defaultTarget = currentSpaceId && targetSpaceOptions.some((s: any) => s.id === currentSpaceId)
      ? currentSpaceId
      : (targetSpaceOptions[0]?.id ?? '');
    setTargetSpaceId(defaultTarget);
    setImportDialogOpen(true);
  };

  const handleTargetSpaceChange = (spaceId: number | '') => {
    setTargetSpaceId(spaceId);
    // 이미 대상 공간에 있는 프로젝트는 선택 해제
    if (spaceId) {
      setSelectedProjectIds(prev => prev.filter(pid => {
        const p = movableProjects.find(mp => mp.id === pid);
        return p && p.current_space_id !== spaceId;
      }));
    }
  };

  const toggleProjectSelection = (projectId: number) => {
    setSelectedProjectIds(prev =>
      prev.includes(projectId) ? prev.filter(id => id !== projectId) : [...prev, projectId]
    );
  };

  const handleMoveSelected = async () => {
    if (!targetSpaceId || selectedProjectIds.length === 0 || movingProjects) return;
    setMovingProjects(true);
    try {
      const result = await api.moveProjectsToSpace(selectedProjectIds, targetSpaceId as number, currentUserId);
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      queryClient.invalidateQueries({ queryKey: ['movableProjects'] });
      queryClient.invalidateQueries({ queryKey: ['unassignedProjects'] });
      queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
      queryClient.invalidateQueries({ queryKey: ['spaces'] });
      queryClient.invalidateQueries({ queryKey: ['stats'] });
      const targetName = targetSpaceOptions.find((s: any) => s.id === targetSpaceId)?.name || '';
      if (result.success.length > 0) {
        enqueueSnackbar(`${result.success.length}개 프로젝트가 "${targetName}" 공간으로 이동되었습니다`, { variant: 'success' });
      }
      result.failed.forEach(f => {
        enqueueSnackbar(`${f.name ?? '프로젝트'} 이동 실패: ${f.reason}`, { variant: 'error' });
      });
      setSelectedProjectIds([]);
      if (result.failed.length === 0) setImportDialogOpen(false);
    } catch (e) {
      console.error(e);
      enqueueSnackbar('프로젝트 이동 중 오류가 발생했습니다', { variant: 'error' });
    } finally {
      setMovingProjects(false);
    }
  };

  const selectSpace = (s: any) => {
    if (!s.is_member) return; // Don't navigate if not member
    setCurrentSpace(s.id, s.name, s.slug);
    const recent = [s.id, ...recentIds.filter((x: number) => x !== s.id)].slice(0, 10);
    localStorage.setItem('plan-a-recent-spaces', JSON.stringify(recent));
    navigate(`/space/${s.slug}`);
  };

  const openCreateDialog = () => {
    setDialogMode('create');
    setEditingSpace(null);
    setSpaceName('');
    setSpaceDesc('');
    setSpacePurpose('project_management');
    setCreateSelectedMembers([]);
    setSpaceDialogOpen(true);
  };

  const openEditDialog = (s: any) => {
    setDialogMode('edit');
    setEditingSpace(s);
    setSpaceName(s.name);
    setSpaceDesc(s.description || '');
    setSpacePurpose((s.purpose as SpacePurpose) || 'project_management');
    setSpaceDialogOpen(true);
  };

  const openMemberDialog = (s: any) => {
    setManagingSpace(s);
    setMemberSearch('');
    setSearchResults([]);
    setBulkAddMsg(null);
    setPendingGroupAdd(null);
    setMemberDialogOpen(true);
  };

  const handleCreateSpace = async () => {
    if (!spaceName.trim() || savingSpace) return;
    setSavingSpace(true);
    setCreateError(null);
    try {
      // 선택 멤버를 local(user_id) / knox(loginid upsert) 페이로드로 분리
      const member_user_ids = createSelectedMembers
        .filter(m => m.source === 'local' && typeof m.user_id === 'number')
        .map(m => m.user_id as number);
      const knox_members = createSelectedMembers
        .filter(m => m.source === 'knox')
        .map(m => ({ loginid: m.login_id, name: m.name, email: m.email, deptname: m.deptname }));
      const created = await api.createSpace(
        {
          name: spaceName.trim(),
          description: spaceDesc.trim() || undefined,
          purpose: spacePurpose,
          member_user_ids,
          knox_members: knox_members.length > 0 ? knox_members : undefined,
        },
        currentUserId
      );
      queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
      queryClient.invalidateQueries({ queryKey: ['spaces'] });
      queryClient.invalidateQueries({ queryKey: ['spaceLimits'] });
      setSpaceDialogOpen(false);
      setCurrentSpace(created.id, created.name, created.slug);
      navigate(`/space/${created.slug}`);
    } catch (e: any) {
      console.error(e);
      setCreateError(e?.response?.data?.detail || '공간을 생성하지 못했습니다. 잠시 후 다시 시도해주세요.');
    } finally { setSavingSpace(false); }
  };

  const handleUpdateSpace = async () => {
    if (!editingSpace || !spaceName.trim() || savingSpace) return;
    setSavingSpace(true);
    try {
      const updated = await api.updateSpace(
        editingSpace.id,
        { name: spaceName.trim(), description: spaceDesc.trim() || undefined, purpose: spacePurpose },
        currentUserId
      );
      queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
      queryClient.invalidateQueries({ queryKey: ['spaces'] });
      // If editing current space, update slug in store and URL
      if (currentSpaceId === editingSpace.id) {
        setCurrentSpace(updated.id, updated.name, updated.slug);
        navigate(`/space/${updated.slug}/spaces`, { replace: true });
      }
      setSpaceDialogOpen(false);
    } catch (e) { console.error(e); } finally { setSavingSpace(false); }
  };

  // 새 공간 만들기 / 수정 Dialog 닫기 — 입력 중 실수로 닫혀 값이 사라지지 않도록.
  // backdrop click / ESC 로는 닫히지 않고, 취소/생성 버튼에서만 이 핸들러로 닫는다.
  const handleCloseSpaceDialog = () => {
    const dirty =
      dialogMode === 'create' &&
      (spaceName.trim() !== '' || spaceDesc.trim() !== '' || createSelectedMembers.length > 0);
    if (dirty && !window.confirm('입력 중인 내용이 있습니다.\n정말 취소하시겠습니까?')) {
      return;
    }
    setSpaceDialogOpen(false);
  };

  const refreshManagingSpace = async () => {
    if (!managingSpace) return;
    queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
    queryClient.invalidateQueries({ queryKey: ['spaces'] });
    const updated = await api.getAllSpaces(currentUserId);
    const refreshed = updated.find((s: any) => s.id === managingSpace.id);
    if (refreshed) setManagingSpace(refreshed);
  };

  const handleAddMember = async (userId: number) => {
    if (!managingSpace) return;
    try {
      await api.addSpaceMember(managingSpace.id, userId, currentUserId);
      await refreshManagingSpace();
    } catch (e) { console.error(e); }
  };

  const handleAddKnoxMember = async (c: Extract<MemberCandidate, { type: 'user'; source: 'knox' }>) => {
    if (!managingSpace) return;
    try {
      await api.addSpaceMemberFromKnox(
        managingSpace.id,
        {
          loginid: c.login_id,
          name: c.name,
          email: c.email || undefined,
          deptname: c.department || undefined,
        },
        currentUserId
      );
      await refreshManagingSpace();
    } catch (e) { console.error(e); }
  };

  const handleAddGroupMembers = async (groupId: number) => {
    if (!managingSpace) return;
    try {
      const result = await api.addSpaceMembersFromGroup(managingSpace.id, groupId, currentUserId);
      setBulkAddMsg(
        `"${result.group_name}" 구성원 ${result.added_count}명 추가 완료` +
          (result.skipped_count > 0 ? `, ${result.skipped_count}명은 이미 멤버라 제외되었습니다.` : '')
      );
      await refreshManagingSpace();
    } catch (e) { console.error(e); setBulkAddMsg('그룹 일괄 추가에 실패했습니다.'); }
  };

  const handleRemoveMember = async (userId: number) => {
    if (!managingSpace) return;
    try {
      await api.removeSpaceMember(managingSpace.id, userId, currentUserId);
      queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
      queryClient.invalidateQueries({ queryKey: ['spaces'] });
      const updated = await api.getAllSpaces(currentUserId);
      const refreshed = updated.find((s: any) => s.id === managingSpace.id);
      if (refreshed) setManagingSpace(refreshed);
    } catch (e) { console.error(e); }
  };

  const handleRoleChange = async (userId: number, role: string) => {
    if (!managingSpace) return;
    try {
      await api.updateSpaceMemberRole(managingSpace.id, userId, role, currentUserId);
      queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
      queryClient.invalidateQueries({ queryKey: ['spaces'] });
      const updated = await api.getAllSpaces(currentUserId);
      const refreshed = updated.find((s: any) => s.id === managingSpace.id);
      if (refreshed) setManagingSpace(refreshed);
    } catch (e) { console.error(e); }
  };

  const handleApproveJoinRequest = async (requestId: number, action: string) => {
    if (!managingSpace) return;
    try {
      await api.approveSpaceJoinRequest(managingSpace.id, requestId, action, currentUserId);
      queryClient.invalidateQueries({ queryKey: ['spaceJoinRequests'] });
      queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
      queryClient.invalidateQueries({ queryKey: ['spaces'] });
      const updated = await api.getAllSpaces(currentUserId);
      const refreshed = updated.find((s: any) => s.id === managingSpace.id);
      if (refreshed) setManagingSpace(refreshed);
    } catch (e) { console.error(e); }
  };

  const getMyRole = (s: any) => {
    const m = s.members?.find((m: any) => m.user_id === currentUserId);
    return m?.role || null;
  };

  const canManage = (s: any) => {
    const role = getMyRole(s);
    return role === 'owner' || role === 'admin' || role === 'operator';
  };

  const renderSpaceCard = (s: any) => {
    const myRole = getMyRole(s);
    const isMember = s.is_member;
    return (
      <Paper
        key={s.id}
        sx={{
          display: 'flex', flexDirection: 'column', gap: 1, p: 2, borderRadius: 2.5,
          border: s.id === currentSpaceId ? `2px solid ${planAiColors.brand.primary}` : isMember ? '1px solid rgba(0,0,0,0.08)' : '1px dashed rgba(0,0,0,0.15)',
          bgcolor: s.id === currentSpaceId ? planAiColors.brand.primarySoft : isMember ? 'rgba(255,255,255,0.9)' : 'rgba(0,0,0,0.02)',
          cursor: isMember ? 'pointer' : 'default',
          transition: 'all 0.15s',
          opacity: isMember ? 1 : 0.75,
          '&:hover': isMember ? { borderColor: planAiColors.brand.primaryBorder, boxShadow: '0 2px 12px rgba(41,85,255,0.08)' } : {},
          position: 'relative',
        }}
        elevation={0}
        onClick={() => isMember && selectSpace(s)}
      >
        {/* Deletion warning */}
        {s.warned_at && s.project_count === 0 && (
          <Box sx={{ bgcolor: planAiColors.status.dangerSoft, border: '1px solid #FECACA', borderRadius: 1.5, px: 1.5, py: 0.8 }}>
            <Typography sx={{ fontSize: '0.7rem', color: planAiColors.status.danger, fontWeight: 600 }}>
              프로젝트를 생성하지 않으면 해당 공간은 곧 삭제됩니다
            </Typography>
          </Box>
        )}

        {/* Top row: name + fav */}
        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Typography variant="body2" sx={{ fontWeight: 700, fontSize: '0.92rem' }}>{s.name}</Typography>
              {!isMember && <LockOutlinedIcon sx={{ fontSize: 14, color: planAiColors.border.normal }} />}
            </Box>
            {s.description && (
              <Typography variant="caption" sx={{ color: planAiColors.text.tertiary, fontSize: '0.7rem', display: 'block', mt: 0.3 }}>
                {s.description}
              </Typography>
            )}
          </Box>
          <IconButton size="small" onClick={e => { e.stopPropagation(); toggleFav(s.id); }} sx={{ p: 0.3 }}>
            {favoriteIds.includes(s.id) ? <StarIcon sx={{ fontSize: 16, color: planAiColors.status.warning }} /> : <StarBorderIcon sx={{ fontSize: 16, color: planAiColors.border.normal }} />}
          </IconButton>
        </Box>

        {/* Bottom row: info chips + actions */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8 }}>
          <Chip label={`${s.member_count}명`} size="small" sx={{ height: 20, fontSize: '0.62rem', bgcolor: planAiColors.background.surfaceAlt, color: planAiColors.text.tertiary }} />
          {myRole && (
            <Chip
              label={ROLE_LABELS[myRole] || myRole}
              size="small"
              sx={{ height: 20, fontSize: '0.62rem', bgcolor: `${ROLE_COLORS[myRole] || planAiColors.text.tertiary}15`, color: ROLE_COLORS[myRole] || planAiColors.text.tertiary, fontWeight: 600 }}
            />
          )}
          {!isMember && (
            s.pending_request ? (
              <Chip label="요청 중" size="small" sx={{ height: 20, fontSize: '0.62rem', bgcolor: planAiColors.status.warningSoft, color: planAiColors.status.warning, fontWeight: 600 }} />
            ) : (
              <Chip label="미참여" size="small" sx={{ height: 20, fontSize: '0.62rem', bgcolor: planAiColors.status.dangerSoft, color: planAiColors.status.danger }} />
            )
          )}
          <Box sx={{ flex: 1 }} />
          {canManage(s) && (
            <>
              <Tooltip title="공간 수정">
                <IconButton size="small" onClick={e => { e.stopPropagation(); openEditDialog(s); }} sx={{ p: 0.3, color: planAiColors.text.muted, '&:hover': { color: planAiColors.brand.primary } }}>
                  <EditIcon sx={{ fontSize: 15 }} />
                </IconButton>
              </Tooltip>
              <Tooltip title="멤버 관리">
                <IconButton size="small" onClick={e => { e.stopPropagation(); openMemberDialog(s); }} sx={{ p: 0.3, color: planAiColors.text.muted, '&:hover': { color: planAiColors.status.warning } }}>
                  <SettingsIcon sx={{ fontSize: 15 }} />
                </IconButton>
              </Tooltip>
            </>
          )}
          {myRole === 'owner' && (
            <Tooltip title="공간 삭제">
              <IconButton size="small" onClick={e => { e.stopPropagation(); setDeleteConfirm(s); }} sx={{ p: 0.3, color: planAiColors.border.normal, '&:hover': { color: planAiColors.status.danger } }}>
                <DeleteOutlineIcon sx={{ fontSize: 15 }} />
              </IconButton>
            </Tooltip>
          )}
          {!isMember && (
            s.pending_request ? (
              <Typography sx={{ fontSize: '0.68rem', fontWeight: 600, color: planAiColors.status.warning, px: 1 }}>
                승인 대기 중
              </Typography>
            ) : (
              <Button
                size="small"
                onClick={async (e) => {
                  e.stopPropagation();
                  try {
                    await api.requestJoinSpace(s.id, currentUserId);
                    queryClient.invalidateQueries({ queryKey: ['allSpaces'] });
                  } catch (err) { console.error(err); }
                }}
                sx={{ textTransform: 'none', fontSize: '0.68rem', fontWeight: 600, color: planAiColors.brand.primary, minWidth: 0, px: 1 }}
              >
                참여 신청
              </Button>
            )
          )}
        </Box>
      </Paper>
    );
  };

  return (
    <Box sx={{ display: 'flex', gap: 3, maxWidth: 1200, mx: 'auto' }}>
      {/* ── Main Area: 전체 공간 목록 ── */}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        {/* Header */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2.5 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <WorkspacesIcon sx={{ fontSize: 24, color: planAiColors.brand.primary }} />
            <Typography variant="h5" sx={{ fontWeight: 800 }}>공간</Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button
              variant="contained"
              size="small"
              startIcon={<AddIcon sx={{ fontSize: 16 }} />}
              onClick={openCreateDialog}
              sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.78rem', bgcolor: planAiColors.brand.primary, borderRadius: 2 }}
            >
              새 공간 만들기
            </Button>
            {targetSpaceOptions.length > 0 && (
              <Button
                variant="outlined"
                size="small"
                startIcon={<MoveToInboxIcon sx={{ fontSize: 14 }} />}
                onClick={openImportDialog}
                sx={{ textTransform: 'none', fontWeight: 600, fontSize: '0.72rem', borderColor: planAiColors.status.success, color: planAiColors.status.success, borderRadius: 2, '&:hover': { bgcolor: planAiColors.status.successSoft } }}
              >
                프로젝트 가져오기 / 이동
              </Button>
            )}
          </Box>
        </Box>

        {/* Search */}
        <TextField
          fullWidth size="small" placeholder="공간 이름으로 검색..."
          value={search} onChange={e => { setSearch(e.target.value); setPage(0); }}
          InputProps={{ startAdornment: <SearchIcon sx={{ fontSize: 18, color: planAiColors.text.muted, mr: 1 }} /> }}
          sx={{ mb: 2.5, '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
        />

        {/* 내가 소유한 빈 공간 경고/보관 배너 */}
        {allSpaces
          .filter((s: any) => s.my_role === 'owner' && (s.warned_at || s.archived_at))
          .map((s: any) => (
            <Box key={`warn-${s.id}`} sx={{ mb: 0 }}>
              <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.secondary, display: 'block', mb: 0.5 }}>
                {s.name}
              </Typography>
              <SpaceEmptyWarningBanner space={s} />
            </Box>
          ))}

        {/* Space grid */}
        <Typography variant="overline" sx={{ fontWeight: 700, fontSize: '0.68rem', color: planAiColors.text.secondary, letterSpacing: '0.08em', mb: 1.5, display: 'block' }}>
          전체 공간 ({filtered.length}개)
        </Typography>
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 1.5, mb: 2 }}>
          {pageSpaces.length === 0 && (
            <Paper sx={{ gridColumn: '1 / -1', textAlign: 'center', py: 6, borderRadius: 2, border: '1px solid rgba(0,0,0,0.06)' }} elevation={0}>
              <WorkspacesIcon sx={{ fontSize: 40, color: planAiColors.border.normal, mb: 1 }} />
              <Typography sx={{ color: planAiColors.text.muted, fontSize: '0.88rem', mb: 2 }}>
                {q ? '검색 결과가 없습니다' : '아직 공간이 없습니다'}
              </Typography>
              {!q && (
                <Button
                  variant="outlined" size="small"
                  startIcon={<AddIcon sx={{ fontSize: 14 }} />}
                  onClick={openCreateDialog}
                  sx={{ textTransform: 'none', fontSize: '0.78rem', fontWeight: 600, color: planAiColors.brand.primary, borderColor: planAiColors.brand.primary }}
                >
                  첫 공간 만들기
                </Button>
              )}
            </Paper>
          )}
          {pageSpaces.map(renderSpaceCard)}
        </Box>
        {totalPages > 1 && (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
            <Pagination count={totalPages} page={page + 1} onChange={(_, p) => setPage(p - 1)} />
          </Box>
        )}
      </Box>

      {/* ── Right Sidebar: 즐겨찾기/최근 ── */}
      <Box sx={{ width: 240, flexShrink: 0 }}>
        {/* 즐겨찾기 */}
        <Box sx={{ mb: 3 }}>
          <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: planAiColors.status.warning, textTransform: 'uppercase', letterSpacing: '0.05em', mb: 1 }}>
            즐겨찾기 공간
          </Typography>
          {favSpaces.length === 0 ? (
            <Typography sx={{ fontSize: '0.75rem', color: planAiColors.text.muted }}>즐겨찾기가 없습니다</Typography>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
              {favSpaces.map((s: any) => (
                <Box
                  key={s.id}
                  onClick={() => s.is_member && selectSpace(s)}
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 0.8,
                    py: 0.6, px: 1, borderRadius: 1.5, cursor: s.is_member ? 'pointer' : 'default',
                    '&:hover': s.is_member ? { bgcolor: planAiColors.background.surfaceAlt } : {},
                    bgcolor: s.id === currentSpaceId ? planAiColors.brand.primarySoft : 'transparent',
                  }}
                >
                  <StarIcon sx={{ fontSize: 13, color: planAiColors.status.warning }} />
                  <Typography sx={{ fontSize: '0.78rem', fontWeight: s.id === currentSpaceId ? 700 : 500, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {s.name}
                  </Typography>
                  {!s.is_member && <LockOutlinedIcon sx={{ fontSize: 12, color: planAiColors.border.normal }} />}
                </Box>
              ))}
            </Box>
          )}
        </Box>

        {/* 최근 사용 */}
        <Box>
          <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: planAiColors.text.tertiary, textTransform: 'uppercase', letterSpacing: '0.05em', mb: 1 }}>
            최근 사용한 공간
          </Typography>
          {recentSpaces.length === 0 ? (
            <Typography sx={{ fontSize: '0.75rem', color: planAiColors.text.muted }}>최근 기록이 없습니다</Typography>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
              {recentSpaces.map((s: any) => (
                <Box
                  key={s.id}
                  onClick={() => s.is_member && selectSpace(s)}
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 0.8,
                    py: 0.6, px: 1, borderRadius: 1.5, cursor: s.is_member ? 'pointer' : 'default',
                    '&:hover': s.is_member ? { bgcolor: planAiColors.background.surfaceAlt } : {},
                    bgcolor: s.id === currentSpaceId ? planAiColors.brand.primarySoft : 'transparent',
                  }}
                >
                  <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: s.is_member ? planAiColors.status.success : planAiColors.border.normal, flexShrink: 0 }} />
                  <Typography sx={{ fontSize: '0.78rem', fontWeight: s.id === currentSpaceId ? 700 : 500, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {s.name}
                  </Typography>
                </Box>
              ))}
            </Box>
          )}
        </Box>
      </Box>

      {/* ── 공간 생성/수정 Dialog ── */}
      <Dialog
        open={spaceDialogOpen}
        disableEscapeKeyDown
        onClose={(_event, reason) => {
          // 바깥(backdrop) 클릭 / ESC 로는 닫지 않는다 — 입력값 유실 방지
          if (reason === 'backdropClick' || reason === 'escapeKeyDown') return;
          handleCloseSpaceDialog();
        }}
        maxWidth="sm"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', pb: 1 }}>
          {dialogMode === 'create' ? '새 공간 만들기' : `공간 수정: ${editingSpace?.name || ''}`}
        </DialogTitle>
        <DialogContent>
          {dialogMode === 'create' && spaceLimits && (
            <Box sx={{ mt: 1, mb: 1.5 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.secondary }}>
                  내가 생성한 공간
                </Typography>
                <Typography variant="caption" sx={{ fontWeight: 700, color: spaceLimits.can_create ? planAiColors.text.primary : planAiColors.status.danger }}>
                  {spaceLimits.created} / {spaceLimits.limit ?? '무제한'}
                </Typography>
              </Box>
              {spaceLimits.limit !== null && !spaceLimits.can_create && (
                <Alert severity="error" sx={{ mt: 1, py: 0.5, fontSize: '0.75rem' }}>
                  생성 가능한 공간 수를 초과했습니다. 현재 최대 {spaceLimits.limit}개의 공간만 생성할 수 있습니다. 추가 공간이 필요하면 관리자에게 문의해주세요.
                </Alert>
              )}
              {spaceLimits.can_create && spaceLimits.near_limit && (
                <Alert severity="warning" sx={{ mt: 1, py: 0.5, fontSize: '0.75rem' }}>
                  공간 생성 가능 개수가 얼마 남지 않았습니다. 테스트용 공간은 사용 후 정리해주세요.
                </Alert>
              )}
            </Box>
          )}
          {dialogMode === 'create' && createError && (
            <Alert severity="error" sx={{ mt: 1, mb: 1, py: 0.5, fontSize: '0.75rem' }}>{createError}</Alert>
          )}
          <TextField
            autoFocus fullWidth label="공간 이름 *"
            placeholder="예: DA파트, 개발팀"
            value={spaceName} onChange={e => setSpaceName(e.target.value)}
            sx={{ mt: 1, mb: 1 }}
            helperText={spaceName.trim() ? `URL: /space/${spaceName.trim().replace(/\s+/g, '-')}` : ''}
            FormHelperTextProps={{ sx: { fontSize: '0.68rem', color: planAiColors.brand.primary } }}
            onKeyDown={e => { if (e.key === 'Enter' && spaceName.trim()) dialogMode === 'create' ? handleCreateSpace() : handleUpdateSpace(); }}
          />
          {dialogMode === 'create' && similarSpaces.length > 0 && (
            <Alert severity="warning" sx={{ mb: 1, py: 0.5, fontSize: '0.75rem' }}>
              비슷한 이름의 공간이 이미 있습니다. 기존 공간을 사용하는 게 좋을지 확인해주세요.
              <Box component="ul" sx={{ m: '4px 0 0', pl: 2 }}>
                {similarSpaces.map(s => (
                  <li key={s.id}>
                    {s.name}{s.exact ? ' (동일 이름)' : ''}{s.is_member ? ' · 내가 속한 공간' : ''}
                  </li>
                ))}
              </Box>
            </Alert>
          )}
          <TextField
            fullWidth label="설명 (선택)"
            placeholder="공간에 대한 간단한 설명"
            value={spaceDesc} onChange={e => setSpaceDesc(e.target.value)}
            sx={{ mb: 2 }}
          />

          <Box sx={{ mb: 2 }}>
            <SpacePurposeSelector value={spacePurpose} onChange={setSpacePurpose} />
          </Box>

          {/* 멤버 추가 — 생성 모드에서만. 사이트 구성원 + Knox 통합 검색(공통 컴포넌트) */}
          {dialogMode === 'create' && (
            <MemberSearchSelect
              currentUserId={currentUserId}
              selected={createSelectedMembers}
              onChange={setCreateSelectedMembers}
              label="멤버 추가"
            />
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleCloseSpaceDialog} sx={{ color: planAiColors.text.tertiary }}>취소</Button>
          <Button
            variant="contained"
            disabled={!spaceName.trim() || savingSpace || (dialogMode === 'create' && spaceLimits != null && !spaceLimits.can_create)}
            onClick={dialogMode === 'create' ? handleCreateSpace : handleUpdateSpace}
            sx={{ bgcolor: planAiColors.brand.primary }}
          >
            {savingSpace ? '처리 중…' : dialogMode === 'create' ? '생성' : '저장'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* ── 멤버 관리 Dialog ── */}
      <Dialog open={memberDialogOpen} onClose={() => setMemberDialogOpen(false)} maxWidth="sm" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', pb: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span>멤버 관리: {managingSpace?.name}</span>
          <IconButton size="small" onClick={() => setMemberDialogOpen(false)}><CloseIcon sx={{ fontSize: 18 }} /></IconButton>
        </DialogTitle>
        <DialogContent>
          {/* Add member by search (site users + Knox + groups) */}
          <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.secondary, mb: 0.5, display: 'block', mt: 1 }}>
            멤버 또는 그룹 추가 (이름, ID, 그룹명으로 검색)
          </Typography>
          <TextField
            size="small" fullWidth
            placeholder="2글자 이상 입력하여 검색 (Knox 사내검색 포함)..."
            value={memberSearch}
            onChange={e => debouncedSearch(e.target.value)}
            InputProps={{ startAdornment: <SearchIcon sx={{ fontSize: 16, color: planAiColors.text.muted, mr: 0.5 }} /> }}
            sx={{ mb: 1, '& .MuiOutlinedInput-root': { fontSize: '0.82rem', borderRadius: 1.5 } }}
          />
          {bulkAddMsg && (
            <Typography sx={{ fontSize: '0.72rem', color: planAiColors.status.success, mb: 1, bgcolor: planAiColors.status.successSoft, borderRadius: 1, px: 1, py: 0.5 }}>
              {bulkAddMsg}
            </Typography>
          )}
          {memberSearch.trim().length >= 2 && (
            <Box sx={{ maxHeight: 200, overflowY: 'auto', border: `1px solid ${planAiColors.border.soft}`, borderRadius: 2, p: 0.5, mb: 2 }}>
              {searching && <Typography sx={{ fontSize: '0.75rem', color: planAiColors.text.muted, textAlign: 'center', py: 1 }}>검색 중...</Typography>}
              {!searching && searchResults.length === 0 && (
                <Typography sx={{ fontSize: '0.75rem', color: planAiColors.text.muted, textAlign: 'center', py: 1 }}>검색 결과가 없습니다</Typography>
              )}
              {searchResults.map((c, idx) => {
                if (c.type === 'group') {
                  return (
                    <Box
                      key={`g-${c.group_id}`}
                      onClick={() => setPendingGroupAdd(c)}
                      sx={{
                        display: 'flex', alignItems: 'center', gap: 1,
                        py: 0.6, px: 1.5, borderRadius: 1.5, cursor: 'pointer',
                        '&:hover': { bgcolor: planAiColors.background.surfaceAlt },
                      }}
                    >
                      <Chip label="그룹" size="small" sx={{ height: 18, fontSize: '0.6rem', bgcolor: planAiColors.status.purpleSoft, color: planAiColors.status.purple, fontWeight: 700 }} />
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                          {c.name}
                          <Typography component="span" sx={{ fontSize: '0.68rem', color: planAiColors.text.muted, ml: 0.5 }}>
                            ({c.member_count}명)
                          </Typography>
                        </Typography>
                      </Box>
                      <PersonAddIcon sx={{ fontSize: 16, color: planAiColors.status.purple }} />
                    </Box>
                  );
                }
                if (c.source === 'site') {
                  const already = managingSpace?.members?.some((m: any) => m.user_id === c.user_id);
                  if (already) return null;
                  return (
                    <Box
                      key={`s-${c.user_id}`}
                      onClick={() => handleAddMember(c.user_id)}
                      sx={{
                        display: 'flex', alignItems: 'center', gap: 1,
                        py: 0.6, px: 1.5, borderRadius: 1.5, cursor: 'pointer',
                        '&:hover': { bgcolor: planAiColors.background.surfaceAlt },
                      }}
                    >
                      <Chip label="사이트" size="small" sx={{ height: 18, fontSize: '0.6rem', bgcolor: planAiColors.brand.primarySoft, color: planAiColors.brand.primary, fontWeight: 700 }} />
                      <Avatar sx={{ width: 22, height: 22, fontSize: '0.6rem', bgcolor: c.avatar_color || planAiColors.brand.primary }}>
                        {c.name?.charAt(0).toUpperCase()}
                      </Avatar>
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 500 }}>
                          {c.name}
                          <Typography component="span" sx={{ fontSize: '0.68rem', color: planAiColors.text.muted, ml: 0.5 }}>
                            ({c.login_id}){c.department ? ` · ${c.department}` : ''}
                          </Typography>
                        </Typography>
                      </Box>
                      <PersonAddIcon sx={{ fontSize: 16, color: planAiColors.status.success }} />
                    </Box>
                  );
                }
                // Knox user
                const knoxAlreadyMember = managingSpace?.members?.some((m: any) => m.loginid === c.login_id);
                if (knoxAlreadyMember) return null;
                return (
                  <Box
                    key={`k-${c.login_id}-${idx}`}
                    onClick={() => handleAddKnoxMember(c)}
                    sx={{
                      display: 'flex', alignItems: 'center', gap: 1,
                      py: 0.6, px: 1.5, borderRadius: 1.5, cursor: 'pointer',
                      '&:hover': { bgcolor: planAiColors.background.surfaceAlt },
                    }}
                  >
                    <Chip label="Knox" size="small" sx={{ height: 18, fontSize: '0.6rem', bgcolor: planAiColors.status.warningSoft, color: planAiColors.status.warning, fontWeight: 700 }} />
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 500 }}>
                        {c.name}
                        <Typography component="span" sx={{ fontSize: '0.68rem', color: planAiColors.text.muted, ml: 0.5 }}>
                          ({c.login_id}){c.department ? ` · ${c.department}` : ''}
                        </Typography>
                      </Typography>
                    </Box>
                    <PersonAddIcon sx={{ fontSize: 16, color: planAiColors.status.warning }} />
                  </Box>
                );
              })}
            </Box>
          )}

          {/* Current members */}
          <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.secondary, mb: 0.5, display: 'block' }}>
            현재 멤버 ({managingSpace?.members?.length || 0}명)
          </Typography>
          <Box sx={{ maxHeight: 300, overflowY: 'auto', border: `1px solid ${planAiColors.border.soft}`, borderRadius: 2, p: 0.5 }}>
            {(managingSpace?.members || []).map((m: any) => {
              const isOwner = m.role === 'owner';
              const myRole = getMyRole(managingSpace);
              const canChangeRole = myRole === 'owner' && !isOwner;
              const canRemove = (myRole === 'owner' || myRole === 'admin' || myRole === 'operator') && !isOwner && m.user_id !== currentUserId;
              return (
                <Box
                  key={m.user_id}
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 1,
                    py: 0.7, px: 1.5, borderRadius: 1.5,
                    '&:hover': { bgcolor: planAiColors.background.surfaceAlt },
                  }}
                >
                  <Avatar sx={{ width: 26, height: 26, fontSize: '0.6rem', bgcolor: m.avatar_color || planAiColors.brand.primary }}>
                    {m.username?.charAt(0).toUpperCase()}
                  </Avatar>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 500 }}>
                      {m.username}
                      <Typography component="span" sx={{ fontSize: '0.68rem', color: planAiColors.text.muted, ml: 0.5 }}>
                        ({m.loginid})
                      </Typography>
                    </Typography>
                  </Box>
                  {canChangeRole ? (
                    <FormControl size="small" sx={{ minWidth: 85 }}>
                      <Select
                        value={m.role}
                        onChange={(e) => handleRoleChange(m.user_id, e.target.value as string)}
                        sx={{ fontSize: '0.68rem', height: 26, borderRadius: 1.5, '& .MuiSelect-select': { py: 0.3, px: 1 } }}
                      >
                        <MenuItem value="operator" sx={{ fontSize: '0.75rem' }}>공간운영</MenuItem>
                        <MenuItem value="member" sx={{ fontSize: '0.75rem' }}>멤버</MenuItem>
                      </Select>
                    </FormControl>
                  ) : (
                    <Chip
                      label={ROLE_LABELS[m.role] || m.role}
                      size="small"
                      sx={{
                        height: 22, fontSize: '0.62rem', fontWeight: 600,
                        bgcolor: `${ROLE_COLORS[m.role] || planAiColors.text.tertiary}15`,
                        color: ROLE_COLORS[m.role] || planAiColors.text.tertiary,
                      }}
                    />
                  )}
                  {canRemove && (
                    <Tooltip title="멤버 제거">
                      <IconButton size="small" onClick={() => handleRemoveMember(m.user_id)} sx={{ p: 0.3, color: planAiColors.border.normal, '&:hover': { color: planAiColors.status.danger } }}>
                        <PersonRemoveIcon sx={{ fontSize: 15 }} />
                      </IconButton>
                    </Tooltip>
                  )}
                </Box>
              );
            })}
          </Box>

          {/* Pending join requests */}
          {joinRequests.length > 0 && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.status.danger, mb: 0.5, display: 'block' }}>
                접근 신청 대기 ({joinRequests.length}건)
              </Typography>
              <Box sx={{ border: '1px solid #FECACA', borderRadius: 2, p: 0.5, bgcolor: planAiColors.status.dangerSoft }}>
                {joinRequests.map((req: any) => (
                  <Box key={req.id} sx={{ display: 'flex', alignItems: 'center', gap: 1, py: 0.6, px: 1 }}>
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 600 }}>
                        {req.username}
                        <Typography component="span" sx={{ fontSize: '0.68rem', color: planAiColors.text.muted, ml: 0.5 }}>({req.loginid})</Typography>
                      </Typography>
                    </Box>
                    <Button size="small" onClick={() => handleApproveJoinRequest(req.id, 'approve')} sx={{ minWidth: 0, fontSize: '0.68rem', color: planAiColors.status.success, fontWeight: 700 }}>승인</Button>
                    <Button size="small" onClick={() => handleApproveJoinRequest(req.id, 'reject')} sx={{ minWidth: 0, fontSize: '0.68rem', color: planAiColors.status.danger, fontWeight: 700 }}>거절</Button>
                  </Box>
                ))}
              </Box>
            </Box>
          )}
        </DialogContent>
      </Dialog>

      {/* 그룹 일괄 추가 확인 */}
      <Dialog open={!!pendingGroupAdd} onClose={() => setPendingGroupAdd(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>그룹 구성원 일괄 추가</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ color: planAiColors.text.secondary }}>
            <strong>{pendingGroupAdd?.name}</strong>의 {pendingGroupAdd?.member_count}명을 이 공간에 추가할까요?
          </Typography>
          <Typography variant="caption" sx={{ color: planAiColors.text.muted, mt: 1, display: 'block' }}>
            이미 멤버인 사용자는 자동으로 제외됩니다.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setPendingGroupAdd(null)} sx={{ color: planAiColors.text.tertiary }}>취소</Button>
          <Button
            variant="contained"
            onClick={async () => {
              if (pendingGroupAdd) {
                const gid = pendingGroupAdd.group_id;
                setPendingGroupAdd(null);
                await handleAddGroupMembers(gid);
              }
            }}
            sx={{ bgcolor: planAiColors.brand.primary }}
          >
            일괄 추가
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete confirmation */}
      <Dialog open={!!deleteConfirm} onClose={() => setDeleteConfirm(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>공간 삭제</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ color: planAiColors.text.secondary }}>
            <strong>{deleteConfirm?.name}</strong> 공간을 삭제하시겠습니까?
          </Typography>
          <Typography variant="caption" sx={{ color: planAiColors.text.muted, mt: 1, display: 'block' }}>
            공간에 속한 프로젝트는 삭제되지 않으며, 기본 공간으로 이동됩니다.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setDeleteConfirm(null)} sx={{ color: planAiColors.text.tertiary }}>취소</Button>
          <Button variant="contained" onClick={handleDeleteSpace} sx={{ bgcolor: planAiColors.status.danger, '&:hover': { bgcolor: planAiColors.status.danger } }}>삭제</Button>
        </DialogActions>
      </Dialog>

      {/* 프로젝트 가져오기 / 공간 이동 */}
      <Dialog open={importDialogOpen} onClose={() => !movingProjects && setImportDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>프로젝트 가져오기 / 이동</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ color: planAiColors.text.tertiary, fontSize: '0.8rem', mb: 1 }}>
            내가 소유자이거나 담당자(관리 멤버)인 프로젝트를 다른 공간으로 이동할 수 있습니다.
          </Typography>
          <Box sx={{ bgcolor: planAiColors.status.successSoft, border: '1px solid #BBF7D0', borderRadius: 2, p: 1.25, mb: 2 }}>
            <Typography variant="caption" sx={{ color: planAiColors.status.success, fontSize: '0.72rem', display: 'block', lineHeight: 1.6 }}>
              선택한 프로젝트는 기존 공간에서 선택한 공간으로 <b>이동</b>됩니다. (복사가 아닙니다)<br />
              프로젝트 내용, 작업, 체크시트, 이력은 그대로 유지됩니다.
            </Typography>
          </Box>

          {/* 이동할 공간 선택 */}
          <FormControl fullWidth size="small" sx={{ mb: 2 }}>
            <InputLabel id="target-space-label">이동할 공간</InputLabel>
            <Select
              labelId="target-space-label"
              label="이동할 공간"
              value={targetSpaceId}
              onChange={(e) => handleTargetSpaceChange(e.target.value as number)}
            >
              {targetSpaceOptions.map((s: any) => (
                <MenuItem key={s.id} value={s.id}>{s.name}</MenuItem>
              ))}
            </Select>
          </FormControl>

          {/* 프로젝트명 검색 */}
          <TextField
            fullWidth size="small" placeholder="프로젝트명 검색..."
            value={importSearch}
            onChange={(e) => setImportSearch(e.target.value)}
            sx={{ mb: 1.5 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ fontSize: 18, color: planAiColors.text.muted }} />
                </InputAdornment>
              ),
            }}
          />

          {/* 이동할 프로젝트 목록 */}
          {movableLoading ? (
            <Typography sx={{ color: planAiColors.text.muted, textAlign: 'center', py: 4, fontSize: '0.85rem' }}>
              불러오는 중...
            </Typography>
          ) : filteredMovable.length === 0 ? (
            <Typography sx={{ color: planAiColors.text.muted, textAlign: 'center', py: 4, fontSize: '0.85rem' }}>
              이동할 수 있는 프로젝트가 없습니다
            </Typography>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75, maxHeight: 320, overflowY: 'auto' }}>
              {filteredMovable.map(p => {
                const alreadyHere = !!targetSpaceId && p.current_space_id === targetSpaceId;
                const checked = selectedProjectIds.includes(p.id);
                return (
                  <Paper
                    key={p.id}
                    elevation={0}
                    onClick={() => !alreadyHere && toggleProjectSelection(p.id)}
                    sx={{
                      display: 'flex', alignItems: 'center', gap: 1, p: 1.25, borderRadius: 2,
                      border: '1px solid', borderColor: checked ? planAiColors.brand.primary : 'rgba(0,0,0,0.06)',
                      bgcolor: alreadyHere ? planAiColors.background.surfaceAlt : checked ? planAiColors.brand.primarySoft : 'transparent',
                      opacity: alreadyHere ? 0.6 : 1, cursor: alreadyHere ? 'default' : 'pointer',
                    }}
                  >
                    <Checkbox
                      size="small" checked={checked} disabled={alreadyHere} sx={{ p: 0.5 }}
                      onChange={() => toggleProjectSelection(p.id)}
                      onClick={(e) => e.stopPropagation()}
                    />
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography variant="body2" sx={{ fontWeight: 600, fontSize: '0.83rem' }} noWrap>{p.name}</Typography>
                      <Typography variant="caption" sx={{ color: planAiColors.text.tertiary, fontSize: '0.68rem' }}>
                        현재 공간: {p.current_space_name || '미지정'} · 내 역할: {PROJECT_ROLE_LABELS[p.my_project_role || ''] || p.my_project_role || '-'}
                      </Typography>
                    </Box>
                    {alreadyHere && (
                      <Chip label="이미 이 공간" size="small" sx={{ height: 20, fontSize: '0.62rem', bgcolor: planAiColors.border.soft, color: planAiColors.text.tertiary }} />
                    )}
                  </Paper>
                );
              })}
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setImportDialogOpen(false)} disabled={movingProjects} sx={{ textTransform: 'none', color: planAiColors.text.tertiary }}>취소</Button>
          <Button
            variant="contained"
            onClick={handleMoveSelected}
            disabled={movingProjects || selectedProjectIds.length === 0 || !targetSpaceId}
            sx={{ textTransform: 'none', bgcolor: planAiColors.status.success, '&:hover': { bgcolor: planAiColors.status.success } }}
          >
            {movingProjects ? '이동 중...' : `선택한 프로젝트 이동${selectedProjectIds.length > 0 ? ` (${selectedProjectIds.length})` : ''}`}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SpaceManagePage;
