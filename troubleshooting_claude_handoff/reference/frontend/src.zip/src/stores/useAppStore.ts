import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Task, CalendarEvent } from '../types';
import { CustomThemeSettings, DEFAULT_CUSTOM_THEME } from '../theme/customTheme';

type ThemeMode = 'preset' | 'custom';

interface AppState {
  // Current user
  currentUserId: number;
  currentLoginId: string; // ✅ 추가
  setCurrentUserId: (id: number) => void;
  setCurrentLoginId: (loginid: string) => void; // ✅ 추가

  // Drawer
  isDrawerOpen: boolean;
  selectedTask: Task | null;
  drawerProjectId: number;
  drawerInitialData: Partial<Task> | null;
  openDrawer: (task?: Task | null, projectId?: number, initialData?: Partial<Task> | null) => void;
  closeDrawer: () => void;

  // Calendar event dialog (Phase 2) — 단순 일정 추가/편집
  isEventDialogOpen: boolean;
  selectedEvent: CalendarEvent | null;
  eventDialogDate: string | null; // 신규 생성 시 기본 날짜 (YYYY-MM-DD)
  openEventDialog: (event?: CalendarEvent | null, date?: string | null) => void;
  closeEventDialog: () => void;

  // Filter
  filterStatus: string;
  filterSearch: string;
  setFilterStatus: (status: string) => void;
  setFilterSearch: (search: string) => void;

  // Board 완료 체크포인트 임시 필터 (특정 체크포인트에 포함된 Task만 Board에 표시)
  // 영속화하지 않는 일시적 탐색 상태. columnId 기준으로 live 재계산하여 카드/Popover/Board count 일치 보장.
  boardCheckpointFilter: { projectId: number; columnId: number; label: string } | null;
  setBoardCheckpointFilter: (filter: { projectId: number; columnId: number; label: string } | null) => void;

  // 중간 완료(체크포인트) 패널 접기 상태 — key: `${projectId}:${viewType}` (board/list/roadmap)
  // 표시 UI만 제어(계산/자동이동/설정 불변). collapsed=true 면 큰 패널 대신 toolbar compact chip 표시.
  checkpointPanelCollapsed: Record<string, boolean>;
  setCheckpointPanelCollapsed: (key: string, collapsed: boolean) => void;

  // Undo
  lastDeletedTask: Task | null;
  setLastDeletedTask: (task: Task | null) => void;

  // Theme
  bgColor: string;
  setBgColor: (color: string) => void;

  // Theme builder (preset + custom)
  themeMode: ThemeMode;
  themePresetId: string;
  customTheme: CustomThemeSettings;
  /** 프리셋(배경) 적용 — 전체 톤을 한 번에 적용 */
  setThemePreset: (background: string) => void;
  /** 고급 설정 일부 변경 (배경/포인트색/둥글기/그림자) */
  setCustomTheme: (partial: Partial<CustomThemeSettings>) => void;
  /** 기본값으로 초기화 */
  resetTheme: () => void;

  // Sidebar collapse
  projectsCollapsed: boolean;
  toggleProjectsCollapsed: () => void;

  // Space context
  currentSpaceId: number | null;
  currentSpaceName: string | null;
  currentSpaceSlug: string | null;
  setCurrentSpace: (id: number | null, name: string | null, slug?: string | null) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    set => ({
      // ✅ Current user (persisted)
      currentUserId: 0, // ⭐ 권장: 1 -> 0
      currentLoginId: '', // ✅ 추가
      setCurrentUserId: id => set({ currentUserId: id }),
      setCurrentLoginId: loginid => set({ currentLoginId: loginid }),

      // Drawer
      isDrawerOpen: false,
      selectedTask: null,
      drawerProjectId: 1,
      drawerInitialData: null,
      openDrawer: (task = null, projectId = 1, initialData = null) =>
        set({
          isDrawerOpen: true,
          selectedTask: task,
          drawerProjectId: projectId,
          drawerInitialData: initialData,
        }),
      closeDrawer: () => set({ isDrawerOpen: false, selectedTask: null, drawerInitialData: null }),

      // Calendar event dialog (Phase 2)
      isEventDialogOpen: false,
      selectedEvent: null,
      eventDialogDate: null,
      openEventDialog: (event = null, date = null) =>
        set({ isEventDialogOpen: true, selectedEvent: event, eventDialogDate: date }),
      closeEventDialog: () => set({ isEventDialogOpen: false, selectedEvent: null, eventDialogDate: null }),

      // Filter
      filterStatus: 'all',
      filterSearch: '',
      setFilterStatus: status => set({ filterStatus: status }),
      setFilterSearch: search => set({ filterSearch: search }),

      // Board 완료 체크포인트 필터 (비영속)
      boardCheckpointFilter: null,
      setBoardCheckpointFilter: filter => set({ boardCheckpointFilter: filter }),

      // 중간 완료 패널 접기 상태 (view별 저장)
      checkpointPanelCollapsed: {},
      setCheckpointPanelCollapsed: (key, collapsed) =>
        set(state => ({
          checkpointPanelCollapsed: { ...state.checkpointPanelCollapsed, [key]: collapsed },
        })),

      // Undo
      lastDeletedTask: null,
      setLastDeletedTask: task => set({ lastDeletedTask: task }),

      // Theme
      bgColor: '#F3F4F6',
      setBgColor: color =>
        set(state => ({ bgColor: color, customTheme: { ...state.customTheme, background: color } })),

      // Theme builder
      themeMode: 'preset',
      themePresetId: DEFAULT_CUSTOM_THEME.background,
      customTheme: DEFAULT_CUSTOM_THEME,
      setThemePreset: background =>
        set(state => ({
          themeMode: 'preset',
          themePresetId: background,
          bgColor: background,
          customTheme: { ...state.customTheme, background },
        })),
      setCustomTheme: partial =>
        set(state => {
          const next = { ...state.customTheme, ...partial };
          return {
            themeMode: 'custom',
            customTheme: next,
            // 배경색은 기존 bgColor 와 항상 동기화한다.
            bgColor: next.background,
          };
        }),
      resetTheme: () =>
        set({
          themeMode: 'preset',
          themePresetId: DEFAULT_CUSTOM_THEME.background,
          customTheme: DEFAULT_CUSTOM_THEME,
          bgColor: DEFAULT_CUSTOM_THEME.background,
        }),

      // Sidebar collapse
      projectsCollapsed: false,
      toggleProjectsCollapsed: () =>
        set(state => ({ projectsCollapsed: !state.projectsCollapsed })),

      // Space context
      currentSpaceId: null,
      currentSpaceName: null,
      currentSpaceSlug: null,
      setCurrentSpace: (id, name, slug = null) => set({ currentSpaceId: id, currentSpaceName: name, currentSpaceSlug: slug }),
    }),
    {
      name: 'antigravity-app-store',
      partialize: state => ({
        currentUserId: state.currentUserId,
        currentLoginId: state.currentLoginId,
        bgColor: state.bgColor,
        themeMode: state.themeMode,
        themePresetId: state.themePresetId,
        customTheme: state.customTheme,
        projectsCollapsed: state.projectsCollapsed,
        checkpointPanelCollapsed: state.checkpointPanelCollapsed,
        currentSpaceId: state.currentSpaceId,
        currentSpaceName: state.currentSpaceName,
        currentSpaceSlug: state.currentSpaceSlug,
      }),
      // 기존 사용자(이전엔 bgColor 만 저장)도 깨지지 않도록 customTheme.background 를 bgColor 에 맞춘다.
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<AppState>;
        const merged = { ...current, ...p } as AppState;
        const base = (p.customTheme as CustomThemeSettings | undefined) ?? current.customTheme;
        merged.customTheme = { ...base, background: p.bgColor ?? base.background };
        merged.bgColor = merged.customTheme.background;
        return merged;
      },
    }
  )
);
