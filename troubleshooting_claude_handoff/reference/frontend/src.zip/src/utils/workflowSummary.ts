import type { Task, WorkflowColumn } from '../types';
import { planAiColors } from '../theme/tokens';

// CUSTOM 컬럼 색 fallback (mapped_status 기준) — Board chips/Dashboard/Graph 공용
export const WORKFLOW_STATUS_FALLBACK_COLOR: Record<string, string> = {
  todo: planAiColors.text.tertiary,
  in_progress: planAiColors.brand.primary,
  done: planAiColors.status.success,
  hold: planAiColors.status.warning,
};

export interface WorkflowStageSummary {
  workflow_column_id: number;
  label: string;
  count: number;
  color: string;
  mapped_status: string;
  is_final_done: boolean;
  sort_order: number;
}

/**
 * Task가 표시될 workflow 컬럼 id를 결정한다.
 * 백엔드 `_pick_column_for_status` 와 동일 정책으로, Board 컬럼 배치/상단 chip/Dashboard가
 * 같은 결과를 내도록 단일 helper로 둔다 (count 불일치 방지).
 *
 * - workflow_column_id 가 있고 active 컬럼이면 그대로 사용
 * - 없으면 status 기준 fallback: done→마지막(is_final_done) / hold→hold / todo→첫 todo /
 *   in_progress→첫 in_progress(없으면 중간) / 그 외→첫 컬럼
 */
export function resolveTaskColumnId(
  task: Pick<Task, 'workflow_column_id' | 'status'>,
  activeSortedColumns: WorkflowColumn[],
): number | null {
  const cols = activeSortedColumns;
  if (cols.length === 0) return null;

  const wid = task.workflow_column_id ?? null;
  if (wid != null && cols.some(c => c.id === wid)) return wid;

  const status = task.status;
  if (status === 'done') {
    const finals = cols.filter(c => c.is_final_done);
    if (finals.length) return finals[finals.length - 1].id;
    const dones = cols.filter(c => c.mapped_status === 'done');
    if (dones.length) return dones[dones.length - 1].id;
    return cols[cols.length - 1].id;
  }
  if (status === 'hold') {
    const holds = cols.filter(c => c.mapped_status === 'hold');
    if (holds.length) return holds[0].id;
    return cols[0].id;
  }
  const match = cols.filter(c => c.mapped_status === status);
  if (match.length) return match[0].id;
  if (status === 'in_progress') {
    const flow = cols.filter(c => c.mapped_status !== 'hold');
    if (flow.length >= 3) return flow[Math.floor(flow.length / 2)].id;
    if (flow.length >= 2) return flow[1].id;
  }
  return cols[0].id;
}

/**
 * CUSTOM 워크플로우 단계별 요약(라벨/개수/색)을 만든다.
 * Board 상단 chip, Dashboard Overview(단일 프로젝트 context)에서 공유한다.
 */
export function buildWorkflowStageSummary(
  tasks: Task[],
  columns: WorkflowColumn[],
): WorkflowStageSummary[] {
  const active = columns.filter(c => c.active).slice().sort((a, b) => a.sort_order - b.sort_order);
  const counts = new Map<number, number>();
  active.forEach(c => counts.set(c.id, 0));
  for (const t of tasks) {
    const cid = resolveTaskColumnId(t, active);
    if (cid != null && counts.has(cid)) counts.set(cid, (counts.get(cid) || 0) + 1);
  }
  return active.map(c => ({
    workflow_column_id: c.id,
    label: c.label,
    count: counts.get(c.id) || 0,
    color: c.color || WORKFLOW_STATUS_FALLBACK_COLOR[c.mapped_status] || planAiColors.text.tertiary,
    mapped_status: c.mapped_status,
    is_final_done: c.is_final_done,
    sort_order: c.sort_order,
  }));
}
