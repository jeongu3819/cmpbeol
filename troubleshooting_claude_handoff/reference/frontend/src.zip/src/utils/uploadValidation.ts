/**
 * 공통 파일 업로드 검증 (frontend 즉시 검증용).
 *
 * frontend 검증은 사용자 편의를 위한 1차 방어선이며, 최종 차단은 backend(`upload_policy.py`)가
 * 동일 규칙으로 수행한다. 정책 값은 `GET /api/upload-policy`(api.getUploadPolicy)에서 받아온다.
 */
import type { GeneralUploadPolicy, InlineImagePolicy } from '../api/client';

export const fileExt = (name: string): string => {
  const dot = name.lastIndexOf('.');
  return dot >= 0 ? name.slice(dot).toLowerCase() : '';
};

export const formatBytes = (bytes: number): string => {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
};

export interface GeneralValidationResult {
  accepted: File[];
  error: string | null;
}

/**
 * 일반 첨부(문서+이미지) 다중 파일 검증.
 * 통과한 파일 목록과, 위반 시 첫 오류 메시지를 반환한다(위반 시 accepted 는 빈 배열).
 */
export function validateGeneralFiles(
  policy: GeneralUploadPolicy | undefined,
  files: File[],
  existingCount: number,
  existingBytes: number,
): GeneralValidationResult {
  if (!policy) return { accepted: files, error: null }; // 정책 미로딩 시 서버 검증에 위임

  let runningCount = existingCount;
  let runningBytes = existingBytes;
  const accepted: File[] = [];

  for (const file of files) {
    const ext = fileExt(file.name);
    if (!ext || !policy.allowed_extensions.includes(ext)) {
      return { accepted: [], error: `업로드할 수 없는 파일 형식입니다. ${policy.allowed_label} 파일만 첨부할 수 있습니다.\n(${file.name})` };
    }
    if (file.size > policy.max_file_bytes) {
      return { accepted: [], error: `파일 1개당 최대 ${policy.max_file_mb}MB까지만 업로드할 수 있습니다.\n(${file.name}: ${formatBytes(file.size)})` };
    }
    if (runningCount + 1 > policy.max_file_count) {
      return { accepted: [], error: `첨부파일은 최대 ${policy.max_file_count}개까지 업로드할 수 있습니다.` };
    }
    if (runningBytes + file.size > policy.max_total_bytes) {
      return { accepted: [], error: `전체 첨부 용량은 최대 ${policy.max_total_mb}MB까지 허용됩니다.` };
    }
    runningCount += 1;
    runningBytes += file.size;
    accepted.push(file);
  }
  return { accepted, error: null };
}

/**
 * 인라인 이미지(Description/작업노트/단발일정 붙여넣기) 단일 파일 검증.
 * @param extraExts VOC 등에서 추가로 허용할 확장자 (예: ['.gif'])
 * @returns 오류 메시지 또는 null(통과)
 */
export function validateInlineImage(
  policy: InlineImagePolicy | undefined,
  file: File,
  extraExts: string[] = [],
): string | null {
  if (!policy) return null; // 정책 미로딩 시 서버 검증에 위임
  const allowed = [...policy.allowed_extensions, ...extraExts];
  const ext = fileExt(file.name);
  if (!ext || !allowed.includes(ext)) {
    return `이미지는 ${policy.allowed_label} 형식만 첨부할 수 있습니다.`;
  }
  if (file.size > policy.max_file_bytes) {
    return `이미지 1개당 최대 ${policy.max_file_mb}MB까지만 업로드할 수 있습니다.`;
  }
  return null;
}
