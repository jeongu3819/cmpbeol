// 일정(Start/Due) 표시 공통 helper.
// "날짜가 비어 있음(null)"과 "사용자가 의도적으로 미정(TBD)으로 설정함"을 구분해서 표시한다.
// Board / List / Roadmap / Calendar / Task Details 어디서나 동일하게 사용한다.

export interface ScheduleInput {
  startDate?: string | null;
  dueDate?: string | null;
  startDateTbd?: boolean | null;
  dueDateTbd?: boolean | null;
}

/** Task 필드(snake_case)를 ScheduleInput 으로 변환하는 편의 함수. */
export function scheduleFromTask(task: {
  start_date?: string | null;
  due_date?: string | null;
  start_date_tbd?: boolean | null;
  due_date_tbd?: boolean | null;
}): ScheduleInput {
  return {
    startDate: task.start_date,
    dueDate: task.due_date,
    startDateTbd: task.start_date_tbd,
    dueDateTbd: task.due_date_tbd,
  };
}

/** YYYY-MM-DD 문자열을 그대로 쓰되, 잘못된 값이면 원본을 반환. (전체 표기: 2026-07-10) */
export function formatDate(d?: string | null): string {
  if (!d) return '';
  return d;
}

/** 짧은 표기용: 2026-07-10 → 7/10 */
export function formatDateShort(d?: string | null): string {
  if (!d) return '';
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(d);
  if (!m) return d;
  return `${Number(m[2])}/${Number(m[3])}`;
}

/**
 * 전체 표기 (Task Details / Roadmap tooltip 등):
 *   일정 미정 / 시작 미정 ~ 2026-07-15 / 2026-07-10 ~ Due 미정 / 2026-07-10 ~ 2026-07-15
 */
export function formatScheduleRange(input: ScheduleInput): string {
  const { startDate, dueDate, startDateTbd, dueDateTbd } = input;
  if (startDateTbd && dueDateTbd) return '일정 미정';
  if (startDateTbd && dueDate) return `시작 미정 ~ ${formatDate(dueDate)}`;
  if (startDate && dueDateTbd) return `${formatDate(startDate)} ~ Due 미정`;
  if (startDate && dueDate) return `${formatDate(startDate)} ~ ${formatDate(dueDate)}`;
  if (startDate) return `${formatDate(startDate)} ~ Due 미정`;
  if (dueDate) return `시작 미정 ~ ${formatDate(dueDate)}`;
  return '일정 미정';
}

/**
 * 짧은 표기 (Board 카드 / List 셀 등 — chip/badge 용):
 *   일정 미정 / 시작 미정 · Due 7/15 / Start 7/10 · Due 미정 / 7/10 ~ 7/15
 * 아무 정보도 없으면 빈 문자열(표시 생략용).
 */
export function formatScheduleShort(input: ScheduleInput): string {
  const { startDate, dueDate, startDateTbd, dueDateTbd } = input;
  if (startDateTbd && dueDateTbd) return '일정 미정';
  if (startDateTbd && dueDate) return `시작 미정 · Due ${formatDateShort(dueDate)}`;
  if (startDate && dueDateTbd) return `Start ${formatDateShort(startDate)} · Due 미정`;
  if (startDate && dueDate) return `${formatDateShort(startDate)} ~ ${formatDateShort(dueDate)}`;
  if (startDate) return `Start ${formatDateShort(startDate)} · Due 미정`;
  if (dueDate) return `시작 미정 · Due ${formatDateShort(dueDate)}`;
  if (startDateTbd || dueDateTbd) return '일정 미정';
  return '';
}

/** 일정이 하나도 확정되지 않았는지(둘 다 미정이거나 둘 다 날짜 없음) 여부. */
export function isScheduleUnset(input: ScheduleInput): boolean {
  const { startDate, dueDate, startDateTbd, dueDateTbd } = input;
  const hasStart = !!startDate && !startDateTbd;
  const hasDue = !!dueDate && !dueDateTbd;
  return !hasStart && !hasDue;
}

// ── 일정 상태 필터 (§11) ──
//   all       : 전체
//   confirmed : 일정 확정 (양쪽 확정 날짜 존재)
//   tbd       : 일정 미정 (Start 또는 Due 가 미정)
//   start_tbd : Start 미정
//   due_tbd   : Due 미정
export type ScheduleFilter = 'all' | 'confirmed' | 'tbd' | 'start_tbd' | 'due_tbd';

export const SCHEDULE_FILTER_OPTIONS: { value: ScheduleFilter; label: string }[] = [
  { value: 'all', label: '전체' },
  { value: 'confirmed', label: '일정 확정' },
  { value: 'tbd', label: '일정 미정' },
  { value: 'start_tbd', label: 'Start 미정' },
  { value: 'due_tbd', label: 'Due 미정' },
];

/** 일정 상태 필터에 부합하는지 판정. */
export function matchesScheduleFilter(input: ScheduleInput, filter: ScheduleFilter): boolean {
  if (filter === 'all') return true;
  const { startDate, dueDate, startDateTbd, dueDateTbd } = input;
  switch (filter) {
    case 'confirmed':
      return !startDateTbd && !dueDateTbd && !!startDate && !!dueDate;
    case 'tbd':
      return !!startDateTbd || !!dueDateTbd;
    case 'start_tbd':
      return !!startDateTbd;
    case 'due_tbd':
      return !!dueDateTbd;
    default:
      return true;
  }
}

/** Task(snake_case) → matchesScheduleFilter 편의 wrapper. */
export function taskMatchesScheduleFilter(
  task: { start_date?: string | null; due_date?: string | null; start_date_tbd?: boolean | null; due_date_tbd?: boolean | null },
  filter: ScheduleFilter,
): boolean {
  return matchesScheduleFilter(scheduleFromTask(task), filter);
}

// ── Start/Due 추천 (Phase 3) ──
// LLM 없이 결정론적으로 추천 날짜를 계산한다.
//   - 우선순위별 기본 소요기간: high=3일, medium=7일, low=14일
//   - Start 미정 + Due 확정  → Start = Due − 기간 (마감 역산)
//   - Due 미정 + Start 확정  → Due = Start + 기간
//   - 둘 다 없음/미정        → Start = 오늘, Due = 오늘 + 기간

const PRIORITY_DURATION_DAYS: Record<string, number> = { high: 3, medium: 7, low: 14 };

function durationForPriority(priority?: string | null): number {
  return PRIORITY_DURATION_DAYS[priority || 'medium'] ?? 7;
}

/** 'YYYY-MM-DD' 에 일수를 더해 'YYYY-MM-DD' 반환 (로컬 타임존 영향 없이 UTC 계산). */
export function addDaysYmd(ymd: string, days: number): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(ymd);
  if (!m) return ymd;
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function todayYmd(): string {
  return new Date().toISOString().slice(0, 10);
}

export interface ScheduleSuggestion {
  date: string;     // 추천 날짜 (YYYY-MM-DD)
  reason: string;   // 추천 근거 (툴팁/설명용)
}

/** Start 날짜 추천. 추천 불가하면 null. */
export function suggestStartDate(input: ScheduleInput & { priority?: string | null }): ScheduleSuggestion | null {
  const { startDate, dueDate, priority } = input;
  const dur = durationForPriority(priority);
  if (startDate) return null; // 이미 시작일 있음
  if (dueDate) {
    return { date: addDaysYmd(dueDate, -dur), reason: `마감일(${dueDate}) 기준 ${dur}일 역산` };
  }
  return { date: todayYmd(), reason: '기준 일정이 없어 오늘로 제안' };
}

/** Due 날짜 추천. 추천 불가하면 null. */
export function suggestDueDate(input: ScheduleInput & { priority?: string | null }): ScheduleSuggestion | null {
  const { startDate, dueDate, priority } = input;
  const dur = durationForPriority(priority);
  if (dueDate) return null; // 이미 마감일 있음
  const anchor = startDate || todayYmd();
  const anchorLabel = startDate ? `시작일(${startDate})` : '오늘';
  return { date: addDaysYmd(anchor, dur), reason: `${anchorLabel} 기준 ${dur}일 (우선순위 반영)` };
}
