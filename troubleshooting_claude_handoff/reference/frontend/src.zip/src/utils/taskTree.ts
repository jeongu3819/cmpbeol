/**
 * 공통 Task 계층(재귀형 Parent/Child) Tree 유틸.
 *
 * Board / List / Roadmap / Graph 에서 계층 계산을 각자 다르게 하지 않도록 한 곳에 모은다.
 * 잘못된 기존 데이터(존재하지 않는 parent_task_id, 순환)로 인해 무한 재귀가 발생하지 않도록
 * 모든 순회에 visited set 을 사용한다.
 */
import type { Task } from '../types';

/** 트리를 만들 수 있는 최소 형태 — id(숫자)와 parent_task_id 만 있으면 된다.
 *  Task 뿐 아니라 Roadmap 등 다른 화면의 항목도 이 util 을 재사용할 수 있게 일반화. */
export interface TreeItemBase {
  id: number;
  parent_task_id?: number | null;
}

export type TaskTreeNode<T extends TreeItemBase = Task> = T & {
  children: TaskTreeNode<T>[];
  depth: number;
};

/**
 * 존재하지 않는 parent / 순환을 방어하며 root 를 최상위로 하는 트리를 만든다.
 * - parent_task_id 가 목록에 없으면 해당 항목은 root 로 승격(고아 방지)
 * - 조상 체인이 순환하면 해당 항목을 root 로 승격(무한루프 방지)
 * - 형제(sibling) 순서는 입력 배열 순서를 그대로 유지
 */
export function buildTaskTree<T extends TreeItemBase>(tasks: T[]): TaskTreeNode<T>[] {
  const byId = new Map<number, T>();
  tasks.forEach((t) => byId.set(t.id, t));

  const nodes = new Map<number, TaskTreeNode<T>>();
  tasks.forEach((t) => nodes.set(t.id, { ...t, children: [], depth: 0 }));

  // 조상 체인이 존재하는 root 로 정상 종료되는지 검사 — 아니면 root 취급.
  const isRoot = (t: T): boolean => {
    const pid = t.parent_task_id ?? null;
    if (pid == null) return true;        // 부모 없음 = 최상위
    if (!byId.has(pid)) return true;     // 직속 부모가 목록에 없음 → root 로 승격(고아 방지)
    // 순환 검사: 조상을 거슬러 올라가다 자기 자신이 다시 나오면 순환 → root 로 승격.
    // (조상 체인이 위에서 끊겨도(=조상의 부모 누락) 직속 부모가 있으면 attach 한다.)
    let cur: number | null = pid;
    const seen = new Set<number>([t.id]);
    while (cur != null && byId.has(cur)) {
      if (seen.has(cur)) return true;
      seen.add(cur);
      cur = byId.get(cur)!.parent_task_id ?? null;
    }
    return false;
  };

  const roots: TaskTreeNode<T>[] = [];
  tasks.forEach((t) => {
    const node = nodes.get(t.id)!;
    if (isRoot(t)) {
      roots.push(node);
    } else {
      nodes.get(t.parent_task_id as number)!.children.push(node);
    }
  });

  // depth 부여 — children 은 위 단계에서 이미 비순환이지만 visited 로 이중 방어.
  const setDepth = (list: TaskTreeNode<T>[], d: number, visited: Set<number>) => {
    list.forEach((n) => {
      if (visited.has(n.id)) {
        n.children = [];
        return;
      }
      visited.add(n.id);
      n.depth = d;
      setDepth(n.children, d + 1, visited);
    });
  };
  setDepth(roots, 0, new Set());
  return roots;
}

/**
 * 펼침(expanded) 상태를 반영해 트리를 화면 표시 순서(부모 바로 아래 자식)로 평탄화한다.
 * expandedIds 에 없는 노드의 children 은 접혀서 결과에서 제외된다.
 */
export function flattenVisibleTaskTree<T extends TreeItemBase>(
  tree: TaskTreeNode<T>[],
  expandedIds: Set<number>,
): TaskTreeNode<T>[] {
  const out: TaskTreeNode<T>[] = [];
  const walk = (nodes: TaskTreeNode<T>[], guard: Set<number>) => {
    nodes.forEach((n) => {
      if (guard.has(n.id)) return;
      guard.add(n.id);
      out.push(n);
      if (n.children.length > 0 && expandedIds.has(n.id)) walk(n.children, guard);
    });
  };
  walk(tree, new Set());
  return out;
}

/** taskId 의 모든 하위(자식/손자/...) id 집합 (자신 제외). 순환 방어. */
export function getTaskDescendantIds(taskId: number, tasks: Task[]): Set<number> {
  const childrenByParent = new Map<number, number[]>();
  tasks.forEach((t) => {
    const pid = t.parent_task_id;
    if (pid != null) {
      const arr = childrenByParent.get(pid);
      if (arr) arr.push(t.id);
      else childrenByParent.set(pid, [t.id]);
    }
  });

  const result = new Set<number>();
  const visited = new Set<number>([taskId]);
  const stack = [taskId];
  while (stack.length) {
    const cur = stack.pop()!;
    const kids = childrenByParent.get(cur);
    if (!kids) continue;
    kids.forEach((k) => {
      if (visited.has(k)) return;
      visited.add(k);
      result.add(k);
      stack.push(k);
    });
  }
  return result;
}

/** candidateId 가 taskId 의 하위(자식/손자/...)인지. 상위 후보 필터·순환 차단에 사용. */
export function isTaskDescendant(candidateId: number, taskId: number, tasks: Task[]): boolean {
  return getTaskDescendantIds(taskId, tasks).has(candidateId);
}

/**
 * activeId(끄는 Task)를 targetId(놓는 Task)의 하위 작업으로 연결 가능한지 — Board/Graph DnD 공통 규칙.
 * Board 단계(컬럼/status) 일치는 뷰에서 별도로 검사한다(여기서는 구조적 유효성만).
 * - 자기 자신 위에는 불가
 * - target 이 active 의 하위(descendant)면 순환 → 불가
 * - 이미 target 의 직속 자식이면 변화 없음 → 불가(불필요한 저장 방지)
 */
export function canLinkTaskAsChild(activeId: number, targetId: number, tasks: Task[]): boolean {
  if (activeId === targetId) return false;
  if (isTaskDescendant(targetId, activeId, tasks)) return false;
  const active = tasks.find((t) => t.id === activeId);
  if (active && (active.parent_task_id ?? null) === targetId) return false;
  return true;
}

/**
 * root → ... → taskId 까지의 조상 경로(자신 포함)를 반환. breadcrumb/tooltip 용.
 * 예: [설계 진행, 상세 설계, 도면 검토]. 순환/누락 부모는 visited/undefined 로 안전 종료.
 */
export function getTaskAncestorPath(taskId: number, tasks: Task[]): Task[] {
  const byId = new Map<number, Task>();
  tasks.forEach((t) => byId.set(t.id, t));

  const path: Task[] = [];
  const seen = new Set<number>();
  let cur: Task | undefined = byId.get(taskId);
  while (cur && !seen.has(cur.id)) {
    seen.add(cur.id);
    path.unshift(cur);
    const pid = cur.parent_task_id ?? null;
    cur = pid != null ? byId.get(pid) : undefined;
  }
  return path;
}

/**
 * 검색/필터 시 매칭된 Task(matchIds)와 그 조상 경로를 함께 보이도록 계산 — List/Roadmap 공용.
 * - visibleIds: 매칭 Task + 모든 조상 (트리 연결이 끊기지 않도록)
 * - ancestorIds: 조상만(자신 제외) — 자동 펼침 대상
 * 중복은 Set 으로 자연 제거되고, 순환/누락 부모는 getTaskAncestorPath 가 방어한다.
 */
export function collectTasksWithAncestors(
  tasks: Task[],
  matchIds: Set<number>,
): { visibleIds: Set<number>; ancestorIds: Set<number> } {
  const visibleIds = new Set<number>();
  const ancestorIds = new Set<number>();
  matchIds.forEach((id) => {
    const path = getTaskAncestorPath(id, tasks);
    path.forEach((a) => visibleIds.add(a.id));
    path.slice(0, -1).forEach((a) => ancestorIds.add(a.id));
  });
  return { visibleIds, ancestorIds };
}

/**
 * 검색/필터 결과의 트리 표시 컨텍스트 (List/Roadmap 공통, 객체 인자 형태).
 * matchedTaskIds 는 텍스트 검색이든 담당자/상태/우선순위 필터든 **직접 매칭된 Task id 집합**이면 된다
 * (필터 종류에 비의존적). 결과:
 * - visibleIds: 매칭 Task + 그 모든 조상 (조상의 다른 형제/하위는 포함하지 않음 → 경로만)
 * - ancestorIds: 조상만(자신 제외) → 검색 중 임시로 펼칠 대상
 */
export function collectVisibleTreeContext(params: {
  allTasks: Task[];
  matchedTaskIds: Set<number>;
}): { visibleIds: Set<number>; ancestorIds: Set<number> } {
  return collectTasksWithAncestors(params.allTasks, params.matchedTaskIds);
}

/**
 * 화면에 표시할 최종 펼침 집합 — **검색 자동 펼침을 임시로만 유지**하는 핵심 계산.
 *   결과 = (기본 펼침 base − 사용자가 접은 collapsed) ∪ 검색으로 임시 펼칠 forcedExpand
 *
 * 기본 전체 펼침(base = children 을 가진 모든 parent id) 정책에서:
 * - 사용자가 접은 노드는 base 에서 제외되어 접힘 유지
 * - 검색 중에는 매칭 경로의 조상(forcedExpand)이 접혀 있어도 임시로 펼쳐짐
 * - 검색을 지우면 forcedExpand 가 비므로 **collapsed 상태가 그대로 복원**된다
 *   (collapsedTaskIds 자체를 절대 변형하지 않는 것이 전제).
 */
export function computeExpandedIds(
  baseExpandableIds: Iterable<number>,
  collapsedIds: Set<number>,
  forcedExpandIds: Set<number>,
): Set<number> {
  const s = new Set<number>();
  for (const id of baseExpandableIds) s.add(id);
  collapsedIds.forEach((id) => s.delete(id));
  forcedExpandIds.forEach((id) => s.add(id));
  return s;
}
