import { describe, it, expect } from 'vitest';
import type { Task } from '../types';
import {
  buildTaskTree,
  flattenVisibleTaskTree,
  getTaskDescendantIds,
  isTaskDescendant,
  getTaskAncestorPath,
  canLinkTaskAsChild,
  collectTasksWithAncestors,
  collectVisibleTreeContext,
  computeExpandedIds,
} from './taskTree';

const mk = (id: number, parent: number | null, title = `t${id}`): Task =>
  ({ id, parent_task_id: parent, title } as Task);

// A(1) → B(2) → C(3), D(4) 최상위, E(5)는 A의 두 번째 자식
const A = mk(1, null, 'A');
const B = mk(2, 1, 'B');
const C = mk(3, 2, 'C');
const D = mk(4, null, 'D');
const E = mk(5, 1, 'E');
const tasks = [A, B, C, D, E];

describe('buildTaskTree', () => {
  it('다단계 트리 + depth 계산 + sibling 순서 유지', () => {
    const tree = buildTaskTree(tasks);
    expect(tree.map((n) => n.id)).toEqual([1, 4]); // roots: A, D (입력 순서)
    const a = tree[0];
    expect(a.depth).toBe(0);
    expect(a.children.map((n) => n.id)).toEqual([2, 5]); // B, E 순서 유지
    const b = a.children[0];
    expect(b.depth).toBe(1);
    expect(b.children.map((n) => n.id)).toEqual([3]); // C
    expect(b.children[0].depth).toBe(2);
  });

  it('존재하지 않는 parent 는 root 로 승격(고아 방지)', () => {
    const orphan = mk(9, 999, 'orphan');
    const tree = buildTaskTree([A, orphan]);
    expect(tree.map((n) => n.id).sort()).toEqual([1, 9]);
  });

  it('순환 데이터에도 무한루프 없이 안전 종료', () => {
    // X→Y→X 상호 참조
    const X = mk(10, 11, 'X');
    const Y = mk(11, 10, 'Y');
    const tree = buildTaskTree([X, Y]);
    // 둘 다 조상 체인이 순환 → root 로 승격되어 렌더 누락되지 않음
    expect(tree.map((n) => n.id).sort()).toEqual([10, 11]);
  });
});

describe('getTaskDescendantIds / isTaskDescendant', () => {
  it('A 의 descendant = {B,C,E}', () => {
    expect([...getTaskDescendantIds(1, tasks)].sort()).toEqual([2, 3, 5]);
  });
  it('B 의 descendant = {C}', () => {
    expect([...getTaskDescendantIds(2, tasks)].sort()).toEqual([3]);
  });
  it('isTaskDescendant: C 는 A 의 하위, A 는 C 의 하위가 아님', () => {
    expect(isTaskDescendant(3, 1, tasks)).toBe(true);
    expect(isTaskDescendant(1, 3, tasks)).toBe(false);
  });
});

describe('상위 작업 후보 필터(1차-B 규칙)', () => {
  // 후보 = 자기 자신 제외 + 자신의 descendant 제외
  const candidatesFor = (taskId: number) => {
    const desc = getTaskDescendantIds(taskId, tasks);
    return tasks.filter((t) => t.id !== taskId && !desc.has(t.id)).map((t) => t.id);
  };
  it('B 의 상위 후보에 다른 유효 Task 표시, 자신/후손(C) 제외', () => {
    // B(2)의 후손은 C(3). 후보 = A,D,E
    expect(candidatesFor(2).sort()).toEqual([1, 4, 5]);
  });
  it('A 의 상위 후보에서 B,C,E(전부 후손) 제외 → D만', () => {
    expect(candidatesFor(1)).toEqual([4]);
  });
});

describe('canLinkTaskAsChild (Board/Graph DnD 규칙)', () => {
  it('D 를 A 하위로 연결 가능(구조상 유효)', () => {
    expect(canLinkTaskAsChild(4, 1, tasks)).toBe(true);
  });
  it('자기 자신 위에는 불가', () => {
    expect(canLinkTaskAsChild(1, 1, tasks)).toBe(false);
  });
  it('A 를 자신의 하위(C) 아래로 연결하면 순환 → 불가', () => {
    expect(canLinkTaskAsChild(1, 3, tasks)).toBe(false);
  });
  it('이미 직속 자식(B→A)이면 변화 없음 → 불가', () => {
    expect(canLinkTaskAsChild(2, 1, tasks)).toBe(false);
  });
});

describe('getTaskAncestorPath', () => {
  it('C 의 경로 = [A,B,C]', () => {
    expect(getTaskAncestorPath(3, tasks).map((t) => t.title)).toEqual(['A', 'B', 'C']);
  });
});

describe('collectTasksWithAncestors (List/Roadmap 검색 시 조상 포함)', () => {
  it('손자 C 매칭 → C+B+A 표시, 조상 A,B 자동 펼침(중복 없음)', () => {
    const { visibleIds, ancestorIds } = collectTasksWithAncestors(tasks, new Set([3]));
    expect([...visibleIds].sort()).toEqual([1, 2, 3]); // A,B,C
    expect([...ancestorIds].sort()).toEqual([1, 2]);   // A,B (자신 C 제외)
  });
  it('root D 매칭 → D만, 조상 없음', () => {
    const { visibleIds, ancestorIds } = collectTasksWithAncestors(tasks, new Set([4]));
    expect([...visibleIds]).toEqual([4]);
    expect([...ancestorIds]).toEqual([]);
  });
  it('여러 매칭의 조상이 겹쳐도 중복 없이 합집합', () => {
    const { visibleIds } = collectTasksWithAncestors(tasks, new Set([3, 5])); // C(손자), E(A의 자식)
    expect([...visibleIds].sort()).toEqual([1, 2, 3, 5]); // A,B,C,E
  });
});

describe('collectVisibleTreeContext (필터 비의존 공통 API)', () => {
  it('collectTasksWithAncestors 와 동일 결과(객체 인자)', () => {
    const a = collectVisibleTreeContext({ allTasks: tasks, matchedTaskIds: new Set([3]) });
    const b = collectTasksWithAncestors(tasks, new Set([3]));
    expect([...a.visibleIds].sort()).toEqual([...b.visibleIds].sort());
    expect([...a.ancestorIds].sort()).toEqual([...b.ancestorIds].sort());
  });
  it('필터 매칭(임의 id 집합)에도 경로만 포함 — 조상의 다른 형제/하위는 제외', () => {
    // C(3) 매칭 → A,B,C 만. E(5=A의 다른 자식), D(4) 는 미포함
    const { visibleIds } = collectVisibleTreeContext({ allTasks: tasks, matchedTaskIds: new Set([3]) });
    expect([...visibleIds].sort()).toEqual([1, 2, 3]);
    expect(visibleIds.has(5)).toBe(false);
    expect(visibleIds.has(4)).toBe(false);
  });
});

describe('computeExpandedIds (검색 자동 펼침 임시성/복원)', () => {
  // A(1),B(2) 가 children 을 가진 parent (base). 사용자가 A 를 접음.
  const base = new Set([1, 2]);
  it('기본: 전체 펼침', () => {
    expect([...computeExpandedIds(base, new Set(), new Set())].sort()).toEqual([1, 2]);
  });
  it('사용자가 A 접음 → A 제외', () => {
    expect([...computeExpandedIds(base, new Set([1]), new Set())].sort()).toEqual([2]);
  });
  it('검색 중: 접힌 A 가 매칭 경로 조상이면 임시로 다시 펼쳐짐', () => {
    const expanded = computeExpandedIds(base, new Set([1]), new Set([1]));
    expect(expanded.has(1)).toBe(true); // 임시 펼침
  });
  it('검색 해제(forced 비움) → 사용자 접힘(A) 그대로 복원', () => {
    const expanded = computeExpandedIds(base, new Set([1]), new Set());
    expect(expanded.has(1)).toBe(false); // 복원되어 다시 접힘
    expect([...expanded]).toEqual([2]);
  });
});

describe('flattenVisibleTaskTree', () => {
  it('접힘 상태 반영: A 만 펼치면 B,E 는 보이고 C 는 숨김', () => {
    const tree = buildTaskTree(tasks);
    const visible = flattenVisibleTaskTree(tree, new Set([1])); // A만 expanded
    expect(visible.map((n) => n.id)).toEqual([1, 2, 5, 4]);
  });
  it('A,B 펼치면 C 까지 표시', () => {
    const tree = buildTaskTree(tasks);
    const visible = flattenVisibleTaskTree(tree, new Set([1, 2]));
    expect(visible.map((n) => n.id)).toEqual([1, 2, 3, 5, 4]);
  });
  it('아무것도 안 펼치면 root(A,D)만 — 접힘 시 모든 descendant 제외', () => {
    const tree = buildTaskTree(tasks);
    const visible = flattenVisibleTaskTree(tree, new Set());
    expect(visible.map((n) => n.id)).toEqual([1, 4]);
  });
});

describe('buildTaskTree generic (Roadmap 등 Task 외 재사용)', () => {
  type W = { id: number; parent_task_id: number | null; name: string };
  it('id/parent_task_id + 부가필드 형태도 트리 구성 + 필드 보존 + depth', () => {
    const items: W[] = [
      { id: 1, parent_task_id: null, name: 'A' },
      { id: 2, parent_task_id: 1, name: 'B' },
      { id: 3, parent_task_id: 2, name: 'C' },
    ];
    const tree = buildTaskTree(items);
    expect(tree).toHaveLength(1);
    expect(tree[0].name).toBe('A');
    expect(tree[0].children[0].name).toBe('B');
    expect(tree[0].children[0].children[0].name).toBe('C');
    expect(tree[0].children[0].children[0].depth).toBe(2);
  });
  it('그룹 밖 부모(누락) 참조는 root 로 승격(고아 방지)', () => {
    const items: W[] = [
      { id: 10, parent_task_id: 999, name: 'orphan' }, // 부모가 이 그룹에 없음
      { id: 11, parent_task_id: 10, name: 'child' },
    ];
    const tree = buildTaskTree(items);
    expect(tree.map((n) => n.id)).toEqual([10]);          // orphan 이 root
    expect(tree[0].children.map((n) => n.id)).toEqual([11]);
  });
});
