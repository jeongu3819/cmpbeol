import { API_URL } from '../api/client';

/** 백엔드가 돌려준 root-relative URL(/api/...)을 절대 URL로 보정.
 *  - 이미 절대 URL(http://, https://, data:, blob:) 이면 그대로.
 *  - 프론트(5173)와 백엔드(8085) 포트가 달라 prepend 필요. */
export const toAbsoluteAttachmentUrl = (url: string): string => {
    if (!url) return url;
    if (/^(https?:|data:|blob:)/i.test(url)) return url;
    const baseUrl = API_URL.replace(/\/api\/?$/, '');
    return url.startsWith('/') ? `${baseUrl}${url}` : `${baseUrl}/${url}`;
};

/** 기존에 root-relative 로 저장된 <img src="/api/..."> 들을 in-place 로 절대 URL 로 보정.
 *  innerHTML 자체는 보존돼야 저장 시 의도치 않은 diff 가 나지 않음. 그래서 src 가 이미
 *  절대 URL 인 경우는 건드리지 않는다. */
export const normalizeImagesInRoot = (root: HTMLElement) => {
    const imgs = root.querySelectorAll('img');
    imgs.forEach((img) => {
        const raw = img.getAttribute('src') || '';
        if (!raw) return;
        if (/^(https?:|data:|blob:)/i.test(raw)) return;
        img.setAttribute('src', toAbsoluteAttachmentUrl(raw));
    });
};

/**
 * description(HTML 또는 plain text)을 카드/목록/리포트 미리보기용 순수 텍스트로 변환.
 * - 리치 에디터 도입 후 description 이 <img>/<div> 등 HTML 을 담을 수 있어, plain text 로
 *   렌더하던 미리보기에서 태그가 그대로 노출되는 것을 방지.
 * - HTML 태그가 없으면(기존 plain text) 원본을 그대로 반환.
 * - 텍스트가 없고 이미지만 있으면 🖼 표시.
 */
export function descriptionToPreviewText(html?: string | null): string {
    if (!html) return '';
    if (!/<[a-z][\s\S]*>/i.test(html)) return html; // 기존 plain text
    try {
        const tmp = document.createElement('div');
        tmp.innerHTML = html;
        const text = (tmp.textContent || '').replace(/\s+/g, ' ').trim();
        if (text) return text;
        if (tmp.querySelector('img')) return '🖼 이미지';
        return '';
    } catch {
        return html;
    }
}

/**
 * 클립보드 붙여넣기 이미지 압축/리사이즈.
 * - 1MB 미만이면 원본 그대로 (확장자만 보정).
 * - 큰 이미지: 긴 변 1920px 로 축소, JPEG q=0.85 (PNG 알파 감지 시 PNG 유지).
 * - 실패하면 원본 Blob 을 File 로 감싸서 반환 (절대 throw 하지 않음).
 */
export async function compressPastedImage(
    blob: Blob,
    timestamp: number,
    namePrefix = 'paste',
): Promise<File> {
    const SMALL_BYTES = 1024 * 1024; // 1MB
    const MAX_EDGE = 1920;
    const QUALITY = 0.85;
    const sourceType = blob.type || 'image/png';
    const fallbackExt = sourceType.includes('jpeg') || sourceType.includes('jpg') ? 'jpg' : 'png';
    const fallback = new File([blob], `${namePrefix}-${timestamp}.${fallbackExt}`, { type: sourceType });
    if (blob.size <= SMALL_BYTES) return fallback;
    try {
        const url = URL.createObjectURL(blob);
        try {
            const image = await new Promise<HTMLImageElement>((resolve, reject) => {
                const img = new Image();
                img.onload = () => resolve(img);
                img.onerror = () => reject(new Error('image decode failed'));
                img.src = url;
            });
            const w = image.naturalWidth || image.width;
            const h = image.naturalHeight || image.height;
            if (!w || !h) return fallback;
            const longEdge = Math.max(w, h);
            const scale = longEdge > MAX_EDGE ? MAX_EDGE / longEdge : 1;
            const tw = Math.max(1, Math.round(w * scale));
            const th = Math.max(1, Math.round(h * scale));
            const canvas = document.createElement('canvas');
            canvas.width = tw;
            canvas.height = th;
            const ctx = canvas.getContext('2d');
            if (!ctx) return fallback;
            ctx.drawImage(image, 0, 0, tw, th);
            // PNG 원본은 알파를 보존(투명 배경 캡처 대비). 그 외엔 JPEG 로 압축.
            const isPng = sourceType.includes('png');
            const outType = isPng ? 'image/png' : 'image/jpeg';
            const outExt = isPng ? 'png' : 'jpg';
            const outBlob: Blob | null = await new Promise((resolve) =>
                canvas.toBlob((b) => resolve(b), outType, QUALITY)
            );
            if (!outBlob) return fallback;
            // 압축 결과가 더 크면 (이미 작은 PNG 등) 원본 사용.
            if (outBlob.size >= blob.size) return fallback;
            return new File([outBlob], `${namePrefix}-${timestamp}.${outExt}`, { type: outType });
        } finally {
            URL.revokeObjectURL(url);
        }
    } catch (e) {
        console.warn('compressPastedImage failed, using original:', e);
        return fallback;
    }
}
