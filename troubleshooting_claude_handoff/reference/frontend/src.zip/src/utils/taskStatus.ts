import type { Task } from '../types';
import { planAiColors } from '../theme/tokens';

export type BoardColumnId =
  | 'todo'
  | 'in_progress'
  | 'in_progress_advanced'
  | 'done'
  | 'hold';

export const BOARD_COLUMNS: {
  id: BoardColumnId;
  label: string;
  sublabel?: string;
  color: string;
  status: Task['status'];
}[] = [
  { id: 'todo', label: 'To Do', color: planAiColors.text.tertiary, status: 'todo' },
  { id: 'in_progress', label: 'In Progress', color: planAiColors.brand.primary, status: 'in_progress' },
  { id: 'in_progress_advanced', label: 'In Progress', sublabel: '50% 이상 진행', color: planAiColors.status.purple, status: 'in_progress' },
  { id: 'done', label: 'Done', color: planAiColors.status.success, status: 'done' },
  { id: 'hold', label: 'Hold', color: planAiColors.status.warning, status: 'hold' },
];

export const ALL_COLUMN_IDS: BoardColumnId[] = BOARD_COLUMNS.map((c) => c.id);

/**
 * Single source of truth: which visual column does a task belong to?
 * Rule:
 *  - hold       → hold
 *  - done OR progress≥100 → done
 *  - in_progress AND progress≥50 → in_progress_advanced
 *  - in_progress (progress<50)   → in_progress
 *  - todo       → todo
 */
export function deriveBoardColumn(task: Pick<Task, 'status' | 'progress'>): BoardColumnId {
  const status = task.status;
  const progress = task.progress ?? 0;
  if (status === 'hold') return 'hold';
  if (status === 'done' || progress >= 100) return 'done';
  if (status === 'in_progress') {
    return progress >= 50 ? 'in_progress_advanced' : 'in_progress';
  }
  return 'todo';
}

/** Does a task render in `colId`? Used by filter predicates. */
export function belongsToColumn(task: Pick<Task, 'status' | 'progress'>, colId: BoardColumnId): boolean {
  return deriveBoardColumn(task) === colId;
}

/**
 * Display label/colors for a task based on its derived column.
 * Use this wherever a single status chip/label is rendered so that
 * `in_progress` with progress ≥50 shows "In Progress · 50% 이상 진행".
 */
export interface StatusDisplay {
  label: string;
  sublabel?: string;
  color: string;
  bgcolor: string;
}

// CUSTOM 워크플로우 컬럼 색 fallback (mapped_status 기준)
const WORKFLOW_FALLBACK_COLOR: Record<string, string> = {
  todo: planAiColors.text.tertiary,
  in_progress: planAiColors.brand.primary,
  done: planAiColors.status.success,
  hold: planAiColors.status.warning,
};

/**
 * CUSTOM 모드면 workflow label 을 우선 표시, 아니면 기존 status display 로 폴백.
 * 통계/완료율 계산은 그대로 canonical status 를 쓰고, 이 함수는 "표시"에만 쓴다.
 */
export function getWorkflowDisplay(
  task: Pick<Task, 'status' | 'progress' | 'workflow_label' | 'workflow_color' | 'workflow_mapped_status'>,
  isCustom: boolean,
): StatusDisplay {
  if (isCustom && task.workflow_label) {
    const color =
      task.workflow_color ||
      WORKFLOW_FALLBACK_COLOR[task.workflow_mapped_status || ''] ||
      planAiColors.brand.primary;
    return { label: task.workflow_label, color, bgcolor: `${color}1A` };
  }
  return getStatusDisplay(task);
}

export function getStatusDisplay(task: Pick<Task, 'status' | 'progress'>): StatusDisplay {
  const col = deriveBoardColumn(task);
  switch (col) {
    case 'todo':
      return { label: 'To Do', color: planAiColors.text.tertiary, bgcolor: planAiColors.background.surfaceAlt };
    case 'in_progress':
      return { label: 'In Progress', color: planAiColors.brand.primary, bgcolor: planAiColors.brand.primarySoft };
    case 'in_progress_advanced':
      return {
        label: 'In Progress',
        sublabel: '50% 이상 진행',
        color: planAiColors.status.purple,
        bgcolor: planAiColors.status.purpleSoft,
      };
    case 'done':
      return { label: 'Done', color: planAiColors.status.success, bgcolor: planAiColors.status.successSoft };
    case 'hold':
      return { label: 'Hold', color: planAiColors.status.warning, bgcolor: planAiColors.status.warningSoft };
  }
}

/**
 * Compute the (status, progress) updates needed to move a task into `targetCol`.
 * Returns `null` if the task already renders in that column (no update needed).
 *
 * Policy:
 *  - 50%+ is derived from progress, not a separate status. So moving between
 *    `in_progress` and `in_progress_advanced` requires adjusting progress %,
 *    not status.
 *  - Minimal change: set just enough progress to land in the target column.
 */
export function computeColumnMoveUpdates(
  task: Pick<Task, 'status' | 'progress'>,
  targetCol: BoardColumnId,
): Partial<Pick<Task, 'status' | 'progress'>> | null {
  const currentCol = deriveBoardColumn(task);
  if (currentCol === targetCol) return null;

  const progress = task.progress ?? 0;
  const updates: Partial<Pick<Task, 'status' | 'progress'>> = {};

  switch (targetCol) {
    case 'todo':
      updates.status = 'todo';
      if (progress !== 0) updates.progress = 0;
      return updates;
    case 'in_progress':
      updates.status = 'in_progress';
      if (progress >= 50) updates.progress = 49;
      else if (progress === 0) updates.progress = 1;
      return updates;
    case 'in_progress_advanced':
      updates.status = 'in_progress';
      if (progress < 50) updates.progress = 50;
      return updates;
    case 'done':
      updates.status = 'done';
      if (progress < 100) updates.progress = 100;
      return updates;
    case 'hold':
      updates.status = 'hold';
      return updates;
  }
}
