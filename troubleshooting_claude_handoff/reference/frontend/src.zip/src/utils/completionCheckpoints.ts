import type { CompletionCheckpoint, Task, WorkflowColumn } from '../types';

/**
 * 해당 Task 가 체크포인트 단계를 '완료' 했는지 판단.
 *
 * 백엔드 _is_task_completed_for_checkpoint 와 동일 공식.
 * - 체크포인트보다 뒤 단계에 있는 Task = 완료 (단계를 통과함).
 * - 같은 단계에 있는 Task = 내부 progress 100%(또는 done) 일 때만 완료.
 * - 앞 단계에 있는 Task = 미완료.
 * - 단, 체크포인트가 최종 완료 컬럼(is_final_done)이면 도달=완료(기존 done 정책 유지).
 *
 * 주의: '도달(>=)'이 아니라 '완료' 기준. 같은 단계의 진행 중 Task 는 완료로 세지 않는다.
 */
export function isTaskCompletedForCheckpoint(
  taskOrder: number,
  taskProgress: number,
  taskStatus: string,
  checkpointOrder: number,
  checkpointIsFinal: boolean,
): boolean {
  if (taskOrder > checkpointOrder) return true;
  if (taskOrder < checkpointOrder) return false;
  if (checkpointIsFinal) return true;
  if (taskStatus === 'done') return true;
  return (taskProgress || 0) >= 100;
}

/**
 * 중간 완료 체크포인트 진행 지표를 tasks + workflow columns 로부터 계산한다.
 *
 * 백엔드 _compute_completion_checkpoints 와 동일한 공식을 사용하며(둘을 같이 유지),
 * Board 에서 Task 가 이동할 때 즉시 반영되도록 프론트에서 live 로 계산한다.
 *
 * - 최종 완료율 / Completion % 와 무관 (보조 지표).
 * - 통과 기준: 체크포인트 단계를 '완료'한 Task (뒤 단계 = 완료, 같은 단계 = progress 100%).
 * - 분모(totalTaskCount)는 프로젝트 active Task 수로 공통.
 */
export function computeCompletionCheckpoints(
  tasks: Task[],
  columns: WorkflowColumn[],
): CompletionCheckpoint[] {
  const active = (columns || [])
    .filter(c => c.active)
    .sort((a, b) => a.sort_order - b.sort_order);
  const checkpoints = active.filter(c => c.is_checkpoint);
  if (checkpoints.length === 0) return [];

  const sortByColId = new Map<number, number>();
  active.forEach(c => sortByColId.set(c.id, c.sort_order));

  // workflow_column_id 가 없는 Task 는 status 로 위치 추정 (백엔드 _pick_column_for_status 단순화)
  const pickOrderForStatus = (status: string): number => {
    if (status === 'done') {
      const finals = active.filter(c => c.is_final_done);
      if (finals.length) return finals[finals.length - 1].sort_order;
      return active.length ? active[active.length - 1].sort_order : 0;
    }
    const match = active.find(c => c.mapped_status === status);
    if (match) return match.sort_order;
    return active.length ? active[0].sort_order : 0;
  };

  const activeTasks = (tasks || []).filter(t => !t.archived_at);
  const total = activeTasks.length;
  // (단계 sort_order, 내부 progress, status) 로 Task 위치/진척을 캡처
  const taskPos = activeTasks.map(t => {
    const so = t.workflow_column_id != null ? sortByColId.get(t.workflow_column_id) : undefined;
    const order = so !== undefined ? so : pickOrderForStatus(t.status || 'todo');
    return { order, progress: t.progress ?? 0, status: t.status || 'todo' };
  });

  return checkpoints.map(c => {
    const passed = taskPos.filter(tp =>
      isTaskCompletedForCheckpoint(tp.order, tp.progress, tp.status, c.sort_order, !!c.is_final_done),
    ).length;
    const percent = total ? Math.round((passed / total) * 100) : 0;
    let status: CompletionCheckpoint['status'];
    if (total === 0 || passed === 0) status = 'waiting';
    else if (passed >= total) status = 'completed';
    else status = 'in_progress';
    return {
      checkpointColumnId: c.id,
      checkpointLabel: (c.checkpoint_label || '').trim() || `${c.label} 완료`,
      checkpointDescription: c.checkpoint_description || null,
      targetColumnLabel: c.label,
      targetSortOrder: c.sort_order,
      passedTaskCount: passed,
      totalTaskCount: total,
      progressPercent: percent,
      status,
    };
  });
}

/**
 * 완료 체크포인트로 지정된 단계 수 (active + is_checkpoint).
 * Task 목록과 무관하게 workflow columns 만으로 결정된다. compact chip 라벨용.
 */
export function countCompletionCheckpoints(columns: WorkflowColumn[]): number {
  return (columns || []).filter(c => c.active && c.is_checkpoint).length;
}

export type CheckpointTaskReason =
  | 'moved_to_later_step' // 완료: 다음 단계로 이동됨
  | 'current_step_100' // 완료: 현재 단계 100% 완료
  | 'earlier_step' // 미완료: 이전 단계 진행 필요
  | 'current_step_incomplete'; // 미완료: 현재 단계 진행 중

export interface CheckpointTaskEntry {
  task: Task;
  /** Task 의 현재 단계 라벨 (워크플로우 컬럼) */
  currentStepLabel: string;
  progress: number;
  /** 체크포인트 기준 분류 사유 */
  reason: CheckpointTaskReason;
}

export interface CheckpointTaskBuckets {
  /** 체크포인트를 이미 완료한 Task (카드 count = completed.length) */
  completed: CheckpointTaskEntry[];
  /** 체크포인트를 아직 완료하지 못한, 진행해야 할 Task */
  pending: CheckpointTaskEntry[];
}

/**
 * 특정 체크포인트 단계 기준으로 Task 를 완료/미완료(남은) 버킷으로 분류한다.
 *
 * computeCompletionCheckpoints 와 동일한 위치/완료 판정을 사용하므로
 * completed.length 는 해당 체크포인트의 passedTaskCount 와 항상 일치한다.
 * (deleted/archived Task 는 제외)
 */
export function getCheckpointTaskBuckets(
  tasks: Task[],
  columns: WorkflowColumn[],
  checkpointColumnId: number,
): CheckpointTaskBuckets {
  const active = (columns || [])
    .filter(c => c.active)
    .sort((a, b) => a.sort_order - b.sort_order);
  const checkpoint = active.find(c => c.id === checkpointColumnId);
  if (!checkpoint) return { completed: [], pending: [] };

  const sortByColId = new Map<number, number>();
  const labelBySortOrder = new Map<number, string>();
  active.forEach(c => {
    sortByColId.set(c.id, c.sort_order);
    labelBySortOrder.set(c.sort_order, c.label);
  });

  const pickOrderForStatus = (status: string): number => {
    if (status === 'done') {
      const finals = active.filter(c => c.is_final_done);
      if (finals.length) return finals[finals.length - 1].sort_order;
      return active.length ? active[active.length - 1].sort_order : 0;
    }
    const match = active.find(c => c.mapped_status === status);
    if (match) return match.sort_order;
    return active.length ? active[0].sort_order : 0;
  };

  const cpOrder = checkpoint.sort_order;
  const cpFinal = !!checkpoint.is_final_done;

  const completed: CheckpointTaskEntry[] = [];
  const pending: CheckpointTaskEntry[] = [];

  (tasks || [])
    .filter(t => !t.archived_at)
    .forEach(t => {
      const so = t.workflow_column_id != null ? sortByColId.get(t.workflow_column_id) : undefined;
      const order = so !== undefined ? so : pickOrderForStatus(t.status || 'todo');
      const progress = t.progress ?? 0;
      const status = t.status || 'todo';
      const currentStepLabel = labelBySortOrder.get(order) || '';
      if (isTaskCompletedForCheckpoint(order, progress, status, cpOrder, cpFinal)) {
        completed.push({
          task: t,
          currentStepLabel,
          progress,
          reason: order > cpOrder ? 'moved_to_later_step' : 'current_step_100',
        });
      } else {
        pending.push({
          task: t,
          currentStepLabel,
          progress,
          reason: order < cpOrder ? 'earlier_step' : 'current_step_incomplete',
        });
      }
    });

  return { completed, pending };
}

/**
 * 체크포인트를 '완료로 계산된' Task 목록 (Dashboard Overview drill-down 등에서 사용).
 * 반환 개수는 해당 체크포인트의 passedTaskCount 와 항상 일치한다.
 */
export function getCheckpointTasks(
  tasks: Task[],
  columns: WorkflowColumn[],
  checkpointColumnId: number,
): CheckpointTaskEntry[] {
  return getCheckpointTaskBuckets(tasks, columns, checkpointColumnId).completed;
}
