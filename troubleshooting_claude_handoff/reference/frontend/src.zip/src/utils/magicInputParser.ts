/**
 * Magic Input Parser — Client-side NLP extraction
 *
 * Parses a natural language task title to extract structured fields.
 * This runs locally (no AI call) for instant preview.
 *
 * ── 설계 원칙 (2026-06 개정) ───────────────────────────────────────────
 * 기본 원칙: 사용자가 입력한 값 전체를 Task 제목으로 보존한다.
 * 예외: "명확하게 일정으로 판단되는 패턴"일 때만 schedule(start/end)로 분리한다.
 *
 * 즉, 숫자가 있다고 무조건 일정으로 빼지 않는다.
 *   - 44.4 테스트        → 제목 "44.4 테스트" (소수점 = 제목)
 *   - 55/66 테스트       → 제목 "55/66 테스트" (불가능한 날짜/비율 = 제목)
 *   - 3~10 개선 아이템   → 제목 "3~10 개선 아이템" (범위 표기 = 제목)
 *   - A-123 / P123-45    → 제목 (제품번호/코드 = 제목)
 * 일정으로 분리하는 경우는 extractSchedule() 주석 참고.
 */

export interface ParsedTaskInput {
  title: string;
  startDate: string | null;   // YYYY-MM-DD
  endDate: string | null;     // YYYY-MM-DD
  tags: string[];
  priority: 'low' | 'medium' | 'high' | null;
  confidence: number;         // 0-1
  rawText: string;
}

// ── 상대 표현 날짜 패턴 (단어 기반이라 숫자 코드와 충돌하지 않음) ──
const RELATIVE_DATE_PATTERNS: { pattern: RegExp; resolver: () => { start?: string; end?: string } }[] = [
  {
    // "이번 달" / "this month"
    pattern: /(?:이번\s*달|this\s+month)/i,
    resolver: () => {
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      return { start: fmt(start), end: fmt(end) };
    },
  },
  {
    // "다음 달" / "next month"
    pattern: /(?:다음\s*달|next\s+month)/i,
    resolver: () => {
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth() + 1, 1);
      const end = new Date(now.getFullYear(), now.getMonth() + 2, 0);
      return { start: fmt(start), end: fmt(end) };
    },
  },
  {
    // "연말" / "year-end" / "year end"
    pattern: /(?:연말|year[\s-]*end)/i,
    resolver: () => {
      const now = new Date();
      return { end: `${now.getFullYear()}-12-31` };
    },
  },
  {
    // "다음 주" / "next week"
    pattern: /(?:다음\s*주|next\s+week)/i,
    resolver: () => {
      const now = new Date();
      const dayOfWeek = now.getDay();
      const nextMon = new Date(now);
      nextMon.setDate(now.getDate() + (7 - dayOfWeek) + 1);
      const nextFri = new Date(nextMon);
      nextFri.setDate(nextMon.getDate() + 4);
      return { start: fmt(nextMon), end: fmt(nextFri) };
    },
  },
  {
    // "이번 주" / "this week"
    pattern: /(?:이번\s*주|this\s+week)/i,
    resolver: () => {
      const now = new Date();
      const dayOfWeek = now.getDay();
      const mon = new Date(now);
      mon.setDate(now.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));
      const fri = new Date(mon);
      fri.setDate(mon.getDate() + 4);
      return { start: fmt(mon), end: fmt(fri) };
    },
  },
  {
    // "다음 금요일" / "next friday" (요일은 "내일/오늘"보다 먼저 평가)
    pattern: /(?:다음\s*금요일|next\s+friday)/i,
    resolver: () => {
      const now = new Date();
      const daysUntilFri = ((5 - now.getDay() + 7) % 7) || 7;
      const d = new Date(now);
      d.setDate(now.getDate() + daysUntilFri);
      return { end: fmt(d) };
    },
  },
  {
    // "내일" / "tomorrow"
    pattern: /(?:내일|tomorrow)/i,
    resolver: () => {
      const d = new Date();
      d.setDate(d.getDate() + 1);
      return { end: fmt(d) };
    },
  },
  {
    // "오늘" / "today"
    pattern: /(?:오늘|today)/i,
    resolver: () => ({ end: fmt(new Date()) }),
  },
];

function fmt(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

function curYear(): number {
  return new Date().getFullYear();
}

// month 1~12 / day 1~31 만 유효한 날짜로 인정한다.
function validMD(month: number, day: number): boolean {
  return month >= 1 && month <= 12 && day >= 1 && day <= 31;
}

/**
 * "완전한" 날짜 토큰(연-월-일 3요소)을 YYYY-MM-DD 로 파싱한다.
 *   예) 2026-07-01 / 2026.07.01 / 2026/07/01 / 26.07.01 / 26/07/01
 * 첫 요소(연도)는 2~4자리여야 한다 → "1.2.3" 같은 1자리 시작 버전코드는 제외.
 * 소수점 2요소("44.4")는 애초에 3요소가 아니므로 매칭되지 않는다.
 */
function parseFullDateToken(s: string): string | null {
  const m = s.match(/^(\d{2,4})[.\-/](\d{1,2})[.\-/](\d{1,2})$/);
  if (!m) return null;
  let year = parseInt(m[1], 10);
  if (m[1].length === 2) year = 2000 + year;
  const month = parseInt(m[2], 10);
  const day = parseInt(m[3], 10);
  if (!validMD(month, day)) return null;
  return `${year}-${pad2(month)}-${pad2(day)}`;
}

/**
 * 한글 날짜 단위 토큰을 파싱한다. 연도는 선택.
 *   예) 6월 30일 / 2026년 7월 1일 / 26년 7월 1일
 */
function parseKoreanDateToken(s: string): string | null {
  const m = s.match(/^(?:(\d{2,4})년\s*)?(\d{1,2})월\s*(\d{1,2})일$/);
  if (!m) return null;
  let year = m[1] ? parseInt(m[1], 10) : curYear();
  if (m[1] && m[1].length === 2) year = 2000 + parseInt(m[1], 10);
  const month = parseInt(m[2], 10);
  const day = parseInt(m[3], 10);
  if (!validMD(month, day)) return null;
  return `${year}-${pad2(month)}-${pad2(day)}`;
}

/** 짧은 슬래시 날짜(M/D)를 파싱한다. 슬래시는 소수점 구분자가 아니므로 2요소도 허용. */
function parseSlashMDToken(s: string): string | null {
  const m = s.match(/^(\d{1,2})\/(\d{1,2})$/);
  if (!m) return null;
  const month = parseInt(m[1], 10);
  const day = parseInt(m[2], 10);
  if (!validMD(month, day)) return null;
  return `${curYear()}-${pad2(month)}-${pad2(day)}`;
}

function parseAnyDateToken(s: string): string | null {
  return parseFullDateToken(s) || parseKoreanDateToken(s);
}

// 날짜 토큰 정규식 조각 (조합용)
const FULL_DATE = String.raw`\d{2,4}[.\-/]\d{1,2}[.\-/]\d{1,2}`;            // 2026-07-01, 26.07.01
const KOR_DATE = String.raw`(?:\d{2,4}년\s*)?\d{1,2}월\s*\d{1,2}일`;        // 6월 30일, 2026년 7월 1일
const ANY_DATE = `(?:${FULL_DATE}|${KOR_DATE})`;
const RANGE_SEP = String.raw`\s*(?:~|—|–|-|부터|에서|to|까지)\s*`;
const INDICATOR = String.raw`(?:마감|기한|deadline|due|일정|기간|schedule|start|시작|종료)`;

interface ScheduleResult {
  startDate: string | null;
  endDate: string | null;
  remainingTitle: string;
}

/**
 * "명확한 일정 표현"만 schedule 로 분리한다. 분리 못하면 null.
 *
 * 분리 케이스(우선순위 순):
 *   A. 일정 표시어 + 날짜       : "마감: 2026-07-01 테스트", "테스트 마감: 2026-07-01"
 *   B. 완전한 날짜 범위/단일     : "6월10일~11월11일", "테스트 2026-07-01", "테스트 6월 30일"
 *   C. 문장 끝의 짧은 슬래시 날짜 : "테스트 6/30"  (앞에 제목 텍스트가 있을 때만)
 *
 * 절대 분리하지 않는 것:
 *   - 소수점(44.4), 비율/코드(55/66, A-123), 단순 범위(3~10), 맨 앞 숫자 코드
 */
function extractSchedule(text: string): ScheduleResult | null {
  const t = text.trim();
  if (!t) return null;

  let m: RegExpMatchArray | null;

  // ── A) 일정 표시어 + 날짜 ──
  // A-1) 표시어 + 범위
  const indRange = new RegExp(`${INDICATOR}\\s*[:：]?\\s*(${ANY_DATE})${RANGE_SEP}(${ANY_DATE})`, 'i');
  m = t.match(indRange);
  if (m) {
    const s = parseAnyDateToken(m[1]);
    const e = parseAnyDateToken(m[2]);
    if (s && e) {
      return { startDate: s, endDate: e, remainingTitle: cleanTitle(t.replace(m[0], '')) };
    }
  }
  // A-2) 표시어 + 단일
  const indSingle = new RegExp(`${INDICATOR}\\s*[:：]?\\s*(${ANY_DATE})`, 'i');
  m = t.match(indSingle);
  if (m) {
    const e = parseAnyDateToken(m[1]);
    if (e) {
      return { startDate: null, endDate: e, remainingTitle: cleanTitle(t.replace(m[0], '')) };
    }
  }

  // ── B) 완전한 날짜 (표시어 없어도 단위/구분자가 명확) ──
  // B-1) 완전한 날짜 범위
  const rangeRe = new RegExp(`(${ANY_DATE})${RANGE_SEP}(${ANY_DATE})`, 'i');
  m = t.match(rangeRe);
  if (m) {
    const s = parseAnyDateToken(m[1]);
    const e = parseAnyDateToken(m[2]);
    if (s && e) {
      return { startDate: s, endDate: e, remainingTitle: cleanTitle(t.replace(m[0], '')) };
    }
  }
  // B-2) 한글 단위 단일 날짜 (월/일 단위가 있어 모호하지 않음)
  m = t.match(new RegExp(KOR_DATE));
  if (m) {
    const e = parseKoreanDateToken(m[0]);
    if (e) return { startDate: null, endDate: e, remainingTitle: cleanTitle(t.replace(m[0], '')) };
  }
  // B-3) 완전한(3요소) 단일 날짜 (YYYY-MM-DD 등 구분자 명확)
  m = t.match(new RegExp(FULL_DATE));
  if (m) {
    const e = parseFullDateToken(m[0]);
    if (e) return { startDate: null, endDate: e, remainingTitle: cleanTitle(t.replace(m[0], '')) };
  }

  // ── C) 문장 끝의 짧은 슬래시 날짜 "제목 6/30" ──
  //   조건: 날짜가 맨 끝 + 앞에 실제 제목 텍스트 존재 + 유효한 날짜
  const trailing = t.match(/^(.+?)\s+(\d{1,2}\/\d{1,2})$/);
  if (trailing && trailing[1].trim()) {
    const e = parseSlashMDToken(trailing[2]);
    if (e) return { startDate: null, endDate: e, remainingTitle: cleanTitle(trailing[1]) };
  }

  return null;
}

// 일정 분리 후 남은 제목에서 매달린 표시어/구분자만 정리한다 (숫자는 절대 제거하지 않음).
function cleanTitle(s: string): string {
  return s
    .replace(new RegExp(`${INDICATOR}\\s*[:：]?\\s*$`, 'i'), '')
    .replace(new RegExp(`^\\s*${INDICATOR}\\s*[:：]?\\s*`, 'i'), '')
    .replace(/[:：]\s*$/, '')
    .replace(/^\s*[:：]\s*/, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// ── Tag extraction ──
function extractTags(text: string): { tags: string[]; cleaned: string } {
  const tags: string[] = [];
  const cleaned = text.replace(/#(\S+)/g, (_, tag) => {
    tags.push(tag);
    return '';
  });
  return { tags, cleaned: cleaned.trim() };
}

// ── Priority extraction ──
function extractPriority(text: string): { priority: ParsedTaskInput['priority']; cleaned: string } {
  const highPatterns = /(?:긴급|급한|중요|urgent|important|high\s*priority)/i;
  const lowPatterns = /(?:낮은|나중에|low\s*priority|when\s*possible)/i;

  if (highPatterns.test(text)) {
    return { priority: 'high', cleaned: text.replace(highPatterns, '').trim() };
  }
  if (lowPatterns.test(text)) {
    return { priority: 'low', cleaned: text.replace(lowPatterns, '').trim() };
  }
  return { priority: null, cleaned: text };
}

/**
 * Parse a natural language input string into structured task fields.
 *
 * 핵심: 원본 입력값을 제목으로 보존하고, 명확한 일정 표현만 schedule 로 분리한다.
 * 파싱 결과 title 이 비면 원본 전체를 title 로 복구한다.
 */
export function parseTaskInput(rawText: string): ParsedTaskInput {
  if (!rawText.trim()) {
    return { title: '', startDate: null, endDate: null, tags: [], priority: null, confidence: 0, rawText };
  }

  let text = rawText.trim();
  let startDate: string | null = null;
  let endDate: string | null = null;
  let confidence = 0.3; // baseline

  // 1) 태그 (#) 추출
  const { tags, cleaned: afterTags } = extractTags(text);
  text = afterTags;
  if (tags.length > 0) confidence += 0.1;

  // 2) 우선순위 키워드 추출
  const { priority, cleaned: afterPriority } = extractPriority(text);
  text = afterPriority;
  if (priority) confidence += 0.1;

  // 3) 명확한 일정 표현만 분리 (숫자/소수점/슬래시/코드는 제목 보존)
  const sched = extractSchedule(text);
  if (sched) {
    startDate = sched.startDate;
    endDate = sched.endDate;
    text = sched.remainingTitle;
    confidence += 0.3;
  }

  // 4) 상대 표현 날짜 (오늘/내일/이번 달 …) — 명시적 날짜가 없을 때만
  if (!startDate && !endDate) {
    for (const dp of RELATIVE_DATE_PATTERNS) {
      if (dp.pattern.test(text)) {
        const resolved = dp.resolver();
        if (resolved.start) startDate = resolved.start;
        if (resolved.end) endDate = resolved.end;
        text = text.replace(dp.pattern, '').trim();
        confidence += 0.2;
        break;
      }
    }
  }

  // 5) 제목 정리 — 공백만 정규화 (숫자 제거 금지)
  let title = text.replace(/\s+/g, ' ').trim();

  // 방어 로직: 파싱 후 title 이 비면 원본 전체를 title 로 복구한다.
  if (!title) title = rawText.trim();

  confidence = Math.min(1, confidence);

  return { title, startDate, endDate, tags, priority, confidence, rawText };
}

// ────────────────────────────────────────────────────────────────────────
// Quick-add(보드 빠른 Task 생성)용 파서
//
// 정책: 자연어 추정 파싱을 하지 않는다. 사용자가 입력한 원문 전체를 제목으로 보존하고,
//       오직 "명확한 구분 문법"이 있을 때만 일정을 분리한다.
//
//   [마감: 2026-07-01] 테스트            → title "테스트",  due 2026-07-01
//   [일정: 2026-07-01~2026-07-05] 테스트 → title "테스트",  start~end
//   테스트 | 마감: 2026-07-01            → title "테스트",  due 2026-07-01
//   테스트 | 일정: 2026-07-01~2026-07-05 → title "테스트",  start~end
//
// 그 외 모든 입력은 통째로 title 이 된다. 숫자/소수점/슬래시/물결표/단어를 절대 제거하지 않는다.
//   "77 체크 필요 항목들" → title "77 체크 필요 항목들" (due 없음)
//   "55 마감 프로젝트"     → title "55 마감 프로젝트"     (due 없음)
//   "6/30 체크 필요 항목"  → title "6/30 체크 필요 항목"  (due 없음)
// ────────────────────────────────────────────────────────────────────────

export interface QuickAddParseResult {
  title: string;
  startDate: string | null;   // YYYY-MM-DD
  endDate: string | null;     // YYYY-MM-DD
}

// 명확한 일정 라벨 (구분 문법 안에서만 의미를 가진다)
const SCHED_LABEL = String.raw`(?:마감|기한|due|deadline|일정|기간|schedule)`;

/** 구분 문법 내부의 날짜 스펙("DATE" 또는 "DATE~DATE")만 해석한다. 못하면 null. */
function parseExplicitDateSpec(spec: string): { startDate: string | null; endDate: string | null } | null {
  const s = spec.trim();
  if (!s) return null;

  // 범위: 2026-07-01~2026-07-05 / 6월10일~6월20일
  const rangeRe = new RegExp(`^(${ANY_DATE})${RANGE_SEP}(${ANY_DATE})$`, 'i');
  const rm = s.match(rangeRe);
  if (rm) {
    const a = parseAnyDateToken(rm[1]);
    const b = parseAnyDateToken(rm[2]);
    if (a && b) return { startDate: a, endDate: b };
  }

  // 단일 완전 날짜: 2026-07-01 / 2026년 7월 1일
  const single = parseAnyDateToken(s);
  if (single) return { startDate: null, endDate: single };

  // 단일 짧은 슬래시 날짜: 7/1 (명확한 라벨 뒤에서만 허용되므로 안전)
  const slash = parseSlashMDToken(s);
  if (slash) return { startDate: null, endDate: slash };

  return null;
}

/**
 * 보드 빠른 생성창 전용 파서.
 * 명확한 구분 문법이 없으면 원문(trim) 전체를 title 로 보존한다.
 */
export function parseQuickAddInput(rawText: string): QuickAddParseResult {
  const raw = rawText.trim();
  if (!raw) return { title: '', startDate: null, endDate: null };

  // 1) 대괄호 문법:  [마감: DATE] / [일정: DATE~DATE]  (문장 어디에 있어도 인식)
  const bracket = raw.match(new RegExp(String.raw`\[\s*${SCHED_LABEL}\s*[:：]\s*([^\]]+?)\s*\]`, 'i'));
  if (bracket) {
    const sched = parseExplicitDateSpec(bracket[1]);
    if (sched) {
      const title = raw.replace(bracket[0], '').replace(/\s+/g, ' ').trim();
      return { title: title || raw, startDate: sched.startDate, endDate: sched.endDate };
    }
  }

  // 2) 파이프 문법:  title | 마감: DATE  /  title | 일정: DATE~DATE
  const pipeIdx = raw.lastIndexOf('|');
  if (pipeIdx > 0) {
    const left = raw.slice(0, pipeIdx).trim();
    const right = raw.slice(pipeIdx + 1).trim();
    const pipe = right.match(new RegExp(`^${SCHED_LABEL}\\s*[:：]\\s*(.+)$`, 'i'));
    if (pipe && left) {
      const sched = parseExplicitDateSpec(pipe[1]);
      if (sched) return { title: left, startDate: sched.startDate, endDate: sched.endDate };
    }
  }

  // 3) 그 외: 원문 전체가 제목 (자연어 추정 금지)
  return { title: raw, startDate: null, endDate: null };
}

/**
 * AI System Prompt for server-side Magic Input parsing.
 * Include this when calling the AI endpoint for refined parsing.
 */
export const MAGIC_INPUT_SYSTEM_PROMPT = `You are a task parser. Convert the user's natural language input into a structured JSON object.

Current date context: ${new Date().toISOString().slice(0, 10)}

Output STRICT JSON only with these fields:
{
  "title": "string - the extracted task title",
  "startDate": "YYYY-MM-DD or null",
  "endDate": "YYYY-MM-DD or null",
  "tags": ["array of strings without # prefix"],
  "assignee": "string or null - name if mentioned",
  "priority": "low | medium | high | null",
  "confidence": 0.0-1.0,
  "rawText": "original input"
}

Rules:
- If unsure about a field, set it to null. Never hallucinate.
- Preserve the original meaning of the title. Keep numbers, decimals, slashes and codes (e.g. "44.4", "55/66", "3~10", "A-123") inside the title.
- Only split a schedule when the date is unambiguous (explicit indicator like "마감:", a full date, or "M월 D일").
- Parse relative dates: "이번 달" = this month, "연말" = year-end, "다음 주" = next week, "내일" = tomorrow, "다음 금요일" = next friday
- Tags start with # in the input.
- Return ONLY valid JSON, no markdown or explanation.`;

/**
 * Expected AI response JSON schema (for documentation).
 */
export const MAGIC_INPUT_SCHEMA = {
  title: 'string',
  startDate: 'YYYY-MM-DD | null',
  endDate: 'YYYY-MM-DD | null',
  tags: ['string'],
  assignee: 'string | null',
  priority: 'low | medium | high | null',
  confidence: 'number (0-1)',
  rawText: 'string',
};
