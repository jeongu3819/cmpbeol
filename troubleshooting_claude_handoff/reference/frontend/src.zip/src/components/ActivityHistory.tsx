import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Box, Typography, Stack, Chip, CircularProgress, Avatar, Tooltip, Button } from '@mui/material';
import HistoryIcon from '@mui/icons-material/History';
import { api } from '../api/client';
import { descriptionToPreviewText } from '../utils/richImage';
import type { ActivityLogEntry, ActivityLogChange } from '../types';

interface Props {
  entityType: 'project' | 'task' | 'calendar_event';
  entityId?: number | null;
  /** 제목 노출 여부 (기본 true) */
  showHeader?: boolean;
  /** 최대 표시 건수 (기본 50) */
  limit?: number;
  /** 컴팩트(밀집) 모드 — 모달/드로어 내부용 */
  dense?: boolean;
  /** 유형 필터 칩 노출 (기본 false) */
  enableFilters?: boolean;
}

const ACTION_META: Record<string, { label: string; color: string }> = {
  created: { label: '생성', color: '#16A34A' },
  updated: { label: '수정', color: '#2955FF' },
  deleted: { label: '삭제', color: '#DC2626' },
  restored: { label: '복구', color: '#0891B2' },
  status_changed: { label: '상태 변경', color: '#7C3AED' },
  assignee_changed: { label: '담당자 변경', color: '#EA580C' },
  moved: { label: '이동', color: '#0891B2' },
};

// 긴 텍스트/HTML/이미지가 섞일 수 있어 기본 목록에서는 펼치지 않는 "내용 수정" 필드.
const CONTENT_FIELDS = new Set(['description', 'note', 'remarks', 'memo']);
// 담당자/일정 관련 필드.
const SCHEDULE_FIELDS = new Set(['assignee_ids', 'assignee_id', 'start_date', 'due_date', 'end_date']);
const STATUS_FIELDS = new Set(['status']);

const FILTERS: { key: string; label: string }[] = [
  { key: 'all', label: '전체' },
  { key: 'major', label: '주요 변경' },
  { key: 'content', label: '내용 수정' },
  { key: 'schedule', label: '담당자·일정' },
  { key: 'status', label: '상태 변경' },
];

/** 변경 전/후 본문을 펼쳤을 때 한 번에 보여줄 최대 글자 수. */
const CONTENT_PREVIEW_CAP = 400;

function formatTime(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** 한 이력 항목이 어떤 필터 그룹에 속하는지 계산. */
function logCategories(log: ActivityLogEntry): Set<string> {
  const cats = new Set<string>(['all']);
  const changes = (log.meta?.changes as ActivityLogChange[] | undefined) ?? [];
  const fields = changes.map((c) => c.field);
  const hasContent = fields.some((f) => CONTENT_FIELDS.has(f));
  const hasSchedule = fields.some((f) => SCHEDULE_FIELDS.has(f)) || log.action === 'assignee_changed';
  const hasStatus = fields.some((f) => STATUS_FIELDS.has(f)) || log.action === 'status_changed';
  // 순수 "내용 수정"(설명/노트만 바뀐 일반 수정)을 제외한 모든 변경은 주요 변경으로 본다.
  const contentOnly =
    log.action === 'updated' && changes.length > 0 && fields.every((f) => CONTENT_FIELDS.has(f));
  if (hasContent) cats.add('content');
  if (hasSchedule) cats.add('schedule');
  if (hasStatus) cats.add('status');
  if (!contentOnly) cats.add('major');
  return cats;
}

/** 스칼라 값 표시(담당자/상태/일정 등). 너무 길면 잘라낸다. */
function formatVal(v: unknown): string {
  if (v === null || v === undefined || v === '') return '없음';
  if (Array.isArray(v)) return v.length ? v.join(', ') : '없음';
  const s = String(v);
  return s.length > 120 ? `${s.slice(0, 120)}…` : s;
}

/** description/note 등 긴 본문의 변경 전/후를 안전하게(태그/이미지/긴 URL 제거) 보여준다. */
const ContentDiffRow: React.FC<{ change: ActivityLogChange }> = ({ change }) => {
  const [open, setOpen] = useState(false);
  const [showFull, setShowFull] = useState(false);

  const beforeText = useMemo(() => descriptionToPreviewText(String(change.before ?? '')), [change.before]);
  const afterText = useMemo(() => descriptionToPreviewText(String(change.after ?? '')), [change.after]);

  const clip = (t: string) =>
    !showFull && t.length > CONTENT_PREVIEW_CAP ? `${t.slice(0, CONTENT_PREVIEW_CAP)}…` : t;
  const needMore =
    !showFull && (beforeText.length > CONTENT_PREVIEW_CAP || afterText.length > CONTENT_PREVIEW_CAP);

  return (
    <Box sx={{ mt: 0.4 }}>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
        · {change.label} 수정
      </Typography>
      <Button
        size="small"
        onClick={() => setOpen((v) => !v)}
        sx={{ p: 0, minWidth: 0, fontSize: 11, fontWeight: 600, textTransform: 'none', color: '#2955FF' }}
      >
        {open ? '변경 전/후 접기' : '변경 전/후 보기'}
      </Button>
      {open && (
        <Box
          sx={{
            mt: 0.5,
            p: 1,
            borderRadius: 1,
            bgcolor: '#F8FAFC',
            border: '1px solid #E5E7EB',
          }}
        >
          <Typography variant="caption" sx={{ fontWeight: 700, color: '#64748B' }}>
            변경 전
          </Typography>
          <Typography
            variant="body2"
            sx={{ color: '#475569', whiteSpace: 'pre-wrap', wordBreak: 'break-word', mb: 0.8 }}
          >
            {clip(beforeText) || '없음'}
          </Typography>
          <Typography variant="caption" sx={{ fontWeight: 700, color: '#1E3A8A' }}>
            변경 후
          </Typography>
          <Typography
            variant="body2"
            sx={{ color: '#1F2937', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}
          >
            {clip(afterText) || '없음'}
          </Typography>
          {needMore && (
            <Button
              size="small"
              onClick={() => setShowFull(true)}
              sx={{ p: 0, minWidth: 0, mt: 0.5, fontSize: 11, textTransform: 'none', color: '#2955FF' }}
            >
              더보기
            </Button>
          )}
        </Box>
      )}
    </Box>
  );
};

/**
 * 아이템(프로젝트/Task/일정)의 변경 이력을 "언제 / 누가 / 무엇을" 형태로 표시.
 * 백엔드 GET /api/activity-logs 를 호출하며, 데이터가 없으면 빈 안내를 보여준다.
 * 긴 설명/노트 변경은 기본적으로 요약만 보여주고, "변경 전/후 보기"로만 펼친다.
 */
const ActivityHistory: React.FC<Props> = ({
  entityType, entityId, showHeader = true, limit = 50, dense = false, enableFilters = false,
}) => {
  const [filter, setFilter] = useState('all');
  const { data: logs = [], isLoading } = useQuery<ActivityLogEntry[]>({
    queryKey: ['activity-logs', entityType, entityId, limit],
    queryFn: () => api.getActivityLogs(entityType, entityId as number, limit),
    enabled: !!entityId,
    staleTime: 10_000,
  });

  const visibleLogs = useMemo(
    () => (filter === 'all' ? logs : logs.filter((l) => logCategories(l).has(filter))),
    [logs, filter],
  );

  return (
    <Box>
      {showHeader && (
        <Stack direction="row" alignItems="center" spacing={0.8} sx={{ mb: 1 }}>
          <HistoryIcon fontSize="small" sx={{ color: 'text.secondary' }} />
          <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>변경 이력</Typography>
          {logs.length > 0 && (
            <Typography variant="caption" color="text.secondary">{logs.length}건</Typography>
          )}
        </Stack>
      )}

      {enableFilters && logs.length > 0 && (
        <Stack direction="row" spacing={0.8} sx={{ mb: 1.4, flexWrap: 'wrap', rowGap: 0.8 }}>
          {FILTERS.map((f) => (
            <Chip
              key={f.key}
              label={f.label}
              size="small"
              onClick={() => setFilter(f.key)}
              variant={filter === f.key ? 'filled' : 'outlined'}
              sx={{
                height: 24, fontSize: 12, fontWeight: 600,
                ...(filter === f.key
                  ? { bgcolor: '#2955FF', color: '#fff' }
                  : { borderColor: '#D1D5DB', color: '#4B5563' }),
              }}
            />
          ))}
        </Stack>
      )}

      {isLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}>
          <CircularProgress size={20} />
        </Box>
      ) : visibleLogs.length === 0 ? (
        <Typography variant="body2" color="text.secondary" sx={{ py: dense ? 1 : 2, textAlign: 'center' }}>
          {logs.length === 0 ? '아직 기록된 변경 이력이 없습니다.' : '해당 유형의 변경 이력이 없습니다.'}
        </Typography>
      ) : (
        <Stack spacing={dense ? 1 : 1.4}>
          {visibleLogs.map((log) => {
            const meta = ACTION_META[log.action] || { label: log.action, color: '#64748B' };
            const changes = (log.meta?.changes as ActivityLogChange[] | undefined) ?? [];
            return (
              <Box
                key={log.id}
                sx={{
                  display: 'flex', gap: 1.2, alignItems: 'flex-start',
                  pb: dense ? 0.8 : 1.2,
                  borderBottom: '1px solid', borderColor: 'divider',
                }}
              >
                <Tooltip title={log.user_name || '알 수 없음'}>
                  <Avatar sx={{ width: 26, height: 26, fontSize: 12, bgcolor: meta.color }}>
                    {(log.user_name || '?').slice(0, 1)}
                  </Avatar>
                </Tooltip>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Stack direction="row" alignItems="center" spacing={0.8} flexWrap="wrap">
                    <Chip
                      label={meta.label}
                      size="small"
                      sx={{
                        height: 18, fontSize: 11, fontWeight: 700,
                        color: meta.color, bgcolor: `${meta.color}1A`,
                      }}
                    />
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      {log.user_name || '알 수 없음'}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {formatTime(log.created_at)}
                    </Typography>
                  </Stack>
                  {log.message && (
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 0.3 }}>
                      {log.message}
                    </Typography>
                  )}
                  {changes.length > 0 && (
                    <Stack spacing={0.2} sx={{ mt: 0.4 }}>
                      {changes.map((c, i) =>
                        CONTENT_FIELDS.has(c.field) ? (
                          <ContentDiffRow key={i} change={c} />
                        ) : (
                          <Typography key={i} variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                            · {c.label}
                            {(c.before !== undefined || c.after !== undefined) && (
                              <>
                                {': '}
                                <span style={{ textDecoration: 'line-through', opacity: 0.6 }}>
                                  {formatVal(c.before)}
                                </span>
                                {' → '}
                                <span style={{ fontWeight: 600 }}>{formatVal(c.after)}</span>
                              </>
                            )}
                          </Typography>
                        ),
                      )}
                    </Stack>
                  )}
                </Box>
              </Box>
            );
          })}
        </Stack>
      )}
    </Box>
  );
};

export default ActivityHistory;
