import React, { useEffect, useRef, useImperativeHandle, forwardRef, useState, useCallback } from 'react';
import { Box, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { sanitizeVocHtml } from './sanitizeVocHtml';

/** 본문 내 이미지에 부여하는 식별자 - paste 시 blob URL, 업로드 후 server URL 로 src 만 교체 */
export const PENDING_DATA_ATTR = 'data-voc-pending';
export const ATT_ID_DATA_ATTR = 'data-voc-att-id';

const DEFAULT_IMG_STYLE = 'width: 60%; max-width: 100%; height: auto; border-radius: 6px; cursor: pointer;';

const MIN_IMG_WIDTH = 120;
const MAX_PASTE_BYTES = 10 * 1024 * 1024;
const ALLOWED_PASTE_MIMES = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];

export interface PendingPasteImage {
  /** placeholder src (blob URL) — 에디터 안의 <img src=...> 와 동일 */
  placeholderSrc: string;
  file: File;
}

export interface VocContentEditorHandle {
  /** 현재 에디터 내용을 sanitized HTML 로 반환 */
  getHtml: () => string;
  /** placeholder src(blob URL)을 실제 업로드 URL 로 치환하고 data-voc-att-id 부여 */
  resolvePendingImage: (placeholderSrc: string, finalSrc: string, attachmentId: number) => void;
  /** 외부에서 HTML 강제 설정 */
  setHtml: (html: string) => void;
  /** 현재 본문에 존재하는 server-side attachment id 목록 (수정 시 삭제 diff 용) */
  getReferencedAttachmentIds: () => number[];
  /** 사용자가 입력한 텍스트(이미지 제외)가 비었는지 */
  isEmpty: () => boolean;
}

interface VocContentEditorProps {
  initialHtml?: string;
  placeholder?: string;
  minHeight?: number;
  maxImages?: number;
  onChange?: (html: string) => void;
  onPasteImage?: (image: PendingPasteImage) => void;
  /** 이미지를 더블클릭했을 때 라이트박스로 확대 보기 */
  onZoomImage?: (src: string, allSrcs: string[]) => void;
  /** 사용자에게 가벼운 알림 (개수/용량 초과 등) */
  onWarn?: (message: string) => void;
}

const stripWidthFromStyle = (style: string): string =>
  style
    .split(';')
    .map(s => s.trim())
    .filter(s => s && !/^width\s*:/i.test(s))
    .join('; ');

const setImageWidthPx = (img: HTMLImageElement, widthPx: number) => {
  const existing = img.getAttribute('style') || '';
  const stripped = stripWidthFromStyle(existing);
  const next = `${stripped}${stripped ? '; ' : ''}width: ${Math.round(widthPx)}px; max-width: 100%; height: auto; cursor: pointer;`;
  img.setAttribute('style', next);
};

const VocContentEditor = forwardRef<VocContentEditorHandle, VocContentEditorProps>(
  (
    {
      initialHtml = '',
      placeholder = '이곳을 클릭해 내용을 입력하고, 스크린샷은 Ctrl+V 로 바로 붙여넣을 수 있습니다.',
      minHeight = 220,
      maxImages = 5,
      onChange,
      onPasteImage,
      onZoomImage,
      onWarn,
    },
    ref
  ) => {
    const wrapperRef = useRef<HTMLDivElement>(null);
    const editorRef = useRef<HTMLDivElement>(null);
    const [selectedImg, setSelectedImg] = useState<HTMLImageElement | null>(null);
    const [overlay, setOverlay] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
    const [isEmptyShown, setIsEmptyShown] = useState(true);

    const emitChange = useCallback(() => {
      if (!editorRef.current) return;
      const raw = editorRef.current.innerHTML;
      const html = sanitizeVocHtml(raw);
      onChange?.(html);
      const hasImg = editorRef.current.querySelector('img') !== null;
      const text = (editorRef.current.textContent || '').replace(/\u200B/g, '').trim();
      setIsEmptyShown(!hasImg && text.length === 0);
    }, [onChange]);

    // 초기 HTML 적용 (1회만 반영해 caret position 손상 방지)
    useEffect(() => {
      if (editorRef.current && editorRef.current.innerHTML !== initialHtml) {
        editorRef.current.innerHTML = sanitizeVocHtml(initialHtml || '');
        emitChange();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [initialHtml]);

    const countImages = (): number => editorRef.current?.querySelectorAll('img').length || 0;

    const insertImageAtCaret = (file: File) => {
      if (!editorRef.current) return;
      if (countImages() >= maxImages) {
        onWarn?.(`이미지는 최대 ${maxImages}장까지 붙여넣을 수 있습니다.`);
        return;
      }
      if (file.size > MAX_PASTE_BYTES) {
        onWarn?.(`이미지 용량은 1장당 최대 ${MAX_PASTE_BYTES / 1024 / 1024}MB까지 가능합니다.`);
        return;
      }
      const blobUrl = URL.createObjectURL(file);
      const img = document.createElement('img');
      img.src = blobUrl;
      img.alt = file.name || 'pasted-image';
      img.setAttribute('style', DEFAULT_IMG_STYLE);
      img.setAttribute(PENDING_DATA_ATTR, '1');

      const sel = window.getSelection();
      let range: Range | null = null;
      if (sel && sel.rangeCount > 0 && editorRef.current.contains(sel.anchorNode)) {
        range = sel.getRangeAt(0);
      }
      if (range) {
        range.deleteContents();
        range.insertNode(img);
        const br = document.createElement('br');
        if (img.nextSibling) img.parentNode?.insertBefore(br, img.nextSibling);
        else img.parentNode?.appendChild(br);
        const newRange = document.createRange();
        newRange.setStartAfter(br);
        newRange.collapse(true);
        sel?.removeAllRanges();
        sel?.addRange(newRange);
      } else {
        editorRef.current.appendChild(img);
        editorRef.current.appendChild(document.createElement('br'));
      }

      onPasteImage?.({ placeholderSrc: blobUrl, file });
      emitChange();
    };

    const handlePaste = (e: React.ClipboardEvent<HTMLDivElement>) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      let handledImage = false;
      for (const item of Array.from(items)) {
        if (item.kind === 'file' && ALLOWED_PASTE_MIMES.includes(item.type)) {
          const file = item.getAsFile();
          if (file) {
            e.preventDefault();
            insertImageAtCaret(file);
            handledImage = true;
          }
        }
      }
      if (handledImage) return;

      const text = e.clipboardData?.getData('text/plain');
      if (text) {
        e.preventDefault();
        const sel = window.getSelection();
        if (sel && sel.rangeCount > 0 && editorRef.current?.contains(sel.anchorNode)) {
          const range = sel.getRangeAt(0);
          range.deleteContents();
          const lines = text.split(/\r\n|\n|\r/);
          const frag = document.createDocumentFragment();
          lines.forEach((line, i) => {
            frag.appendChild(document.createTextNode(line));
            if (i < lines.length - 1) frag.appendChild(document.createElement('br'));
          });
          range.insertNode(frag);
          sel.collapseToEnd();
        }
        emitChange();
      }
    };

    // 선택된 이미지의 overlay 영역(테두리 + 핸들/삭제 위치) 재계산
    const recomputeOverlay = useCallback(() => {
      if (!selectedImg || !wrapperRef.current) {
        setOverlay(null);
        return;
      }
      const wRect = wrapperRef.current.getBoundingClientRect();
      const iRect = selectedImg.getBoundingClientRect();
      setOverlay({
        top: iRect.top - wRect.top,
        left: iRect.left - wRect.left,
        width: iRect.width,
        height: iRect.height,
      });
    }, [selectedImg]);

    // 선택 변경 시 voc-selected 클래스 토글 + overlay 갱신
    useEffect(() => {
      editorRef.current?.querySelectorAll('img.voc-selected').forEach(el => el.classList.remove('voc-selected'));
      selectedImg?.classList.add('voc-selected');
      recomputeOverlay();
    }, [selectedImg, recomputeOverlay]);

    // 에디터 스크롤 / 윈도우 리사이즈 시 overlay 따라가기
    useEffect(() => {
      if (!selectedImg) return;
      const handler = () => recomputeOverlay();
      const ed = editorRef.current;
      ed?.addEventListener('scroll', handler);
      window.addEventListener('resize', handler);
      return () => {
        ed?.removeEventListener('scroll', handler);
        window.removeEventListener('resize', handler);
      };
    }, [selectedImg, recomputeOverlay]);

    const handleClick = (e: React.MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'IMG' && editorRef.current?.contains(target)) {
        e.preventDefault();
        setSelectedImg(target as HTMLImageElement);
      } else {
        setSelectedImg(null);
      }
    };

    const handleDblClick = (e: React.MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'IMG' && editorRef.current?.contains(target) && onZoomImage) {
        e.preventDefault();
        const img = target as HTMLImageElement;
        const all: string[] = [];
        editorRef.current.querySelectorAll('img').forEach(i => {
          const s = i.getAttribute('src');
          if (s) all.push(s);
        });
        onZoomImage(img.getAttribute('src') || '', all);
      }
    };

    // wrapper 밖 클릭 시 선택 해제 (핸들/삭제 버튼은 wrapper 안에 있으므로 안전)
    useEffect(() => {
      const onDocDown = (e: MouseEvent) => {
        const tgt = e.target as HTMLElement;
        if (wrapperRef.current && !wrapperRef.current.contains(tgt)) {
          setSelectedImg(null);
        }
      };
      document.addEventListener('mousedown', onDocDown);
      return () => document.removeEventListener('mousedown', onDocDown);
    }, []);

    // 에디터 content 너비 (padding 제외) — 이미지 max 너비로 사용
    const getMaxContentWidth = (): number => {
      const ed = editorRef.current;
      if (!ed) return 1200;
      const cs = window.getComputedStyle(ed);
      const padL = parseFloat(cs.paddingLeft) || 0;
      const padR = parseFloat(cs.paddingRight) || 0;
      return Math.max(MIN_IMG_WIDTH, ed.clientWidth - padL - padR);
    };

    // 우하단 핸들 드래그 시작
    const beginResize = (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      const img = selectedImg;
      if (!img) return;
      const startX = e.clientX;
      const startWidth = img.getBoundingClientRect().width;
      const maxWidth = getMaxContentWidth();

      const onMove = (ev: MouseEvent) => {
        const dx = ev.clientX - startX;
        const w = Math.max(MIN_IMG_WIDTH, Math.min(maxWidth, startWidth + dx));
        setImageWidthPx(img, w);
        recomputeOverlay();
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        emitChange();
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    };

    const removeSelected = () => {
      if (!selectedImg) return;
      const src = selectedImg.getAttribute('src') || '';
      if (src.startsWith('blob:')) {
        try {
          URL.revokeObjectURL(src);
        } catch {
          /* noop */
        }
      }
      selectedImg.parentNode?.removeChild(selectedImg);
      setSelectedImg(null);
      emitChange();
    };

    useImperativeHandle(
      ref,
      () => ({
        getHtml: () => sanitizeVocHtml(editorRef.current?.innerHTML || ''),
        resolvePendingImage: (placeholderSrc, finalSrc, attachmentId) => {
          if (!editorRef.current) return;
          editorRef.current.querySelectorAll('img').forEach(img => {
            if (img.getAttribute('src') === placeholderSrc) {
              img.setAttribute('src', finalSrc);
              img.setAttribute(ATT_ID_DATA_ATTR, String(attachmentId));
              img.removeAttribute(PENDING_DATA_ATTR);
            }
          });
          if (placeholderSrc.startsWith('blob:')) {
            try {
              URL.revokeObjectURL(placeholderSrc);
            } catch {
              /* noop */
            }
          }
          emitChange();
        },
        setHtml: (html: string) => {
          if (!editorRef.current) return;
          editorRef.current.innerHTML = sanitizeVocHtml(html);
          setSelectedImg(null);
          emitChange();
        },
        getReferencedAttachmentIds: () => {
          const ids: number[] = [];
          editorRef.current?.querySelectorAll('img').forEach(img => {
            const id = img.getAttribute(ATT_ID_DATA_ATTR);
            if (id) {
              const n = Number(id);
              if (Number.isFinite(n)) ids.push(n);
            }
          });
          return ids;
        },
        isEmpty: () => {
          const el = editorRef.current;
          if (!el) return true;
          const hasImg = el.querySelector('img') !== null;
          const text = (el.textContent || '').replace(/\u200B/g, '').trim();
          return !hasImg && text.length === 0;
        },
      }),
      [emitChange]
    );

    return (
      <Box ref={wrapperRef} sx={{ position: 'relative' }}>
        <Typography variant="caption" sx={{ color: '#6B7280', display: 'block', mb: 0.6 }}>
          내용 (Ctrl+V 로 이미지 붙여넣기 · 이미지 클릭 후 우하단 모서리를 드래그하면 크기 조절 · 더블클릭으로 확대 · 최대 {maxImages}장)
        </Typography>

        <Box
          ref={editorRef}
          contentEditable
          suppressContentEditableWarning
          onInput={emitChange}
          onPaste={handlePaste}
          onClick={handleClick}
          onDoubleClick={handleDblClick}
          onBlur={emitChange}
          sx={{
            border: '1px solid #D1D5DB',
            borderRadius: 1.5,
            px: 1.5,
            py: 1.2,
            minHeight: `${minHeight}px`,
            maxHeight: '55vh',
            overflowY: 'auto',
            fontSize: '0.95rem',
            lineHeight: 1.65,
            color: '#1F2937',
            outline: 'none',
            transition: 'border-color 0.15s',
            '&:focus': { borderColor: '#2955FF', boxShadow: '0 0 0 2px rgba(41,85,255,0.12)' },
            '& img': { maxWidth: '100%', height: 'auto', borderRadius: 1, my: 0.5 },
            '& img.voc-selected': {
              outline: '2px solid #2955FF',
              outlineOffset: '2px',
            },
            position: 'relative',
            wordBreak: 'break-word',
          }}
        />

        {isEmptyShown && (
          <Typography
            variant="body2"
            sx={{
              position: 'absolute',
              top: 31,
              left: 14,
              color: '#9CA3AF',
              pointerEvents: 'none',
              userSelect: 'none',
            }}
          >
            {placeholder}
          </Typography>
        )}

        {selectedImg && overlay && (
          <>
            {/* 우하단 resize 핸들 */}
            <Box
              onMouseDown={beginResize}
              sx={{
                position: 'absolute',
                top: overlay.top + overlay.height - 7,
                left: overlay.left + overlay.width - 7,
                width: 14,
                height: 14,
                bgcolor: '#2955FF',
                border: '2px solid #fff',
                borderRadius: '3px',
                cursor: 'nwse-resize',
                boxShadow: '0 1px 3px rgba(0,0,0,0.35)',
                zIndex: 10,
              }}
            />
            {/* 우상단 삭제 버튼 */}
            <Box
              onMouseDown={e => {
                e.preventDefault();
                e.stopPropagation();
              }}
              onClick={removeSelected}
              sx={{
                position: 'absolute',
                top: overlay.top - 10,
                left: overlay.left + overlay.width - 10,
                width: 22,
                height: 22,
                bgcolor: '#1F2937',
                color: '#fff',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                boxShadow: '0 2px 6px rgba(0,0,0,0.25)',
                zIndex: 10,
                '&:hover': { bgcolor: '#DC2626' },
              }}
            >
              <CloseIcon sx={{ fontSize: 14 }} />
            </Box>
          </>
        )}
      </Box>
    );
  }
);

VocContentEditor.displayName = 'VocContentEditor';

export default VocContentEditor;
