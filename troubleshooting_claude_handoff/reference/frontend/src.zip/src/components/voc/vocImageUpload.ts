import { API_URL } from '../../api/client';

/**
 * VOC 본문/댓글 에디터(VocContentEditor)에서 붙여넣은 이미지 업로드 공용 헬퍼.
 *
 * 흐름: paste → 에디터에 blob placeholder <img> 삽입 + File 을 pendingMap 에 보관
 *   → 등록 시 collectPendingUploads 로 실제 사용 중인 blob 만 추려 업로드
 *   → resolvePendingImage 로 src(blob → 서버 URL) 치환 + att id 부여
 *   → normalizeForStorage 로 절대 URL 을 /api 상대 경로로 정규화 후 저장.
 */

/** 서버 상대 경로(/api/...)를 프론트에서 접근 가능한 절대 URL 로. */
export const buildAbsoluteUrl = (path: string): string =>
  path.startsWith('http') ? path : `${API_URL}${path.replace(/^\/api/, '')}`;

/**
 * 현재 에디터 HTML 에서 실제 사용 중인 blob placeholder 만 추려서 File 과 함께 반환.
 * 사용자가 paste 후 삭제한 이미지는 제외된다.
 */
export const collectPendingUploads = (
  html: string,
  pendingMap: Map<string, File>,
): { placeholderSrc: string; file: File }[] => {
  const result: { placeholderSrc: string; file: File }[] = [];
  const used = new Set<string>();
  const re = /<img[^>]*\bsrc=(["'])(blob:[^"']+)\1/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) !== null) used.add(m[2]);
  for (const src of used) {
    const file = pendingMap.get(src);
    if (file) result.push({ placeholderSrc: src, file });
  }
  return result;
};

/** 본문의 절대/상대 URL 을 백엔드 저장용 상대 경로(/api/voc/...) 로 정규화. */
export const normalizeForStorage = (html: string): string => {
  if (!html) return html;
  // absolute API_URL 접두사 제거 (백엔드는 상대 경로 기준)
  const apiPrefix = API_URL.replace(/\/+$/, '');
  if (apiPrefix) {
    const re = new RegExp(
      `(<img[^>]*\\bsrc=["'])${apiPrefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\/[^"']+)(["'])`,
      'gi',
    );
    html = html.replace(re, (_m, p1, p2, q) => `${p1}/api${p2}${q}`);
  }
  return html;
};

/**
 * pending(blob) 이미지들을 업로드하고 에디터의 src 를 서버 URL 로 치환한다.
 * uploadFn 은 업로드 후 { id, url } 을 돌려주는 API (본문=uploadVocAttachment, 댓글=uploadVocCommentImage).
 * 실패 시 예외를 그대로 전파 — 호출부가 입력 내용을 보존한 채 사용자에게 알리도록 한다.
 */
export const uploadAndResolvePending = async (
  pending: { placeholderSrc: string; file: File }[],
  uploadFn: (file: File) => Promise<{ id: number; url: string }>,
  resolve: (placeholderSrc: string, finalSrc: string, attachmentId: number) => void,
  pendingMap: Map<string, File>,
): Promise<void> => {
  for (const item of pending) {
    const att = await uploadFn(item.file);
    const finalSrc = att?.url ? buildAbsoluteUrl(att.url) : '';
    if (finalSrc && att?.id) {
      resolve(item.placeholderSrc, finalSrc, att.id);
    }
    pendingMap.delete(item.placeholderSrc);
  }
};
