import { VocCategory, VocPriority, VocRelatedScreen, VocStatus, VocVisibility } from '../../types';

export const VOC_CATEGORY_OPTIONS: { value: VocCategory; label: string }[] = [
  { value: 'bug', label: '버그' },
  { value: 'improvement', label: '개선 요청' },
  { value: 'feature', label: '기능 추가' },
  { value: 'ux', label: '사용 불편' },
  { value: 'design', label: '디자인/화면' },
  { value: 'etc', label: '기타' },
];

export const VOC_RELATED_SCREEN_OPTIONS: { value: VocRelatedScreen; label: string }[] = [
  { value: 'dashboard', label: 'Dashboard' },
  { value: 'space', label: '공간 관리' },
  { value: 'project', label: '프로젝트' },
  { value: 'settings', label: 'Settings' },
  { value: 'sheet', label: 'Sheet' },
  { value: 'messenger', label: 'Messenger' },
  { value: 'ai_report', label: 'AI Report' },
  { value: 'etc', label: '기타' },
];

export const VOC_PRIORITY_OPTIONS: { value: VocPriority; label: string }[] = [
  { value: 'low', label: '낮음' },
  { value: 'normal', label: '보통' },
  { value: 'high', label: '높음' },
  { value: 'urgent', label: '긴급' },
];

export const VOC_STATUS_OPTIONS: { value: VocStatus; label: string }[] = [
  { value: 'received', label: '접수' },
  { value: 'reviewing', label: '검토중' },
  { value: 'in_progress', label: '진행중' },
  { value: 'completed', label: '반영완료' },
  { value: 'on_hold', label: '보류' },
];

export const VOC_CATEGORY_LABEL: Record<VocCategory, string> = Object.fromEntries(
  VOC_CATEGORY_OPTIONS.map(o => [o.value, o.label])
) as Record<VocCategory, string>;

export const VOC_RELATED_SCREEN_LABEL: Record<VocRelatedScreen, string> = Object.fromEntries(
  VOC_RELATED_SCREEN_OPTIONS.map(o => [o.value, o.label])
) as Record<VocRelatedScreen, string>;

export const VOC_PRIORITY_LABEL: Record<VocPriority, string> = Object.fromEntries(
  VOC_PRIORITY_OPTIONS.map(o => [o.value, o.label])
) as Record<VocPriority, string>;

export const VOC_STATUS_LABEL: Record<VocStatus, string> = Object.fromEntries(
  VOC_STATUS_OPTIONS.map(o => [o.value, o.label])
) as Record<VocStatus, string>;

export const VOC_STATUS_COLOR: Record<VocStatus, { bg: string; fg: string }> = {
  received: { bg: '#EEF2FF', fg: '#2955FF' },
  reviewing: { bg: '#FEF3C7', fg: '#B45309' },
  in_progress: { bg: '#E0F2FE', fg: '#0369A1' },
  completed: { bg: '#DCFCE7', fg: '#15803D' },
  on_hold: { bg: '#F3F4F6', fg: '#6B7280' },
};

export const VOC_PRIORITY_COLOR: Record<VocPriority, { bg: string; fg: string }> = {
  low: { bg: '#F3F4F6', fg: '#6B7280' },
  normal: { bg: '#EFF6FF', fg: '#3B82F6' },
  high: { bg: '#FEF2F2', fg: '#EF4444' },
  urgent: { bg: '#FEE2E2', fg: '#B91C1C' },
};

export const VOC_VISIBILITY_LABEL: Record<VocVisibility, string> = {
  public: '공개',
  private: '비공개',
};
