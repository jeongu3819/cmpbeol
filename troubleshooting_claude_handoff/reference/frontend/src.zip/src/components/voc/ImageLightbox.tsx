import React, { useEffect, useState, useCallback } from 'react';
import {
  Dialog,
  IconButton,
  Box,
  Typography,
  Stack,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import ZoomOutIcon from '@mui/icons-material/ZoomOut';
import FitScreenIcon from '@mui/icons-material/FitScreen';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

export interface LightboxImage {
  url: string;
  filename?: string | null;
}

interface ImageLightboxProps {
  open: boolean;
  onClose: () => void;
  images: LightboxImage[];
  initialIndex?: number;
}

const ZOOM_STEP = 0.25;
const ZOOM_MIN = 0.25;
const ZOOM_MAX = 4;

const ImageLightbox: React.FC<ImageLightboxProps> = ({
  open,
  onClose,
  images,
  initialIndex = 0,
}) => {
  const [index, setIndex] = useState(initialIndex);
  const [zoom, setZoom] = useState(1);

  useEffect(() => {
    if (open) {
      setIndex(initialIndex);
      setZoom(1);
    }
  }, [open, initialIndex]);

  const total = images.length;
  const current = images[index];

  const goPrev = useCallback(() => {
    if (total <= 1) return;
    setIndex(i => (i - 1 + total) % total);
    setZoom(1);
  }, [total]);

  const goNext = useCallback(() => {
    if (total <= 1) return;
    setIndex(i => (i + 1) % total);
    setZoom(1);
  }, [total]);

  const zoomIn = useCallback(() => {
    setZoom(z => Math.min(ZOOM_MAX, Math.round((z + ZOOM_STEP) * 100) / 100));
  }, []);
  const zoomOut = useCallback(() => {
    setZoom(z => Math.max(ZOOM_MIN, Math.round((z - ZOOM_STEP) * 100) / 100));
  }, []);
  const zoomFit = useCallback(() => setZoom(1), []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') goPrev();
      else if (e.key === 'ArrowRight') goNext();
      else if (e.key === '+' || e.key === '=') zoomIn();
      else if (e.key === '-') zoomOut();
      else if (e.key === '0') zoomFit();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, goPrev, goNext, zoomIn, zoomOut, zoomFit]);

  // wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) zoomIn();
    else zoomOut();
  };

  if (!current) return null;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth={false}
      fullWidth
      PaperProps={{
        sx: {
          bgcolor: 'rgba(17, 24, 39, 0.95)',
          boxShadow: 'none',
          m: 0,
          width: '100vw',
          height: '100vh',
          maxWidth: '100vw',
          maxHeight: '100vh',
          borderRadius: 0,
        },
      }}
    >
      <Box sx={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden' }}>
        {/* Top bar */}
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            px: 2,
            py: 1.2,
            zIndex: 2,
            bgcolor: 'rgba(0,0,0,0.35)',
          }}
        >
          <Typography variant="body2" sx={{ color: '#fff', maxWidth: '60vw', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {current.filename || ''} {total > 1 ? `(${index + 1}/${total})` : ''}
          </Typography>
          <Stack direction="row" spacing={0.5} alignItems="center">
            <IconButton size="small" onClick={zoomOut} sx={{ color: '#fff' }} title="축소 ( - )">
              <ZoomOutIcon />
            </IconButton>
            <Typography variant="caption" sx={{ color: '#fff', minWidth: 48, textAlign: 'center' }}>
              {Math.round(zoom * 100)}%
            </Typography>
            <IconButton size="small" onClick={zoomIn} sx={{ color: '#fff' }} title="확대 ( + )">
              <ZoomInIcon />
            </IconButton>
            <IconButton size="small" onClick={zoomFit} sx={{ color: '#fff' }} title="화면 맞춤 ( 0 )">
              <FitScreenIcon />
            </IconButton>
            <IconButton size="small" onClick={onClose} sx={{ color: '#fff' }} title="닫기 (Esc)">
              <CloseIcon />
            </IconButton>
          </Stack>
        </Stack>

        {/* Prev / Next */}
        {total > 1 && (
          <>
            <IconButton
              onClick={goPrev}
              sx={{
                position: 'absolute',
                left: 12,
                top: '50%',
                transform: 'translateY(-50%)',
                bgcolor: 'rgba(0,0,0,0.45)',
                color: '#fff',
                '&:hover': { bgcolor: 'rgba(0,0,0,0.7)' },
                zIndex: 2,
              }}
            >
              <ChevronLeftIcon />
            </IconButton>
            <IconButton
              onClick={goNext}
              sx={{
                position: 'absolute',
                right: 12,
                top: '50%',
                transform: 'translateY(-50%)',
                bgcolor: 'rgba(0,0,0,0.45)',
                color: '#fff',
                '&:hover': { bgcolor: 'rgba(0,0,0,0.7)' },
                zIndex: 2,
              }}
            >
              <ChevronRightIcon />
            </IconButton>
          </>
        )}

        {/* Image area */}
        <Box
          onClick={onClose}
          onWheel={handleWheel}
          sx={{
            width: '100%',
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'auto',
            cursor: zoom > 1 ? 'grab' : 'zoom-out',
          }}
        >
          <img
            src={current.url}
            alt={current.filename || 'attachment'}
            onClick={e => e.stopPropagation()}
            style={{
              maxWidth: zoom <= 1 ? '92vw' : 'none',
              maxHeight: zoom <= 1 ? '88vh' : 'none',
              transform: `scale(${zoom})`,
              transformOrigin: 'center center',
              transition: 'transform 0.12s ease-out',
              userSelect: 'none',
              objectFit: 'contain',
            }}
            draggable={false}
          />
        </Box>
      </Box>
    </Dialog>
  );
};

export default ImageLightbox;
