import React, { useEffect, useRef, useState } from 'react';
import {
  Box,
  Typography,
  Button,
  Avatar,
  Chip,
  IconButton,
  CircularProgress,
  Tooltip,
  Collapse,
} from '@mui/material';
import ForumOutlinedIcon from '@mui/icons-material/ForumOutlined';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useSnackbar } from 'notistack';
import { format } from 'date-fns';
import { api } from '../../api/client';
import { VocComment } from '../../types';
import { planAiColors } from '../../theme/tokens';
import VocContentEditor, {
  VocContentEditorHandle,
  PendingPasteImage,
} from './VocContentEditor';
import VocContentRenderer from './VocContentRenderer';
import ImageLightbox, { LightboxImage } from './ImageLightbox';
import {
  collectPendingUploads,
  normalizeForStorage,
  uploadAndResolvePending,
} from './vocImageUpload';

interface VocCommentThreadProps {
  vocId: number;
  vocAuthorId: number;
  currentUserId: number;
  isAdmin: boolean;
  /** 메일 딥링크로 진입 시 true — 댓글(답변) 영역을 자동으로 펼친다. */
  autoOpen?: boolean;
}

const MAX_COMMENT_IMAGES = 5;

/**
 * VOC 상세 카드 하단의 대화형 댓글 영역.
 * - 펼치기 전에는 가벼운 버튼만 보여주고, 펼칠 때 lazy 로 댓글을 조회한다.
 * - 작성 권한(can_comment)은 서버 정책(작성자 본인 또는 관리자)을 그대로 따른다.
 * - 입력창은 VOC 본문과 동일한 리치 에디터(VocContentEditor)를 재사용해
 *   Ctrl+V 이미지 붙여넣기 / 크기 조절 / 확대를 지원한다. 이미지는 S3(또는 로컬)에
 *   업로드되고 댓글 본문 HTML 에 서버 URL <img> 로 저장된다(base64 저장 X).
 * - 표시도 본문과 동일한 VocContentRenderer(sanitize 후 렌더 + 라이트박스)를 재사용한다.
 */
const VocCommentThread: React.FC<VocCommentThreadProps> = ({
  vocId,
  vocAuthorId,
  currentUserId,
  isAdmin,
  autoOpen = false,
}) => {
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const [open, setOpen] = useState(false);

  // 메일 딥링크(?vocId=)로 들어오면 답변 영역을 자동으로 펼친다(한 번만).
  const autoOpenHandledRef = useRef(false);
  useEffect(() => {
    if (autoOpen && !autoOpenHandledRef.current) {
      autoOpenHandledRef.current = true;
      setOpen(true);
    }
  }, [autoOpen]);

  const editorRef = useRef<VocContentEditorHandle>(null);
  /** placeholderSrc(blob URL) → File */
  const pendingMapRef = useRef<Map<string, File>>(new Map());
  // 빈 입력(텍스트도 이미지도 없음) 여부 — 등록 버튼 활성화 판단용
  const [isEmpty, setIsEmpty] = useState(true);
  const [lightbox, setLightbox] = useState<{ images: LightboxImage[]; index: number } | null>(null);

  const { data, isLoading } = useQuery<{ items: VocComment[]; can_comment: boolean; is_admin: boolean }>({
    queryKey: ['voc-comments', vocId],
    queryFn: () => api.listVocComments(vocId, currentUserId),
    enabled: open && !!currentUserId,
  });

  const comments = data?.items ?? [];
  // 서버 권한이 우선. (open 전에는 data 가 없으므로 클라이언트 추정으로 버튼 노출 여부만 가늠)
  const canComment = data?.can_comment ?? (isAdmin || vocAuthorId === currentUserId);

  const openLightbox = (src: string, allSrcs: string[]) => {
    const images: LightboxImage[] = allSrcs.map(s => ({ url: s }));
    setLightbox({ images, index: Math.max(0, allSrcs.indexOf(src)) });
  };

  const resetEditor = () => {
    editorRef.current?.setHtml('');
    pendingMapRef.current.clear();
    setIsEmpty(true);
  };

  const createMut = useMutation({
    mutationFn: async () => {
      const liveHtml = editorRef.current?.getHtml() || '';
      // 1) 붙여넣은 이미지(blob)들을 먼저 업로드하고 src 를 서버 URL 로 치환
      const pending = collectPendingUploads(liveHtml, pendingMapRef.current);
      if (pending.length > 0) {
        await uploadAndResolvePending(
          pending,
          file => api.uploadVocCommentImage(vocId, file, currentUserId),
          (placeholderSrc, finalSrc, attachmentId) =>
            editorRef.current?.resolvePendingImage(placeholderSrc, finalSrc, attachmentId),
          pendingMapRef.current,
        );
      }
      // 2) 최종 HTML(절대 URL → /api 상대 경로 정규화) 저장.
      //    추가 문의/댓글 저장은 메일 알림을 발생시키지 않는다(메일은 관리자 메모 저장 경로에서만 opt-in).
      const finalHtml = normalizeForStorage(editorRef.current?.getHtml() || '');
      return api.createVocComment(vocId, finalHtml, currentUserId);
    },
    onSuccess: () => {
      resetEditor();
      queryClient.invalidateQueries({ queryKey: ['voc-comments', vocId] });
    },
    onError: (err: any) => {
      // 업로드/등록 실패 시 입력 내용은 그대로 유지한다.
      enqueueSnackbar(
        err?.response?.data?.detail || '댓글 등록에 실패했습니다. 다시 시도해주세요.',
        { variant: 'error' },
      );
    },
  });

  const deleteMut = useMutation({
    mutationFn: (commentId: number) => api.deleteVocComment(vocId, commentId, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['voc-comments', vocId] });
    },
    onError: (err: any) => {
      enqueueSnackbar(err?.response?.data?.detail || '삭제에 실패했습니다.', { variant: 'error' });
    },
  });

  return (
    <Box sx={{ mt: 1.4 }}>
      <Button
        size="small"
        startIcon={<ForumOutlinedIcon sx={{ fontSize: '0.95rem' }} />}
        onClick={() => setOpen(o => !o)}
        sx={{
          textTransform: 'none',
          color: planAiColors.text.tertiary,
          fontWeight: 600,
          px: 1,
        }}
      >
        {open ? '댓글 접기' : '댓글 · 추가 문의'}
      </Button>

      <Collapse in={open} unmountOnExit>
        <Box
          sx={{
            mt: 1,
            pt: 1.4,
            borderTop: `1px dashed ${planAiColors.border.soft}`,
          }}
        >
          {isLoading ? (
            <Box sx={{ textAlign: 'center', py: 2 }}>
              <CircularProgress size={20} />
            </Box>
          ) : comments.length === 0 ? (
            <Typography variant="caption" sx={{ color: planAiColors.text.muted, display: 'block', mb: 1 }}>
              아직 댓글이 없습니다. {canComment ? '추가 문의나 답변을 남겨보세요.' : ''}
            </Typography>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.2, mb: canComment ? 1.5 : 0 }}>
              {comments.map(c => {
                const canDelete = isAdmin || c.author_id === currentUserId;
                return (
                  <Box key={c.id} sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
                    <Avatar
                      sx={{
                        width: 26,
                        height: 26,
                        bgcolor: c.author_color || planAiColors.text.muted,
                        fontSize: '0.72rem',
                        fontWeight: 700,
                        mt: 0.2,
                      }}
                    >
                      {(c.author_name || '?').slice(0, 1)}
                    </Avatar>
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8, flexWrap: 'wrap' }}>
                        <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.secondary }}>
                          {c.author_name || '익명'}
                        </Typography>
                        {c.is_admin_reply && (
                          <Chip
                            size="small"
                            label="운영자"
                            sx={{
                              height: 16,
                              fontSize: '0.6rem',
                              fontWeight: 700,
                              bgcolor: planAiColors.brand.primarySoft,
                              color: planAiColors.brand.primary,
                            }}
                          />
                        )}
                        <Typography variant="caption" sx={{ color: planAiColors.text.muted }}>
                          {c.created_at ? format(new Date(c.created_at), 'yyyy-MM-dd HH:mm') : ''}
                        </Typography>
                        {canDelete && (
                          <Tooltip title="삭제">
                            <IconButton
                              size="small"
                              onClick={() => {
                                if (window.confirm('이 댓글을 삭제할까요?')) deleteMut.mutate(c.id);
                              }}
                              sx={{ p: 0.2, color: planAiColors.text.muted, '&:hover': { color: planAiColors.status.danger } }}
                            >
                              <DeleteOutlineIcon sx={{ fontSize: '0.85rem' }} />
                            </IconButton>
                          </Tooltip>
                        )}
                      </Box>
                      <VocContentRenderer
                        content={c.content}
                        mt={0.3}
                        fontSize="0.85rem"
                        onImageClick={openLightbox}
                      />
                    </Box>
                  </Box>
                );
              })}
            </Box>
          )}

          {canComment && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.8 }}>
              <VocContentEditor
                ref={editorRef}
                initialHtml=""
                minHeight={80}
                maxImages={MAX_COMMENT_IMAGES}
                placeholder="추가 문의 또는 답변을 입력하세요. 오류 화면이나 참고 이미지는 캡처 후 Ctrl+V 로 붙여넣을 수 있습니다."
                onChange={() => setIsEmpty(editorRef.current?.isEmpty() ?? true)}
                onPasteImage={(img: PendingPasteImage) => {
                  pendingMapRef.current.set(img.placeholderSrc, img.file);
                }}
                onZoomImage={openLightbox}
                onWarn={msg => enqueueSnackbar(msg, { variant: 'warning' })}
              />
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                  gap: 1,
                  flexWrap: 'wrap',
                }}
              >
                <Button
                  variant="contained"
                  size="small"
                  onClick={() => createMut.mutate()}
                  disabled={isEmpty || createMut.isPending}
                  startIcon={createMut.isPending ? <CircularProgress size={14} color="inherit" /> : undefined}
                  sx={{ bgcolor: planAiColors.brand.primary, textTransform: 'none', whiteSpace: 'nowrap', flexShrink: 0 }}
                >
                  {createMut.isPending ? '등록 중...' : '등록'}
                </Button>
              </Box>
            </Box>
          )}
        </Box>
      </Collapse>

      {lightbox && (
        <ImageLightbox
          open={!!lightbox}
          onClose={() => setLightbox(null)}
          images={lightbox.images}
          initialIndex={lightbox.index}
        />
      )}
    </Box>
  );
};

export default VocCommentThread;
