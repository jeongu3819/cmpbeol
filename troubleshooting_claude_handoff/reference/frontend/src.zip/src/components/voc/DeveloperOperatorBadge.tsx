import React from 'react';
import { Box, Typography, Tooltip } from '@mui/material';

interface DeveloperOperatorBadgeProps {
  /** 개발/운영 담당자 이름 */
  name: string;
}

/**
 * PLAN-AI를 직접 개발·운영하는 담당자를 보여주는 미니멀 배지.
 * 아이콘/점 없이 텍스트 중심으로 정리하고, 아주 은은한 shimmer(빛이 천천히 스쳐 지나가는 효과)만 적용한다.
 */
const DeveloperOperatorBadge: React.FC<DeveloperOperatorBadgeProps> = ({ name }) => {
  return (
    <Tooltip title="PLAN-AI 개발 및 운영 담당자" arrow placement="top">
      <Box
        sx={{
          position: 'relative',
          display: 'inline-flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          px: 2,
          py: 1,
          borderRadius: 2,
          flexShrink: 0,
          background:
            'linear-gradient(135deg, rgba(255,255,255,0.92), rgba(239,246,255,0.82))',
          border: '1px solid rgba(59, 130, 246, 0.20)',
          boxShadow: '0 8px 22px rgba(37, 99, 235, 0.10)',
          overflow: 'hidden',
          transition: 'transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease',
          '&:hover': {
            transform: 'translateY(-1px)',
            borderColor: 'rgba(59, 130, 246, 0.34)',
            boxShadow: '0 12px 28px rgba(37, 99, 235, 0.14)',
          },
          // 은은한 shimmer: 얇은 빛줄기가 천천히 1회 지나간 뒤 잠시 쉬고 반복.
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: '-45%',
            width: '35%',
            height: '100%',
            background:
              'linear-gradient(120deg, transparent 0%, rgba(255,255,255,0.55) 50%, transparent 100%)',
            transform: 'skewX(-20deg)',
            animation: 'devBadgeShimmer 5.2s ease-in-out infinite',
            pointerEvents: 'none',
          },
          '@keyframes devBadgeShimmer': {
            '0%': { left: '-45%', opacity: 0 },
            '8%': { opacity: 0.9 },
            '24%': { left: '115%', opacity: 0 },
            '100%': { left: '115%', opacity: 0 },
          },
          '@media (prefers-reduced-motion: reduce)': {
            transition: 'none',
            '&::before': { animation: 'none' },
          },
        }}
      >
        <Typography
          variant="caption"
          sx={{
            position: 'relative',
            zIndex: 1,
            fontWeight: 700,
            color: '#475569',
            letterSpacing: '0.01em',
            lineHeight: 1.2,
          }}
        >
          PLAN-AI 개발 · 운영
        </Typography>
        <Typography
          variant="body2"
          sx={{
            position: 'relative',
            zIndex: 1,
            fontWeight: 800,
            color: '#2955FF',
            lineHeight: 1.3,
          }}
        >
          {name}
        </Typography>
      </Box>
    </Tooltip>
  );
};

export default DeveloperOperatorBadge;
