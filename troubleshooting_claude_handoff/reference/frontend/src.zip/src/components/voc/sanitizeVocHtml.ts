/**
 * VOC 본문 전용 minimal HTML sanitizer.
 *
 * 에디터가 직접 만들어내는 태그 외에는 모두 차단하므로 (paste 핸들러에서 plain text/이미지만 삽입)
 * 정상 경로의 컨텐츠는 변형 없이 통과한다. 사용자가 직접 HTML을 붙여 넣거나 stored content 가
 * 변조된 경우를 대비한 방어 레이어로 사용한다.
 */

const ALLOWED_TAGS = new Set([
  'P', 'DIV', 'BR', 'SPAN',
  'B', 'STRONG', 'I', 'EM', 'U',
  'UL', 'OL', 'LI',
  'IMG',
]);

// 태그별 허용 속성. 그 외 속성은 모두 제거.
const ALLOWED_ATTRS: Record<string, Set<string>> = {
  IMG: new Set(['src', 'alt', 'style', 'width', 'height', 'data-voc-att-id']),
  SPAN: new Set(['style']),
  DIV: new Set(['style']),
  P: new Set(['style']),
};

const ALLOWED_STYLE_PROPS = new Set([
  'width', 'height', 'max-width', 'max-height', 'text-align',
]);

const SAFE_URL_RE = /^(https?:|\/|data:image\/)/i;

const sanitizeStyle = (raw: string): string => {
  return raw
    .split(';')
    .map(s => s.trim())
    .filter(Boolean)
    .map(decl => {
      const idx = decl.indexOf(':');
      if (idx <= 0) return '';
      const prop = decl.slice(0, idx).trim().toLowerCase();
      const val = decl.slice(idx + 1).trim();
      if (!ALLOWED_STYLE_PROPS.has(prop)) return '';
      if (/url\s*\(/i.test(val) || /expression\s*\(/i.test(val)) return '';
      return `${prop}: ${val}`;
    })
    .filter(Boolean)
    .join('; ');
};

const cleanElement = (el: Element): void => {
  const tag = el.tagName.toUpperCase();

  if (!ALLOWED_TAGS.has(tag)) {
    // 태그는 제거하고 자식만 남긴다
    const parent = el.parentNode;
    if (parent) {
      while (el.firstChild) parent.insertBefore(el.firstChild, el);
      parent.removeChild(el);
    }
    return;
  }

  const allowedAttrs = ALLOWED_ATTRS[tag] || new Set<string>();
  for (const attr of Array.from(el.attributes)) {
    const name = attr.name.toLowerCase();
    if (!allowedAttrs.has(name)) {
      el.removeAttribute(attr.name);
      continue;
    }
    if (name === 'src') {
      const v = attr.value.trim();
      if (!SAFE_URL_RE.test(v)) {
        el.removeAttribute(attr.name);
      }
    } else if (name === 'style') {
      const cleaned = sanitizeStyle(attr.value);
      if (cleaned) el.setAttribute('style', cleaned);
      else el.removeAttribute('style');
    }
  }
};

const walk = (root: Element): void => {
  // 깊은 후위 순회 — 자식 변경 안전성
  const children = Array.from(root.children);
  for (const child of children) {
    walk(child);
  }
  if (root.parentElement) cleanElement(root);
};

export const sanitizeVocHtml = (html: string): string => {
  if (!html) return '';
  const tpl = document.createElement('template');
  tpl.innerHTML = html;
  walk(tpl.content as unknown as Element);
  return tpl.innerHTML;
};

/** 컨텐츠가 HTML 인지(<p>...</p> 형식) 단순 휴리스틱으로 판단. 구 plain text 호환용. */
export const looksLikeHtml = (s: string): boolean => {
  if (!s) return false;
  return /^\s*<[a-z]/i.test(s);
};
