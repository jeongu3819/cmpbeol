import React, { useEffect, useMemo, useRef } from 'react';
import { Box, Typography } from '@mui/material';
import { API_URL } from '../../api/client';
import { planAiColors } from '../../theme/tokens';
import { sanitizeVocHtml, looksLikeHtml } from './sanitizeVocHtml';
import { stripHtmlToText } from '../../utils/htmlText';

// DB에 저장된 본문/댓글은 img src 가 /api/voc/... 상대 경로이므로 백엔드 절대 URL 로 다시 붙여준다.
// (프론트는 5173, 백엔드는 8085 처럼 origin 이 다를 수 있어 상대 경로면 broken icon 으로 표시됨)
const API_PREFIX_RE = /(<img[^>]*\bsrc=)(["'])(\/api\/[^"']+)\2/gi;
export const absolutizeApiUrls = (html: string): string => {
  if (!html) return html;
  const apiBase = (API_URL || '').replace(/\/+$/, '');
  if (!apiBase) return html;
  // API_URL 은 보통 'http://host:port/api' 형태. /api 접두사가 두 번 붙지 않도록 잘라낸다.
  const originBase = apiBase.replace(/\/api$/, '');
  return html.replace(API_PREFIX_RE, (_m, p1, q, p3) => `${p1}${q}${originBase}${p3}${q}`);
};

/**
 * VOC 본문/댓글(content)을 안전하게 렌더링하는 공용 컴포넌트.
 * - HTML 처럼 보이면 sanitize(allowlist) 후 innerHTML (이미지 포함)
 * - 그 외(구 plain text)는 pre-wrap 으로 표시
 * - 내부 <img> 클릭 시 onImageClick(src, allSrcs) 콜백 → 라이트박스 확대
 */
const VocContentRenderer: React.FC<{
  content: string;
  onImageClick?: (src: string, allSrcs: string[]) => void;
  /** plain text 표시 시 위쪽 여백(mt). 기본 1. */
  mt?: number;
  fontSize?: string;
}> = ({ content, onImageClick, mt = 1, fontSize = '0.875rem' }) => {
  const ref = useRef<HTMLDivElement>(null);
  // 태그로 시작하거나, 본문 어디든 <img> 가 있으면 HTML 로 렌더(텍스트가 앞서는 댓글에서도 이미지 보존).
  const isHtml = looksLikeHtml(content) || /<img[\s>]/i.test(content);
  const html = useMemo(
    () => (isHtml ? absolutizeApiUrls(sanitizeVocHtml(content)) : ''),
    [isHtml, content]
  );

  useEffect(() => {
    if (!isHtml || !ref.current || !onImageClick) return;
    const container = ref.current;
    const handler = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (t && t.tagName === 'IMG') {
        const all: string[] = [];
        container.querySelectorAll('img').forEach(img => {
          const s = img.getAttribute('src');
          if (s) all.push(s);
        });
        const src = (t as HTMLImageElement).getAttribute('src') || '';
        if (src) onImageClick(src, all);
      }
    };
    container.addEventListener('click', handler);
    return () => container.removeEventListener('click', handler);
  }, [isHtml, html, onImageClick]);

  if (!content) return null;
  if (!isHtml) {
    // 구 plain text 호환. 다만 저장값에 <br>/<div>/&nbsp; 등이 섞여 있을 수 있어
    // plain text 로 정리 후 표시한다(태그/엔티티가 raw 로 노출되는 것 방지).
    return (
      <Typography
        variant="body2"
        sx={{ mt, color: planAiColors.text.secondary, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}
      >
        {stripHtmlToText(content)}
      </Typography>
    );
  }
  return (
    <Box
      ref={ref}
      sx={{
        mt,
        color: planAiColors.text.secondary,
        fontSize,
        lineHeight: 1.7,
        wordBreak: 'break-word',
        '& img': {
          maxWidth: '100%',
          height: 'auto',
          borderRadius: 1,
          my: 0.5,
          cursor: 'zoom-in',
        },
        '& p': { my: 0.4 },
      }}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};

export default VocContentRenderer;
