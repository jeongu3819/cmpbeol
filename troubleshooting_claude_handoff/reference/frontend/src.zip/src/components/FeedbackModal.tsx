import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  Typography,
  MenuItem,
  Stack,
  CircularProgress,
  FormControlLabel,
  Checkbox,
} from '@mui/material';
import FeedbackIcon from '@mui/icons-material/Feedback';
import EditIcon from '@mui/icons-material/Edit';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useSnackbar } from 'notistack';
import { api } from '../api/client';
import {
  VocCategory,
  VocPriority,
  VocRelatedScreen,
  VocItem,
} from '../types';
import {
  VOC_CATEGORY_OPTIONS,
  VOC_RELATED_SCREEN_OPTIONS,
  VOC_PRIORITY_OPTIONS,
} from './voc/vocLabels';
import VocContentEditor, {
  VocContentEditorHandle,
  PendingPasteImage,
  ATT_ID_DATA_ATTR,
  PENDING_DATA_ATTR,
} from './voc/VocContentEditor';
import ImageLightbox, { LightboxImage } from './voc/ImageLightbox';
import {
  buildAbsoluteUrl,
  collectPendingUploads,
  normalizeForStorage,
} from './voc/vocImageUpload';

interface FeedbackModalProps {
  open: boolean;
  onClose: () => void;
  currentUserId: number;
  defaultRelatedScreen?: VocRelatedScreen | null;
  /** 수정 모드일 때 기존 VOC 객체. 미지정 시 새 작성 모드. */
  editingVoc?: VocItem | null;
}

const MAX_IMAGES = 5;

/**
 * 수정 시 기존 첨부의 url 을 frontend 절대 URL 로 prefilled HTML 에 박아준다.
 * 이미 absolute 경로면 그대로, 그 외에는 absolute 화.
 */
const prefillEditorHtml = (voc: VocItem | null | undefined): string => {
  if (!voc) return '';
  let html = voc.content || '';
  // 기존 plain text 호환 — HTML 같지 않으면 <p> 로 감싸고 줄바꿈 처리
  if (!/^\s*<[a-z]/i.test(html)) {
    const escaped = html
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    html = `<p>${escaped.replace(/\n/g, '<br/>')}</p>`;
  }
  // 본문에 src 가 상대 경로(/api/...)로 저장돼 있으면 절대화
  html = html.replace(
    /(<img[^>]*\bsrc=)(["'])(\/api\/[^"']+)\2/gi,
    (_m, p1, q, p3) => `${p1}${q}${buildAbsoluteUrl(p3)}${q}`
  );
  return html;
};

const FeedbackModal: React.FC<FeedbackModalProps> = ({
  open,
  onClose,
  currentUserId,
  defaultRelatedScreen,
  editingVoc,
}) => {
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const isEdit = !!editingVoc;

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<VocCategory>('improvement');
  const [relatedScreen, setRelatedScreen] = useState<VocRelatedScreen | ''>('');
  const [priority, setPriority] = useState<VocPriority>('normal');
  const [isPrivate, setIsPrivate] = useState(false);
  const [contentHtml, setContentHtml] = useState('');

  const editorRef = useRef<VocContentEditorHandle>(null);
  /** placeholderSrc(blob URL) → File */
  const pendingMapRef = useRef<Map<string, File>>(new Map());

  const [lightbox, setLightbox] = useState<{ images: LightboxImage[]; index: number } | null>(null);

  // open / editingVoc 변경 시 폼 초기화
  useEffect(() => {
    if (!open) return;
    if (isEdit && editingVoc) {
      setTitle(editingVoc.title || '');
      setCategory((editingVoc.category as VocCategory) || 'improvement');
      setRelatedScreen((editingVoc.related_screen as VocRelatedScreen) || '');
      setPriority(editingVoc.priority || 'normal');
      setIsPrivate(editingVoc.visibility === 'private');
      setContentHtml(prefillEditorHtml(editingVoc));
    } else {
      setTitle('');
      setCategory('improvement');
      setRelatedScreen(defaultRelatedScreen ?? '');
      setPriority('normal');
      setIsPrivate(false);
      setContentHtml('');
    }
    pendingMapRef.current.clear();
    // editor 에 새 HTML 반영
    setTimeout(() => {
      editorRef.current?.setHtml(isEdit && editingVoc ? prefillEditorHtml(editingVoc) : '');
    }, 0);
  }, [open, isEdit, editingVoc, defaultRelatedScreen]);

  const handlePasteImage = (img: PendingPasteImage) => {
    pendingMapRef.current.set(img.placeholderSrc, img.file);
  };

  const handleZoomImage = (src: string, allSrcs: string[]) => {
    const images: LightboxImage[] = allSrcs.map(s => ({ url: s }));
    const idx = Math.max(0, allSrcs.indexOf(src));
    setLightbox({ images, index: idx });
  };

  const uploadAndResolve = async (
    vocId: number,
    pending: { placeholderSrc: string; file: File }[]
  ): Promise<void> => {
    for (const item of pending) {
      try {
        const att = await api.uploadVocAttachment(vocId, item.file, currentUserId);
        const finalSrc = att?.url ? buildAbsoluteUrl(att.url) : '';
        if (finalSrc && att?.id) {
          editorRef.current?.resolvePendingImage(item.placeholderSrc, finalSrc, att.id);
        }
        pendingMapRef.current.delete(item.placeholderSrc);
      } catch (err: any) {
        const detail = err?.response?.data?.detail || `'${item.file.name}' 이미지 업로드 실패`;
        enqueueSnackbar(detail, { variant: 'error' });
        throw err;
      }
    }
  };

  // 변경 다이얼로그 진단용 textOnly check (사용자가 적은 텍스트가 있는지)
  const isEmpty = (): boolean => {
    if (!editorRef.current) return true;
    return editorRef.current.isEmpty();
  };

  const createMut = useMutation({
    mutationFn: async () => {
      const liveHtml = editorRef.current?.getHtml() || contentHtml;
      const pending = collectPendingUploads(liveHtml, pendingMapRef.current);

      // 1) placeholder HTML (이미지 src 를 marker 로 잠시 치환) — 서버는 무시해도 무방
      // 그러나 단순화를 위해 그대로 보내고, 업로드 후 PATCH 로 덮어쓴다.
      // 서버는 단순히 HTML 텍스트로 저장하므로 blob URL 도 일단 받는다.
      const created = await api.createVoc(
        {
          title: title.trim(),
          category,
          content: liveHtml, // blob URL 포함될 수 있으나 즉시 PATCH 로 교체됨
          related_screen: relatedScreen || null,
          priority,
          visibility: isPrivate ? 'private' : 'public',
        },
        currentUserId
      );

      if (created?.id && pending.length > 0) {
        await uploadAndResolve(created.id, pending);
        const finalHtml = normalizeForStorage(editorRef.current?.getHtml() || '');
        await api.updateVoc(created.id, { content: finalHtml }, currentUserId);
      }
      return created;
    },
    onSuccess: () => {
      enqueueSnackbar('개선 요청이 접수되었습니다. 감사합니다!', { variant: 'success' });
      queryClient.invalidateQueries({ queryKey: ['voc-list'] });
      queryClient.invalidateQueries({ queryKey: ['voc-stats'] });
      onClose();
    },
    onError: (err: any) => {
      const detail = err?.response?.data?.detail || '저장에 실패했습니다.';
      enqueueSnackbar(detail, { variant: 'error' });
    },
  });

  const updateMut = useMutation({
    mutationFn: async () => {
      if (!editingVoc) throw new Error('수정할 항목이 없습니다.');
      const liveHtml = editorRef.current?.getHtml() || contentHtml;

      // 신규 paste 이미지 먼저 업로드 → src 치환
      const pending = collectPendingUploads(liveHtml, pendingMapRef.current);
      if (pending.length > 0) {
        await uploadAndResolve(editingVoc.id, pending);
      }

      const finalHtml = normalizeForStorage(editorRef.current?.getHtml() || '');

      // 제거된 server-side 첨부 id 계산 (기존 - 현재 본문에 남아있는 것)
      const remaining = new Set(editorRef.current?.getReferencedAttachmentIds() || []);
      const originalIds = (editingVoc.attachments || []).map(a => a.id);
      const removed = originalIds.filter(id => !remaining.has(id));

      const body: Record<string, any> = {};
      const t = title.trim();
      if (t !== (editingVoc.title || '')) body.title = t;
      if (category !== editingVoc.category) body.category = category;
      if (finalHtml !== (editingVoc.content || '')) body.content = finalHtml;
      const rs = relatedScreen || null;
      if (rs !== (editingVoc.related_screen ?? null)) body.related_screen = rs;
      if (removed.length > 0) body.remove_attachment_ids = removed;

      if (Object.keys(body).length > 0) {
        await api.updateVoc(editingVoc.id, body, currentUserId);
      }
    },
    onSuccess: () => {
      enqueueSnackbar('개선 요청이 수정되었습니다.', { variant: 'success' });
      queryClient.invalidateQueries({ queryKey: ['voc-list'] });
      queryClient.invalidateQueries({ queryKey: ['voc-stats'] });
      onClose();
    },
    onError: (err: any) => {
      const detail = err?.response?.data?.detail || '수정에 실패했습니다.';
      enqueueSnackbar(detail, { variant: 'error' });
    },
  });

  const submitting = createMut.isPending || updateMut.isPending;
  const canSubmit = title.trim().length > 0 && !isEmpty() && !submitting;

  // contentHtml 변경 추적용 — canSubmit 재평가 트리거
  // (editor 가 ref 기반이라 setState 갱신은 onChange 콜백으로)
  useMemo(() => contentHtml, [contentHtml]);

  return (
    <>
      <Dialog
        open={open}
        onClose={() => (!submitting ? onClose() : undefined)}
        maxWidth="md"
        fullWidth
        PaperProps={{ sx: { borderRadius: 3 } }}
      >
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1.05rem' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            {isEdit ? (
              <EditIcon sx={{ color: '#2955FF', fontSize: '1.3rem' }} />
            ) : (
              <FeedbackIcon sx={{ color: '#2955FF', fontSize: '1.3rem' }} />
            )}
            {isEdit ? '개선 요청 수정' : '개선 요청 작성'}
          </Box>
          <Typography variant="caption" sx={{ color: '#6B7280', display: 'block', mt: 0.5 }}>
            내용 영역에서 <b>Ctrl+V</b> 로 스크린샷을 바로 붙여넣을 수 있어요. (최대 {MAX_IMAGES}장)
          </Typography>
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="제목"
              value={title}
              onChange={e => setTitle(e.target.value)}
              fullWidth
              size="small"
              inputProps={{ maxLength: 200 }}
            />

            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr 1fr' }, gap: 2 }}>
              <TextField
                label="분류"
                select
                value={category}
                onChange={e => setCategory(e.target.value as VocCategory)}
                size="small"
                fullWidth
              >
                {VOC_CATEGORY_OPTIONS.map(o => (
                  <MenuItem key={o.value} value={o.value}>
                    {o.label}
                  </MenuItem>
                ))}
              </TextField>

              <TextField
                label="우선순위"
                select
                value={priority}
                onChange={e => setPriority(e.target.value as VocPriority)}
                size="small"
                fullWidth
                disabled={isEdit}
                helperText={isEdit ? '변경은 관리자만 가능합니다.' : undefined}
              >
                {VOC_PRIORITY_OPTIONS.map(o => (
                  <MenuItem key={o.value} value={o.value}>
                    {o.label}
                  </MenuItem>
                ))}
              </TextField>

              <TextField
                label="관련 화면 (선택)"
                select
                value={relatedScreen}
                onChange={e => setRelatedScreen(e.target.value as VocRelatedScreen | '')}
                size="small"
                fullWidth
              >
                <MenuItem value="">선택 안 함</MenuItem>
                {VOC_RELATED_SCREEN_OPTIONS.map(o => (
                  <MenuItem key={o.value} value={o.value}>
                    {o.label}
                  </MenuItem>
                ))}
              </TextField>
            </Box>

            <VocContentEditor
              ref={editorRef}
              initialHtml={contentHtml}
              minHeight={220}
              maxImages={MAX_IMAGES}
              onChange={html => setContentHtml(html)}
              onPasteImage={handlePasteImage}
              onZoomImage={handleZoomImage}
              onWarn={msg => enqueueSnackbar(msg, { variant: 'warning' })}
            />

            {!isEdit && (
              <Box sx={{ bgcolor: '#F9FAFB', borderRadius: 1.5, p: 1.5, border: '1px solid #EEF0F4' }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      size="small"
                      checked={isPrivate}
                      onChange={e => setIsPrivate(e.target.checked)}
                      icon={<LockOutlinedIcon fontSize="small" />}
                      checkedIcon={<LockOutlinedIcon fontSize="small" />}
                    />
                  }
                  label={
                    <Typography variant="body2" sx={{ fontWeight: 600, color: '#374151' }}>
                      비공개로 등록
                    </Typography>
                  }
                  sx={{ m: 0 }}
                />
                <Typography variant="body2" sx={{ display: 'block', color: '#6B7280', mt: 0.6, lineHeight: 1.6 }}>
                  공개 요청은 다른 사용자도 볼 수 있어요.
                </Typography>
                <Typography
                  variant="body2"
                  sx={{ display: 'block', color: '#B45309', fontWeight: 600, mt: 0.8, lineHeight: 1.6 }}
                >
                  사람 이름·부서·내부 시스템 정보·오류 화면 등 민감한 내용이 포함된 경우
                  <br />
                  비공개로 등록해 주세요.
                </Typography>
                <Typography variant="caption" sx={{ display: 'block', color: '#9CA3AF', mt: 0.8 }}>
                  (작성 후 공개 전환은 관리자만 가능)
                </Typography>
              </Box>
            )}
          </Stack>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={onClose} disabled={submitting} sx={{ color: '#6B7280' }}>
            취소
          </Button>
          <Button
            variant="contained"
            onClick={() => (isEdit ? updateMut.mutate() : createMut.mutate())}
            disabled={!canSubmit}
            startIcon={submitting ? <CircularProgress size={16} sx={{ color: '#fff' }} /> : undefined}
            sx={{ bgcolor: '#2955FF' }}
          >
            {submitting ? '저장 중…' : isEdit ? '수정 저장' : '제출'}
          </Button>
        </DialogActions>
      </Dialog>

      {lightbox && (
        <ImageLightbox
          open={!!lightbox}
          onClose={() => setLightbox(null)}
          images={lightbox.images}
          initialIndex={lightbox.index}
        />
      )}
    </>
  );
};

// data attributes 는 외부에서 참조될 수 있어 re-export
export { ATT_ID_DATA_ATTR, PENDING_DATA_ATTR };

export default FeedbackModal;
