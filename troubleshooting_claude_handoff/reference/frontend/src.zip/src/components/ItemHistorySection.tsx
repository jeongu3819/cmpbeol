import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box, Typography, Stack, Button, Drawer, IconButton, Divider, useMediaQuery, useTheme,
} from '@mui/material';
import HistoryIcon from '@mui/icons-material/History';
import CloseIcon from '@mui/icons-material/Close';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { api } from '../api/client';
import type { ActivityLogEntry } from '../types';
import ActivityHistory from './ActivityHistory';

interface Props {
  entityType: 'project' | 'task' | 'calendar_event';
  entityId?: number | null;
  /** 상세 Drawer 상단에 표시할 대상 이름(선택). */
  itemName?: string;
  /** 최대 표시 건수 (기본 50) */
  limit?: number;
}

/**
 * 변경 이력을 "상시 노출"하지 않고 compact row + Drawer 로 분리한 진입점.
 * - 기본 화면: "변경 이력 N건 [보기]" 만 노출 (목록은 렌더링하지 않음).
 * - [보기] 클릭 시에만 상세 이력 Drawer(PC: 우측 / 모바일: 전체화면) 를 연다.
 * - 이력 데이터 자체(activity_logs)는 그대로 유지된다.
 */
const ItemHistorySection: React.FC<Props> = ({ entityType, entityId, itemName, limit = 50 }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [open, setOpen] = useState(false);

  // compact row 의 건수 표시용. 상세 Drawer 의 ActivityHistory 와 동일 queryKey 라 캐시를 공유한다.
  const { data: logs = [] } = useQuery<ActivityLogEntry[]>({
    queryKey: ['activity-logs', entityType, entityId, limit],
    queryFn: () => api.getActivityLogs(entityType, entityId as number, limit),
    enabled: !!entityId,
    staleTime: 10_000,
  });

  const count = logs.length;

  return (
    <>
      {/* compact row */}
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        spacing={1}
        sx={{ py: 0.5 }}
      >
        <Stack direction="row" alignItems="center" spacing={1} sx={{ minWidth: 0 }}>
          <HistoryIcon fontSize="small" sx={{ color: 'text.secondary' }} />
          <Box sx={{ minWidth: 0 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700, lineHeight: 1.3 }}>
              변경 이력
            </Typography>
            <Typography variant="caption" color="text.secondary" noWrap>
              {count > 0 ? `최근 ${count}건의 변경 기록이 있습니다.` : '기록된 변경 이력이 없습니다.'}
            </Typography>
          </Box>
        </Stack>
        {count > 0 && (
          <Button
            size="small"
            variant="outlined"
            endIcon={<ChevronRightIcon />}
            onClick={() => setOpen(true)}
            sx={{
              flexShrink: 0, textTransform: 'none', fontWeight: 600,
              borderColor: '#D1D5DB', color: '#374151',
            }}
          >
            보기
          </Button>
        )}
      </Stack>

      {/* 상세 이력 Drawer
          Dialog(일정 편집 등) 내부에서 열릴 때 모달 backdrop 뒤에 깔리지 않도록
          z-index 를 modal 레이어보다 위로 올린다. Drawer 자체 backdrop 으로 닫기/클릭이 가능하다. */}
      <Drawer
        anchor={isMobile ? 'bottom' : 'right'}
        open={open}
        onClose={() => setOpen(false)}
        sx={(theme) => ({ zIndex: theme.zIndex.modal + 20 })}
        PaperProps={{
          sx: isMobile
            ? { height: '90vh', borderTopLeftRadius: 12, borderTopRightRadius: 12 }
            : { width: 420, maxWidth: '100vw' },
        }}
      >
        <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <Box sx={{ p: 2, display: 'flex', alignItems: 'flex-start', gap: 1 }}>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Stack direction="row" alignItems="center" spacing={1}>
                <HistoryIcon fontSize="small" sx={{ color: '#2955FF' }} />
                <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1.05rem' }}>
                  변경 이력
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  총 {count}건
                </Typography>
              </Stack>
              {itemName && (
                <Typography variant="body2" color="text.secondary" noWrap sx={{ mt: 0.3 }}>
                  {itemName}
                </Typography>
              )}
            </Box>
            <IconButton size="small" onClick={() => setOpen(false)} aria-label="닫기">
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
          <Divider />
          <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
            {/* Drawer 가 열린 동안에만 상세 목록을 렌더링한다. */}
            {open && (
              <ActivityHistory
                entityType={entityType}
                entityId={entityId}
                limit={limit}
                showHeader={false}
                enableFilters
                dense
              />
            )}
          </Box>
        </Box>
      </Drawer>
    </>
  );
};

export default ItemHistorySection;
