/**
 * MagicInput — AI-powered task creation overlay for QuickAdd
 *
 * Enhances the existing QuickAdd text field with real-time NLP parsing.
 * Extracted fields appear as preview chips below the input.
 * Parsed values auto-fill into the task creation payload.
 *
 * Falls back gracefully: if parsing is uncertain, keeps raw text as title.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Box, TextField, Chip, Fade } from '@mui/material';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../api/client';
import { Task } from '../types';
import { useAppStore } from '../stores/useAppStore';
import { parseQuickAddInput, QuickAddParseResult } from '../utils/magicInputParser';
import AddIcon from '@mui/icons-material/Add';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';

interface MagicInputProps {
  projectId: number;
  defaultStatus?: Task['status'];
  onSuccess?: () => void;
}

const MagicInput: React.FC<MagicInputProps> = ({ projectId, defaultStatus = 'todo', onSuccess }) => {
  const [rawText, setRawText] = useState('');
  const [parsed, setParsed] = useState<QuickAddParseResult | null>(null);
  const [isFocused, setIsFocused] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();
  const queryClient = useQueryClient();
  const currentUserId = useAppStore(state => state.currentUserId);

  const createMutation = useMutation({
    mutationFn: (newTask: Omit<Task, 'id'>) => api.createTask(newTask),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setRawText('');
      setParsed(null);
      if (onSuccess) onSuccess();
    },
  });

  // Debounced parsing (300ms) — 미리보기 용도. 자연어 추정 없이 명확한 일정 문법만 인식.
  const doParse = useCallback((text: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      if (text.trim().length >= 2) {
        const result = parseQuickAddInput(text);
        setParsed(result);
      } else {
        setParsed(null);
      }
    }, 300);
  }, []);

  useEffect(() => {
    doParse(rawText);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [rawText, doParse]);

  const handleSubmit = () => {
    if (!rawText.trim()) return;

    // 제출 시점에 동기로 파싱한다 (debounce 상태에 의존하지 않음 → 입력 훼손 방지).
    const result = parseQuickAddInput(rawText);
    if (!result.title) return;

    const taskData: Omit<Task, 'id'> = {
      title: result.title,
      project_id: projectId,
      status: defaultStatus,
      assignee_ids: currentUserId > 0 ? [currentUserId] : [],
      tags: [],
      start_date: result.startDate || undefined,
      due_date: result.endDate || undefined,
    };

    createMutation.mutate(taskData);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
    }
    if (e.key === 'Escape') {
      setRawText('');
      setParsed(null);
      (e.target as HTMLInputElement).blur();
    }
  };

  // 명확한 일정 문법이 인식됐을 때만 미리보기를 노출한다.
  const hasExtracted = !!(parsed && (parsed.startDate || parsed.endDate));

  return (
    <Box>
      {/* Input field */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 0.5,
          p: 0.5,
          borderRadius: 1.5,
          border: isFocused ? '1px solid #2955FF' : '1px dashed #D1D5DB',
          bgcolor: isFocused ? '#fff' : 'transparent',
          transition: 'all 0.15s',
          '&:hover': {
            borderColor: '#9CA3AF',
            bgcolor: '#fff',
          },
        }}
      >
        {hasExtracted ? (
          <AutoAwesomeIcon sx={{ fontSize: '0.9rem', color: '#7C3AED', ml: 0.5 }} />
        ) : (
          <AddIcon sx={{ fontSize: '1rem', color: isFocused ? '#2955FF' : '#9CA3AF', ml: 0.5 }} />
        )}
        <TextField
          fullWidth
          placeholder="+ Task 제목 입력"
          variant="standard"
          size="small"
          value={rawText}
          onChange={(e) => setRawText(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          disabled={createMutation.isPending}
          InputProps={{
            disableUnderline: true,
            sx: { fontSize: '0.8rem', py: 0.5 },
          }}
        />
      </Box>

      {/* 입력 도움말 — 포커스 상태이고 아직 추출된 값이 없을 때만 */}
      {isFocused && !hasExtracted && (
        <Box sx={{ px: 0.8, pt: 0.3 }}>
          <span style={{ fontSize: '0.6rem', color: '#9CA3AF' }}>
            입력값 전체가 제목이 됩니다. 일정은 “[마감: 2026-07-01]” 형식으로만 분리돼요.
          </span>
        </Box>
      )}

      {/* Preview chips — only show when extracted fields exist */}
      <Fade in={!!hasExtracted} timeout={200}>
        <Box
          sx={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: 0.5,
            mt: 0.5,
            px: 0.5,
            minHeight: hasExtracted ? 24 : 0,
          }}
        >
          {parsed?.title && parsed.title !== rawText.trim() && (
            <Chip
              label={parsed.title}
              size="small"
              variant="outlined"
              sx={{
                height: 20,
                fontSize: '0.62rem',
                fontWeight: 600,
                borderColor: '#E5E7EB',
                color: '#374151',
                '& .MuiChip-label': { px: 0.8 },
              }}
            />
          )}

          {(parsed?.startDate || parsed?.endDate) && (
            <Chip
              icon={<CalendarTodayIcon sx={{ fontSize: '0.65rem !important' }} />}
              label={
                parsed.startDate && parsed.endDate
                  ? `${parsed.startDate} ~ ${parsed.endDate}`
                  : parsed.endDate
                    ? `~ ${parsed.endDate}`
                    : `${parsed.startDate} ~`
              }
              size="small"
              sx={{
                height: 20,
                fontSize: '0.6rem',
                fontWeight: 600,
                bgcolor: '#EEF2FF',
                color: '#2955FF',
                border: '1px solid #C7D2FE',
                '& .MuiChip-icon': { color: '#2955FF', ml: 0.3 },
                '& .MuiChip-label': { px: 0.5 },
              }}
            />
          )}
        </Box>
      </Fade>
    </Box>
  );
};

export default MagicInput;
