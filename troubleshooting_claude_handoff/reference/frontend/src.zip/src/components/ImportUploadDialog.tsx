/**
 * ImportUploadDialog — CSV/XLSX upload for bulk project/task creation.
 *
 * Flow: File select → Column detect → Preview/Validate → Execute → Results
 */

import React, { useState, useRef } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Box, Typography, Button, IconButton, Chip, Paper,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Alert, AlertTitle, LinearProgress, Divider, Tooltip,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import DownloadIcon from '@mui/icons-material/Download';
import DescriptionIcon from '@mui/icons-material/Description';
import { useQueryClient } from '@tanstack/react-query';
import { api } from '../api/client';
import { readFile, parseImportData, generateSampleCSV, ImportPreview } from '../utils/importParser';
import { stripHtmlToText, escapeHtml } from '../utils/htmlText';

interface ImportUploadDialogProps {
  open: boolean;
  onClose: () => void;
  currentUserId: number;
  spaceId?: number | null;
}

type Step = 'upload' | 'preview' | 'executing' | 'result';

interface ImportResult {
  createdProjects: number;
  createdTasks: number;
  createdWorkNotes: number;        // 텍스트 + 체크리스트 item 총합
  createdTextNotes: number;
  createdChecklistNotes: number;   // 체크리스트 item 수
  checklistChecked: number;
  checklistUnchecked: number;
  skippedRows: number;
  warningCount: number;
  errors: string[];
}

/**
 * CSV 작업노트 셀을 작업노트 블록(HTML) 내용으로 변환.
 * - 셀에 <div>/<br>/&nbsp; 등이 섞여 있어도 plain text 로 정리(stripHtmlToText)
 * - 다시 안전하게 escape 후 줄바꿈을 <br> 로 — 작업노트 블록은 HTML 로 렌더링되므로
 */
const buildWorkNoteHtml = (raw: string): string => {
  const text = stripHtmlToText(raw);
  if (!text.trim()) return '';
  return escapeHtml(text).replace(/\n/g, '<br>');
};

// 작업노트 유형 표시용
const NOTE_TYPE_META: Record<string, { label: string; color: string }> = {
  text: { label: '텍스트', color: '#6B7280' },
  checklist: { label: '체크리스트', color: '#0EA5E9' },
};

const statusLabels: Record<string, { label: string; color: string }> = {
  todo: { label: 'To Do', color: '#6B7280' },
  in_progress: { label: 'In Progress', color: '#2955FF' },
  done: { label: 'Done', color: '#22C55E' },
  hold: { label: 'Hold', color: '#F59E0B' },
};

// 처리 유형 chip 표시용 라벨/색상
const ROW_TYPE_META: Record<string, { label: string; color: string }> = {
  NEW_PROJECT: { label: '새 프로젝트', color: '#2955FF' },
  NEW_TASK: { label: '새 태스크', color: '#7C3AED' },
  ADD_NOTE_TO_EXISTING_TASK: { label: '노트 추가', color: '#0EA5E9' },
  SKIP_EMPTY_ROW: { label: '빈 행', color: '#9CA3AF' },
  WARNING_ONLY: { label: '경고', color: '#F59E0B' },
  ERROR_ROW: { label: '오류', color: '#EF4444' },
};

const ImportUploadDialog: React.FC<ImportUploadDialogProps> = ({ open, onClose, currentUserId, spaceId }) => {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [step, setStep] = useState<Step>('upload');
  const [fileName, setFileName] = useState('');
  const [preview, setPreview] = useState<ImportPreview | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [progress, setProgress] = useState(0);
  const [fileError, setFileError] = useState('');

  const handleReset = () => {
    setStep('upload');
    setFileName('');
    setPreview(null);
    setResult(null);
    setProgress(0);
    setFileError('');
  };

  const handleClose = () => {
    handleReset();
    onClose();
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileError('');
    setFileName(file.name);

    try {
      const { headers, data } = await readFile(file);
      const parsed = parseImportData(headers, data);
      setPreview(parsed);
      setStep('preview');
    } catch (err: any) {
      setFileError(err.message || '파일을 읽을 수 없습니다.');
    }
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleExecute = async () => {
    if (!preview) return;
    setStep('executing');
    setProgress(0);

    // 처리 대상: 빈 행/에러 행 제외. (carry-forward 후 project/task 가 채워진 행)
    const actionableRows = preview.rows.filter(
      r => r.rowType !== 'SKIP_EMPTY_ROW' && r.rowType !== 'ERROR_ROW'
    );
    const projectMap = new Map<string, number>();   // projectName → projectId
    const taskMap = new Map<string, number>();       // `${projectId} ${task}` → taskId
    const errors: string[] = [];
    let createdProjects = 0;
    let createdTasks = 0;
    let createdTextNotes = 0;
    let createdChecklistNotes = 0;
    let checklistChecked = 0;
    let checklistUnchecked = 0;

    const total = actionableRows.length || 1;

    for (let i = 0; i < actionableRows.length; i++) {
      const row = actionableRows[i];
      setProgress(Math.round(((i + 1) / total) * 100));

      try {
        // 프로젝트 확보 (carry-forward 로 같은 이름이 반복돼도 1회만 생성)
        if (!projectMap.has(row.project)) {
          const project = await api.createProject({
            name: row.project,
            owner_id: currentUserId,
            space_id: spaceId || undefined,
          }, { suppressRealtime: true });
          projectMap.set(row.project, project.id);
          createdProjects++;
        }
        const projectId = projectMap.get(row.project)!;

        // Task 확보 (동일 Project + 동일 Task = 중복 생성 금지 → 첫 행에서만 생성)
        const taskKey = `${projectId} ${row.task}`;
        if (!taskMap.has(taskKey)) {
          const task = await api.createTask({
            title: row.task,
            project_id: projectId,
            status: row.normalizedStatus as any,
            start_date: row.startDate || undefined,
            due_date: row.endDate || undefined,
            assignee_ids: currentUserId > 0 ? [currentUserId] : [],
            priority: 'medium',
          }, { suppressRealtime: true });
          taskMap.set(taskKey, task.id);
          createdTasks++;
        }
        const taskId = taskMap.get(taskKey)!;

        // 작업노트 생성 — 기존 TaskActivity 구조 재사용(별도 import 전용 구조 없음).
        //  - checklist: 각 item 을 block_type='checkbox' 로 생성(checked 는 행 status 기준)
        //  - text: 기존처럼 block_type='text' 로 생성(연속행 meta 포함 noteText)
        if (row.noteType === 'checklist' && row.checklistItems.length > 0) {
          for (const item of row.checklistItems) {
            const itemHtml = buildWorkNoteHtml(item);
            if (!itemHtml) continue;
            try {
              await api.createTaskActivity(taskId, {
                content: itemHtml,
                block_type: 'checkbox',
                checked: row.checklistChecked,
              });
              createdChecklistNotes++;
              if (row.checklistChecked) checklistChecked++;
              else checklistUnchecked++;
            } catch (noteErr: any) {
              errors.push(`${row.rowNumber}행: 체크리스트 작업노트 생성 실패 - ${noteErr?.message || '알 수 없는 오류'}`);
            }
          }
        } else if (row.noteText && row.noteText.trim()) {
          const noteHtml = buildWorkNoteHtml(row.noteText);
          if (noteHtml) {
            try {
              await api.createTaskActivity(taskId, { content: noteHtml, block_type: 'text' });
              createdTextNotes++;
            } catch (noteErr: any) {
              errors.push(`${row.rowNumber}행: 작업노트 생성 실패 - ${noteErr?.message || '알 수 없는 오류'}`);
            }
          }
        }
      } catch (err: any) {
        errors.push(`${row.rowNumber}행: 생성 실패 - ${err.message || '알 수 없는 오류'}`);
      }
    }

    const skippedRows = preview.skipCount + preview.errorCount;

    setResult({
      createdProjects,
      createdTasks,
      createdWorkNotes: createdTextNotes + createdChecklistNotes,
      createdTextNotes,
      createdChecklistNotes,
      checklistChecked,
      checklistUnchecked,
      skippedRows,
      warningCount: preview.warningCount,
      errors,
    });
    setStep('result');

    // 다른 사용자 화면 동기화: 개별 이벤트 대신 bulk event 1개만 발행한다.
    // 실제로 생성된 게 있을 때만(부분 성공 포함, 최종 성공 개수 기준), 실패만 발생했으면 발행하지 않음.
    if (spaceId && (createdProjects > 0 || createdTasks > 0)) {
      try {
        await api.emitRealtimeBulkEvent(spaceId, currentUserId, {
          event_type: 'space_bulk_changed',
          summary: {
            projects_created: createdProjects,
            tasks_created: createdTasks,
            notes_created: createdTextNotes + createdChecklistNotes,
            text_notes_created: createdTextNotes,
            checklist_notes_created: createdChecklistNotes,
          },
        });
      } catch {
        /* bulk event 발행 실패는 화면/결과에 영향 주지 않음 (다른 사용자는 다음 변경 때 갱신됨) */
      }
    }

    // 본인 화면 즉시 갱신 (기존 동작 유지)
    queryClient.invalidateQueries({ queryKey: ['projects'] });
    queryClient.invalidateQueries({ queryKey: ['stats'] });
    queryClient.invalidateQueries({ queryKey: ['tasks'] });
    queryClient.invalidateQueries({ queryKey: ['activities'] });
  };

  const handleDownloadSample = () => {
    const csv = generateSampleCSV();
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'import_sample.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const allWarnings = preview?.rows.flatMap(r => r.warnings) || [];
  const allErrors = preview?.rows.flatMap(r => r.errors) || [];

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth PaperProps={{ sx: { borderRadius: 3, maxHeight: '85vh' } }}>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', pb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <CloudUploadIcon sx={{ color: '#2955FF', fontSize: 22 }} />
          <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem' }}>
            파일에서 가져오기
          </Typography>
        </Box>
        <IconButton size="small" onClick={handleClose}><CloseIcon sx={{ fontSize: 20 }} /></IconButton>
      </DialogTitle>

      <DialogContent sx={{ pt: 1 }}>
        {/* ── Step 1: Upload ── */}
        {step === 'upload' && (
          <Box>
            {/* Upload area */}
            <Paper
              onClick={() => fileInputRef.current?.click()}
              sx={{
                p: 4, textAlign: 'center', borderRadius: 3,
                border: '2px dashed #C7D2FE', bgcolor: '#FAFBFF',
                cursor: 'pointer', transition: 'all 0.2s',
                '&:hover': { borderColor: '#2955FF', bgcolor: '#EEF2FF' },
                mb: 3,
              }}
              elevation={0}
            >
              <CloudUploadIcon sx={{ fontSize: 40, color: '#2955FF', mb: 1, opacity: 0.7 }} />
              <Typography variant="body1" sx={{ fontWeight: 600, color: '#374151', mb: 0.5 }}>
                CSV 또는 XLSX 파일을 선택하세요
              </Typography>
              <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
                클릭하여 파일 선택
              </Typography>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls"
                style={{ display: 'none' }}
                onChange={handleFileSelect}
              />
            </Paper>

            {fileError && (
              <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>{fileError}</Alert>
            )}

            {/* Column rules guide */}
            <Paper sx={{ p: 2.5, borderRadius: 2, border: '1px solid rgba(0,0,0,0.06)', bgcolor: 'rgba(255,255,255,0.8)' }} elevation={0}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, fontSize: '0.85rem', mb: 1.5, color: '#1A1D29' }}>
                컬럼 인식 규칙
              </Typography>
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5, mb: 2 }}>
                {[
                  { label: 'Project (필수)', desc: 'project, 프로젝트', color: '#2955FF' },
                  { label: 'Task (필수)', desc: 'task, 업무, 작업, 태스크', color: '#7C3AED' },
                  { label: 'Schedule', desc: 'schedule, 일정', color: '#059669' },
                  { label: 'Status', desc: 'status, 상태', color: '#EA580C' },
                  { label: '작업노트', desc: '작업노트, 메모, note, 비고, remark', color: '#0EA5E9' },
                  { label: '체크유무', desc: '체크유무, 체크리스트, checklist, note_type', color: '#0284C7' },
                ].map(item => (
                  <Box key={item.label} sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
                    <Box sx={{ width: 4, height: 4, borderRadius: '50%', bgcolor: item.color, mt: 0.8, flexShrink: 0 }} />
                    <Box>
                      <Typography variant="caption" sx={{ fontWeight: 700, fontSize: '0.72rem', color: item.color }}>{item.label}</Typography>
                      <Typography variant="caption" sx={{ display: 'block', fontSize: '0.65rem', color: '#6B7280' }}>{item.desc}</Typography>
                    </Box>
                  </Box>
                ))}
              </Box>

              <Divider sx={{ my: 1.5 }} />

              <Typography variant="caption" sx={{ fontSize: '0.68rem', color: '#6B7280', lineHeight: 1.8, display: 'block' }}>
                - Project가 빈 칸이면 위 행의 Project를 이어받습니다 (엑셀 병합/빈칸 양식 지원)<br />
                - Task가 빈 칸이면 위 Task를 이어받아 <b>작업노트만 추가</b>됩니다 (새 Task 아님)<br />
                - 같은 Project + 같은 Task는 중복 생성하지 않고 작업노트만 모읍니다<br />
                - <b>Schedule/Status는 Task 단위 값</b>입니다. 각 Task의 <b>첫 작업노트 행</b>에만 입력하고, 같은 Task의 두 번째 작업노트부터는 비워 둡니다<br />
                - status 값: To do, In Progress, Done, Hold, 보류/취소 등 (대소문자 무관)<br />
                - 일정 예시: 3월~10월, 3/10~11/11, 26.3~26.10, 26년3월1일-26년10월20일, ~26.12월<br />
                - 작업노트 컬럼이 있으면 해당 Task에 작업노트가 함께 생성됩니다 (빈 값은 건너뜀)<br />
                - <b>체크유무</b>는 작업노트별 값입니다. O를 입력하면 체크리스트 작업노트로 생성됩니다 (빈칸/X는 일반 텍스트)<br />
                - 체크리스트는 그 <b>Task의 Status가 Done/완료</b>면 체크됨, 그 외(In Progress/To do/빈칸)는 미체크로 생성됩니다
              </Typography>
            </Paper>

            {/* Sample download */}
            <Box sx={{ mt: 2, textAlign: 'center' }}>
              <Button
                size="small"
                startIcon={<DownloadIcon sx={{ fontSize: 16 }} />}
                onClick={handleDownloadSample}
                sx={{ textTransform: 'none', color: '#6B7280', fontSize: '0.78rem', fontWeight: 600 }}
              >
                샘플 CSV 다운로드
              </Button>
            </Box>
          </Box>
        )}

        {/* ── Step 2: Preview ── */}
        {step === 'preview' && preview && (
          <Box>
            {/* File info */}
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
              <DescriptionIcon sx={{ color: '#2955FF', fontSize: 20 }} />
              <Typography variant="body2" sx={{ fontWeight: 600, fontSize: '0.85rem' }}>{fileName}</Typography>
              <Button size="small" onClick={handleReset} sx={{ textTransform: 'none', fontSize: '0.72rem', color: '#9CA3AF' }}>
                다시 선택
              </Button>
            </Box>

            {/* Column detection result */}
            <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
              {(['project', 'task', 'schedule', 'status', 'workNote', 'check'] as const).map(col => {
                const detected = preview.columns[col];
                const colLabel = col === 'workNote' ? '작업노트' : col === 'check' ? '체크유무' : col;
                return (
                  <Chip
                    key={col}
                    icon={detected ? <CheckCircleIcon sx={{ fontSize: '0.8rem !important' }} /> : <ErrorOutlineIcon sx={{ fontSize: '0.8rem !important' }} />}
                    label={`${colLabel}: ${detected || '미감지'}`}
                    size="small"
                    sx={{
                      height: 24, fontSize: '0.68rem', fontWeight: 600,
                      bgcolor: detected ? '#F0FDF4' : '#FEF2F2',
                      color: detected ? '#16A34A' : '#DC2626',
                      border: `1px solid ${detected ? '#BBF7D0' : '#FECACA'}`,
                      '& .MuiChip-icon': { color: detected ? '#16A34A' : '#DC2626' },
                    }}
                  />
                );
              })}
            </Box>

            {/* Column errors */}
            {preview.columnErrors.length > 0 && (
              <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>
                <AlertTitle sx={{ fontSize: '0.82rem', fontWeight: 700 }}>필수 컬럼 누락</AlertTitle>
                {preview.columnErrors.map((e, i) => (
                  <Typography key={i} variant="caption" sx={{ display: 'block', fontSize: '0.72rem' }}>{e}</Typography>
                ))}
              </Alert>
            )}

            {/* Summary stats */}
            <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
              {[
                { label: '프로젝트', value: preview.projectCount, color: '#2955FF' },
                { label: '태스크', value: preview.taskCount, color: '#22C55E' },
                { label: '텍스트노트', value: preview.textNoteCount, color: '#6B7280' },
                { label: '체크리스트', value: preview.checklistNoteCount, color: '#0EA5E9' },
                { label: '건너뜀', value: preview.skipCount, color: '#9CA3AF' },
                { label: '오류', value: preview.errorCount, color: '#EF4444' },
                { label: '경고', value: preview.warningCount, color: '#F59E0B' },
              ].map(s => (
                <Box key={s.label} sx={{ textAlign: 'center' }}>
                  <Typography variant="h6" sx={{ fontWeight: 800, color: s.color, fontSize: '1.2rem' }}>{s.value}</Typography>
                  <Typography variant="caption" sx={{ fontSize: '0.6rem', color: '#6B7280' }}>{s.label}</Typography>
                </Box>
              ))}
            </Box>

            {/* Warnings */}
            {allWarnings.length > 0 && (
              <Alert severity="warning" icon={<WarningAmberIcon sx={{ fontSize: 18 }} />} sx={{ mb: 2, borderRadius: 2 }}>
                <AlertTitle sx={{ fontSize: '0.78rem', fontWeight: 700 }}>경고 ({allWarnings.length}건)</AlertTitle>
                <Box sx={{ maxHeight: 100, overflowY: 'auto' }}>
                  {allWarnings.map((w, i) => (
                    <Typography key={i} variant="caption" sx={{ display: 'block', fontSize: '0.68rem', lineHeight: 1.6 }}>{w}</Typography>
                  ))}
                </Box>
              </Alert>
            )}

            {/* Errors */}
            {allErrors.length > 0 && (
              <Alert severity="error" icon={<ErrorOutlineIcon sx={{ fontSize: 18 }} />} sx={{ mb: 2, borderRadius: 2 }}>
                <AlertTitle sx={{ fontSize: '0.78rem', fontWeight: 700 }}>스킵 예정 ({allErrors.length}건)</AlertTitle>
                <Box sx={{ maxHeight: 100, overflowY: 'auto' }}>
                  {allErrors.map((e, i) => (
                    <Typography key={i} variant="caption" sx={{ display: 'block', fontSize: '0.68rem', lineHeight: 1.6 }}>{e}</Typography>
                  ))}
                </Box>
              </Alert>
            )}

            {/* Preview table */}
            <TableContainer component={Paper} elevation={0} sx={{ border: '1px solid rgba(0,0,0,0.08)', borderRadius: 2, maxHeight: 280 }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB', width: 36 }}>#</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB', width: 84 }}>처리</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB' }}>Project</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB' }}>Task</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB' }}>Schedule</TableCell>
                    <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB' }}>Status</TableCell>
                    {preview.columns.workNote && (
                      <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB' }}>작업노트</TableCell>
                    )}
                    {preview.columns.check && (
                      <>
                        <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB', width: 76 }}>유형</TableCell>
                        <TableCell sx={{ fontWeight: 700, fontSize: '0.7rem', bgcolor: '#F9FAFB', width: 64 }}>체크</TableCell>
                      </>
                    )}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {preview.rows.map(row => {
                    const isError = row.rowType === 'ERROR_ROW';
                    const isSkip = row.rowType === 'SKIP_EMPTY_ROW';
                    const hasWarning = row.warnings.length > 0;
                    const rt = ROW_TYPE_META[row.rowType] || ROW_TYPE_META.WARNING_ONLY;
                    const sl = statusLabels[row.normalizedStatus] || statusLabels.todo;
                    const scheduleText = row.startDate && row.endDate
                      ? `${row.startDate} ~ ${row.endDate}`
                      : row.endDate
                        ? `~ ${row.endDate}`
                        : (row.schedule || '-');
                    return (
                      <TableRow
                        key={row.rowNumber}
                        sx={{
                          bgcolor: isError ? 'rgba(239,68,68,0.05)'
                            : isSkip ? 'rgba(0,0,0,0.02)'
                            : hasWarning ? 'rgba(245,158,11,0.04)' : 'transparent',
                          opacity: isSkip ? 0.6 : 1,
                        }}
                      >
                        <TableCell sx={{ fontSize: '0.68rem', color: '#9CA3AF' }}>{row.rowNumber}</TableCell>
                        <TableCell>
                          <Tooltip title={[...row.errors, ...row.warnings].join('\n') || rt.label}>
                            <Chip label={rt.label} size="small" sx={{ height: 18, fontSize: '0.56rem', fontWeight: 700, bgcolor: `${rt.color}15`, color: rt.color }} />
                          </Tooltip>
                        </TableCell>
                        <TableCell sx={{ fontSize: '0.72rem', fontWeight: 600 }}>{row.project || '-'}</TableCell>
                        <TableCell sx={{ fontSize: '0.72rem' }}>{row.task || '-'}</TableCell>
                        <TableCell sx={{ fontSize: '0.68rem', color: row.scheduleParseFailed ? '#DC2626' : '#6B7280' }}>
                          <Tooltip title={row.schedule || ''}>
                            <span>{scheduleText}</span>
                          </Tooltip>
                        </TableCell>
                        <TableCell>
                          {isSkip || isError ? (
                            <Typography sx={{ fontSize: '0.62rem', color: '#9CA3AF' }}>-</Typography>
                          ) : row.isNewTask ? (
                            <Chip
                              label={row.statusRecognized ? sl.label : `${row.status || '?'} → To Do`}
                              size="small"
                              sx={{ height: 18, fontSize: '0.58rem', fontWeight: 600, bgcolor: `${sl.color}15`, color: row.statusRecognized ? sl.color : '#B45309' }}
                            />
                          ) : (
                            <Tooltip title="연속행 — 상태는 작업노트에 보존됩니다">
                              <Typography sx={{ fontSize: '0.62rem', color: '#9CA3AF' }}>{row.status || '-'}</Typography>
                            </Tooltip>
                          )}
                        </TableCell>
                        {preview.columns.workNote && (() => {
                          const noteDisplay = row.noteType === 'checklist'
                            ? row.checklistItems.join(' · ')
                            : row.noteText;
                          return (
                            <TableCell sx={{ fontSize: '0.68rem', color: '#6B7280', maxWidth: 200 }}>
                              {noteDisplay ? (
                                <Tooltip title={row.noteType === 'checklist' ? row.checklistItems.map(i => `☐ ${i}`).join('\n') : row.noteText}>
                                  <Box sx={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 190 }}>
                                    {noteDisplay.replace(/\n/g, ' ')}
                                  </Box>
                                </Tooltip>
                              ) : '-'}
                            </TableCell>
                          );
                        })()}
                        {preview.columns.check && (() => {
                          const hasNoteForType = row.noteType === 'checklist'
                            ? row.checklistItems.length > 0
                            : !!row.noteText;
                          const nt = NOTE_TYPE_META[row.noteType] || NOTE_TYPE_META.text;
                          return (
                            <>
                              <TableCell>
                                {isSkip || isError || !hasNoteForType ? (
                                  <Typography sx={{ fontSize: '0.62rem', color: '#9CA3AF' }}>-</Typography>
                                ) : (
                                  <Tooltip title={row.checkRaw ? `체크유무 원본값: ${row.checkRaw}` : '체크유무 빈칸'}>
                                    <Chip label={nt.label} size="small" sx={{ height: 18, fontSize: '0.56rem', fontWeight: 700, bgcolor: `${nt.color}15`, color: nt.color }} />
                                  </Tooltip>
                                )}
                              </TableCell>
                              <TableCell>
                                {row.noteType === 'checklist' && hasNoteForType ? (
                                  <Typography sx={{ fontSize: '0.62rem', fontWeight: 700, color: row.checklistChecked ? '#16A34A' : '#9CA3AF' }}>
                                    {row.checklistChecked ? '✔ 체크' : '미체크'}
                                  </Typography>
                                ) : (
                                  <Typography sx={{ fontSize: '0.62rem', color: '#D1D5DB' }}>-</Typography>
                                )}
                              </TableCell>
                            </>
                          );
                        })()}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        )}

        {/* ── Step 3: Executing ── */}
        {step === 'executing' && (
          <Box sx={{ py: 6, textAlign: 'center' }}>
            <Typography variant="body1" sx={{ fontWeight: 600, mb: 2 }}>
              프로젝트와 태스크를 생성하고 있습니다...
            </Typography>
            <LinearProgress
              variant="determinate"
              value={progress}
              sx={{
                height: 8, borderRadius: 4, maxWidth: 400, mx: 'auto',
                bgcolor: '#E5E7EB',
                '& .MuiLinearProgress-bar': { bgcolor: '#2955FF', borderRadius: 4 },
              }}
            />
            <Typography variant="caption" sx={{ mt: 1, display: 'block', color: '#6B7280' }}>
              {progress}%
            </Typography>
          </Box>
        )}

        {/* ── Step 4: Result ── */}
        {step === 'result' && result && (
          <Box sx={{ py: 2 }}>
            <Box sx={{ textAlign: 'center', mb: 3 }}>
              <CheckCircleIcon sx={{ fontSize: 48, color: '#22C55E', mb: 1 }} />
              <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1.1rem' }}>
                가져오기 완료
              </Typography>
            </Box>

            <Box sx={{ display: 'flex', gap: 3, justifyContent: 'center', mb: 2, flexWrap: 'wrap' }}>
              {[
                { label: '생성된 프로젝트', value: result.createdProjects, color: '#2955FF' },
                { label: '생성된 태스크', value: result.createdTasks, color: '#22C55E' },
                { label: '텍스트 작업노트', value: result.createdTextNotes, color: '#6B7280' },
                { label: '체크리스트 작업노트', value: result.createdChecklistNotes, color: '#0EA5E9' },
                { label: '건너뜀', value: result.skippedRows, color: '#9CA3AF' },
                { label: '경고', value: result.warningCount, color: '#F59E0B' },
              ].map(s => (
                <Box key={s.label} sx={{ textAlign: 'center' }}>
                  <Typography variant="h5" sx={{ fontWeight: 800, color: s.color }}>{s.value}</Typography>
                  <Typography variant="caption" sx={{ fontSize: '0.68rem', color: '#6B7280' }}>{s.label}</Typography>
                </Box>
              ))}
            </Box>

            {/* 체크리스트 체크됨/미체크 분해 */}
            {result.createdChecklistNotes > 0 && (
              <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', mb: 3 }}>
                <Chip
                  label={`체크됨 ${result.checklistChecked}개`}
                  size="small"
                  sx={{ height: 22, fontSize: '0.68rem', fontWeight: 700, bgcolor: '#DCFCE7', color: '#16A34A' }}
                />
                <Chip
                  label={`미체크 ${result.checklistUnchecked}개`}
                  size="small"
                  sx={{ height: 22, fontSize: '0.68rem', fontWeight: 700, bgcolor: '#F3F4F6', color: '#6B7280' }}
                />
              </Box>
            )}

            {result.errors.length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 2 }}>
                <AlertTitle sx={{ fontSize: '0.82rem', fontWeight: 700 }}>오류 목록</AlertTitle>
                {result.errors.map((e, i) => (
                  <Typography key={i} variant="caption" sx={{ display: 'block', fontSize: '0.68rem' }}>{e}</Typography>
                ))}
              </Alert>
            )}
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        {step === 'upload' && (
          <Button onClick={handleClose} sx={{ textTransform: 'none', color: '#6B7280' }}>닫기</Button>
        )}
        {step === 'preview' && (
          <>
            <Button onClick={handleReset} sx={{ textTransform: 'none', color: '#6B7280' }}>취소</Button>
            <Button
              variant="contained"
              onClick={handleExecute}
              disabled={preview!.columnErrors.length > 0 || preview!.taskCount === 0}
              sx={{ textTransform: 'none', bgcolor: '#2955FF', fontWeight: 700 }}
            >
              {preview!.taskCount}개 태스크 생성하기
            </Button>
          </>
        )}
        {step === 'result' && (
          <Button variant="contained" onClick={handleClose} sx={{ textTransform: 'none', bgcolor: '#2955FF' }}>
            확인
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default ImportUploadDialog;
