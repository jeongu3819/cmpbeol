import React, { useState } from 'react';
import {
    Dialog, DialogTitle, DialogContent, DialogActions,
    Button, MenuItem, TextField, Typography, Box, IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useSnackbar } from 'notistack';
import { api } from '../api/client';
import { SubProject } from '../types';
import { planAiColors } from '../theme/tokens';

interface Props {
    open: boolean;
    onClose: () => void;
    taskId: number;
    currentProjectId: number;
    currentProjectName?: string;
    spaceId?: number | null;
    currentUserId: number;
    onMoved?: () => void;
}

const TaskMoveDialog: React.FC<Props> = ({
    open, onClose, taskId, currentProjectId, currentProjectName, spaceId, currentUserId, onMoved,
}) => {
    const queryClient = useQueryClient();
    const { enqueueSnackbar } = useSnackbar();
    const [targetProjectId, setTargetProjectId] = useState<number | ''>('');
    const [targetSubProjectId, setTargetSubProjectId] = useState<number | ''>('');

    // 같은 Space 안의 Project 목록 (현재 프로젝트 제외)
    const { data: projects = [] } = useQuery<any[]>({
        queryKey: ['projects', currentUserId, spaceId],
        queryFn: () => api.getProjects(currentUserId, spaceId ?? undefined),
        enabled: open && !!spaceId,
    });
    const candidateProjects = projects.filter(
        (p: any) => p.id !== currentProjectId && !p.archived_at && !p.is_system,
    );

    // 대상 Project 의 Sub Project 목록
    const { data: targetSubProjects = [] } = useQuery<SubProject[]>({
        queryKey: ['subProjects', targetProjectId],
        queryFn: () => api.getSubProjects(Number(targetProjectId)),
        enabled: open && !!targetProjectId,
    });

    const resetAndClose = () => {
        setTargetProjectId('');
        setTargetSubProjectId('');
        onClose();
    };

    const moveMut = useMutation({
        mutationFn: () => api.moveTask(taskId, Number(targetProjectId), targetSubProjectId === '' ? null : Number(targetSubProjectId)),
        onSuccess: () => {
            enqueueSnackbar('Task를 다른 Project로 이동했습니다.', { variant: 'success' });
            // 이동 전/후 프로젝트 뷰가 모두 갱신되도록 넓게 무효화
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            queryClient.invalidateQueries({ queryKey: ['board'] });
            queryClient.invalidateQueries({ queryKey: ['roadmap'] });
            queryClient.invalidateQueries({ queryKey: ['projects'] });
            resetAndClose();
            onMoved?.();
        },
        onError: (err: any) => {
            enqueueSnackbar(err?.response?.data?.detail || 'Task 이동에 실패했습니다.', { variant: 'error' });
        },
    });

    return (
        <Dialog open={open} onClose={resetAndClose} maxWidth="xs" fullWidth
            PaperProps={{ sx: { borderRadius: 3 } }}>
            <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                Task 이동
                <IconButton size="small" onClick={resetAndClose}><CloseIcon fontSize="small" /></IconButton>
            </DialogTitle>
            <DialogContent>
                <Box sx={{ mb: 2 }}>
                    <Typography sx={{ fontSize: '0.72rem', color: planAiColors.text.muted }}>현재 Project</Typography>
                    <Typography sx={{ fontSize: '0.85rem', fontWeight: 600 }}>{currentProjectName || `#${currentProjectId}`}</Typography>
                </Box>

                <TextField
                    select fullWidth size="small" label="이동할 Project"
                    value={targetProjectId}
                    onChange={(e) => { setTargetProjectId(Number(e.target.value)); setTargetSubProjectId(''); }}
                    sx={{ mb: 2 }}
                >
                    {candidateProjects.length === 0 && (
                        <MenuItem value="" disabled>이동 가능한 Project가 없습니다.</MenuItem>
                    )}
                    {candidateProjects.map((p: any) => (
                        <MenuItem key={p.id} value={p.id}>{p.name}</MenuItem>
                    ))}
                </TextField>

                <TextField
                    select fullWidth size="small" label="이동할 Sub Project (선택)"
                    value={targetSubProjectId}
                    onChange={(e) => setTargetSubProjectId(e.target.value === '' ? '' : Number(e.target.value))}
                    disabled={!targetProjectId}
                >
                    <MenuItem value="">선택 안 함 (Project 직속)</MenuItem>
                    {targetSubProjects.map((sp) => (
                        <MenuItem key={sp.id} value={sp.id}>{sp.name}</MenuItem>
                    ))}
                </TextField>

                <Typography sx={{ fontSize: '0.72rem', color: planAiColors.text.muted, mt: 2 }}>
                    Task를 이동하면 대상 Project의 첫 번째 단계로 배치됩니다. 상위 Task 연결은 해제되며,
                    제목·설명·작업노트·댓글·첨부는 그대로 유지됩니다.
                </Typography>
            </DialogContent>
            <DialogActions sx={{ px: 3, pb: 2 }}>
                <Button onClick={resetAndClose} sx={{ textTransform: 'none', color: planAiColors.text.tertiary }}>
                    취소
                </Button>
                <Button
                    variant="contained"
                    disabled={!targetProjectId || moveMut.isPending}
                    onClick={() => moveMut.mutate()}
                    sx={{ textTransform: 'none', bgcolor: planAiColors.brand.primary }}
                >
                    {moveMut.isPending ? '이동 중…' : '이동'}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default TaskMoveDialog;
