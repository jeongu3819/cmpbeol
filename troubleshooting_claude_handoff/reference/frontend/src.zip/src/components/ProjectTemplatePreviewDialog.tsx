import React, { useState, useEffect, useMemo } from 'react';
import {
  Dialog, Box, Typography, IconButton, Button, Chip, Tabs, Tab,
  Stack, useMediaQuery, useTheme,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import DashboardIcon from '@mui/icons-material/Dashboard';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import EventIcon from '@mui/icons-material/Event';
import HistoryIcon from '@mui/icons-material/History';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import StickyNote2OutlinedIcon from '@mui/icons-material/StickyNote2Outlined';
import type { ProjectTemplate, TemplateTask } from './ZeroStateDashboard';
import { PROJECT_TEMPLATE_PREVIEWS } from './projectTemplatePreviewConfig';

interface Props {
  open: boolean;
  template: ProjectTemplate | null;
  onClose: () => void;
  /** "이 템플릿으로 생성하기" — 기존 생성 플로우로 연결 */
  onSelect: (template: ProjectTemplate) => void;
}

const STATUS_KO: Record<string, { label: string; color: string }> = {
  todo: { label: '예정', color: '#64748B' },
  in_progress: { label: '진행 중', color: '#F59E0B' },
  review: { label: '검토', color: '#7C3AED' },
  done: { label: '완료', color: '#22C55E' },
};

function statusMeta(s: string) {
  return STATUS_KO[s] || { label: s, color: '#64748B' };
}

function fmtDate(s?: string): string {
  if (!s) return '';
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return s;
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/**
 * 프로젝트 템플릿 "생성 전 미리보기" Dialog.
 *
 * 대시보드/Task 구조/일정/Note 는 실제 템플릿 정의 데이터에서 파생(read-only).
 * 주요 기능/마일스톤/이력 예시/AI 요약은 projectTemplatePreviewConfig 의 정적 설명을 사용.
 * 미리보기만으로는 어떤 데이터도 생성되지 않으며, "이 템플릿으로 생성하기"를 눌렀을 때만 onSelect 로 연결된다.
 */
const ProjectTemplatePreviewDialog: React.FC<Props> = ({ open, template, onClose, onSelect }) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
  const [tab, setTab] = useState(0);

  useEffect(() => { setTab(0); }, [template, open]);

  const meta = template ? PROJECT_TEMPLATE_PREVIEWS[template.id] : undefined;

  // ── 실제 템플릿 정의에서 파생 ──
  const derived = useMemo(() => {
    if (!template) return null;
    const tasks = template.defaultTasks || [];
    const total = tasks.length;
    const done = tasks.filter((t) => t.status === 'done').length;
    const inProgress = tasks.filter((t) => t.status === 'in_progress').length;
    const completion = total > 0 ? Math.round((done / total) * 100) : 0;

    const now = new Date();
    const soon = new Date();
    soon.setDate(now.getDate() + 7);
    const dueSoon = tasks.filter((t) => {
      if (!t.due_date || t.status === 'done') return false;
      const d = new Date(t.due_date);
      return !Number.isNaN(d.getTime()) && d >= now && d <= soon;
    }).length;

    let noteCount = 0;
    let checkCount = 0;
    tasks.forEach((t) => {
      (t.activities || []).forEach((a) => {
        if (a.block_type === 'text') noteCount += 1;
        else checkCount += 1;
      });
    });

    // 서브프로젝트별 Task 그룹 (서브 미지정은 '기타')
    const groups = new Map<string, TemplateTask[]>();
    (template.subProjects || []).forEach((sp) => groups.set(sp.name, []));
    tasks.forEach((t) => {
      const key = t.subproject || '기타';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(t);
    });

    // 일정 타임라인 (날짜 있는 Task 정렬)
    const schedule = tasks
      .filter((t) => t.start_date || t.due_date)
      .slice()
      .sort((a, b) => {
        const da = new Date(a.due_date || a.start_date || 0).getTime();
        const db = new Date(b.due_date || b.start_date || 0).getTime();
        return da - db;
      });

    // Note 모음 (text activities)
    const notes: { task: string; content: string }[] = [];
    tasks.forEach((t) => {
      (t.activities || []).forEach((a) => {
        if (a.block_type === 'text') notes.push({ task: t.title, content: a.content });
      });
    });

    return {
      total, done, inProgress, completion, dueSoon, noteCount, checkCount,
      subCount: template.subProjects?.length || 0,
      groups: Array.from(groups.entries()),
      schedule, notes,
    };
  }, [template]);

  if (!template || !derived) return null;
  const accent = template.color;
  const overview = meta?.overview || template.description;

  const statCards = [
    { label: 'Task', value: `${derived.total}개` },
    { label: 'Sub Project', value: `${derived.subCount}개` },
    { label: 'Note', value: `${derived.noteCount}개` },
    { label: '완료율', value: `${derived.completion}%` },
    { label: '마감 임박', value: `${derived.dueSoon}건` },
  ];

  const tabs = [
    { label: '대시보드', icon: <DashboardIcon fontSize="small" /> },
    { label: 'Task 구조', icon: <AccountTreeIcon fontSize="small" /> },
    { label: '일정 · 마일스톤', icon: <EventIcon fontSize="small" /> },
    { label: '이력 · Note', icon: <HistoryIcon fontSize="small" /> },
    { label: 'AI 요약', icon: <AutoAwesomeIcon fontSize="small" /> },
  ];
  const currentLabel = tabs[tab]?.label;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="lg"
      fullWidth
      fullScreen={fullScreen}
      PaperProps={{ sx: { borderRadius: fullScreen ? 0 : 3, minHeight: fullScreen ? '100%' : '72vh' } }}
    >
      {/* Header */}
      <Box sx={{ p: 2.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, minWidth: 0 }}>
          <Box sx={{ width: 40, height: 40, borderRadius: 2, bgcolor: `${accent}14`, color: accent, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            {React.cloneElement(template.icon as React.ReactElement, { sx: { fontSize: 22 } })}
          </Box>
          <Box sx={{ minWidth: 0 }}>
            <Stack direction="row" spacing={1} alignItems="center">
              <Typography variant="h6" sx={{ fontWeight: 800, lineHeight: 1.2 }} noWrap>
                {template.name} 미리보기
              </Typography>
              <Chip label={template.category} size="small" sx={{ height: 18, fontSize: 11, fontWeight: 600, bgcolor: '#F3F4F6', color: '#6B7280' }} />
            </Stack>
            <Typography variant="caption" color="text.secondary">
              샘플 화면입니다. 실제 데이터는 생성되지 않습니다.
            </Typography>
          </Box>
        </Box>
        <IconButton size="small" onClick={onClose}><CloseIcon /></IconButton>
      </Box>

      <Box sx={{ p: { xs: 2, md: 3 }, flex: 1, overflowY: 'auto' }}>
        {/* 상단 요약 */}
        <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>{overview}</Typography>
        {meta && (
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 2.5 }}>
            {meta.features.map((f) => (
              <Chip key={f} label={f} size="small" sx={{ bgcolor: `${accent}14`, color: accent, fontWeight: 600 }} />
            ))}
          </Stack>
        )}

        {/* 핵심 요약 카드 */}
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: 'repeat(2, 1fr)', md: 'repeat(5, 1fr)' }, gap: 1.5, mb: 1.5 }}>
          {statCards.map((s) => (
            <Box key={s.label} sx={{ p: 1.5, borderRadius: 2, border: '1px solid', borderColor: 'divider', bgcolor: 'background.paper' }}>
              <Typography variant="caption" color="text.secondary">{s.label}</Typography>
              <Typography variant="h6" sx={{ fontWeight: 800, color: accent }}>{s.value}</Typography>
            </Box>
          ))}
        </Box>
        {meta && (
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2.5 }}>
            추천 용도: {meta.recommendedFor}
          </Typography>
        )}

        {/* 상세 Preview 탭 */}
        <Box sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 2, overflow: 'hidden' }}>
          <Tabs
            value={tab}
            onChange={(_, v) => setTab(v)}
            variant="scrollable"
            scrollButtons="auto"
            sx={{ borderBottom: '1px solid', borderColor: 'divider', minHeight: 44, '& .MuiTab-root': { minHeight: 44, textTransform: 'none', fontWeight: 600 }, '& .Mui-selected': { color: `${accent} !important` }, '& .MuiTabs-indicator': { bgcolor: accent } }}
          >
            {tabs.map((t) => <Tab key={t.label} icon={t.icon} iconPosition="start" label={t.label} />)}
          </Tabs>

          <Box sx={{ p: { xs: 1.5, md: 2.5 }, minHeight: 260 }}>
            {/* 대시보드 */}
            {currentLabel === '대시보드' && (
              <Stack spacing={2}>
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>진행 현황</Typography>
                  <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                    <Chip label={`진행 중 ${derived.inProgress}`} size="small" sx={{ bgcolor: '#FEF3C7', color: '#B45309', fontWeight: 700 }} />
                    <Chip label={`완료 ${derived.done}`} size="small" sx={{ bgcolor: '#DCFCE7', color: '#15803D', fontWeight: 700 }} />
                    <Chip label={`예정 ${derived.total - derived.done - derived.inProgress}`} size="small" sx={{ bgcolor: '#F1F5F9', color: '#475569', fontWeight: 700 }} />
                    <Chip label={`마감 임박 ${derived.dueSoon}`} size="small" sx={{ bgcolor: '#FEE2E2', color: '#B91C1C', fontWeight: 700 }} />
                  </Stack>
                </Box>
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>최근/주요 Task</Typography>
                  <Stack spacing={0.8}>
                    {template.defaultTasks.slice(0, 6).map((t, i) => {
                      const sm = statusMeta(t.status);
                      return (
                        <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                          <Chip label={sm.label} size="small" sx={{ width: 64, height: 20, fontSize: 11, fontWeight: 700, color: sm.color, bgcolor: `${sm.color}1A` }} />
                          <Typography variant="body2" sx={{ flex: 1, minWidth: 0 }} noWrap>{t.title}</Typography>
                          {t.due_date && <Typography variant="caption" color="text.secondary">{fmtDate(t.due_date)}</Typography>}
                        </Box>
                      );
                    })}
                  </Stack>
                </Box>
                {meta && (
                  <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: `${accent}0A`, border: '1px solid', borderColor: `${accent}33` }}>
                    <Stack direction="row" spacing={0.8} alignItems="center" sx={{ mb: 0.5 }}>
                      <AutoAwesomeIcon fontSize="small" sx={{ color: accent }} />
                      <Typography variant="caption" sx={{ fontWeight: 700, color: accent }}>AI 요약 (예시)</Typography>
                    </Stack>
                    <Typography variant="body2" color="text.secondary">{meta.aiSummaryExample}</Typography>
                  </Box>
                )}
              </Stack>
            )}

            {/* Task 구조 */}
            {currentLabel === 'Task 구조' && (
              <Stack spacing={2}>
                {derived.groups.map(([groupName, groupTasks]) => (
                  <Box key={groupName}>
                    <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.8 }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: accent }} />
                      <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{groupName}</Typography>
                      <Typography variant="caption" color="text.secondary">{groupTasks.length}개 Task</Typography>
                    </Stack>
                    <Stack spacing={1} sx={{ pl: 1.5, borderLeft: '2px solid', borderColor: 'divider' }}>
                      {groupTasks.map((t, i) => {
                        const sm = statusMeta(t.status);
                        const checks = (t.activities || []).filter((a) => a.block_type !== 'text');
                        const tnotes = (t.activities || []).filter((a) => a.block_type === 'text');
                        return (
                          <Box key={i}>
                            <Stack direction="row" spacing={1} alignItems="center">
                              <Chip label={sm.label} size="small" sx={{ width: 58, height: 18, fontSize: 10, fontWeight: 700, color: sm.color, bgcolor: `${sm.color}1A` }} />
                              <Typography variant="body2" sx={{ fontWeight: 600 }}>{t.title}</Typography>
                              {t.priority === 'high' && <Chip label="High" size="small" sx={{ height: 16, fontSize: 9, bgcolor: '#FEF2F2', color: '#EF4444' }} />}
                            </Stack>
                            {checks.map((a, j) => (
                              <Stack key={`c${j}`} direction="row" spacing={0.8} alignItems="center" sx={{ pl: 1, mt: 0.3 }}>
                                {a.checked
                                  ? <CheckCircleIcon sx={{ fontSize: 15, color: '#22C55E' }} />
                                  : <RadioButtonUncheckedIcon sx={{ fontSize: 15, color: 'text.disabled' }} />}
                                <Typography variant="caption" sx={{ color: a.checked ? 'text.secondary' : 'text.primary', textDecoration: a.checked ? 'line-through' : 'none' }}>
                                  {a.content}
                                </Typography>
                              </Stack>
                            ))}
                            {tnotes.map((a, j) => (
                              <Stack key={`n${j}`} direction="row" spacing={0.8} alignItems="flex-start" sx={{ pl: 1, mt: 0.3 }}>
                                <StickyNote2OutlinedIcon sx={{ fontSize: 14, color: '#9CA3AF', mt: 0.2 }} />
                                <Typography variant="caption" color="text.secondary">{a.content}</Typography>
                              </Stack>
                            ))}
                          </Box>
                        );
                      })}
                    </Stack>
                  </Box>
                ))}
              </Stack>
            )}

            {/* 일정 · 마일스톤 */}
            {currentLabel === '일정 · 마일스톤' && (
              <Stack spacing={2.5}>
                {meta && (
                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>업무 흐름 (마일스톤)</Typography>
                    <Stack spacing={1}>
                      {meta.milestones.map((m, i) => (
                        <Stack key={i} direction="row" spacing={1.2} alignItems="flex-start">
                          <Box sx={{ width: 22, height: 22, borderRadius: '50%', bgcolor: `${accent}1A`, color: accent, fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{i + 1}</Box>
                          <Box>
                            <Typography variant="body2" sx={{ fontWeight: 600 }}>{m.title}</Typography>
                            <Typography variant="caption" color="text.secondary">{m.description}</Typography>
                          </Box>
                        </Stack>
                      ))}
                    </Stack>
                  </Box>
                )}
                {derived.schedule.length > 0 && (
                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>샘플 일정</Typography>
                    <Stack spacing={0.8}>
                      {derived.schedule.map((t, i) => {
                        const sm = statusMeta(t.status);
                        const range = [fmtDate(t.start_date), fmtDate(t.due_date)].filter(Boolean).join(' ~ ');
                        return (
                          <Stack key={i} direction="row" spacing={1.2} alignItems="center">
                            <Typography variant="caption" sx={{ width: 92, color: 'text.secondary', flexShrink: 0 }}>{range || '-'}</Typography>
                            <Box sx={{ width: 7, height: 7, borderRadius: '50%', bgcolor: sm.color, flexShrink: 0 }} />
                            <Typography variant="body2" noWrap>{t.title}</Typography>
                          </Stack>
                        );
                      })}
                    </Stack>
                  </Box>
                )}
              </Stack>
            )}

            {/* 이력 · Note */}
            {currentLabel === '이력 · Note' && (
              <Stack spacing={2.5}>
                {meta && (
                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>남기게 될 기록 예시</Typography>
                    <Stack spacing={0.6}>
                      {meta.historyExamples.map((h, i) => (
                        <Stack key={i} direction="row" spacing={0.8} alignItems="center">
                          <HistoryIcon sx={{ fontSize: 15, color: accent }} />
                          <Typography variant="body2" color="text.secondary">{h}</Typography>
                        </Stack>
                      ))}
                    </Stack>
                  </Box>
                )}
                <Box>
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1 }}>Note 모음 ({derived.notes.length})</Typography>
                  {derived.notes.length === 0 ? (
                    <Typography variant="body2" color="text.secondary">이 템플릿에는 기본 Note 가 없습니다.</Typography>
                  ) : (
                    <Stack spacing={1}>
                      {derived.notes.map((n, i) => (
                        <Box key={i} sx={{ p: 1.2, borderRadius: 1.5, bgcolor: '#FAFBFC', border: '1px solid', borderColor: 'divider' }}>
                          <Typography variant="caption" sx={{ fontWeight: 700, color: accent }}>{n.task}</Typography>
                          <Typography variant="body2" color="text.secondary">{n.content}</Typography>
                        </Box>
                      ))}
                    </Stack>
                  )}
                </Box>
              </Stack>
            )}

            {/* AI 요약 */}
            {currentLabel === 'AI 요약' && (
              <Box sx={{ p: 2, borderRadius: 2, bgcolor: `${accent}0A`, border: '1px solid', borderColor: `${accent}33` }}>
                <Stack direction="row" spacing={0.8} alignItems="center" sx={{ mb: 1 }}>
                  <AutoAwesomeIcon fontSize="small" sx={{ color: accent }} />
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, color: accent }}>AI 프로젝트 요약 (예시)</Typography>
                </Stack>
                <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.7 }}>
                  {meta?.aiSummaryExample || '이 템플릿으로 생성하면 진행 상황을 바탕으로 AI 요약이 제공됩니다.'}
                </Typography>
                <Typography variant="caption" color="text.disabled" sx={{ display: 'block', mt: 1 }}>
                  ※ 실제 AI 호출이 아닌 예시 텍스트입니다.
                </Typography>
              </Box>
            )}
          </Box>
        </Box>
      </Box>

      {/* 하단 CTA */}
      <Box sx={{ p: 2, display: 'flex', gap: 1.5, justifyContent: 'flex-end', borderTop: '1px solid', borderColor: 'divider', bgcolor: 'background.default' }}>
        <Button onClick={onClose} sx={{ color: 'text.secondary', textTransform: 'none' }}>닫기</Button>
        <Button
          variant="contained"
          onClick={() => onSelect(template)}
          sx={{ bgcolor: accent, fontWeight: 700, textTransform: 'none', '&:hover': { bgcolor: accent, filter: 'brightness(0.92)' } }}
        >
          이 템플릿으로 생성하기
        </Button>
      </Box>
    </Dialog>
  );
};

export default ProjectTemplatePreviewDialog;
