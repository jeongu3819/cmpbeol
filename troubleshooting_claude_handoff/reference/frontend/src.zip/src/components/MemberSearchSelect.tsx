import React, { useEffect, useRef, useState } from 'react';
import { Box, Typography, TextField, Chip, Avatar, Button } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import CloseIcon from '@mui/icons-material/Close';
import {
  api,
  MemberCandidate,
  MemberOption,
  candidateToMemberOption,
  memberOptionLabel,
} from '../api/client';

interface Props {
  currentUserId: number;
  selected: MemberOption[];
  onChange: (next: MemberOption[]) => void;
  /** 이미 멤버라서 후보에서 제외할 login_id 목록 (예: 기존 공간 멤버) */
  excludeLoginIds?: string[];
  label?: string;
  placeholder?: string;
  /** 검색 결과 영역 최대 높이 (px) */
  maxResultHeight?: number;
}

const PAGE_SIZE = 50;

/**
 * 공간 생성 / 그룹 생성·수정 등에서 공통으로 쓰는 멤버 검색·선택 컴포넌트.
 * - 사이트 구성원(local) + Knox/사내 디렉토리(knox) 통합 검색
 * - login_id(Knox ID) 직접 조회 지원 (backend 가 ID 패턴이면 직접 조회 우선)
 * - 같은 이름이 많아도 "더보기"로 끝까지 탐색 (pagination)
 * - 선택 상태는 항상 MemberOption[] (object) — 숫자 user_id 가 화면에 노출되지 않음
 */
const MemberSearchSelect: React.FC<Props> = ({
  currentUserId,
  selected,
  onChange,
  excludeLoginIds = [],
  label = '멤버 추가',
  placeholder = '이름 또는 Knox ID로 검색',
  maxResultHeight = 220,
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<MemberCandidate[]>([]);
  const [searching, setSearching] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(1);
  const [hasNext, setHasNext] = useState(false);
  const [total, setTotal] = useState(0);
  const timerRef = useRef<any>(null);

  const excludeSet = new Set(excludeLoginIds.map(x => (x || '').toLowerCase()));
  const selectedLogins = new Set(selected.map(m => (m.login_id || '').toLowerCase()));

  const candidateKey = (c: MemberCandidate): string =>
    c.type === 'user' ? `${c.source}-${c.login_id}` : `group-${c.group_id}`;

  const load = async (q: string, nextPage: number, append: boolean) => {
    if (q.length < 2) {
      setResults([]);
      setHasNext(false);
      setTotal(0);
      return;
    }
    if (append) setLoadingMore(true); else setSearching(true);
    try {
      const { items, pagination } = await api.getGroupMemberCandidatesPaged(q, currentUserId, nextPage, PAGE_SIZE);
      setResults(prev => {
        if (!append) return items;
        const seen = new Set(prev.map(candidateKey));
        return [...prev, ...items.filter(c => !seen.has(candidateKey(c)))];
      });
      setPage(pagination.page);
      setHasNext(pagination.has_next);
      setTotal(pagination.total);
    } catch {
      if (!append) { setResults([]); setTotal(0); }
      setHasNext(false);
    } finally {
      if (append) setLoadingMore(false); else setSearching(false);
    }
  };

  // 디바운스 검색 (page 1)
  useEffect(() => {
    const q = query.trim();
    if (timerRef.current) clearTimeout(timerRef.current);
    if (q.length < 2) {
      setResults([]); setHasNext(false); setTotal(0); setPage(1);
      return;
    }
    setSearching(true);
    timerRef.current = setTimeout(() => { load(q, 1, false); }, 300);
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, currentUserId]);

  const isTaken = (c: MemberCandidate): boolean => {
    if (c.type !== 'user') return true;
    const lid = (c.login_id || '').toLowerCase();
    return selectedLogins.has(lid) || excludeSet.has(lid);
  };

  const addCandidate = (c: MemberCandidate) => {
    const opt = candidateToMemberOption(c);
    if (!opt) return;
    if (selectedLogins.has((opt.login_id || '').toLowerCase())) return;
    onChange([...selected, opt]);
  };

  const removeSelected = (m: MemberOption) => {
    onChange(selected.filter(x => x.login_id.toLowerCase() !== m.login_id.toLowerCase()));
  };

  return (
    <Box>
      <Typography variant="caption" sx={{ fontWeight: 700, color: '#374151', mb: 0.5, display: 'block' }}>
        {label} ({selected.length}명 선택)
      </Typography>
      <TextField
        size="small"
        fullWidth
        placeholder={placeholder}
        value={query}
        onChange={e => setQuery(e.target.value)}
        sx={{ mb: 1 }}
        InputProps={{ endAdornment: <SearchIcon sx={{ fontSize: 18, color: '#9CA3AF' }} /> }}
      />

      {query.trim().length < 2 ? (
        <Box sx={{ border: '1px dashed #E5E7EB', borderRadius: 2, p: 1.5, mb: 1 }}>
          <Typography variant="body2" sx={{ color: '#9CA3AF', fontSize: '0.74rem', textAlign: 'center' }}>
            이름 또는 Knox ID로 검색하세요 (사이트 구성원 + Knox 사내검색).
          </Typography>
          <Typography variant="body2" sx={{ color: '#9CA3AF', fontSize: '0.7rem', textAlign: 'center', mt: 0.3 }}>
            동명이인이 많거나 이름 검색에 안 나오는 사용자는 Knox ID/Login ID로 직접 검색하세요.
          </Typography>
        </Box>
      ) : (
        <Box sx={{ maxHeight: maxResultHeight, overflowY: 'auto', border: '1px solid #E5E7EB', borderRadius: 2, p: 0.5, mb: 1 }}>
          {searching && (
            <Typography sx={{ fontSize: '0.78rem', color: '#9CA3AF', textAlign: 'center', py: 1.5 }}>검색 중...</Typography>
          )}
          {!searching && results.length === 0 && (
            <Box sx={{ py: 1.5, px: 1 }}>
              <Typography sx={{ fontSize: '0.78rem', color: '#9CA3AF', textAlign: 'center' }}>검색 결과가 없습니다</Typography>
              <Typography sx={{ fontSize: '0.7rem', color: '#C4C7D0', textAlign: 'center', mt: 0.3 }}>
                이름으로 검색되지 않는 경우 Knox ID 또는 Login ID로 다시 검색해보세요.
              </Typography>
            </Box>
          )}
          {results.map((c, idx) => {
            if (c.type !== 'user') return null;
            const taken = isTaken(c);
            return (
              <Box
                key={`${candidateKey(c)}-${idx}`}
                onClick={() => !taken && addCandidate(c)}
                sx={{
                  display: 'flex', alignItems: 'center', gap: 1,
                  py: 0.7, px: 1.5, borderRadius: 1.5,
                  cursor: taken ? 'default' : 'pointer',
                  opacity: taken ? 0.5 : 1,
                  '&:hover': taken ? {} : { bgcolor: '#F3F4F6' },
                }}
              >
                <Chip
                  label={c.source === 'site' ? '사이트' : 'Knox'}
                  size="small"
                  sx={{
                    height: 18, fontSize: '0.6rem', fontWeight: 700,
                    bgcolor: c.source === 'site' ? '#EEF2FF' : '#FEF3C7',
                    color: c.source === 'site' ? '#2955FF' : '#92400E',
                  }}
                />
                {c.source === 'site' && (
                  <Avatar sx={{ width: 22, height: 22, fontSize: '0.6rem', bgcolor: c.avatar_color || '#2955FF' }}>
                    {(c.name || '?').charAt(0).toUpperCase()}
                  </Avatar>
                )}
                <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                  <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 500 }}>
                    {c.name}
                    <Typography component="span" sx={{ fontSize: '0.7rem', color: '#9CA3AF', ml: 0.5 }}>
                      ({c.login_id})
                    </Typography>
                  </Typography>
                  {(c.department || c.email) && (
                    <Typography sx={{ fontSize: '0.66rem', color: '#9CA3AF', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {[c.department, c.email].filter(Boolean).join(' · ')}
                    </Typography>
                  )}
                </Box>
                {taken
                  ? <Typography sx={{ fontSize: '0.62rem', color: '#9CA3AF' }}>선택됨</Typography>
                  : <PersonAddIcon sx={{ fontSize: 16, color: c.source === 'site' ? '#22C55E' : '#F59E0B' }} />}
              </Box>
            );
          })}
          {!searching && hasNext && (
            <Box sx={{ textAlign: 'center', py: 0.5 }}>
              <Button
                size="small"
                onClick={() => load(query.trim(), page + 1, true)}
                disabled={loadingMore}
                sx={{ fontSize: '0.72rem', color: '#2955FF', fontWeight: 600 }}
              >
                {loadingMore ? '불러오는 중...' : `더보기 (${results.length}${total ? ` / ${total}+` : ''})`}
              </Button>
            </Box>
          )}
          {!searching && !hasNext && results.length > 0 && total > 0 && (
            <Typography sx={{ fontSize: '0.66rem', color: '#C4C7D0', textAlign: 'center', py: 0.5 }}>
              검색 결과 끝 ({results.length}명)
            </Typography>
          )}
        </Box>
      )}

      {/* 동명이인 안내 */}
      <Typography sx={{ fontSize: '0.66rem', color: '#9CA3AF', mb: 1 }}>
        동명이인이 있을 수 있으므로 Knox ID와 부서를 확인한 뒤 선택해주세요.
      </Typography>

      {/* 선택된 멤버 chips — 항상 name·login_id 로 표시 (숫자 id 노출 금지) */}
      {selected.length > 0 && (
        <Box sx={{ mb: 1 }}>
          <Typography variant="caption" sx={{ fontWeight: 700, color: '#374151', mb: 0.5, display: 'block' }}>
            선택된 멤버
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {selected.map(m => (
              <Chip
                key={m.login_id}
                label={memberOptionLabel(m)}
                size="small"
                deleteIcon={<CloseIcon sx={{ fontSize: 14 }} />}
                onDelete={() => removeSelected(m)}
                sx={{
                  height: 24, fontSize: '0.68rem', fontWeight: 600,
                  bgcolor: m.source === 'knox' ? '#FEF3C7' : '#EEF2FF',
                  color: m.source === 'knox' ? '#92400E' : '#2955FF',
                }}
              />
            ))}
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default MemberSearchSelect;
