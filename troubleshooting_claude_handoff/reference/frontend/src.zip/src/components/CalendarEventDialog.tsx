import React, { useEffect, useState } from 'react';
import {
    Dialog, Box, Typography, TextField, Button, IconButton, MenuItem,
    Divider, Chip,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../api/client';
import type { SpaceMemberInfo } from '../types';
import { useAppStore } from '../stores/useAppStore';
import RichDescriptionEditor from './RichDescriptionEditor';
import ItemHistorySection from './ItemHistorySection';
import { validateInlineImage } from '../utils/uploadValidation';
import { planAiColors } from '../theme/tokens';

const STATUS_OPTIONS = [
    { value: 'planned', label: '예정', color: planAiColors.brand.primary },
    { value: 'in_progress', label: '진행 중', color: planAiColors.status.warning },
    { value: 'done', label: '완료', color: planAiColors.status.success },
    { value: 'canceled', label: '취소', color: planAiColors.text.muted },
];

/**
 * 단순 일정(CalendarEvent) 추가/편집용 가벼운 다이얼로그 (Phase 2).
 * Task 보다 단순하며, 필요 시 "Task로 전환"으로 [시스템] 단발 업무 task 로 만든다.
 */
const CalendarEventDialog: React.FC = () => {
    const {
        isEventDialogOpen, selectedEvent, eventDialogDate, closeEventDialog,
        currentSpaceId, currentUserId, openDrawer,
    } = useAppStore();
    const queryClient = useQueryClient();

    const isEdit = !!selectedEvent;

    const [title, setTitle] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [description, setDescription] = useState('');
    const [status, setStatus] = useState('planned');
    const [assigneeId, setAssigneeId] = useState<number | ''>('');

    // 담당자 후보는 "현재 공간의 멤버"만. 사이트 전체 사용자 목록은 사용하지 않는다.
    const { data: uploadPolicy } = useQuery({
        queryKey: ['uploadPolicy'],
        queryFn: () => api.getUploadPolicy(),
        staleTime: 60 * 60 * 1000,
    });

    const { data: spaceMembers = [] } = useQuery<SpaceMemberInfo[]>({
        queryKey: ['space-members', currentSpaceId],
        queryFn: () => api.getSpaceMembers(currentSpaceId!, currentUserId),
        enabled: isEventDialogOpen && !!currentSpaceId,
    });

    // 기존 데이터 호환: 편집 중인 일정의 담당자가 현재 공간 멤버가 아닌 경우
    // (과거 데이터 등) 드롭다운에 임시 옵션으로 노출해 화면이 깨지지 않게 한다.
    const assigneeIsStale =
        assigneeId !== '' && !spaceMembers.some((m) => m.user_id === assigneeId);

    useEffect(() => {
        if (!isEventDialogOpen) return;
        if (selectedEvent) {
            setTitle(selectedEvent.title || '');
            setStartDate(selectedEvent.start_date || '');
            setEndDate(selectedEvent.end_date || selectedEvent.start_date || '');
            setDescription(selectedEvent.description || '');
            setStatus(selectedEvent.status || 'planned');
            setAssigneeId(selectedEvent.assignee_id ?? '');
        } else {
            const d = eventDialogDate || '';
            setTitle('');
            setStartDate(d);
            setEndDate(d);
            setDescription('');
            setStatus('planned');
            setAssigneeId('');
        }
    }, [isEventDialogOpen, selectedEvent, eventDialogDate]);

    const invalidate = () => {
        queryClient.invalidateQueries({ queryKey: ['calendarEvents'] });
        queryClient.invalidateQueries({ queryKey: ['tasks'] });
        queryClient.invalidateQueries({ queryKey: ['stats'] });
        queryClient.invalidateQueries({ queryKey: ['spaceOverview'] });
    };

    const createMutation = useMutation({
        mutationFn: () => api.createCalendarEvent(currentSpaceId!, currentUserId, {
            title: title.trim(),
            description,
            start_date: startDate || null,
            end_date: endDate || startDate || null,
            status,
            assignee_id: assigneeId === '' ? null : Number(assigneeId),
        }),
        onSuccess: () => { invalidate(); closeEventDialog(); },
    });

    const updateMutation = useMutation({
        mutationFn: () => api.updateCalendarEvent(selectedEvent!.id, currentUserId, {
            title: title.trim(),
            description,
            start_date: startDate || null,
            end_date: endDate || startDate || null,
            status,
            assignee_id: assigneeId === '' ? null : Number(assigneeId),
        }),
        onSuccess: () => { invalidate(); closeEventDialog(); },
    });

    const deleteMutation = useMutation({
        mutationFn: () => api.deleteCalendarEvent(selectedEvent!.id, currentUserId),
        onSuccess: () => { invalidate(); closeEventDialog(); },
    });

    const convertMutation = useMutation({
        mutationFn: () => api.convertEventToTask(selectedEvent!.id, currentUserId),
        onSuccess: (res) => {
            invalidate();
            closeEventDialog();
            // 전환된 task 를 바로 편집할 수 있게 TaskDrawer 열기
            openDrawer(res.task, res.task.project_id);
        },
    });

    const alreadyConverted = !!selectedEvent?.linked_task_id;
    const canSave = !!title.trim() && !!currentSpaceId;
    const busy = createMutation.isPending || updateMutation.isPending ||
        deleteMutation.isPending || convertMutation.isPending;

    const handleSave = () => {
        if (!canSave) return;
        if (isEdit) updateMutation.mutate();
        else createMutation.mutate();
    };

    return (
        <Dialog
            open={isEventDialogOpen}
            onClose={closeEventDialog}
            maxWidth="xs"
            fullWidth
            PaperProps={{ sx: { borderRadius: 3 } }}
        >
            <Box sx={{ p: 2.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <EventAvailableIcon sx={{ color: planAiColors.brand.primary }} />
                    <Typography variant="h6" sx={{ fontWeight: 800, color: planAiColors.text.primary }}>
                        {isEdit ? '일정 편집' : '단발 일정 추가'}
                    </Typography>
                </Box>
                <IconButton size="small" onClick={closeEventDialog}><CloseIcon /></IconButton>
            </Box>
            <Divider />

            <Box sx={{ p: 2.5, display: 'flex', flexDirection: 'column', gap: 2 }}>
                {!currentSpaceId && (
                    <Typography sx={{ color: planAiColors.status.danger, fontSize: '0.8rem' }}>
                        일정은 공간 안에서만 추가할 수 있습니다. 공간을 먼저 선택해주세요.
                    </Typography>
                )}

                <TextField
                    label="제목"
                    fullWidth
                    size="small"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    autoFocus
                    placeholder="예) A설비 점검 예정"
                />

                <Box sx={{ display: 'flex', gap: 2 }}>
                    <TextField
                        label="시작일"
                        type="date"
                        fullWidth
                        size="small"
                        InputLabelProps={{ shrink: true }}
                        value={startDate}
                        onChange={(e) => {
                            setStartDate(e.target.value);
                            if (!endDate || endDate < e.target.value) setEndDate(e.target.value);
                        }}
                    />
                    <TextField
                        label="종료일"
                        type="date"
                        fullWidth
                        size="small"
                        InputLabelProps={{ shrink: true }}
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        inputProps={{ min: startDate || undefined }}
                    />
                </Box>

                <Box sx={{ display: 'flex', gap: 2 }}>
                    <TextField
                        select label="상태" fullWidth size="small"
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                    >
                        {STATUS_OPTIONS.map(o => (
                            <MenuItem key={o.value} value={o.value}>
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                    <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: o.color }} />
                                    {o.label}
                                </Box>
                            </MenuItem>
                        ))}
                    </TextField>
                    <TextField
                        select label="담당자" fullWidth size="small"
                        value={assigneeId}
                        onChange={(e) => setAssigneeId(e.target.value === '' ? '' : Number(e.target.value))}
                        InputLabelProps={{ shrink: true }}
                        SelectProps={{ displayEmpty: true }}
                    >
                        <MenuItem value="">
                            <Typography sx={{ color: planAiColors.text.muted, fontSize: '0.85rem' }}>미지정</Typography>
                        </MenuItem>
                        {spaceMembers.map(m => (
                            <MenuItem key={m.user_id} value={m.user_id}>{m.username}</MenuItem>
                        ))}
                        {assigneeIsStale && (
                            <MenuItem value={assigneeId as number} sx={{ color: planAiColors.status.warning }}>
                                {`사용자 #${assigneeId} (현재 공간 멤버 아님)`}
                            </MenuItem>
                        )}
                    </TextField>
                </Box>

                <Box>
                    <Typography sx={{ fontSize: '0.78rem', color: planAiColors.text.tertiary, mb: 0.5, fontWeight: 600 }}>
                        설명
                    </Typography>
                    <RichDescriptionEditor
                        value={description}
                        onChange={setDescription}
                        uploadImage={async (file) => {
                            const err = validateInlineImage(uploadPolicy?.inline_image, file);
                            if (err) throw new Error(err);
                            const res = await api.uploadSpaceImage(currentSpaceId!, file, currentUserId);
                            return res.url;
                        }}
                        disabled={!currentSpaceId}
                        placeholder="설명을 입력하세요. 이미지는 Ctrl+V 로 붙여넣을 수 있습니다."
                    />
                </Box>

                {isEdit && (
                    alreadyConverted ? (
                        <Chip
                            icon={<TaskAltIcon />}
                            label="이미 Task로 전환됨"
                            size="small"
                            sx={{ alignSelf: 'flex-start', bgcolor: planAiColors.background.surfaceAlt, color: planAiColors.text.tertiary }}
                        />
                    ) : (
                        <Button
                            variant="outlined"
                            size="small"
                            startIcon={<TaskAltIcon />}
                            onClick={() => convertMutation.mutate()}
                            disabled={busy}
                            sx={{ alignSelf: 'flex-start', textTransform: 'none' }}
                        >
                            Task로 전환
                        </Button>
                    )
                )}

                {isEdit && selectedEvent && (
                    <Box sx={{ pt: 1, borderTop: `1px solid ${planAiColors.border.soft}` }}>
                        <ItemHistorySection
                            entityType="calendar_event"
                            entityId={selectedEvent.id}
                            itemName={selectedEvent.title}
                        />
                    </Box>
                )}
            </Box>

            <Divider />
            <Box sx={{ p: 2, display: 'flex', gap: 1.5, bgcolor: planAiColors.background.surfaceAlt }}>
                <Button
                    variant="contained"
                    fullWidth
                    onClick={handleSave}
                    disabled={!canSave || busy}
                    sx={{ py: 1, bgcolor: planAiColors.brand.primary, '&:hover': { bgcolor: planAiColors.brand.primaryHover } }}
                >
                    {isEdit ? '저장' : '추가'}
                </Button>
                {isEdit && (
                    <IconButton
                        onClick={() => deleteMutation.mutate()}
                        disabled={busy}
                        sx={{ border: `1px solid ${planAiColors.status.danger}`, color: planAiColors.status.danger, borderRadius: 2 }}
                    >
                        <DeleteOutlineIcon />
                    </IconButton>
                )}
            </Box>
        </Dialog>
    );
};

export default CalendarEventDialog;
