import React, { useEffect, useRef } from 'react';
import { Box, Typography, Chip, Button, IconButton, Tooltip } from '@mui/material';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import PrecisionManufacturingOutlinedIcon from '@mui/icons-material/PrecisionManufacturingOutlined';
import CloseIcon from '@mui/icons-material/Close';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { api, InternalRecommendation, RecommendationPlacement } from '../api/client';
import { planAiColors, planAiShadows } from '../theme/tokens';

interface Props {
  placement: RecommendationPlacement;
  currentUserId: number;
}

/**
 * 사내 추천 도구 스트립 (Internal Service Recommendations).
 *
 * 노출 정책 (DESIGN_SPEC.md):
 *  - global feature flag(internal_service_recommendations_enabled)가 false면 아무것도 렌더링하지 않음.
 *  - active=false 항목은 서버에서 제외됨.
 *  - 추천 데이터가 없으면 영역 자체를 표시하지 않음.
 *  - API 실패가 Dashboard 전체를 깨지 않도록 react-query 가 에러를 격리하고, 에러 시 null 반환.
 *
 * 광고처럼 보이지 않도록 기존 카드보다 얇고 조용한 slim strip 으로 구성.
 */
const InternalRecommendationStrip: React.FC<Props> = ({ placement, currentUserId }) => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data } = useQuery({
    queryKey: ['internalRecommendations', placement, currentUserId],
    queryFn: () => api.getInternalRecommendations(placement, currentUserId),
    // 실패해도 Dashboard 가 깨지지 않도록: 재시도 최소화 + throw 억제
    retry: false,
    // 에러를 throw 하지 않고 빈 응답으로 폴백
    select: (d) => d,
  });

  const recommendations: InternalRecommendation[] = data?.enabled ? data.recommendations || [] : [];

  // impression 로그 — 항목당 1회만.
  const impressionLogged = useRef<Set<number>>(new Set());
  useEffect(() => {
    recommendations.forEach((rec) => {
      if (!impressionLogged.current.has(rec.id)) {
        impressionLogged.current.add(rec.id);
        api.logInternalRecommendationEvent(rec.id, 'impression', currentUserId).catch(() => {});
      }
    });
  }, [recommendations, currentUserId]);

  if (recommendations.length === 0) return null;

  const refetch = () =>
    queryClient.invalidateQueries({ queryKey: ['internalRecommendations', placement, currentUserId] });

  const handleCta = (rec: InternalRecommendation) => {
    api.logInternalRecommendationEvent(rec.id, 'click', currentUserId).catch(() => {});
    const url = (rec.cta_url || '').trim();
    if (!url) return;
    if (/^https?:\/\//i.test(url)) {
      window.open(url, '_blank', 'noopener,noreferrer');
    } else {
      navigate(url);
    }
  };

  const handleDismiss = (rec: InternalRecommendation, mode: 'today' | 'later') => {
    api.logInternalRecommendationEvent(rec.id, 'dismiss', currentUserId).catch(() => {});
    api
      .dismissInternalRecommendation(rec.id, mode, currentUserId)
      .then(() => refetch())
      .catch(() => {});
  };

  const isEquipment = placement === 'EQUIPMENT_DASHBOARD_AFTER_KPI';

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mb: 3 }}>
      {recommendations.map((rec) => (
        <Box
          key={rec.id}
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 2,
            minHeight: 64,
            px: { xs: 1.5, sm: 2.25 },
            py: 1.25,
            borderRadius: '20px',
            bgcolor: 'rgba(255,255,255,0.82)',
            backdropFilter: 'blur(12px)',
            border: `1px solid ${planAiColors.border.soft}`,
            boxShadow: planAiShadows.sm,
            transition: 'box-shadow 0.2s',
            '&:hover': { boxShadow: planAiShadows.md },
          }}
        >
          {/* 왼쪽: label + badge */}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              flexShrink: 0,
              pr: 2,
              borderRight: { xs: 'none', md: `1px solid ${planAiColors.border.soft}` },
            }}
          >
            <AutoAwesomeIcon sx={{ fontSize: '1.05rem', color: planAiColors.brand.primary }} />
            <Typography
              sx={{
                fontSize: '0.8rem',
                fontWeight: 700,
                color: planAiColors.text.secondary,
                whiteSpace: 'nowrap',
                display: { xs: 'none', md: 'block' },
              }}
            >
              {rec.label}
            </Typography>
            {rec.badge && (
              <Chip
                label={rec.badge}
                size="small"
                sx={{
                  height: 20,
                  fontSize: '0.66rem',
                  fontWeight: 700,
                  bgcolor: planAiColors.brand.primarySoft,
                  color: planAiColors.brand.primary,
                }}
              />
            )}
          </Box>

          {/* 중앙: 아이콘 + 제목 + 설명 + reason */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexGrow: 1, minWidth: 0 }}>
            <Box
              sx={{
                width: 36,
                height: 36,
                borderRadius: '10px',
                flexShrink: 0,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                bgcolor: planAiColors.brand.primarySoft,
                color: planAiColors.brand.primary,
              }}
            >
              {isEquipment ? (
                <PrecisionManufacturingOutlinedIcon sx={{ fontSize: '1.2rem' }} />
              ) : (
                <DescriptionOutlinedIcon sx={{ fontSize: '1.2rem' }} />
              )}
            </Box>
            <Box sx={{ minWidth: 0 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                <Typography
                  sx={{
                    fontSize: '0.92rem',
                    fontWeight: 800,
                    color: planAiColors.text.primary,
                    whiteSpace: 'nowrap',
                  }}
                >
                  {rec.title}
                </Typography>
                {rec.reason_text && (
                  <Chip
                    label={rec.reason_text}
                    size="small"
                    sx={{
                      height: 18,
                      fontSize: '0.62rem',
                      fontWeight: 600,
                      bgcolor: planAiColors.background.surfaceAlt,
                      color: planAiColors.text.tertiary,
                      display: { xs: 'none', lg: 'inline-flex' },
                    }}
                  />
                )}
              </Box>
              {rec.description && (
                <Typography
                  sx={{
                    fontSize: '0.78rem',
                    color: planAiColors.text.tertiary,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    display: { xs: 'none', sm: 'block' },
                  }}
                >
                  {rec.description}
                </Typography>
              )}
            </Box>
          </Box>

          {/* 오른쪽: 바로가기 / 나중에 보기 / 닫기 */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flexShrink: 0 }}>
            <Button
              variant="contained"
              size="small"
              disableElevation
              onClick={() => handleCta(rec)}
              sx={{
                textTransform: 'none',
                fontWeight: 700,
                fontSize: '0.78rem',
                borderRadius: '10px',
                px: 1.75,
                bgcolor: planAiColors.brand.primary,
                '&:hover': { bgcolor: planAiColors.brand.primaryHover },
              }}
            >
              {rec.cta_label || '바로가기'}
            </Button>
            <Button
              size="small"
              onClick={() => handleDismiss(rec, 'later')}
              sx={{
                textTransform: 'none',
                fontWeight: 600,
                fontSize: '0.76rem',
                color: planAiColors.text.tertiary,
                display: { xs: 'none', sm: 'inline-flex' },
                '&:hover': { bgcolor: 'rgba(0,0,0,0.04)' },
              }}
            >
              {rec.secondary_label || '나중에 보기'}
            </Button>
            <Tooltip title="오늘 하루 보지 않기">
              <IconButton
                size="small"
                onClick={() => handleDismiss(rec, 'today')}
                sx={{ color: planAiColors.text.muted, '&:hover': { color: planAiColors.text.secondary } }}
              >
                <CloseIcon sx={{ fontSize: '1.05rem' }} />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
      ))}
    </Box>
  );
};

export default InternalRecommendationStrip;
