import React, { useEffect, useState } from 'react';
import {
    Box, Typography, TextField, Button, Stack, Avatar, IconButton, Tooltip,
    CircularProgress,
} from '@mui/material';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import CloseIcon from '@mui/icons-material/Close';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useSnackbar } from 'notistack';
import { api } from '../api/client';
import { TaskComment, TaskCommentAttachment, ProjectMember } from '../types';
import { planAiColors } from '../theme/tokens';
import { buildAbsoluteUrl } from './voc/vocImageUpload';
import ImageLightbox, { LightboxImage } from './voc/ImageLightbox';
import MentionTextField, { MentionedUser, resolveMentionedUserIds } from './MentionTextField';
import { Checkbox, FormControlLabel } from '@mui/material';

// 작성자 측 "메일 알림 보내기" 기본값. 부담되면 false 로 바꾼다(수신자 on/off 가 최종 게이트).
const DEFAULT_SEND_MENTION_EMAIL = true;

const MAX_COMMENT_IMAGES = 5;
const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp'];

const formatDateTime = (iso?: string | null): string => {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    const p = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
};

// @멘션 토큰을 굵게 강조하면서 나머지는 그대로(줄바꿈 보존) 렌더한다.
const renderContent = (content: string): React.ReactNode => {
    const parts = content.split(/(@\S+)/g);
    return parts.map((part, i) =>
        part.startsWith('@')
            ? <strong key={i} style={{ color: planAiColors.brand.primary }}>{part}</strong>
            : <React.Fragment key={i}>{part}</React.Fragment>,
    );
};

// 붙여넣기 대기 이미지(등록 전) — 미리보기 blob URL + 실제 File.
interface PendingImage {
    id: string;
    file: File;
    previewUrl: string;
}

// ── 첨부 이미지 썸네일 행 (댓글 본문 아래 표시, 클릭 시 라이트박스) ──
const AttachmentThumbs: React.FC<{
    attachments: TaskCommentAttachment[];
    onOpen: (images: LightboxImage[], index: number) => void;
}> = ({ attachments, onOpen }) => {
    if (!attachments || attachments.length === 0) return null;
    const images: LightboxImage[] = attachments.map(a => ({ url: buildAbsoluteUrl(a.url), filename: a.filename }));
    return (
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.8, mt: 0.6 }}>
            {attachments.map((a, idx) => (
                <Box
                    key={a.id}
                    component="img"
                    src={buildAbsoluteUrl(a.url)}
                    alt={a.filename || 'image'}
                    onClick={() => onOpen(images, idx)}
                    sx={{
                        width: 72, height: 72, objectFit: 'cover', borderRadius: 1,
                        border: `1px solid ${planAiColors.border.soft}`, cursor: 'pointer',
                        '&:hover': { opacity: 0.85 },
                    }}
                />
            ))}
        </Box>
    );
};

// ── 댓글 목록 + 입력창 본체 (인라인 / 팝업 공용) ──
const CommentsBody: React.FC<{
    taskId: number;
    comments: TaskComment[];
    isLoading: boolean;
    canComment: boolean;
    listMaxHeight?: number | string;
    /** true면 부모 높이를 꽉 채우고 목록만 내부 스크롤, 입력창은 하단 고정. */
    fill?: boolean;
    /** @멘션 후보(현재 Project 멤버) 조회용. 없으면 멘션 피커 없이 일반 입력. */
    projectId?: number;
}> = ({ taskId, comments, isLoading, canComment, listMaxHeight, fill, projectId }) => {
    const queryClient = useQueryClient();
    const { enqueueSnackbar } = useSnackbar();

    const [draft, setDraft] = useState('');
    const [pending, setPending] = useState<PendingImage[]>([]);
    const [uploading, setUploading] = useState(false);
    const [editingId, setEditingId] = useState<number | null>(null);
    const [editDraft, setEditDraft] = useState('');
    const [lightbox, setLightbox] = useState<{ images: LightboxImage[]; index: number } | null>(null);
    // @멘션 피커로 고른 대상 + 메일 발송 opt-in
    const [mentioned, setMentioned] = useState<MentionedUser[]>([]);
    const [sendEmail, setSendEmail] = useState<boolean>(DEFAULT_SEND_MENTION_EMAIL);

    const { data: members = [] } = useQuery<ProjectMember[]>({
        queryKey: ['projectMembers', projectId],
        queryFn: () => api.getProjectMembers(projectId as number),
        enabled: !!projectId,
    });
    // 본문에 실제로 남아있는 멘션만 유효 (사용자가 지운 토큰 제외)
    const activeMentionIds = resolveMentionedUserIds(mentioned, draft);

    // 언마운트 시 blob URL 정리
    useEffect(() => () => { pending.forEach(p => URL.revokeObjectURL(p.previewUrl)); }, []); // eslint-disable-line react-hooks/exhaustive-deps

    const invalidate = () => queryClient.invalidateQueries({ queryKey: ['taskComments', taskId] });
    const onError = (err: any, fallback: string) =>
        enqueueSnackbar(err?.response?.data?.detail || fallback, { variant: 'error' });

    const addFiles = (files: File[]) => {
        const imgs = files.filter(f => f.type.startsWith('image/'));
        if (imgs.length === 0) return;
        setPending(prev => {
            const next = [...prev];
            for (const f of imgs) {
                if (next.length >= MAX_COMMENT_IMAGES) {
                    enqueueSnackbar(`이미지는 댓글당 최대 ${MAX_COMMENT_IMAGES}개까지 첨부할 수 있습니다.`, { variant: 'warning' });
                    break;
                }
                if (!ALLOWED_IMAGE_TYPES.includes(f.type)) {
                    enqueueSnackbar('PNG, JPEG, WEBP 이미지만 첨부할 수 있습니다.', { variant: 'warning' });
                    continue;
                }
                if (f.size > MAX_IMAGE_BYTES) {
                    enqueueSnackbar('이미지 1개당 최대 10MB까지 첨부할 수 있습니다.', { variant: 'warning' });
                    continue;
                }
                next.push({ id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, file: f, previewUrl: URL.createObjectURL(f) });
            }
            return next;
        });
    };

    const handlePaste = (e: React.ClipboardEvent) => {
        const files: File[] = [];
        for (const item of Array.from(e.clipboardData.items)) {
            if (item.kind === 'file') {
                const f = item.getAsFile();
                if (f && f.type.startsWith('image/')) files.push(f);
            }
        }
        if (files.length > 0) { e.preventDefault(); addFiles(files); }
    };

    const removePending = (id: string) => {
        setPending(prev => {
            const target = prev.find(p => p.id === id);
            if (target) URL.revokeObjectURL(target.previewUrl);
            return prev.filter(p => p.id !== id);
        });
    };

    const submitDraft = async () => {
        const content = draft.trim();
        if (!content && pending.length === 0) return;
        setUploading(true);
        try {
            // 1) 붙여넣은 이미지들을 먼저 업로드(pending) → attachment id 수집
            const attachmentIds: number[] = [];
            for (const p of pending) {
                const att = await api.uploadTaskCommentImage(taskId, p.file);
                if (att?.id) attachmentIds.push(att.id);
            }
            // 2) 댓글 등록(텍스트 + 링크할 첨부 id + 피커 멘션 대상/메일 opt-in)
            const ids = resolveMentionedUserIds(mentioned, content);
            const opts = ids.length > 0 ? { mentionedUserIds: ids, sendMentionEmail: sendEmail } : undefined;
            await api.createTaskComment(taskId, content, attachmentIds, opts);
            pending.forEach(p => URL.revokeObjectURL(p.previewUrl));
            setDraft('');
            setPending([]);
            setMentioned([]);
            setSendEmail(DEFAULT_SEND_MENTION_EMAIL);
            invalidate();
        } catch (e) {
            onError(e, '댓글 작성에 실패했습니다.');
        } finally {
            setUploading(false);
        }
    };

    const updateMut = useMutation({
        mutationFn: ({ id, content }: { id: number; content: string }) => api.updateTaskComment(taskId, id, content),
        onSuccess: () => { setEditingId(null); setEditDraft(''); invalidate(); },
        onError: (e) => onError(e, '댓글 수정에 실패했습니다.'),
    });
    const deleteMut = useMutation({
        mutationFn: (id: number) => api.deleteTaskComment(taskId, id),
        onSuccess: () => invalidate(),
        onError: (e) => onError(e, '댓글 삭제에 실패했습니다.'),
    });

    const submitEdit = (id: number) => {
        const content = editDraft.trim();
        if (!content) return;
        updateMut.mutate({ id, content });
    };

    // 삭제된 댓글은 방어적으로 렌더에서 제외 (백엔드도 목록에서 제외)
    const visible = comments.filter(c => !c.deleted);

    return (
        <Box sx={fill ? { display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 } : undefined}>
            <Stack
                spacing={1.5}
                sx={{
                    mb: 2,
                    ...(fill
                        ? { flex: 1, minHeight: 0, overflowY: 'auto', pr: 0.5 }
                        : { maxHeight: listMaxHeight, overflowY: listMaxHeight ? 'auto' : undefined, pr: listMaxHeight ? 0.5 : 0 }),
                }}
            >
                {isLoading && (
                    <Typography sx={{ fontSize: '0.8rem', color: planAiColors.text.muted }}>불러오는 중…</Typography>
                )}
                {!isLoading && visible.length === 0 && (
                    <Typography sx={{ fontSize: '0.8rem', color: planAiColors.text.muted }}>
                        아직 댓글이 없습니다. 첫 의견을 남겨보세요.
                    </Typography>
                )}
                {visible.map(c => (
                    <Box key={c.id} sx={{ display: 'flex', gap: 1.2 }}>
                        <Avatar sx={{ width: 28, height: 28, fontSize: '0.75rem', bgcolor: c.author_color || planAiColors.brand.primary }}>
                            {(c.author_name || '?').charAt(0)}
                        </Avatar>
                        <Box sx={{ flex: 1, minWidth: 0 }}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                <Typography sx={{ fontSize: '0.78rem', fontWeight: 700 }}>
                                    {c.author_name || '알 수 없음'}
                                </Typography>
                                <Typography sx={{ fontSize: '0.68rem', color: planAiColors.text.muted }}>
                                    {formatDateTime(c.created_at)}{c.edited_at ? ' (수정됨)' : ''}
                                </Typography>
                                {(c.can_edit || c.can_delete) && editingId !== c.id && (
                                    <Box sx={{ ml: 'auto', display: 'flex', gap: 0.2 }}>
                                        {c.can_edit && (
                                            <Tooltip title="수정" arrow>
                                                <IconButton size="small" onClick={() => { setEditingId(c.id); setEditDraft(c.content); }}>
                                                    <EditOutlinedIcon sx={{ fontSize: 15 }} />
                                                </IconButton>
                                            </Tooltip>
                                        )}
                                        {c.can_delete && (
                                            <Tooltip title="삭제" arrow>
                                                <IconButton
                                                    size="small"
                                                    onClick={() => { if (window.confirm('이 댓글을 삭제하시겠습니까?')) deleteMut.mutate(c.id); }}
                                                    sx={{ color: planAiColors.status.danger }}
                                                >
                                                    <DeleteOutlineIcon sx={{ fontSize: 15 }} />
                                                </IconButton>
                                            </Tooltip>
                                        )}
                                    </Box>
                                )}
                            </Box>

                            {editingId === c.id ? (
                                <Box sx={{ mt: 0.5 }}>
                                    <TextField
                                        value={editDraft}
                                        onChange={(e) => setEditDraft(e.target.value)}
                                        multiline minRows={2} fullWidth size="small"
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); submitEdit(c.id); }
                                        }}
                                    />
                                    <Box sx={{ display: 'flex', gap: 1, mt: 0.5 }}>
                                        <Button size="small" variant="contained"
                                            disabled={!editDraft.trim() || updateMut.isPending}
                                            onClick={() => submitEdit(c.id)}
                                            sx={{ textTransform: 'none', bgcolor: planAiColors.brand.primary }}>
                                            저장
                                        </Button>
                                        <Button size="small" onClick={() => { setEditingId(null); setEditDraft(''); }}
                                            sx={{ textTransform: 'none', color: planAiColors.text.tertiary }}>
                                            취소
                                        </Button>
                                    </Box>
                                </Box>
                            ) : (
                                <>
                                    {c.content && (
                                        <Typography sx={{
                                            fontSize: '0.82rem', mt: 0.2, whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                                            color: planAiColors.text.primary,
                                        }}>
                                            {renderContent(c.content)}
                                        </Typography>
                                    )}
                                    <AttachmentThumbs
                                        attachments={c.attachments || []}
                                        onOpen={(images, index) => setLightbox({ images, index })}
                                    />
                                </>
                            )}
                        </Box>
                    </Box>
                ))}
            </Stack>

            {/* 새 댓글 입력 */}
            {canComment && (
                <Box sx={fill ? { flexShrink: 0 } : undefined}>
                    <MentionTextField
                        value={draft}
                        onChange={setDraft}
                        members={members}
                        mentioned={mentioned}
                        onMentionedChange={setMentioned}
                        onSubmit={submitDraft}
                        onPaste={handlePaste}
                        placeholder="의견을 입력하세요. @로 멘션, 이미지는 Ctrl+V 로 붙여넣기 (Ctrl+Enter로 등록)"
                        minRows={2}
                    />
                    {/* 멘션이 있을 때만 메일 알림 opt-in 노출 */}
                    {activeMentionIds.length > 0 && (
                        <FormControlLabel
                            sx={{ mt: 0.5, ml: 0 }}
                            control={
                                <Checkbox
                                    size="small"
                                    checked={sendEmail}
                                    onChange={(e) => setSendEmail(e.target.checked)}
                                    sx={{ py: 0.3 }}
                                />
                            }
                            label={
                                <Typography sx={{ fontSize: '0.76rem', color: planAiColors.text.secondary }}>
                                    멘션한 {activeMentionIds.length}명에게 메일 알림 보내기
                                </Typography>
                            }
                        />
                    )}
                    {/* 붙여넣은 이미지 미리보기 (등록 전 삭제 가능) */}
                    {pending.length > 0 && (
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                            {pending.map(p => (
                                <Box key={p.id} sx={{ position: 'relative' }}>
                                    <Box component="img" src={p.previewUrl} alt="preview"
                                        sx={{ width: 64, height: 64, objectFit: 'cover', borderRadius: 1, border: `1px solid ${planAiColors.border.soft}` }} />
                                    <IconButton size="small" onClick={() => removePending(p.id)}
                                        sx={{
                                            position: 'absolute', top: -8, right: -8, bgcolor: 'rgba(0,0,0,0.6)', color: '#fff', p: 0.2,
                                            '&:hover': { bgcolor: 'rgba(0,0,0,0.8)' },
                                        }}>
                                        <CloseIcon sx={{ fontSize: 13 }} />
                                    </IconButton>
                                </Box>
                            ))}
                        </Box>
                    )}
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 0.8 }}>
                        <Button
                            variant="contained" size="small"
                            disabled={(!draft.trim() && pending.length === 0) || uploading}
                            onClick={submitDraft}
                            startIcon={uploading ? <CircularProgress size={13} color="inherit" /> : undefined}
                            sx={{ textTransform: 'none', bgcolor: planAiColors.brand.primary }}
                        >
                            {uploading ? '등록 중…' : '등록'}
                        </Button>
                    </Box>
                </Box>
            )}

            {lightbox && (
                <ImageLightbox
                    open={!!lightbox}
                    onClose={() => setLightbox(null)}
                    images={lightbox.images}
                    initialIndex={lightbox.index}
                />
            )}
        </Box>
    );
};

// ── Task Details 내부에서 '화면 전환'으로 표시하는 댓글 전용 뷰 ──
// 상단: [← Details로 돌아가기]  ...  Comments (N)
// 본문: 목록만 내부 스크롤 + 입력창 하단 고정 (Details 레이아웃과 분리)
export const TaskCommentsView: React.FC<{
    taskId: number;
    comments: TaskComment[];
    isLoading: boolean;
    canComment: boolean;
    onBack: () => void;
    projectId?: number;
}> = ({ taskId, comments, isLoading, canComment, onBack, projectId }) => (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2, flexShrink: 0 }}>
            <Button
                onClick={onBack}
                size="small"
                startIcon={<ArrowBackIcon sx={{ fontSize: '1rem !important' }} />}
                sx={{ textTransform: 'none', color: planAiColors.text.secondary, fontWeight: 600, px: 0.5 }}
            >
                Details로 돌아가기
            </Button>
            <Typography sx={{ ml: 'auto', fontWeight: 800, fontSize: '0.95rem', color: planAiColors.text.primary }}>
                Comments ({comments.length})
            </Typography>
        </Box>
        <Box sx={{ flex: 1, minHeight: 0 }}>
            <CommentsBody
                taskId={taskId}
                comments={comments}
                isLoading={isLoading}
                canComment={canComment}
                projectId={projectId}
                fill
            />
        </Box>
    </Box>
);

export default TaskCommentsView;
