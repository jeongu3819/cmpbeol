import React, { useState } from 'react';
import { Box, Typography, Tabs, Tab, Button, Tooltip } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import { useAppStore } from '../stores/useAppStore';
import { deriveSidebarColor, autoTextColor } from '../utils/colorUtils';
import {
  BACKGROUND_OPTIONS,
  ACCENT_OPTIONS,
  RADIUS_OPTIONS,
  SHADOW_OPTIONS,
  resolveRadius,
  resolveShadow,
} from '../theme/customTheme';
import ThemePreviewSwatch from './ThemePreviewSwatch';

interface Props {
  /** 프리셋 탭에 노출할 배경색 목록(BG_PALETTE). */
  presetColors: string[];
}

const SectionLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <Typography
    variant="caption"
    sx={{ display: 'block', fontWeight: 700, color: '#334155', mt: 1.6, mb: 0.8 }}
  >
    {children}
  </Typography>
);

/** 작은 선택 칩(둥글기/그림자/배경 라벨). */
const OptionChip: React.FC<{ label: string; selected: boolean; onClick: () => void }> = ({
  label, selected, onClick,
}) => (
  <Box
    onClick={onClick}
    role="button"
    aria-pressed={selected}
    sx={{
      px: 1.2,
      py: 0.6,
      borderRadius: 1.5,
      fontSize: '0.75rem',
      fontWeight: 600,
      cursor: 'pointer',
      textAlign: 'center',
      color: selected ? '#fff' : '#475569',
      bgcolor: selected ? '#2563EB' : '#F1F5F9',
      border: selected ? '1px solid #2563EB' : '1px solid #E2E8F0',
      transition: 'all 140ms ease',
      '&:hover': { borderColor: '#2563EB' },
    }}
  >
    {label}
  </Box>
);

/**
 * Custom Theme Builder.
 * - [프리셋] 탭: 배경 프리셋을 한 번에 적용 (기존 동작 유지).
 * - [고급 설정] 탭: 배경색 / 포인트색 / 둥글기 / 그림자를 개별 조정 + 실시간 미리보기.
 */
const ThemeBuilderPanel: React.FC<Props> = ({ presetColors }) => {
  const [tab, setTab] = useState(0);
  const bgColor = useAppStore(s => s.bgColor);
  const customTheme = useAppStore(s => s.customTheme);
  const setThemePreset = useAppStore(s => s.setThemePreset);
  const setCustomTheme = useAppStore(s => s.setCustomTheme);
  const resetTheme = useAppStore(s => s.resetTheme);

  const sidebar = deriveSidebarColor(customTheme.background);
  const sidebarText = autoTextColor(sidebar);
  const radiusPx = resolveRadius(customTheme.radius);
  const shadow = resolveShadow(customTheme.shadow);

  return (
    <Box>
      <Typography sx={{ fontWeight: 700, fontSize: '0.95rem', color: '#0F172A' }}>
        테마 프리셋
      </Typography>
      <Typography variant="caption" sx={{ display: 'block', color: '#64748B', lineHeight: 1.4 }}>
        카드를 선택하면 배경, 사이드바, 카드 톤이 함께 적용됩니다.
      </Typography>

      <Tabs
        value={tab}
        onChange={(_, v) => setTab(v)}
        sx={{ minHeight: 36, mt: 1, mb: 1, '& .MuiTab-root': { minHeight: 36, py: 0.5, textTransform: 'none', fontWeight: 600 } }}
      >
        <Tab label="프리셋" />
        <Tab label="고급 설정" />
      </Tabs>

      {tab === 0 ? (
        <Box
          sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 1.2, pb: 0.5 }}
        >
          {presetColors.map(color => (
            <ThemePreviewSwatch
              key={color}
              color={color}
              selected={bgColor === color}
              height={64}
              onClick={() => setThemePreset(color)}
            />
          ))}
        </Box>
      ) : (
        <Box>
          <Typography variant="caption" sx={{ display: 'block', color: '#64748B', lineHeight: 1.4 }}>
            원하는 UI 분위기를 직접 조정할 수 있습니다.
          </Typography>

          {/* 배경색 */}
          <SectionLabel>배경색</SectionLabel>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 0.8 }}>
            {BACKGROUND_OPTIONS.map(opt => {
              const selected = customTheme.background === opt.value;
              return (
                <Box
                  key={opt.id}
                  onClick={() => setCustomTheme({ background: opt.value })}
                  role="button"
                  aria-pressed={selected}
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 0.7,
                    px: 1, py: 0.6, borderRadius: 1.5, cursor: 'pointer',
                    border: selected ? '2px solid #2563EB' : '1px solid #E2E8F0',
                    transition: 'border-color 140ms ease',
                    '&:hover': { borderColor: '#2563EB' },
                  }}
                >
                  <Box sx={{ width: 16, height: 16, borderRadius: '50%', bgcolor: opt.value, border: '1px solid rgba(15,23,42,0.12)', flexShrink: 0 }} />
                  <Typography variant="caption" sx={{ fontWeight: 600, color: '#475569' }} noWrap>
                    {opt.label}
                  </Typography>
                </Box>
              );
            })}
          </Box>

          {/* 포인트색 */}
          <SectionLabel>포인트색</SectionLabel>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            {ACCENT_OPTIONS.map(opt => {
              const selected = customTheme.accent === opt.value;
              return (
                <Tooltip key={opt.id} title={opt.label} placement="top">
                  <Box
                    onClick={() => setCustomTheme({ accent: opt.value })}
                    role="button"
                    aria-pressed={selected}
                    sx={{
                      width: 30, height: 30, borderRadius: '50%', cursor: 'pointer',
                      bgcolor: opt.value,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      boxShadow: selected ? `0 0 0 3px ${opt.value}40` : 'none',
                      border: '2px solid #fff',
                      outline: selected ? `2px solid ${opt.value}` : '1px solid rgba(15,23,42,0.12)',
                      transition: 'transform 140ms ease',
                      '&:hover': { transform: 'translateY(-1px)' },
                    }}
                  >
                    {selected && <CheckIcon sx={{ fontSize: 16, color: '#fff' }} />}
                  </Box>
                </Tooltip>
              );
            })}
          </Box>

          {/* 둥글기 */}
          <SectionLabel>둥글기</SectionLabel>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 0.8 }}>
            {RADIUS_OPTIONS.map(opt => (
              <OptionChip
                key={opt.id}
                label={opt.label}
                selected={customTheme.radius === opt.id}
                onClick={() => setCustomTheme({ radius: opt.id })}
              />
            ))}
          </Box>

          {/* 그림자 강도 */}
          <SectionLabel>그림자 강도</SectionLabel>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 0.8 }}>
            {SHADOW_OPTIONS.map(opt => (
              <OptionChip
                key={opt.id}
                label={opt.label}
                selected={customTheme.shadow === opt.id}
                onClick={() => setCustomTheme({ shadow: opt.id })}
              />
            ))}
          </Box>

          {/* 미리보기 */}
          <SectionLabel>미리보기</SectionLabel>
          <Box
            sx={{
              display: 'flex',
              height: 96,
              borderRadius: `${radiusPx}px`,
              overflow: 'hidden',
              bgcolor: customTheme.background,
              border: '1px solid #E2E8F0',
            }}
          >
            <Box sx={{ width: '28%', bgcolor: sidebar, p: 1, display: 'flex', flexDirection: 'column', gap: 0.6 }}>
              <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: customTheme.accent }} />
              <Box sx={{ height: 4, borderRadius: 1, bgcolor: sidebarText, opacity: 0.5, width: '80%' }} />
              <Box sx={{ height: 4, borderRadius: 1, bgcolor: sidebarText, opacity: 0.5, width: '55%' }} />
            </Box>
            <Box sx={{ flex: 1, p: 1, display: 'flex', flexDirection: 'column', gap: 0.7 }}>
              <Box
                sx={{
                  bgcolor: '#fff',
                  borderRadius: `${Math.max(4, radiusPx - 4)}px`,
                  boxShadow: shadow.card,
                  border: '1px solid #EEF1F5',
                  p: 0.8,
                  flex: 1,
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 0.6,
                }}
              >
                <Box sx={{ height: 5, borderRadius: 1, bgcolor: '#334155', width: '60%' }} />
                <Box sx={{ display: 'flex', gap: 0.6, mt: 'auto', alignItems: 'center' }}>
                  <Box sx={{ px: 1, py: 0.4, borderRadius: `${Math.max(4, radiusPx - 6)}px`, bgcolor: customTheme.accent, color: '#fff', fontSize: '0.6rem', fontWeight: 700 }}>
                    Button
                  </Box>
                  <Box sx={{ px: 0.9, py: 0.3, borderRadius: 999, bgcolor: `${customTheme.accent}1A`, color: customTheme.accent, fontSize: '0.6rem', fontWeight: 700 }}>
                    Chip
                  </Box>
                </Box>
              </Box>
            </Box>
          </Box>

          <Button
            size="small"
            startIcon={<RestartAltIcon />}
            onClick={resetTheme}
            sx={{ mt: 1.5, textTransform: 'none', color: '#64748B' }}
          >
            기본값으로 초기화
          </Button>
        </Box>
      )}
    </Box>
  );
};

export default ThemeBuilderPanel;
