import React, { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
    Drawer, Box, Typography, TextField, Button, MenuItem,
    Stack, IconButton, Divider, Chip, Avatar, Autocomplete,
    Checkbox, Slider, Link, CircularProgress, LinearProgress,
    Tooltip, Dialog, DialogTitle, DialogContent, DialogActions,
    FormControlLabel,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import LinkIcon from '@mui/icons-material/Link';
import AddIcon from '@mui/icons-material/Add';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import OpenInFullIcon from '@mui/icons-material/OpenInFull';
import EditNoteIcon from '@mui/icons-material/EditNote';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import CheckIcon from '@mui/icons-material/Check';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import DownloadIcon from '@mui/icons-material/Download';
import BugReportOutlinedIcon from '@mui/icons-material/BugReportOutlined';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import SubdirectoryArrowRightIcon from '@mui/icons-material/SubdirectoryArrowRight';
import DriveFileMoveOutlinedIcon from '@mui/icons-material/DriveFileMoveOutlined';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import { useAppStore } from '../stores/useAppStore';
import { Task, Attachment, TaskActivity, SubProject } from '../types';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useSnackbar } from 'notistack';
import { api, User, API_URL } from '../api/client';
import WorkNoteModal from './WorkNoteModal';
import TaskSheetPanel from './sheets/TaskSheetPanel';
import RichDescriptionEditor from './RichDescriptionEditor';
import ItemHistorySection from './ItemHistorySection';
import { TaskCommentsView } from './TaskCommentsSection';
import { TaskComment } from '../types';
import TaskMoveDialog from './TaskMoveDialog';
import { parseQuickAddInput } from '../utils/magicInputParser';
import { suggestStartDate, suggestDueDate } from '../utils/scheduleFormat';
import { validateGeneralFiles, validateInlineImage } from '../utils/uploadValidation';
import { getTaskDescendantIds, getTaskAncestorPath } from '../utils/taskTree';
import { planAiColors } from '../theme/tokens';
import { useWorkflow } from '../hooks/useWorkflow';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const formatFileSize = (bytes?: number): string => {
    if (!bytes || bytes === 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
};

const TaskDrawer: React.FC = () => {
    const { isDrawerOpen, closeDrawer, openDrawer, selectedTask, drawerProjectId, drawerInitialData, currentUserId, currentSpaceId } = useAppStore();
    const queryClient = useQueryClient();
    const { enqueueSnackbar } = useSnackbar();
    const pendingFollowUpRef = useRef<{ title: string; projectId: number } | null>(null);
    const [formData, setFormData] = useState<Partial<Task>>({});
    const [selectedAssignees, setSelectedAssignees] = useState<User[]>([]);
    const [newAttachmentUrl, setNewAttachmentUrl] = useState('');
    const [newAttachmentName, setNewAttachmentName] = useState('');
    const [showAttachmentForm, setShowAttachmentForm] = useState(false);
    // URL 첨부 인라인 편집 상태
    const [editingAttId, setEditingAttId] = useState<number | null>(null);
    const [editAttUrl, setEditAttUrl] = useState('');
    const [editAttName, setEditAttName] = useState('');
    const [uploading, setUploading] = useState(false);
    const [moveDialogOpen, setMoveDialogOpen] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Pending state for new tasks
    const [pendingUrls, setPendingUrls] = useState<{url: string, filename?: string}[]>([]);
    const [pendingFiles, setPendingFiles] = useState<File[]>([]);
    const [pendingSheets, setPendingSheets] = useState<{templateId: number, title: string}[]>([]);

    // mode flag: calendar 날짜 클릭으로 생성 중인가?
    const isCalendarCreateMode = !selectedTask && (drawerInitialData as any)?.isCalendarCreate === true;

    // Fetch space projects for creation selection
    const { data: spaceProjects = [] } = useQuery<any[]>({
        queryKey: ['projects', currentUserId, currentSpaceId],
        queryFn: () => api.getProjects(currentUserId, currentSpaceId),
        enabled: !!currentSpaceId && isCalendarCreateMode,
    });

    // Fetch users (all - for fallback/display)
    const { data: allUsers = [] } = useQuery<User[]>({
        queryKey: ['users'],
        queryFn: () => api.getUsers(),
    });

    // Fetch project members - only assignable (not viewer)
    const activeProjectId = selectedTask?.project_id || formData.project_id || (drawerProjectId > 0 ? drawerProjectId : undefined);
    const { data: projectMembers = [] } = useQuery<any[]>({
        queryKey: ['projectMembers', activeProjectId],
        queryFn: () => api.getProjectMembers(activeProjectId!),
        enabled: !!activeProjectId,
    });

    // Fetch subprojects for the project
    const { data: subProjects = [] } = useQuery<SubProject[]>({
        queryKey: ['subProjects', activeProjectId],
        queryFn: () => api.getSubProjects(activeProjectId!),
        enabled: !!activeProjectId,
    });

    // Check Sheets 는 설비운영(equipment_ops) 공간에서만 노출 — 프로젝트관리 등 일반 공간에서는 숨김.
    // 프로젝트 → space_id → space.purpose 로 판별 (ProjectSettingsView 와 동일 패턴, 동일 query key 로 캐시 공유).
    const { data: allProjects = [] } = useQuery<any[]>({
        queryKey: ['projects', currentUserId],
        queryFn: () => api.getProjects(currentUserId),
        enabled: currentUserId > 0,
    });
    const { data: spaces = [] } = useQuery<any[]>({
        queryKey: ['spaces', currentUserId],
        queryFn: () => api.getSpaces(currentUserId),
        enabled: currentUserId > 0,
    });
    const activeProject = allProjects.find((p: any) => p.id === activeProjectId);
    const activeProjectSpace = activeProject?.space_id
        ? spaces.find((s: any) => s.id === activeProject.space_id)
        : null;
    const isEquipmentOpsSpace = activeProjectSpace?.purpose === 'equipment_ops';

    // Filter: viewer cannot be assigned
    const memberUserIds = new Set(
        projectMembers
            .filter((m: any) => m.role !== 'viewer')
            .map((m: any) => m.user_id)
    );
    const users = activeProjectId
        ? allUsers.filter(u => memberUserIds.has(u.id))
        : allUsers;

    // Check if current user is viewer (read-only)
    const currentMember = projectMembers.find((m: any) => m.user_id === currentUserId);
    const isViewer = currentMember?.role === 'viewer';

    // Fetch attachments when editing existing task
    const { data: attachments = [], isLoading: attachmentsLoading } = useQuery<Attachment[]>({
        queryKey: ['attachments', selectedTask?.id],
        queryFn: () => api.getAttachments(selectedTask!.id),
        enabled: !!selectedTask?.id,
    });

    const urlAttachments = attachments.filter(a => a.type !== 'file');
    const fileAttachments = attachments.filter(a => a.type === 'file');

    // 업로드 제한 정책 (서버와 동일 규칙으로 즉시 검증). 캐시 길게 유지.
    const { data: uploadPolicy } = useQuery({
        queryKey: ['uploadPolicy'],
        queryFn: () => api.getUploadPolicy(),
        staleTime: 60 * 60 * 1000,
    });

    /**
     * 선택한 파일들을 공통 일반-첨부 정책 기준으로 검증한다.
     * 통과한 파일 배열을 반환하고, 위반 시 첫 위반 메시지를 alert 후 빈 배열 반환.
     * (frontend 1차 검증 — 최종 차단은 backend가 동일하게 수행한다.)
     */
    const validateFilesAgainstPolicy = (files: File[]): File[] => {
        // 현재 task에 이미 첨부된 개수/용량 (편집 모드) + 대기 중 파일
        const existingCount = (selectedTask?.id ? fileAttachments.length : 0) + pendingFiles.length;
        const existingBytes =
            (selectedTask?.id ? fileAttachments.reduce((sum, a) => sum + (a.size || 0), 0) : 0) +
            pendingFiles.reduce((sum, f) => sum + f.size, 0);

        const { accepted, error } = validateGeneralFiles(uploadPolicy?.general, files, existingCount, existingBytes);
        if (error) {
            alert(error);
            return [];
        }
        return accepted;
    };

    /** 인라인 이미지(Description 붙여넣기) 검증 — 위반 시 Error throw → 에디터가 메시지 표시. */
    const validateInlineImageOrThrow = (file: File) => {
        const err = validateInlineImage(uploadPolicy?.inline_image, file);
        if (err) throw new Error(err);
    };

    useEffect(() => {
        if (selectedTask) {
            setFormData({ ...selectedTask });
        } else {
            setFormData({
                title: '',
                status: 'todo',
                description: '',
                priority: 'medium',
                start_date: '',
                due_date: '',
                start_date_tbd: false,
                due_date_tbd: false,
                assignee_ids: [],
                tags: [],
                progress: 0,
                project_id: drawerProjectId > 0 ? drawerProjectId : undefined,
                ...(drawerInitialData || {}),
            });
            setSelectedAssignees([]);
        }
        setShowAttachmentForm(false);
        setNewAttachmentUrl('');
        setNewAttachmentName('');
        setPendingUrls([]);
        setPendingFiles([]);
        setPendingSheets([]);
        const tags = selectedTask?.tags || [];
        setIsIssue(tags.includes('이슈'));
        setIsSpecial(tags.includes('특이사항'));
        setCreateFollowUp(false);
        setSubProjectAdding(false);
        setNewSubProjectName('');
        setNewSubProjectDesc('');
        setChildAdding(false);
        setNewChildTitle('');
    }, [selectedTask, isDrawerOpen, drawerProjectId, drawerInitialData]);

    // Sync assignees when users load (separate effect to avoid infinite loop)
    useEffect(() => {
        if (selectedTask && users.length > 0) {
            const assigned = users.filter(u => selectedTask.assignee_ids?.includes(u.id));
            setSelectedAssignees(assigned);
        }
    }, [selectedTask?.id, users.length]);

    const updateMutation = useMutation({
        mutationFn: (updates: Partial<Task>) => {
            if (!selectedTask?.id) return Promise.reject("No task selected");
            return api.updateTask(selectedTask.id, updates);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            queryClient.invalidateQueries({ queryKey: ['stats'] });
            queryClient.invalidateQueries({ queryKey: ['spaceOverview'] });
            queryClient.invalidateQueries({ queryKey: ['sheetExecutions'] });
            queryClient.invalidateQueries({ queryKey: ['graph'] });
            queryClient.invalidateQueries({ queryKey: ['roadmap'] });
            enqueueSnackbar('저장되었습니다.', { variant: 'success' });
            closeDrawer();
        },
        // 저장 실패(권한/상하관계·Sub Project 검증 400 등)를 조용히 삼키지 않고 사용자에게 노출
        onError: (err: any) => {
            enqueueSnackbar(
                err?.response?.data?.detail || '저장에 실패했습니다. 잠시 후 다시 시도해주세요.',
                { variant: 'error' },
            );
        },
    });

    // 4차: 사용자 '단계 완료 선언' — 체크 시 stage의 auto_move_on_complete 설정에 따라 다음 단계로 자동 이동
    const stageCompletionMut = useMutation({
        mutationFn: (completed: boolean) => {
            if (!selectedTask?.id) return Promise.reject('No task selected');
            return api.declareStageCompletion(selectedTask.id, completed);
        },
        onSuccess: (updated: any) => {
            // 자동 이동으로 단계/상태가 바뀔 수 있으므로 form + store 를 갱신
            setFormData(prev => ({
                ...prev,
                workflow_column_id: updated.workflow_column_id,
                status: updated.status,
            }));
            useAppStore.setState(s => (
                s.selectedTask && s.selectedTask.id === updated.id
                    ? { selectedTask: { ...s.selectedTask, ...updated } }
                    : {}
            ));
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            queryClient.invalidateQueries({ queryKey: ['graph'] });
            queryClient.invalidateQueries({ queryKey: ['roadmap'] });
            queryClient.invalidateQueries({ queryKey: ['spaceOverview'] });
        },
        onError: (err: any) => {
            enqueueSnackbar(err?.response?.data?.detail || '단계 완료 처리에 실패했습니다.', { variant: 'error' });
        },
    });

    const createMutation = useMutation({
        mutationFn: (newTask: Omit<Task, 'id'>) => api.createTask(newTask),
        onSuccess: async (createdTask) => {
            // v3.14: Task 생성 성공 후 pending 상태의 파일, URL, 시트 처리
            const uPromises = pendingUrls.map(att => api.createAttachment(createdTask.id, { ...att, type: 'url' }).catch(e => console.error(e)));
            const fPromises = pendingFiles.map(file => api.uploadTaskFile(createdTask.id, file, currentUserId).catch(e => console.error(e)));
            const sPromises = pendingSheets.map(sheet => {
                if (!currentSpaceId) return Promise.resolve();
                return api.createSheetExecution({
                    template_id: sheet.templateId,
                    task_id: createdTask.id,
                    project_id: createdTask.project_id,
                    title: sheet.title || undefined,
                }, currentSpaceId, currentUserId).catch(e => console.error(e));
            });

            if (uPromises.length > 0 || fPromises.length > 0 || sPromises.length > 0) {
                await Promise.all([...uPromises, ...fPromises, ...sPromises]);
            }

            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            queryClient.invalidateQueries({ queryKey: ['stats'] });
            queryClient.invalidateQueries({ queryKey: ['spaceOverview'] });
            queryClient.invalidateQueries({ queryKey: ['sheetExecutions'] });
            
            const followUp = pendingFollowUpRef.current;
            pendingFollowUpRef.current = null;
            
            if (followUp) {
                openDrawer(null, followUp.projectId);
                setTimeout(() => setFormData(prev => ({ ...prev, title: followUp.title })), 30);
            } else if (isCalendarCreateMode) {
                // 캘린더 생성 모드면 생성 후 닫기
                closeDrawer();
            } else {
                // 보드 등에서의 생성은 생성 후 바로 편집 모드로 전환 (상세 기능 활성화)
                openDrawer(createdTask, createdTask.project_id);
            }
        },
    });

    const deleteMutation = useMutation({
        mutationFn: (taskId: number) => api.deleteTask(taskId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            queryClient.invalidateQueries({ queryKey: ['stats'] });
            queryClient.invalidateQueries({ queryKey: ['spaceOverview'] });
            closeDrawer();
        },
    });

    const addAttachmentMutation = useMutation({
        mutationFn: (att: { url: string; filename?: string }) =>
            api.createAttachment(selectedTask!.id, { ...att, type: 'url' }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['attachments', selectedTask?.id] });
            setNewAttachmentUrl('');
            setNewAttachmentName('');
            setShowAttachmentForm(false);
        },
    });

    const deleteAttachmentMutation = useMutation({
        mutationFn: (id: number) => api.deleteAttachment(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['attachments', selectedTask?.id] });
        },
    });

    const updateAttachmentMutation = useMutation({
        mutationFn: ({ id, url, filename }: { id: number; url?: string; filename?: string }) =>
            api.updateAttachment(id, currentUserId, { url, filename }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['attachments', selectedTask?.id] });
            setEditingAttId(null);
        },
        onError: (err: any) => {
            alert(err?.response?.data?.detail || 'URL 첨부 수정에 실패했습니다.');
        },
    });

    const startEditAttachment = (att: Attachment) => {
        setEditingAttId(att.id);
        setEditAttUrl(att.url || '');
        setEditAttName(att.filename || '');
    };

    const submitEditAttachment = () => {
        if (editingAttId == null) return;
        const url = editAttUrl.trim();
        if (url && !/^https?:\/\//i.test(url)) {
            alert('URL은 http:// 또는 https:// 로 시작해야 합니다.');
            return;
        }
        updateAttachmentMutation.mutate({
            id: editingAttId,
            url: url || undefined,
            filename: editAttName.trim() || undefined,
        });
    };

    const uploadFileMutation = useMutation({
        mutationFn: (file: File) => api.uploadTaskFile(selectedTask!.id, file, currentUserId),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['attachments', selectedTask?.id] });
            setUploading(false);
        },
        onError: (err: any) => {
            setUploading(false);
            // backend 업로드 정책 위반(400) 등 서버 메시지를 사용자에게 노출
            alert(err?.response?.data?.detail || '파일 업로드에 실패했습니다.');
        },
    });

    // Activities (for progress display only)
    const { data: activities = [] } = useQuery<TaskActivity[]>({
        queryKey: ['activities', selectedTask?.id],
        queryFn: () => api.getTaskActivities(selectedTask!.id),
        enabled: !!selectedTask?.id,
    });

    const [workNoteOpen, setWorkNoteOpen] = useState(false);
    const [isIssue, setIsIssue] = useState(false);
    const [isSpecial, setIsSpecial] = useState(false);
    const [createFollowUp, setCreateFollowUp] = useState(false);

    // Sub Project 인라인 생성 (Task 작성/편집 화면을 떠나지 않고 바로 생성)
    const [subProjectAdding, setSubProjectAdding] = useState(false);
    const [newSubProjectName, setNewSubProjectName] = useState('');
    const [newSubProjectDesc, setNewSubProjectDesc] = useState('');

    const createSubProjectMutation = useMutation({
        mutationFn: (payload: { name: string; description?: string }) =>
            api.createSubProject(activeProjectId!, payload),
        onSuccess: (created) => {
            // 목록 갱신 후 방금 만든 sub project 를 현재 task 에 자동 선택
            queryClient.invalidateQueries({ queryKey: ['subProjects', activeProjectId] });
            handleSubProjectChange(created.id);
            // 입력값/모드 초기화 (성공 시에만)
            setNewSubProjectName('');
            setNewSubProjectDesc('');
            setSubProjectAdding(false);
        },
        onError: (err: any) => {
            // 실패 시 입력값을 유지하고 drawer 도 닫지 않는다.
            alert(err?.response?.data?.detail || 'Sub Project 생성에 실패했습니다. 입력값은 유지됩니다.');
        },
    });

    const handleCreateSubProject = () => {
        const name = newSubProjectName.trim();
        if (!name || !activeProjectId) return;
        // 같은 프로젝트 내 중복 이름 방지(대소문자/공백 무시)
        const dup = subProjects.some(sp => (sp.name || '').trim().toLowerCase() === name.toLowerCase());
        if (dup) {
            alert('같은 이름의 Sub Project가 이미 있습니다.');
            return;
        }
        createSubProjectMutation.mutate({
            name,
            description: newSubProjectDesc.trim() || undefined,
        });
    };

    // Sub Project 삭제 (Graph 페이지와 동일한 API/정책 재사용)
    // 정책: 하위 Task 는 삭제하지 않고 프로젝트 직속으로 이동(sub_project_id=null). Project 도 보존.
    const [deleteSubTarget, setDeleteSubTarget] = useState<SubProject | null>(null);
    // dropdown 안의 휴지통으로 삭제를 시작할 때, 확인 dialog 뒤에 select 메뉴가 남지 않도록 open 상태를 제어
    const [subSelectOpen, setSubSelectOpen] = useState(false);

    // ── Task 상하 관계 (Parent / Child) ──
    // 편집 중인 Task 의 프로젝트 Task 목록 — 상위 후보/하위 목록 산출용.
    // BoardView 와 동일한 query key(['tasks', projectId, currentUserId]) 로 캐시 공유 → 추가 로딩 최소화.
    const { data: projectTasks = [] } = useQuery<Task[]>({
        queryKey: ['tasks', activeProjectId, currentUserId],
        queryFn: () => api.getTasks(activeProjectId!, currentUserId),
        enabled: !!activeProjectId && !!selectedTask?.id,
    });
    const childTasks = React.useMemo(
        () => (selectedTask?.id ? projectTasks.filter(t => t.parent_task_id === selectedTask.id) : []),
        [projectTasks, selectedTask?.id],
    );
    // 하위 Task(상위에 연결됨)는 단계 변경 불가 — 상위와 같은 Board 단계를 유지해야 하므로.
    const isChildTask = !!selectedTask?.id && formData.parent_task_id != null;
    const parentTask = formData.parent_task_id
        ? projectTasks.find(t => t.id === formData.parent_task_id)
        : undefined;
    // 상위 후보(다단계): 같은 프로젝트의 유효 Task 중 자기 자신 + 자신의 모든 하위(descendant)를 제외.
    // 하위 Task 도 다른 Task 의 상위가 될 수 있으므로 "최상위만" 제한은 없앤다(순환은 descendant 제외로 차단).
    // + Sub Project 조건(둘 다 Sub Project 있으면 같은 Sub Project만) + 같은 Board 단계.
    const parentCandidates = React.useMemo(() => {
        if (!selectedTask?.id) return [];
        const childSub = formData.sub_project_id ?? null;
        // 같은 Board 단계 조건: 커스텀 워크플로우면 workflow_column_id, 아니면 status 로 비교.
        const childCol = formData.workflow_column_id ?? null;
        const childStatus = formData.status ?? null;
        const descendantIds = getTaskDescendantIds(selectedTask.id, projectTasks);
        return projectTasks.filter(t => {
            if (t.id === selectedTask.id) return false;         // 자기 자신 제외
            if (descendantIds.has(t.id)) return false;          // 자신의 하위(자식/손자) 제외 → 순환 차단
            if (t.task_type === 'one_off') return false;
            const parentSub = t.sub_project_id ?? null;
            if (childSub != null && parentSub != null && childSub !== parentSub) return false;
            // 같은 Board 단계(컬럼/상태)만 상위 후보로 노출
            const parentCol = t.workflow_column_id ?? null;
            if (childCol != null || parentCol != null) {
                if (childCol !== parentCol) return false;
            } else if (t.status !== childStatus) {
                return false;
            }
            return true;
        });
    }, [projectTasks, selectedTask?.id, formData.sub_project_id, formData.workflow_column_id, formData.status]);
    // 상위 작업 전체 경로(자신 제외) — 보조 문구/tooltip 용. 예: 설계 진행 > 상세 설계
    const ancestorPath = React.useMemo(
        () => (selectedTask?.id ? getTaskAncestorPath(selectedTask.id, projectTasks).slice(0, -1) : []),
        [projectTasks, selectedTask?.id],
    );
    // 후보 표시용 Sub Project 이름 맵 (동명 Task 구분 보조)
    const subProjectNameById = React.useMemo(() => {
        const m = new Map<number, string>();
        subProjects.forEach(sp => m.set(sp.id, sp.name));
        return m;
    }, [subProjects]);

    const [childAdding, setChildAdding] = useState(false);
    const [newChildTitle, setNewChildTitle] = useState('');
    const createChildMutation = useMutation({
        mutationFn: (title: string) =>
            api.createTask({
                title,
                project_id: selectedTask!.project_id,
                parent_task_id: selectedTask!.id,
                status: (selectedTask!.status as Task['status']) || 'todo',
                workflow_column_id: selectedTask!.workflow_column_id ?? null,
                sub_project_id: selectedTask!.sub_project_id ?? null,
                description: '',
                priority: 'medium',
                start_date: null,
                due_date: null,
                assignee_ids: [],
                tags: [],
                progress: 0,
            } as Omit<Task, 'id'>),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['tasks'] });
            setChildAdding(false);
            setNewChildTitle('');
            enqueueSnackbar('하위 작업이 추가되었습니다.', { variant: 'success' });
        },
        onError: (err: any) => {
            alert(err?.response?.data?.detail || '하위 작업 추가에 실패했습니다.');
        },
    });
    const deleteSubProjectMutation = useMutation({
        mutationFn: (subId: number) => api.deleteSubProject(subId),
        onSuccess: (_data, subId) => {
            // Graph/Task Details/dropdown 이 모두 최신이 되도록 관련 query 일괄 invalidate
            // (Graph 는 'subprojects'(소문자), TaskDrawer 는 'subProjects' 키를 쓰므로 둘 다 무효화)
            queryClient.invalidateQueries({ queryKey: ['subProjects', activeProjectId] });
            queryClient.invalidateQueries({ queryKey: ['subprojects', activeProjectId] });
            queryClient.invalidateQueries({ queryKey: ['graph', activeProjectId] });
            queryClient.invalidateQueries({ queryKey: ['tasks', activeProjectId] });
            queryClient.invalidateQueries({ queryKey: ['roadmap', activeProjectId] });
            // 현재 Task 가 삭제된 Sub Project 를 선택 중이었다면 '선택 안 함'으로 변경
            if (formData.sub_project_id === subId) {
                handleChange('sub_project_id', null);
            }
            setDeleteSubTarget(null);
            enqueueSnackbar('Sub Project가 삭제되었습니다.', { variant: 'success' });
        },
        onError: (err: any) => {
            enqueueSnackbar(
                err?.response?.data?.detail || 'Sub Project 삭제에 실패했습니다. 다시 시도해주세요.',
                { variant: 'error' },
            );
        },
    });

    // ── Sub Project 이름 수정 ──
    const [editSubTarget, setEditSubTarget] = useState<SubProject | null>(null);
    const [editSubName, setEditSubName] = useState('');
    const updateSubProjectMutation = useMutation({
        mutationFn: ({ id, name }: { id: number; name: string }) => api.updateSubProject(id, { name }),
        onSuccess: () => {
            // dropdown / Graph / Roadmap 등 이름이 보이는 모든 곳을 갱신.
            // 현재 선택 중인 Sub Project 이름은 subProjects refetch 후 renderValue가 자동 반영한다.
            queryClient.invalidateQueries({ queryKey: ['subProjects', activeProjectId] });
            queryClient.invalidateQueries({ queryKey: ['subprojects', activeProjectId] });
            queryClient.invalidateQueries({ queryKey: ['graph', activeProjectId] });
            queryClient.invalidateQueries({ queryKey: ['tasks', activeProjectId] });
            queryClient.invalidateQueries({ queryKey: ['roadmap', activeProjectId] });
            setEditSubTarget(null);
            enqueueSnackbar('Sub Project 이름이 수정되었습니다.', { variant: 'success' });
        },
        onError: (err: any) => {
            enqueueSnackbar(
                err?.response?.data?.detail || 'Sub Project 이름 수정에 실패했습니다. 다시 시도해주세요.',
                { variant: 'error' },
            );
        },
    });
    const handleEditSubSave = () => {
        if (!editSubTarget) return;
        const name = editSubName.trim();
        if (!name) {
            enqueueSnackbar('Sub Project 이름을 입력해주세요.', { variant: 'warning' });
            return;
        }
        if (name === (editSubTarget.name || '').trim()) { setEditSubTarget(null); return; } // 변경 없음
        const dup = subProjects.some(
            sp => sp.id !== editSubTarget.id && (sp.name || '').trim().toLowerCase() === name.toLowerCase(),
        );
        if (dup) {
            enqueueSnackbar('이미 같은 이름의 Sub Project가 있습니다.', { variant: 'error' });
            return;
        }
        updateSubProjectMutation.mutate({ id: editSubTarget.id, name });
    };

    // ── Description 확대 편집 팝업 (적용 = form state 반영, 실제 저장은 Save Changes) ──
    const [descExpandOpen, setDescExpandOpen] = useState(false);
    const [descDraft, setDescDraft] = useState('');

    const [searchParams, setSearchParams] = useSearchParams();

    // @멘션 링크에서 작업노트 자동 열기
    useEffect(() => {
        if (searchParams.get('openWorkNote') === '1' && selectedTask && isDrawerOpen) {
            setWorkNoteOpen(true);
            // 파라미터 정리
            const newParams = new URLSearchParams(searchParams);
            newParams.delete('openWorkNote');
            newParams.delete('openTask');
            setSearchParams(newParams, { replace: true });
        }
    }, [selectedTask, isDrawerOpen, searchParams, setSearchParams]);

    // ── Comments 전용 화면 전환 (accordion이 아니라 body 영역만 교체) ──
    const [showComments, setShowComments] = useState(false);
    // 헤더 배지 카운트 + 전용 화면이 같은 캐시(queryKey)를 공유한다.
    const { data: commentsData, isLoading: commentsLoading } = useQuery({
        queryKey: ['taskComments', selectedTask?.id],
        queryFn: () => api.getTaskComments(selectedTask!.id),
        enabled: !!selectedTask?.id,
    });
    const taskComments: TaskComment[] = (commentsData?.items || []).filter((c: TaskComment) => !c.deleted);
    const canComment: boolean = commentsData?.can_comment ?? true;
    // Task 전환 / 드로어 open 변화 시 항상 Details 화면부터 (아래 자동열기 effect가 필요 시 덮어씀)
    useEffect(() => {
        setShowComments(false);
    }, [selectedTask?.id, isDrawerOpen]);
    // @멘션(작업댓글) 링크에서 진입 시 Comments 화면 자동 전환
    useEffect(() => {
        if (searchParams.get('openComments') === '1' && selectedTask && isDrawerOpen) {
            setShowComments(true);
            const newParams = new URLSearchParams(searchParams);
            newParams.delete('openComments');
            newParams.delete('openTask');
            setSearchParams(newParams, { replace: true });
        }
    }, [selectedTask, isDrawerOpen, searchParams, setSearchParams]);

    // Comments 화면은 기존 Task(id 존재)에서만 의미가 있다.
    const showCommentsView = showComments && !!selectedTask?.id;

    const checkboxActivities = activities.filter(a => (a.block_type || 'checkbox') === 'checkbox');
    const activityProgress = checkboxActivities.length > 0
        ? Math.round(checkboxActivities.filter(a => a.checked).length / checkboxActivities.length * 100)
        : null;
    const displayProgress = activityProgress !== null ? activityProgress : (formData.progress || 0);

    const handleChange = (field: keyof Task, value: any) => {
        setFormData((prev) => ({ ...prev, [field]: value }));
    };

    // 일정 "미정(TBD)" 토글: 체크 시 대응 날짜를 비우고, 해제 시 날짜 입력을 다시 허용.
    const handleTbdToggle = (which: 'start' | 'due', checked: boolean) => {
        setFormData((prev) => {
            if (which === 'start') {
                return { ...prev, start_date_tbd: checked, start_date: checked ? null : prev.start_date };
            }
            return { ...prev, due_date_tbd: checked, due_date: checked ? null : prev.due_date };
        });
    };

    // 추천 날짜 적용: 해당 날짜를 설정하고 미정(TBD) 해제.
    const applyDateSuggestion = (which: 'start' | 'due', date: string) => {
        setFormData((prev) => {
            if (which === 'start') return { ...prev, start_date_tbd: false, start_date: date };
            return { ...prev, due_date_tbd: false, due_date: date };
        });
    };

    // Sub Project 변경 시 상하 관계(Sub Project 조건) 정합성 유지:
    //  - 내가 자식인데 새 Sub Project 가 상위와 충돌 → 상위 연결 자동 해제 + 안내
    //  - 내가 부모(자식 보유)면 저장 시 충돌 child 가 해제될 수 있음을 경고
    // (백엔드에서도 동일 규칙으로 최종 정리 — FE 는 UI 정합/안내만 담당)
    const handleSubProjectChange = (newSub: number | null) => {
        handleChange('sub_project_id', newSub);
        if (formData.parent_task_id) {
            const parent = projectTasks.find(t => t.id === formData.parent_task_id);
            const parentSub = parent?.sub_project_id ?? null;
            if (newSub != null && parentSub != null && newSub !== parentSub) {
                handleChange('parent_task_id', null);
                enqueueSnackbar('Sub Project가 변경되어 상위 Task 연결이 해제됩니다.', { variant: 'info' });
            }
        }
        if (childTasks.length > 0) {
            const willBreak = childTasks.some(c => {
                const cs = c.sub_project_id ?? null;
                return newSub != null && cs != null && newSub !== cs;
            });
            if (willBreak) {
                enqueueSnackbar('Sub Project 변경으로 일부 하위 Task 연결이 저장 시 해제될 수 있습니다.', { variant: 'warning' });
            }
        }
    };

    // 신규 Task 생성 시: 입력 원문은 제목으로 보존하고, 명확한 일정 문법
    // ([마감: …] / 제목 | 마감: …)이 있을 때만 일정을 분리한다. (자연어 추정 금지)
    const handleTitleBlur = () => {
        if (selectedTask) return; // only for new tasks
        const title = formData.title || '';
        if (!title.trim()) return;
        const parsed = parseQuickAddInput(title);
        if ((parsed.startDate || parsed.endDate) && parsed.title !== title.trim()) {
            setFormData(prev => ({
                ...prev,
                title: parsed.title,
                start_date: parsed.startDate || prev.start_date,
                due_date: parsed.endDate || prev.due_date,
            }));
        }
        // Auto-assign current user if no assignees yet
        if (selectedAssignees.length === 0 && currentUserId > 0 && users.length > 0) {
            const me = users.find(u => u.id === currentUserId);
            if (me) setSelectedAssignees([me]);
        }
    };

    const buildTags = (base: string[]) => {
        const t = new Set(base);
        if (isIssue) t.add('이슈'); else t.delete('이슈');
        if (isSpecial) t.add('특이사항'); else t.delete('특이사항');
        return Array.from(t);
    };

    const handleSave = () => {
        const assigneeIds = selectedAssignees.map(u => u.id);
        const tags = buildTags(formData.tags || []);
        if (selectedTask && selectedTask.id) {
            updateMutation.mutate({ ...formData, assignee_ids: assigneeIds, tags });
        } else {
            const currentTitle = formData.title || 'Untitled Task';
            const pid = formData.project_id || drawerProjectId;
            const newTask: Omit<Task, 'id'> = {
                title: currentTitle,
                project_id: pid,
                status: (formData.status as Task['status']) || 'todo',
                description: formData.description || '',
                priority: (formData.priority as Task['priority']) || 'medium',
                start_date: formData.start_date_tbd ? null : (formData.start_date || null),
                due_date: formData.due_date_tbd ? null : (formData.due_date || null),
                start_date_tbd: !!formData.start_date_tbd,
                due_date_tbd: !!formData.due_date_tbd,
                assignee_ids: assigneeIds,
                tags,
                progress: formData.progress || 0,
                sub_project_id: formData.sub_project_id || null,
            };
            if (createFollowUp) {
                pendingFollowUpRef.current = { title: `[후속] ${currentTitle}`, projectId: pid };
            }
            createMutation.mutate(newTask);
        }
    };

    const handleDelete = () => {
        if (selectedTask?.id) {
            deleteMutation.mutate(selectedTask.id);
        }
    };

    const statusOptions = [
        { value: 'todo', label: 'To Do', color: planAiColors.text.tertiary },
        { value: 'in_progress', label: 'In Progress', color: planAiColors.brand.primary },
        { value: 'done', label: 'Done', color: planAiColors.status.success },
        { value: 'hold', label: 'Hold', color: planAiColors.status.warning },
    ];

    // CUSTOM 워크플로우 — Status 대신 "작업 단계" 드롭다운 표시
    const effProjectId = selectedTask?.project_id || formData.project_id || drawerProjectId;
    const { data: workflow } = useWorkflow(isDrawerOpen ? effProjectId : undefined);
    const isCustomWorkflow = workflow?.mode === 'CUSTOM' && (workflow.columns?.length ?? 0) > 0;
    const workflowColumns = React.useMemo(
        () => (workflow?.columns ? [...workflow.columns].sort((a, b) => a.sort_order - b.sort_order) : []),
        [workflow],
    );
    const handleWorkflowStageChange = (colId: number) => {
        const col = workflowColumns.find(c => c.id === colId);
        handleChange('workflow_column_id', colId);
        // 새 Task 생성 시 status 기준으로 컬럼 배치되므로 mapped_status도 맞춰둔다.
        if (col) handleChange('status', col.mapped_status);
    };

    // ── 단계 완료 선언(현재 단계) ──
    const currentStageColumn = React.useMemo(
        () => workflowColumns.find(c => c.id === formData.workflow_column_id) ?? null,
        [workflowColumns, formData.workflow_column_id],
    );
    const nextStageColumn = React.useMemo(() => {
        const flow = workflowColumns.filter(c => c.mapped_status !== 'hold');
        const idx = flow.findIndex(c => c.id === formData.workflow_column_id);
        return idx >= 0 && idx < flow.length - 1 ? flow[idx + 1] : null;
    }, [workflowColumns, formData.workflow_column_id]);
    const stageAutoMove = currentStageColumn?.auto_move_on_complete ?? true;
    const currentStageCompleted = (selectedTask as any)?.current_stage_completed ?? false;

    const priorityOptions = [
        { value: 'low', label: 'Low', color: planAiColors.text.tertiary },
        { value: 'medium', label: 'Medium', color: planAiColors.brand.primary },
        { value: 'high', label: 'High', color: planAiColors.status.danger },
    ];

    const canEdit = !isViewer;

    return (
        <Drawer
            anchor="right"
            open={isDrawerOpen}
            onClose={closeDrawer}
            PaperProps={{ sx: { width: 560, p: 0, bgcolor: '#fff' } }}
        >
            {/* Header */}
            <Box sx={{
                p: 2.5, display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                borderBottom: `1px solid ${planAiColors.border.soft}`, bgcolor: planAiColors.background.surfaceAlt,
            }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem' }}>
                        {selectedTask ? 'Task Details' : 'New Task'}
                    </Typography>
                    {isViewer && (
                        <Chip label="Viewer (읽기 전용)" size="small" sx={{ fontSize: '0.65rem', bgcolor: planAiColors.background.surfaceAlt, color: planAiColors.text.tertiary }} />
                    )}
                </Box>
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                    {selectedTask?.id && !showCommentsView && (
                        <Button
                            size="small"
                            onClick={() => setShowComments(true)}
                            startIcon={<ChatBubbleOutlineIcon sx={{ fontSize: '0.95rem !important' }} />}
                            sx={{
                                textTransform: 'none', fontWeight: 600, fontSize: '0.78rem',
                                color: planAiColors.brand.primary, borderRadius: 1.5, px: 1,
                                bgcolor: planAiColors.brand.primarySoft,
                                '&:hover': { bgcolor: planAiColors.brand.primaryBorder },
                            }}
                        >
                            Comments ({taskComments.length})
                        </Button>
                    )}
                    {selectedTask && canEdit && activeProject?.space_id && (
                        <Tooltip title="다른 Project로 이동" arrow>
                            <IconButton size="small" onClick={() => setMoveDialogOpen(true)} sx={{ color: planAiColors.text.tertiary }}>
                                <DriveFileMoveOutlinedIcon fontSize="small" />
                            </IconButton>
                        </Tooltip>
                    )}
                    {selectedTask && canEdit && (
                        <IconButton size="small" onClick={handleDelete} sx={{ color: planAiColors.status.danger }}>
                            <DeleteOutlineIcon fontSize="small" />
                        </IconButton>
                    )}
                    <IconButton size="small" onClick={closeDrawer}>
                        <CloseIcon fontSize="small" />
                    </IconButton>
                </Box>
            </Box>

            {/* Body — Details 화면과 Comments 전용 화면을 '전환'(accordion 아님)으로 표시 */}
            <Box
                sx={{
                    p: 3, flexGrow: 1, minHeight: 0,
                    ...(showCommentsView
                        ? { display: 'flex', flexDirection: 'column', overflowY: 'hidden' }
                        : { overflowY: 'auto' }),
                }}
            >
                {showCommentsView && selectedTask?.id ? (
                    <TaskCommentsView
                        taskId={selectedTask.id}
                        comments={taskComments}
                        isLoading={commentsLoading}
                        canComment={canComment}
                        projectId={selectedTask.project_id}
                        onBack={() => setShowComments(false)}
                    />
                ) : (
                <Stack spacing={3}>
                    {/* Title */}
                    <TextField
                        placeholder={selectedTask ? "Task title..." : "예: 개선 아이템 3월~10월"}
                        fullWidth
                        value={formData.title || ''}
                        onChange={(e) => handleChange('title', e.target.value)}
                        onBlur={handleTitleBlur}
                        variant="standard"
                        InputProps={{
                            disableUnderline: true,
                            sx: { fontSize: '1.3rem', fontWeight: 700 },
                            readOnly: !canEdit,
                        }}
                        helperText={!selectedTask && !formData.title ? '일정을 포함하면 자동 설정됩니다 (예: 3~10, 3/10~10/20)' : undefined}
                        FormHelperTextProps={{ sx: { fontSize: '0.68rem', color: planAiColors.text.muted, mt: 0.5 } }}
                        autoFocus={!selectedTask}
                    />

                    <Divider />

                    {/* Project Selection (Calendar Create Task only) */}
                    {isCalendarCreateMode && (
                        <Box>
                            <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem', mb: 1, display: 'block' }}>
                                Project *
                            </Typography>
                            <TextField
                                select
                                fullWidth
                                size="small"
                                value={formData.project_id || ''}
                                onChange={(e) => handleChange('project_id', Number(e.target.value))}
                                disabled={!canEdit}
                                SelectProps={{ displayEmpty: true }}
                                error={!formData.project_id}
                                helperText={!formData.project_id ? '프로젝트를 선택해주세요' : ''}
                            >
                                <MenuItem value="" disabled>
                                    <Typography sx={{ color: planAiColors.text.muted, fontSize: '0.85rem' }}>프로젝트 선택</Typography>
                                </MenuItem>
                                {spaceProjects.length === 0 ? (
                                    <MenuItem value="" disabled>
                                        <Typography sx={{ fontSize: '0.85rem' }}>먼저 프로젝트를 생성해주세요</Typography>
                                    </MenuItem>
                                ) : (
                                    spaceProjects.map(p => (
                                        <MenuItem key={p.id} value={p.id}>
                                            {p.name}
                                        </MenuItem>
                                    ))
                                )}
                            </TextField>
                        </Box>
                    )}

                    {/* Status & Priority */}
                    <Box data-tour="status-priority-section">
                        <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem', mb: 1, display: 'block' }}>
                            Status & Priority
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 2 }}>
                            {isCustomWorkflow ? (
                                <TextField
                                    data-tour="status-select"
                                    select label="작업 단계" fullWidth size="small"
                                    value={formData.workflow_column_id ?? ''}
                                    onChange={(e) => handleWorkflowStageChange(Number(e.target.value))}
                                    disabled={!canEdit || isChildTask}
                                >
                                    {workflowColumns.map(col => (
                                        <MenuItem key={col.id} value={col.id}>
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: col.color || planAiColors.brand.primary }} />
                                                {col.label}
                                            </Box>
                                        </MenuItem>
                                    ))}
                                </TextField>
                            ) : (
                                <TextField
                                    data-tour="status-select"
                                    select label="Status" fullWidth size="small"
                                    value={formData.status || 'todo'}
                                    onChange={(e) => handleChange('status', e.target.value)}
                                    disabled={!canEdit || isChildTask}
                                >
                                    {statusOptions.map(opt => (
                                        <MenuItem key={opt.value} value={opt.value}>
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: opt.color }} />
                                                {opt.label}
                                            </Box>
                                        </MenuItem>
                                    ))}
                                </TextField>
                            )}
                            <TextField
                                data-tour="priority-select"
                                select label="Priority" fullWidth size="small"
                                value={formData.priority || 'medium'}
                                onChange={(e) => handleChange('priority', e.target.value)}
                                disabled={!canEdit}
                            >
                                {priorityOptions.map(opt => (
                                    <MenuItem key={opt.value} value={opt.value}>
                                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                            <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: opt.color }} />
                                            {opt.label}
                                        </Box>
                                    </MenuItem>
                                ))}
                            </TextField>
                        </Box>
                        {isChildTask && (
                            <Typography variant="caption" sx={{ color: planAiColors.text.muted, display: 'block', mt: 0.75 }}>
                                이 Task는 상위 Task에 연결되어 있어 단계를 변경할 수 없습니다. 다른 단계로 옮기려면 아래에서 <strong>상위 Task 연결을 해제</strong>한 뒤 저장하세요.
                            </Typography>
                        )}

                        {/* 단계 완료 선언 — 사용자가 현재 단계 완료를 체크 (CUSTOM, 기존 Task, 하위 아님) */}
                        {isCustomWorkflow && !!selectedTask?.id && !isChildTask && currentStageColumn && (
                            <Box
                                sx={{
                                    mt: 1.25, p: 1.25, borderRadius: 2,
                                    border: `1px solid ${currentStageCompleted ? planAiColors.status.success : planAiColors.border.soft}`,
                                    bgcolor: currentStageCompleted ? `${planAiColors.status.success}0D` : planAiColors.background.surfaceAlt,
                                }}
                            >
                                <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
                                    <Checkbox
                                        size="small"
                                        checked={currentStageCompleted}
                                        disabled={!canEdit || stageCompletionMut.isPending}
                                        onChange={(e) => stageCompletionMut.mutate(e.target.checked)}
                                        sx={{ p: 0.25, mt: -0.25 }}
                                    />
                                    <Box sx={{ minWidth: 0 }}>
                                        <Typography sx={{ fontSize: '0.82rem', fontWeight: 600, color: planAiColors.text.primary }}>
                                            {currentStageColumn.label} 완료
                                        </Typography>
                                        <Typography sx={{ fontSize: '0.7rem', color: planAiColors.text.muted, mt: 0.1 }}>
                                            {!nextStageColumn
                                                ? '체크 시 → 최종 완료 처리 (다음 단계 없음)'
                                                : stageAutoMove
                                                    ? `체크 시 → '${nextStageColumn.label}' 단계로 이동`
                                                    : '체크 시 → 현재 단계에 유지'}
                                        </Typography>
                                    </Box>
                                </Box>
                            </Box>
                        )}
                    </Box>

                    {/* SubProject — 선택 + 인라인 생성 (Task 작성 흐름을 끊지 않음) */}
                    {!!activeProjectId && (
                    <Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                            <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem', display: 'block' }}>
                                Sub Project
                            </Typography>
                            {canEdit && !subProjectAdding && (
                                <Button
                                    size="small"
                                    startIcon={<AddIcon sx={{ fontSize: '0.85rem' }} />}
                                    onClick={() => setSubProjectAdding(true)}
                                    sx={{ textTransform: 'none', fontSize: '0.7rem', fontWeight: 600, color: planAiColors.brand.primary, py: 0, minWidth: 0 }}
                                >
                                    새 Sub Project
                                </Button>
                            )}
                        </Box>

                        {subProjects.length > 0 && (
                            <TextField
                                data-tour="subproject-select"
                                select
                                fullWidth
                                size="small"
                                value={formData.sub_project_id || ''}
                                onChange={(e) => handleSubProjectChange(e.target.value ? Number(e.target.value) : null)}
                                disabled={!canEdit}
                                SelectProps={{
                                    displayEmpty: true,
                                    open: subSelectOpen,
                                    onOpen: () => setSubSelectOpen(true),
                                    onClose: () => setSubSelectOpen(false),
                                    // 닫힌 상태에는 삭제 아이콘 없이 이름만 표시 (option 안의 휴지통이 필드에 노출되지 않도록)
                                    renderValue: (val: any) => {
                                        const sel = subProjects.find(sp => sp.id === Number(val));
                                        if (!sel) {
                                            return <Typography sx={{ color: planAiColors.text.muted, fontSize: '0.85rem' }}>선택 안 함</Typography>;
                                        }
                                        return <span>{sel.name}</span>;
                                    },
                                }}
                            >
                                <MenuItem value="">
                                    <Typography sx={{ color: planAiColors.text.muted, fontSize: '0.85rem' }}>선택 안 함</Typography>
                                </MenuItem>
                                {subProjects.map(sp => (
                                    <MenuItem
                                        key={sp.id}
                                        value={sp.id}
                                        sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1, pr: 1 }}
                                    >
                                        <Box component="span" sx={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                            {sp.name}
                                        </Box>
                                        {canEdit && (
                                            <Box component="span" sx={{ display: 'flex', alignItems: 'center', gap: 0.25, flexShrink: 0 }}>
                                                <Tooltip title="Sub Project 이름 수정">
                                                    <IconButton
                                                        size="small"
                                                        // 수정 클릭이 dropdown 선택(MenuItem onClick)으로 번지지 않게 차단
                                                        onMouseDown={(e) => { e.stopPropagation(); }}
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            e.preventDefault();
                                                            setSubSelectOpen(false);  // 메뉴 닫고 수정 dialog 표시
                                                            setEditSubTarget(sp);
                                                            setEditSubName(sp.name || '');
                                                        }}
                                                        sx={{ p: 0.3, color: planAiColors.text.muted, '&:hover': { color: planAiColors.brand.primary } }}
                                                    >
                                                        <EditOutlinedIcon sx={{ fontSize: '1rem' }} />
                                                    </IconButton>
                                                </Tooltip>
                                                <Tooltip title="Sub Project 삭제">
                                                    <IconButton
                                                        size="small"
                                                        // 휴지통 클릭이 dropdown 선택(MenuItem onClick)으로 번지지 않게 차단
                                                        onMouseDown={(e) => { e.stopPropagation(); }}
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            e.preventDefault();
                                                            setSubSelectOpen(false);  // 메뉴 닫고 확인 dialog 표시
                                                            setDeleteSubTarget(sp);
                                                        }}
                                                        sx={{ p: 0.3, color: planAiColors.text.muted, '&:hover': { color: planAiColors.status.danger } }}
                                                    >
                                                        <DeleteOutlineIcon sx={{ fontSize: '1rem' }} />
                                                    </IconButton>
                                                </Tooltip>
                                            </Box>
                                        )}
                                    </MenuItem>
                                ))}
                            </TextField>
                        )}

                        {canEdit && subProjects.length === 0 && !subProjectAdding && (
                            <Typography variant="caption" sx={{ color: planAiColors.text.muted, display: 'block' }}>
                                아직 Sub Project가 없습니다. "새 Sub Project"로 바로 만들 수 있어요.
                            </Typography>
                        )}

                        {/* 인라인 생성 폼 */}
                        {canEdit && subProjectAdding && (
                            <Box sx={{ mt: 1, p: 1.2, borderRadius: 1.5, border: `1px solid ${planAiColors.border.soft}`, bgcolor: planAiColors.background.surfaceAlt }}>
                                <TextField
                                    autoFocus
                                    fullWidth
                                    size="small"
                                    placeholder="Sub Project 이름 (필수)"
                                    value={newSubProjectName}
                                    onChange={(e) => setNewSubProjectName(e.target.value)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') { e.preventDefault(); handleCreateSubProject(); }
                                        if (e.key === 'Escape') { e.preventDefault(); setSubProjectAdding(false); }
                                    }}
                                    sx={{ mb: 1 }}
                                />
                                <TextField
                                    fullWidth
                                    size="small"
                                    placeholder="설명 (선택)"
                                    value={newSubProjectDesc}
                                    onChange={(e) => setNewSubProjectDesc(e.target.value)}
                                    sx={{ mb: 1 }}
                                />
                                <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                                    <Button
                                        size="small"
                                        onClick={() => { setSubProjectAdding(false); }}
                                        disabled={createSubProjectMutation.isPending}
                                        sx={{ textTransform: 'none', color: planAiColors.text.tertiary }}
                                    >
                                        취소
                                    </Button>
                                    <Button
                                        size="small"
                                        variant="contained"
                                        onClick={handleCreateSubProject}
                                        disabled={!newSubProjectName.trim() || createSubProjectMutation.isPending}
                                        sx={{ textTransform: 'none', bgcolor: planAiColors.brand.primary }}
                                    >
                                        {createSubProjectMutation.isPending ? '생성 중…' : '생성 후 선택'}
                                    </Button>
                                </Box>
                            </Box>
                        )}
                    </Box>
                    )}

                    {/* 상위 Task / 하위 Task (Parent / Child) — 기존 Task 편집 시에만, 단발 일정 제외 */}
                    {!!selectedTask?.id && !!activeProjectId && selectedTask.task_type !== 'one_off' && (
                    <Box>
                        {/* ── 상위 작업: 현재 Task 의 parent 선택 (다단계 허용 — 하위 작업도 상위를 가질 수 있음) ── */}
                        <>
                                <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem', display: 'block', mb: 1 }}>
                                    상위 작업
                                </Typography>
                                <TextField
                                    select
                                    fullWidth
                                    size="small"
                                    value={formData.parent_task_id ?? ''}
                                    onChange={(e) => handleChange('parent_task_id', e.target.value === '' ? null : Number(e.target.value))}
                                    disabled={!canEdit}
                                    SelectProps={{
                                        displayEmpty: true,
                                        renderValue: (val: any) => {
                                            const sel = parentCandidates.find(t => t.id === Number(val)) || parentTask;
                                            if (!sel) return <Typography sx={{ color: planAiColors.text.muted, fontSize: '0.85rem' }}>선택 안 함 (최상위 작업)</Typography>;
                                            return <span>{sel.title}</span>;
                                        },
                                    }}
                                >
                                    <MenuItem value="">
                                        <Typography sx={{ color: planAiColors.text.muted, fontSize: '0.85rem' }}>선택 안 함 (최상위 작업)</Typography>
                                    </MenuItem>
                                    {parentCandidates.map(t => {
                                        const subName = t.sub_project_id ? subProjectNameById.get(t.sub_project_id) : null;
                                        return (
                                            <MenuItem key={t.id} value={t.id} sx={{ fontSize: '0.85rem', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 0.1, py: 0.6 }}>
                                                <span style={{ maxWidth: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.title}</span>
                                                {subName && (
                                                    <Typography sx={{ fontSize: '0.65rem', color: planAiColors.text.muted }}>
                                                        {subName}
                                                    </Typography>
                                                )}
                                            </MenuItem>
                                        );
                                    })}
                                </TextField>
                                {ancestorPath.length > 0 && (
                                    <Tooltip title={ancestorPath.map(a => a.title).join(' > ')} arrow>
                                        <Typography variant="caption" sx={{ color: planAiColors.text.tertiary, display: 'block', mt: 0.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                            상위 경로: {ancestorPath.map(a => a.title).join(' > ')}
                                        </Typography>
                                    </Tooltip>
                                )}
                                <Typography variant="caption" sx={{ color: planAiColors.text.muted, display: 'block', mt: 0.5 }}>
                                    상위 작업은 <strong>같은 Board 단계</strong>의 작업만 선택할 수 있습니다.
                                    {formData.parent_task_id != null && <> 변경/해제는 <strong>저장</strong> 시 반영됩니다.</>}
                                </Typography>
                        </>

                        {/* 하위 작업 목록 + 추가 — 다단계: 자식 Task 도 다시 하위 작업을 가질 수 있음 */}
                        {(
                            <Box sx={{ mt: 1.5 }}>
                                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: childTasks.length > 0 ? 1 : 0 }}>
                                    <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem' }}>
                                        하위 작업 {childTasks.length > 0 ? `· ${childTasks.length}개` : ''}
                                    </Typography>
                                    {canEdit && !childAdding && (
                                        <Button
                                            size="small"
                                            startIcon={<AddIcon sx={{ fontSize: '0.85rem' }} />}
                                            onClick={() => setChildAdding(true)}
                                            sx={{ textTransform: 'none', fontSize: '0.7rem', fontWeight: 600, color: planAiColors.brand.primary, py: 0, minWidth: 0 }}
                                        >
                                            하위 작업 추가
                                        </Button>
                                    )}
                                </Box>

                                <Stack spacing={0.75}>
                                    {childTasks.map(c => (
                                        <Box
                                            key={c.id}
                                            onClick={() => openDrawer(c, c.project_id)}
                                            sx={{
                                                display: 'flex', alignItems: 'center', gap: 1,
                                                p: 1, borderRadius: 1.5,
                                                border: `1px solid ${planAiColors.border.soft}`,
                                                bgcolor: planAiColors.background.surfaceAlt,
                                                cursor: 'pointer',
                                                '&:hover': { borderColor: planAiColors.brand.primary },
                                            }}
                                        >
                                            <SubdirectoryArrowRightIcon sx={{ fontSize: '1rem', color: planAiColors.text.muted, flexShrink: 0 }} />
                                            <Typography sx={{ flex: 1, minWidth: 0, fontSize: '0.82rem', color: planAiColors.text.primary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                {c.title}
                                            </Typography>
                                            {c.due_date && (
                                                <Typography sx={{ fontSize: '0.68rem', color: planAiColors.text.muted, flexShrink: 0 }}>
                                                    {c.due_date}
                                                </Typography>
                                            )}
                                        </Box>
                                    ))}
                                </Stack>

                                {canEdit && childAdding && (
                                    <Box sx={{ mt: 1, p: 1.2, borderRadius: 1.5, border: `1px solid ${planAiColors.border.soft}`, bgcolor: planAiColors.background.surfaceAlt }}>
                                        <TextField
                                            autoFocus
                                            fullWidth
                                            size="small"
                                            placeholder="하위 작업 제목 (필수)"
                                            value={newChildTitle}
                                            onChange={(e) => setNewChildTitle(e.target.value)}
                                            onKeyDown={(e) => {
                                                if (e.key === 'Enter' && newChildTitle.trim()) { e.preventDefault(); createChildMutation.mutate(newChildTitle.trim()); }
                                                if (e.key === 'Escape') { e.preventDefault(); setChildAdding(false); setNewChildTitle(''); }
                                            }}
                                            sx={{ mb: 1 }}
                                        />
                                        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                                            <Button
                                                size="small"
                                                onClick={() => { setChildAdding(false); setNewChildTitle(''); }}
                                                disabled={createChildMutation.isPending}
                                                sx={{ textTransform: 'none', color: planAiColors.text.tertiary }}
                                            >
                                                취소
                                            </Button>
                                            <Button
                                                size="small"
                                                variant="contained"
                                                onClick={() => createChildMutation.mutate(newChildTitle.trim())}
                                                disabled={!newChildTitle.trim() || createChildMutation.isPending}
                                                sx={{ textTransform: 'none', bgcolor: planAiColors.brand.primary }}
                                            >
                                                {createChildMutation.isPending ? '추가 중…' : '추가'}
                                            </Button>
                                        </Box>
                                    </Box>
                                )}
                            </Box>
                        )}
                    </Box>
                    )}

                    {/* Sub Project 삭제 확인 — Graph 페이지와 동일한 정책/문구 */}
                    <Dialog
                        open={!!deleteSubTarget}
                        onClose={() => setDeleteSubTarget(null)}
                        maxWidth="xs"
                        fullWidth
                        PaperProps={{ sx: { borderRadius: 3 } }}
                    >
                        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', color: planAiColors.status.danger }}>
                            Sub Project 삭제
                        </DialogTitle>
                        <DialogContent>
                            <Typography variant="body2" sx={{ color: planAiColors.text.secondary, fontSize: '0.9rem' }}>
                                <strong>"{deleteSubTarget?.name}"</strong> 을(를) 삭제하시겠습니까?
                            </Typography>
                            <Typography variant="body2" sx={{ color: planAiColors.text.muted, fontSize: '0.85rem', mt: 1 }}>
                                하위 Task는 삭제되지 않고 프로젝트 직속으로 이동됩니다.
                            </Typography>
                        </DialogContent>
                        <DialogActions sx={{ px: 3, pb: 2 }}>
                            <Button
                                onClick={() => setDeleteSubTarget(null)}
                                sx={{ textTransform: 'none', color: planAiColors.text.tertiary }}
                            >
                                취소
                            </Button>
                            <Button
                                variant="contained"
                                onClick={() => { if (deleteSubTarget) deleteSubProjectMutation.mutate(deleteSubTarget.id); }}
                                disabled={deleteSubProjectMutation.isPending}
                                sx={{ textTransform: 'none', bgcolor: planAiColors.status.danger, '&:hover': { bgcolor: '#DC2626' } }}
                            >
                                {deleteSubProjectMutation.isPending ? '삭제 중…' : '삭제'}
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Sub Project 이름 수정 */}
                    <Dialog
                        open={!!editSubTarget}
                        onClose={() => setEditSubTarget(null)}
                        maxWidth="xs"
                        fullWidth
                        PaperProps={{ sx: { borderRadius: 3 } }}
                    >
                        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>Sub Project 이름 수정</DialogTitle>
                        <DialogContent>
                            <TextField
                                autoFocus
                                fullWidth
                                size="small"
                                label="이름"
                                value={editSubName}
                                onChange={(e) => setEditSubName(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') { e.preventDefault(); handleEditSubSave(); }
                                    if (e.key === 'Escape') { e.preventDefault(); setEditSubTarget(null); }
                                }}
                                sx={{ mt: 1 }}
                            />
                        </DialogContent>
                        <DialogActions sx={{ px: 3, pb: 2 }}>
                            <Button
                                onClick={() => setEditSubTarget(null)}
                                sx={{ textTransform: 'none', color: planAiColors.text.tertiary }}
                            >
                                취소
                            </Button>
                            <Button
                                variant="contained"
                                onClick={handleEditSubSave}
                                disabled={!editSubName.trim() || updateSubProjectMutation.isPending}
                                sx={{ textTransform: 'none', bgcolor: planAiColors.brand.primary }}
                            >
                                {updateSubProjectMutation.isPending ? '저장 중…' : '저장'}
                            </Button>
                        </DialogActions>
                    </Dialog>

                    {/* Progress + Work Note */}
                    <Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
                            <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem' }}>
                                Progress: {displayProgress}%
                                {activityProgress !== null && (
                                    <Chip label="자동 계산" size="small" sx={{ ml: 1, height: 16, fontSize: '0.55rem', bgcolor: planAiColors.brand.primarySoft, color: planAiColors.brand.primary }} />
                                )}
                            </Typography>
                            <Tooltip title={selectedTask?.id ? "작업노트 열기" : "저장 후 작성 가능합니다"} arrow>
                                <span>
                                    <Button
                                        data-tour="work-note-btn"
                                        size="small"
                                        startIcon={<EditNoteIcon sx={{ fontSize: '0.9rem' }} />}
                                        onClick={() => setWorkNoteOpen(true)}
                                        disabled={!selectedTask?.id}
                                        sx={{
                                            textTransform: 'none', fontSize: '0.7rem', fontWeight: 600,
                                            color: planAiColors.brand.primary, borderRadius: 2, px: 1.2, py: 0.3,
                                            bgcolor: planAiColors.brand.primarySoft,
                                            '&:hover': { bgcolor: planAiColors.brand.primaryBorder },
                                            '&.Mui-disabled': { bgcolor: planAiColors.background.surfaceAlt, color: planAiColors.text.muted }
                                        }}
                                    >
                                        작업노트
                                        {checkboxActivities.length > 0 && (
                                            <Chip
                                                label={`${checkboxActivities.filter(a => a.checked).length}/${checkboxActivities.length}`}
                                                size="small"
                                                sx={{ ml: 0.5, height: 16, fontSize: '0.55rem', bgcolor: 'rgba(41,85,255,0.15)', color: planAiColors.brand.primary }}
                                            />
                                        )}
                                    </Button>
                                </span>
                            </Tooltip>
                        </Box>

                        {activityProgress !== null ? (
                            <Box
                                onClick={() => selectedTask?.id && setWorkNoteOpen(true)}
                                sx={{ cursor: selectedTask?.id ? 'pointer' : 'default', borderRadius: 1, p: 0.5, mx: -0.5, '&:hover': selectedTask?.id ? { bgcolor: planAiColors.brand.primarySoft } : {} }}
                            >
                                <LinearProgress
                                    variant="determinate"
                                    value={displayProgress}
                                    sx={{
                                        height: 8, borderRadius: 4,
                                        bgcolor: planAiColors.border.soft,
                                        '& .MuiLinearProgress-bar': { bgcolor: displayProgress >= 100 ? planAiColors.status.success : planAiColors.brand.primary, borderRadius: 4 },
                                    }}
                                />
                            </Box>
                        ) : (
                            <Slider
                                value={formData.progress || 0}
                                onChange={(_, v) => handleChange('progress', v as number)}
                                min={0} max={100} step={5}
                                disabled={!canEdit}
                                sx={{
                                    color: planAiColors.brand.primary,
                                    '& .MuiSlider-thumb': { width: 16, height: 16 },
                                    '& .MuiSlider-track': { height: 6 },
                                    '& .MuiSlider-rail': { height: 6 },
                                }}
                            />
                        )}
                    </Box>

                    {/* Assignees */}
                    <Box>
                        <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem', mb: 1, display: 'block' }}>
                            Assignees
                        </Typography>
                        <Autocomplete
                            multiple
                            size="small"
                            options={users}
                            disableCloseOnSelect
                            value={selectedAssignees}
                            onChange={(_, newValue) => setSelectedAssignees(newValue)}
                            getOptionLabel={(option) => option.username}
                            isOptionEqualToValue={(option, value) => option.id === value.id}
                            disabled={!canEdit}
                            renderOption={(props, option, { selected }) => (
                                <li {...props}>
                                    <Checkbox
                                        icon={icon}
                                        checkedIcon={checkedIcon}
                                        style={{ marginRight: 8 }}
                                        checked={selected}
                                    />
                                    <Avatar sx={{ width: 24, height: 24, fontSize: '0.7rem', mr: 1, bgcolor: option.avatar_color || planAiColors.brand.primary }}>
                                        {option.username.charAt(0).toUpperCase()}
                                    </Avatar>
                                    <Box>
                                        <Typography variant="body2" sx={{ fontSize: '0.85rem', fontWeight: 500 }}>{option.username}</Typography>
                                        <Typography variant="caption" sx={{ color: planAiColors.text.muted, fontSize: '0.7rem' }}>{option.role || 'member'}</Typography>
                                    </Box>
                                </li>
                            )}
                            renderTags={(tagValue, getTagProps) =>
                                tagValue.map((option, index) => (
                                    <Chip
                                        {...getTagProps({ index })}
                                        key={option.id}
                                        avatar={
                                            <Avatar sx={{ bgcolor: option.avatar_color || planAiColors.brand.primary, width: 20, height: 20, fontSize: '0.6rem' }}>
                                                {option.username.charAt(0).toUpperCase()}
                                            </Avatar>
                                        }
                                        label={option.username}
                                        size="small"
                                        sx={{ height: 26, fontSize: '0.75rem' }}
                                    />
                                ))
                            }
                            renderInput={(params) => (
                                <TextField {...params} placeholder="Search members..." />
                            )}
                        />
                    </Box>

                    {/* Dates */}
                    <Box>
                        <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem', mb: 1, display: 'block' }}>
                            Schedule
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 2 }}>
                            <Box sx={{ flex: 1 }}>
                                <TextField
                                    label="Start Date"
                                    type="date"
                                    fullWidth
                                    size="small"
                                    value={formData.start_date_tbd ? '' : (formData.start_date || '')}
                                    onChange={(e) => handleChange('start_date', e.target.value)}
                                    InputLabelProps={{ shrink: true }}
                                    placeholder={formData.start_date_tbd ? '미정' : undefined}
                                    disabled={!canEdit || !!formData.start_date_tbd}
                                />
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            size="small"
                                            checked={!!formData.start_date_tbd}
                                            onChange={(e) => handleTbdToggle('start', e.target.checked)}
                                            disabled={!canEdit}
                                        />
                                    }
                                    label="미정"
                                    sx={{ mt: 0.25, '& .MuiFormControlLabel-label': { fontSize: '0.8rem' } }}
                                />
                                {canEdit && (() => {
                                    const hasConfirmedStart = !formData.start_date_tbd && !!formData.start_date;
                                    const hasConfirmedDue = !formData.due_date_tbd && !!formData.due_date;
                                    if (hasConfirmedStart) return null;
                                    if (!(formData.start_date_tbd || hasConfirmedDue)) return null;
                                    const sug = suggestStartDate({
                                        startDate: null,
                                        dueDate: hasConfirmedDue ? formData.due_date : null,
                                        priority: formData.priority,
                                    });
                                    if (!sug) return null;
                                    return (
                                        <Tooltip title={sug.reason} arrow>
                                            <Button
                                                size="small"
                                                onClick={() => applyDateSuggestion('start', sug.date)}
                                                sx={{ textTransform: 'none', fontSize: '0.68rem', fontWeight: 600, color: planAiColors.brand.primary, py: 0, px: 0.5, minWidth: 0, display: 'block' }}
                                            >
                                                💡 추천 {sug.date}
                                            </Button>
                                        </Tooltip>
                                    );
                                })()}
                            </Box>
                            <Box sx={{ flex: 1 }}>
                                <TextField
                                    label="Due Date"
                                    type="date"
                                    fullWidth
                                    size="small"
                                    value={formData.due_date_tbd ? '' : (formData.due_date || '')}
                                    onChange={(e) => handleChange('due_date', e.target.value)}
                                    InputLabelProps={{ shrink: true }}
                                    placeholder={formData.due_date_tbd ? '미정' : undefined}
                                    disabled={!canEdit || !!formData.due_date_tbd}
                                />
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            size="small"
                                            checked={!!formData.due_date_tbd}
                                            onChange={(e) => handleTbdToggle('due', e.target.checked)}
                                            disabled={!canEdit}
                                        />
                                    }
                                    label="미정"
                                    sx={{ mt: 0.25, '& .MuiFormControlLabel-label': { fontSize: '0.8rem' } }}
                                />
                                {canEdit && (() => {
                                    const hasConfirmedStart = !formData.start_date_tbd && !!formData.start_date;
                                    const hasConfirmedDue = !formData.due_date_tbd && !!formData.due_date;
                                    if (hasConfirmedDue) return null;
                                    if (!(formData.due_date_tbd || hasConfirmedStart)) return null;
                                    const sug = suggestDueDate({
                                        startDate: hasConfirmedStart ? formData.start_date : null,
                                        dueDate: null,
                                        priority: formData.priority,
                                    });
                                    if (!sug) return null;
                                    return (
                                        <Tooltip title={sug.reason} arrow>
                                            <Button
                                                size="small"
                                                onClick={() => applyDateSuggestion('due', sug.date)}
                                                sx={{ textTransform: 'none', fontSize: '0.68rem', fontWeight: 600, color: planAiColors.brand.primary, py: 0, px: 0.5, minWidth: 0, display: 'block' }}
                                            >
                                                💡 추천 {sug.date}
                                            </Button>
                                        </Tooltip>
                                    );
                                })()}
                            </Box>
                        </Box>
                    </Box>

                    {/* Description */}
                    <Box>
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                            <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem', display: 'block' }}>
                                Description
                            </Typography>
                            <Button
                                size="small"
                                startIcon={<OpenInFullIcon sx={{ fontSize: '0.8rem' }} />}
                                onClick={() => { setDescDraft(formData.description || ''); setDescExpandOpen(true); }}
                                sx={{ textTransform: 'none', fontSize: '0.7rem', fontWeight: 600, color: planAiColors.brand.primary, py: 0, minWidth: 0 }}
                            >
                                크게 편집
                            </Button>
                        </Box>
                        <RichDescriptionEditor
                            value={formData.description || ''}
                            onChange={(html) => handleChange('description', html)}
                            disabled={!canEdit}
                            placeholder="설명을 입력하세요. 이미지는 Ctrl+V 로 붙여넣을 수 있습니다."
                            minHeight={120}
                            uploadImage={async (file) => {
                                if (!currentSpaceId) {
                                    throw new Error('공간 정보가 없어 이미지를 업로드할 수 없습니다.');
                                }
                                validateInlineImageOrThrow(file);
                                const res = await api.uploadSpaceImage(currentSpaceId, file, currentUserId);
                                return res.url;
                            }}
                        />
                    </Box>

                    {/* Quick actions (new task only) */}
                    {!selectedTask && canEdit && (
                        <Box>
                            <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem', mb: 1, display: 'block' }}>
                                추가 액션 (선택)
                            </Typography>
                            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                                <Chip
                                    icon={<BugReportOutlinedIcon sx={{ fontSize: '0.9rem !important' }} />}
                                    label="이슈로 등록"
                                    size="small"
                                    clickable
                                    onClick={() => setIsIssue(v => !v)}
                                    sx={{
                                        fontSize: '0.72rem', height: 28,
                                        bgcolor: isIssue ? planAiColors.status.dangerSoft : planAiColors.background.surfaceAlt,
                                        color: isIssue ? planAiColors.status.danger : planAiColors.text.tertiary,
                                        borderColor: isIssue ? planAiColors.status.danger : 'transparent',
                                        border: '1px solid',
                                        fontWeight: isIssue ? 700 : 400,
                                    }}
                                />
                                <Chip
                                    icon={<WarningAmberIcon sx={{ fontSize: '0.9rem !important' }} />}
                                    label="특이사항 표시"
                                    size="small"
                                    clickable
                                    onClick={() => setIsSpecial(v => !v)}
                                    sx={{
                                        fontSize: '0.72rem', height: 28,
                                        bgcolor: isSpecial ? planAiColors.status.warningSoft : planAiColors.background.surfaceAlt,
                                        color: isSpecial ? planAiColors.status.warning : planAiColors.text.tertiary,
                                        borderColor: isSpecial ? planAiColors.status.warning : 'transparent',
                                        border: '1px solid',
                                        fontWeight: isSpecial ? 700 : 400,
                                    }}
                                />
                                <Chip
                                    icon={<SubdirectoryArrowRightIcon sx={{ fontSize: '0.9rem !important' }} />}
                                    label="후속 Task 생성"
                                    size="small"
                                    clickable
                                    onClick={() => setCreateFollowUp(v => !v)}
                                    sx={{
                                        fontSize: '0.72rem', height: 28,
                                        bgcolor: createFollowUp ? planAiColors.brand.primarySoft : planAiColors.background.surfaceAlt,
                                        color: createFollowUp ? planAiColors.brand.primary : planAiColors.text.tertiary,
                                        borderColor: createFollowUp ? planAiColors.brand.primaryBorder : 'transparent',
                                        border: '1px solid',
                                        fontWeight: createFollowUp ? 700 : 400,
                                    }}
                                />
                            </Box>
                            {createFollowUp && (
                                <Typography variant="caption" sx={{ color: planAiColors.text.tertiary, fontSize: '0.68rem', mt: 0.5, display: 'block' }}>
                                    저장 후 제목에 "[후속]"이 붙은 새 Task 입력창이 열립니다
                                </Typography>
                            )}
                        </Box>
                    )}

                    {/* Issue/Special badges for existing tasks */}
                    {selectedTask && (isIssue || isSpecial) && (
                        <Box sx={{ display: 'flex', gap: 1 }}>
                            {isIssue && <Chip icon={<BugReportOutlinedIcon sx={{ fontSize: '0.85rem !important' }} />} label="이슈" size="small" sx={{ fontSize: '0.7rem', height: 24, bgcolor: planAiColors.status.dangerSoft, color: planAiColors.status.danger }} />}
                            {isSpecial && <Chip icon={<WarningAmberIcon sx={{ fontSize: '0.85rem !important' }} />} label="특이사항" size="small" sx={{ fontSize: '0.7rem', height: 24, bgcolor: planAiColors.status.warningSoft, color: planAiColors.status.warning }} />}
                        </Box>
                    )}

                    {/* v3.13: 상세 기능 영역 (보드 생성 시에도 노출, 캘린더 생성 시에만 프로젝트 선택 후 노출) */}
                    {(!isCalendarCreateMode || formData.project_id) && (
                        <>
                        {/* URL Attachments */}
                        <Box>
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                                <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem' }}>
                                    <LinkIcon sx={{ fontSize: '0.8rem', mr: 0.5, verticalAlign: 'text-bottom' }} />
                                    URL 첨부 ({(selectedTask?.id ? urlAttachments.length : 0) + pendingUrls.length})
                                </Typography>
                                {canEdit && (
                                    <Tooltip title="URL 추가" arrow>
                                        <span>
                                            <IconButton
                                                data-tour="url-add-btn"
                                                size="small"
                                                onClick={() => setShowAttachmentForm(!showAttachmentForm)}
                                                sx={{ color: planAiColors.brand.primary }}
                                            >
                                                <AddIcon sx={{ fontSize: '1rem' }} />
                                            </IconButton>
                                        </span>
                                    </Tooltip>
                                )}
                            </Box>

                            {/* Add Attachment Form */}
                            {showAttachmentForm && canEdit && (
                                <Box sx={{ display: 'flex', gap: 1, mb: 1.5, p: 1.5, bgcolor: planAiColors.brand.primarySoft, borderRadius: 1.5, border: `1px solid ${planAiColors.brand.primaryBorder}` }}>
                                    <TextField
                                        data-tour="url-input"
                                        size="small" placeholder="URL..." fullWidth
                                        value={newAttachmentUrl}
                                        onChange={e => setNewAttachmentUrl(e.target.value)}
                                        InputProps={{ startAdornment: <LinkIcon sx={{ fontSize: '1rem', color: planAiColors.text.muted, mr: 0.5 }} /> }}
                                        sx={{ '& .MuiOutlinedInput-root': { fontSize: '0.8rem' } }}
                                    />
                                    <TextField
                                        data-tour="url-name-input"
                                        size="small" placeholder="Name..." sx={{ minWidth: 120, '& .MuiOutlinedInput-root': { fontSize: '0.8rem' } }}
                                        value={newAttachmentName}
                                        onChange={e => setNewAttachmentName(e.target.value)}
                                    />
                                    <Button data-tour="url-add-submit" size="small" variant="contained"
                                        disabled={!newAttachmentUrl.trim()}
                                        onClick={() => {
                                            if (selectedTask?.id) {
                                                addAttachmentMutation.mutate({ url: newAttachmentUrl.trim(), filename: newAttachmentName.trim() || undefined });
                                            } else {
                                                setPendingUrls(prev => [...prev, { url: newAttachmentUrl.trim(), filename: newAttachmentName.trim() || undefined }]);
                                                setNewAttachmentUrl('');
                                                setNewAttachmentName('');
                                                setShowAttachmentForm(false);
                                            }
                                        }}
                                        sx={{ bgcolor: planAiColors.brand.primary, minWidth: 'auto', px: 2 }}
                                    >
                                        Add
                                    </Button>
                                </Box>
                            )}

                            {/* URL Attachment List */}
                            {attachmentsLoading ? (
                                <CircularProgress size={16} />
                            ) : (urlAttachments.length > 0 || pendingUrls.length > 0) ? (
                                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                                    {pendingUrls.map((att, idx) => (
                                        <Box key={`pending-url-${idx}`} sx={{
                                            display: 'flex', alignItems: 'center', gap: 1, p: 1,
                                            borderRadius: 1, border: `1px dashed ${planAiColors.border.normal}`, bgcolor: planAiColors.background.surfaceAlt
                                        }}>
                                            <LinkIcon sx={{ fontSize: '0.9rem', color: planAiColors.text.muted }} />
                                            <Typography variant="body2" sx={{ fontSize: '0.8rem', fontWeight: 500, flexGrow: 1, color: planAiColors.text.tertiary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                {att.filename || att.url}
                                            </Typography>
                                            <Chip label="대기 중" size="small" sx={{ height: 16, fontSize: '0.55rem', bgcolor: planAiColors.border.soft, color: planAiColors.text.secondary }} />
                                            {canEdit && (
                                                <IconButton size="small" onClick={() => setPendingUrls(prev => prev.filter((_, i) => i !== idx))} sx={{ color: planAiColors.text.muted, '&:hover': { color: planAiColors.status.danger } }}>
                                                    <DeleteOutlineIcon sx={{ fontSize: '0.8rem' }} />
                                                </IconButton>
                                            )}
                                        </Box>
                                    ))}
                                    {urlAttachments.map(att => (
                                        editingAttId === att.id ? (
                                            <Box key={att.id} sx={{
                                                display: 'flex', flexDirection: 'column', gap: 0.5, p: 1,
                                                borderRadius: 1, border: `1px solid ${planAiColors.brand.primary}`,
                                                bgcolor: planAiColors.background.surfaceAlt,
                                            }}>
                                                <TextField
                                                    size="small" fullWidth label="URL 이름"
                                                    value={editAttName}
                                                    onChange={e => setEditAttName(e.target.value)}
                                                    InputProps={{ sx: { fontSize: '0.8rem' } }}
                                                    InputLabelProps={{ sx: { fontSize: '0.75rem' } }}
                                                />
                                                <TextField
                                                    size="small" fullWidth label="URL 주소"
                                                    value={editAttUrl}
                                                    onChange={e => setEditAttUrl(e.target.value)}
                                                    onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); submitEditAttachment(); } }}
                                                    InputProps={{ sx: { fontSize: '0.8rem' } }}
                                                    InputLabelProps={{ sx: { fontSize: '0.75rem' } }}
                                                />
                                                <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 0.5 }}>
                                                    <Button size="small" onClick={() => setEditingAttId(null)} sx={{ fontSize: '0.7rem' }}>
                                                        취소
                                                    </Button>
                                                    <Button
                                                        size="small" variant="contained"
                                                        startIcon={<CheckIcon sx={{ fontSize: '0.8rem' }} />}
                                                        disabled={updateAttachmentMutation.isPending}
                                                        onClick={submitEditAttachment}
                                                        sx={{ fontSize: '0.7rem' }}
                                                    >
                                                        저장
                                                    </Button>
                                                </Box>
                                            </Box>
                                        ) : (
                                        <Box key={att.id} sx={{
                                            display: 'flex', alignItems: 'center', gap: 1, p: 1,
                                            borderRadius: 1, border: `1px solid ${planAiColors.border.soft}`,
                                            '&:hover': { bgcolor: planAiColors.background.surfaceAlt },
                                        }}>
                                            <LinkIcon sx={{ fontSize: '0.9rem', color: planAiColors.brand.primary }} />
                                            <Link
                                                href={att.url}
                                                target="_blank"
                                                sx={{
                                                    fontSize: '0.8rem', fontWeight: 500, flexGrow: 1,
                                                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                                                }}
                                            >
                                                {att.filename || att.url}
                                            </Link>
                                            <IconButton size="small" href={att.url} target="_blank" sx={{ color: planAiColors.text.tertiary }}>
                                                <OpenInNewIcon sx={{ fontSize: '0.8rem' }} />
                                            </IconButton>
                                            {canEdit && (
                                                <IconButton size="small" onClick={() => startEditAttachment(att)} sx={{ color: planAiColors.border.normal, '&:hover': { color: planAiColors.brand.primary } }}>
                                                    <EditOutlinedIcon sx={{ fontSize: '0.8rem' }} />
                                                </IconButton>
                                            )}
                                            {canEdit && (
                                                <IconButton size="small" onClick={() => deleteAttachmentMutation.mutate(att.id)} sx={{ color: planAiColors.border.normal, '&:hover': { color: planAiColors.status.danger } }}>
                                                    <DeleteOutlineIcon sx={{ fontSize: '0.8rem' }} />
                                                </IconButton>
                                            )}
                                        </Box>
                                        )
                                    ))}
                                </Box>
                            ) : (
                                <Typography variant="caption" sx={{ color: planAiColors.text.muted }}>
                                    URL 첨부 없음
                                </Typography>
                            )}
                        </Box>

                        {/* File Attachments */}
                        <Box>
                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                                <Typography variant="caption" sx={{ fontWeight: 700, color: planAiColors.text.tertiary, textTransform: 'uppercase', fontSize: '0.7rem' }}>
                                    <CloudUploadIcon sx={{ fontSize: '0.8rem', mr: 0.5, verticalAlign: 'text-bottom' }} />
                                    Files 업로드 ({(selectedTask?.id ? fileAttachments.length : 0) + pendingFiles.length})
                                </Typography>
                                {canEdit && (
                                    <Tooltip title="파일 선택" arrow>
                                        <span>
                                            <Button
                                                size="small"
                                                startIcon={<CloudUploadIcon sx={{ fontSize: '0.8rem' }} />}
                                                onClick={() => fileInputRef.current?.click()}
                                                disabled={uploading}
                                                sx={{ textTransform: 'none', fontSize: '0.7rem', color: planAiColors.brand.primary }}
                                            >
                                                {uploading ? '업로드 중...' : '파일 선택'}
                                            </Button>
                                        </span>
                                    </Tooltip>
                                )}
                                <input
                                    ref={fileInputRef}
                                    type="file"
                                    multiple
                                    hidden
                                    accept={uploadPolicy?.general.allowed_extensions.join(',')}
                                    onChange={(e) => {
                                        const selectedFiles = e.target.files;
                                        if (!selectedFiles || selectedFiles.length === 0) {
                                            if (fileInputRef.current) fileInputRef.current.value = '';
                                            return;
                                        }
                                        const accepted = validateFilesAgainstPolicy(Array.from(selectedFiles));
                                        if (accepted.length > 0) {
                                            if (selectedTask?.id) {
                                                setUploading(true);
                                                accepted.forEach((file) => uploadFileMutation.mutate(file));
                                            } else {
                                                setPendingFiles(prev => [...prev, ...accepted]);
                                            }
                                        }
                                        if (fileInputRef.current) fileInputRef.current.value = '';
                                    }}
                                />
                            </Box>

                            {uploadPolicy && (
                                <Typography variant="caption" sx={{ display: 'block', color: planAiColors.text.muted, fontSize: '0.62rem', mb: 0.5 }}>
                                    {uploadPolicy.general.allowed_label} · 1개당 {uploadPolicy.general.max_file_mb}MB · 최대 {uploadPolicy.general.max_file_count}개 (총 {uploadPolicy.general.max_total_mb}MB)
                                </Typography>
                            )}

                            {uploading && <LinearProgress sx={{ mb: 1, borderRadius: 1 }} />}

                            {(fileAttachments.length > 0 || pendingFiles.length > 0) ? (
                                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                                    {pendingFiles.map((file, idx) => (
                                        <Box key={`pending-file-${idx}`} sx={{
                                            display: 'flex', alignItems: 'center', gap: 1, p: 1,
                                            borderRadius: 1, border: `1px dashed ${planAiColors.border.normal}`, bgcolor: planAiColors.background.surfaceAlt
                                        }}>
                                            <InsertDriveFileIcon sx={{ fontSize: '0.9rem', color: planAiColors.text.muted }} />
                                            <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                                                <Typography variant="body2" noWrap sx={{ fontSize: '0.8rem', fontWeight: 500, color: planAiColors.text.tertiary }}>
                                                    {file.name}
                                                </Typography>
                                                <Typography variant="caption" sx={{ color: planAiColors.text.muted, fontSize: '0.65rem' }}>
                                                    {formatFileSize(file.size)}
                                                </Typography>
                                            </Box>
                                            <Chip label="대기 중" size="small" sx={{ height: 16, fontSize: '0.55rem', bgcolor: planAiColors.border.soft, color: planAiColors.text.secondary }} />
                                            {canEdit && (
                                                <IconButton size="small" onClick={() => setPendingFiles(prev => prev.filter((_, i) => i !== idx))} sx={{ color: planAiColors.text.muted, '&:hover': { color: planAiColors.status.danger } }}>
                                                    <DeleteOutlineIcon sx={{ fontSize: '0.8rem' }} />
                                                </IconButton>
                                            )}
                                        </Box>
                                    ))}
                                    {fileAttachments.map(att => (
                                        <Box key={att.id} sx={{
                                            display: 'flex', alignItems: 'center', gap: 1, p: 1,
                                            borderRadius: 1, border: `1px solid ${planAiColors.border.soft}`,
                                            '&:hover': { bgcolor: planAiColors.background.surfaceAlt },
                                        }}>
                                            <InsertDriveFileIcon sx={{ fontSize: '0.9rem', color: planAiColors.status.purple }} />
                                            <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                                                <Typography variant="body2" noWrap sx={{ fontSize: '0.8rem', fontWeight: 500 }}>
                                                    {att.filename || 'file'}
                                                </Typography>
                                                {att.size && (
                                                    <Typography variant="caption" sx={{ color: planAiColors.text.muted, fontSize: '0.65rem' }}>
                                                        {formatFileSize(att.size)}
                                                    </Typography>
                                                )}
                                            </Box>
                                            <Tooltip title="다운로드">
                                                <IconButton
                                                    size="small"
                                                    onClick={() => {
                                                        const baseUrl = API_URL.replace(/\/api\/?$/, '');
                                                        const fileUrl = att.url.startsWith('/') ? `${baseUrl}${att.url}` : `${baseUrl}/${att.url}`;
                                                        window.open(fileUrl, '_blank');
                                                    }}
                                                    sx={{ color: planAiColors.brand.primary }}
                                                >
                                                    <DownloadIcon sx={{ fontSize: '0.8rem' }} />
                                                </IconButton>
                                            </Tooltip>
                                            {canEdit && (
                                                <IconButton size="small" onClick={() => deleteAttachmentMutation.mutate(att.id)} sx={{ color: planAiColors.border.normal, '&:hover': { color: planAiColors.status.danger } }}>
                                                    <DeleteOutlineIcon sx={{ fontSize: '0.8rem' }} />
                                                </IconButton>
                                            )}
                                        </Box>
                                    ))}
                                </Box>
                            ) : (
                                <Typography variant="caption" sx={{ color: planAiColors.text.muted }}>첨부 파일 없음</Typography>
                            )}
                        </Box>

                        {/* Check Sheets — 설비운영 공간에서만 노출 */}
                        {isEquipmentOpsSpace && (
                        <Box>
                            <TaskSheetPanel
                                taskId={selectedTask?.id || 0}
                                projectId={selectedTask?.project_id || drawerProjectId || undefined}
                                canEdit={canEdit}
                                pendingSheets={pendingSheets}
                                onAddPendingSheet={(sheet) => setPendingSheets(prev => [...prev, sheet])}
                                onRemovePendingSheet={(idx) => setPendingSheets(prev => prev.filter((_, i) => i !== idx))}
                            />
                        </Box>
                        )}

                        {/* 댓글은 상단 Comments 버튼 → 전용 화면(TaskCommentsView)으로 표시.
                            (하단 중복 표시 방지를 위해 기존 인라인 COMMENTS 섹션 제거) */}

                        {/* 변경 이력 (기존 Task 편집 시에만) */}
                        {selectedTask?.id && (
                            <Box sx={{ pt: 1, borderTop: `1px solid ${planAiColors.border.soft}` }}>
                                <ItemHistorySection
                                    entityType="task"
                                    entityId={selectedTask.id}
                                    itemName={selectedTask.title}
                                />
                            </Box>
                        )}
                        </>
                    )}
                </Stack>
                )}
            </Box>

            {/* Footer — Comments 전용 화면에서는 숨김(입력창은 Comments 화면 하단에 고정) */}
            {!showCommentsView && canEdit && (
                <Box sx={{
                    p: 2.5, display: 'flex', gap: 2,
                    borderTop: `1px solid ${planAiColors.border.soft}`, bgcolor: planAiColors.background.surfaceAlt,
                }}>
                    <Button
                        variant="contained"
                        fullWidth
                        onClick={handleSave}
                        disabled={updateMutation.isPending || createMutation.isPending || !formData.title?.trim()}
                        sx={{ py: 1.2, bgcolor: planAiColors.brand.primary, '&:hover': { bgcolor: planAiColors.brand.primaryHover } }}
                    >
                        {selectedTask ? 'Save Changes' : 'Create Task'}
                    </Button>
                    <Button variant="outlined" fullWidth onClick={closeDrawer} sx={{ py: 1.2 }}>
                        Cancel
                    </Button>
                </Box>
            )}
            {!showCommentsView && !canEdit && (
                <Box sx={{
                    p: 2.5, display: 'flex', gap: 2,
                    borderTop: `1px solid ${planAiColors.border.soft}`, bgcolor: planAiColors.background.surfaceAlt,
                }}>
                    <Button variant="outlined" fullWidth onClick={closeDrawer} sx={{ py: 1.2 }}>
                        닫기
                    </Button>
                </Box>
            )}
            {/* Work Note Modal */}
            {selectedTask?.id && (
                <WorkNoteModal
                    open={workNoteOpen}
                    onClose={() => setWorkNoteOpen(false)}
                    taskId={selectedTask.id}
                    taskTitle={selectedTask.title}
                    canEdit={canEdit}
                    projectId={selectedTask.project_id}
                />
            )}

            {/* Task 이동 (다른 Project로) */}
            {selectedTask?.id && activeProjectId && (
                <TaskMoveDialog
                    open={moveDialogOpen}
                    onClose={() => setMoveDialogOpen(false)}
                    taskId={selectedTask.id}
                    currentProjectId={activeProjectId}
                    currentProjectName={activeProject?.name}
                    spaceId={activeProject?.space_id}
                    currentUserId={currentUserId}
                    onMoved={closeDrawer}
                />
            )}

            {/* Description 크게 편집 — '적용'은 form state만 변경, 실제 저장은 Save Changes */}
            <Dialog
                open={descExpandOpen}
                onClose={() => setDescExpandOpen(false)}
                maxWidth={false}
                PaperProps={{
                    sx: {
                        borderRadius: 3,
                        // 좌/우/위/아래 모두 크기 조절. resize 는 overflow 가 visible 이 아니어야 동작.
                        resize: { xs: 'none', sm: 'both' },
                        overflow: 'auto',
                        width: { xs: 'calc(100vw - 32px)', sm: '70vw' },
                        minWidth: { xs: 'auto', sm: 600 },
                        // 화면 밖으로 튀어나가지 않도록 제한하되, 좌우 resize 여유를 충분히 둔다.
                        maxWidth: 'calc(100vw - 48px)',
                        height: { xs: 'calc(100vh - 120px)', sm: '60vh' },
                        minHeight: { xs: 'auto', sm: 420 },
                        maxHeight: 'calc(100vh - 48px)',
                        m: { xs: 2, sm: 4 },
                    },
                }}
            >
                <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    Description 크게 편집
                    <IconButton size="small" onClick={() => setDescExpandOpen(false)}><CloseIcon fontSize="small" /></IconButton>
                </DialogTitle>
                <DialogContent sx={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
                    <RichDescriptionEditor
                        value={descDraft}
                        onChange={setDescDraft}
                        disabled={!canEdit}
                        placeholder="설명을 입력하세요. 이미지는 Ctrl+V 로 붙여넣을 수 있습니다."
                        fill
                        uploadImage={async (file) => {
                            if (!currentSpaceId) {
                                throw new Error('공간 정보가 없어 이미지를 업로드할 수 없습니다.');
                            }
                            validateInlineImageOrThrow(file);
                            const res = await api.uploadSpaceImage(currentSpaceId, file, currentUserId);
                            return res.url;
                        }}
                    />
                </DialogContent>
                <DialogActions sx={{ px: 3, pb: 2 }}>
                    <Button onClick={() => setDescExpandOpen(false)} sx={{ textTransform: 'none', color: planAiColors.text.tertiary }}>
                        취소
                    </Button>
                    <Button
                        variant="contained"
                        disabled={!canEdit}
                        onClick={() => { handleChange('description', descDraft); setDescExpandOpen(false); }}
                        sx={{ textTransform: 'none', bgcolor: planAiColors.brand.primary }}
                    >
                        적용
                    </Button>
                </DialogActions>
            </Dialog>
        </Drawer>
    );
};

export default TaskDrawer;
