import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Box, TextField, Avatar, Typography, Popper } from '@mui/material';
import type { TextFieldProps } from '@mui/material';
import { ProjectMember } from '../types';
import { planAiColors } from '../theme/tokens';

/** 선택된 멘션 1건. token = 본문에 실제로 삽입된 표시 문자열(예: "@홍길동"). */
export interface MentionedUser {
  userId: number;
  token: string;
}

/**
 * 본문에 아직 남아있는 토큰만 유효한 멘션으로 남긴다(사용자가 지운 멘션은 발송 대상에서 제외).
 * 반환: 중복 제거된 user_id 배열.
 */
export function resolveMentionedUserIds(mentioned: MentionedUser[], text: string): number[] {
  const ids = new Set<number>();
  for (const m of mentioned) {
    if (m.token && text.includes(m.token)) ids.add(m.userId);
  }
  return [...ids];
}

const MENTION_QUERY_RE = /(?:^|\s)@(\S*)$/;

interface Props {
  value: string;
  onChange: (next: string) => void;
  members: ProjectMember[];
  mentioned: MentionedUser[];
  onMentionedChange: (next: MentionedUser[]) => void;
  /** dropdown 이 닫혀있을 때 Ctrl/Cmd+Enter 로 호출. */
  onSubmit?: () => void;
  onPaste?: (e: React.ClipboardEvent) => void;
  placeholder?: string;
  minRows?: number;
  disabled?: boolean;
  size?: TextFieldProps['size'];
  autoFocus?: boolean;
}

const MAX_SUGGESTIONS = 8;

const MentionTextField: React.FC<Props> = ({
  value, onChange, members, mentioned, onMentionedChange,
  onSubmit, onPaste, placeholder, minRows = 2, disabled, size = 'small', autoFocus,
}) => {
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const anchorRef = useRef<HTMLDivElement | null>(null);       // Popper anchor = TextField wrapper
  const [query, setQuery] = useState<string | null>(null);     // null = dropdown 닫힘
  const [mentionStart, setMentionStart] = useState<number>(-1);
  const [highlight, setHighlight] = useState(0);
  const pendingCaret = useRef<number | null>(null);

  // 프로그램적으로 value 를 바꾼 뒤 caret 위치 복원
  useEffect(() => {
    if (pendingCaret.current != null && inputRef.current) {
      const pos = pendingCaret.current;
      pendingCaret.current = null;
      requestAnimationFrame(() => {
        if (inputRef.current) {
          inputRef.current.focus();
          try { inputRef.current.setSelectionRange(pos, pos); } catch { /* noop */ }
        }
      });
    }
  });

  const suggestions = useMemo(() => {
    if (query == null) return [];
    const q = query.toLowerCase();
    const match = (m: ProjectMember) =>
      !q ||
      (m.username || '').toLowerCase().includes(q) ||
      (m.loginid || '').toLowerCase().includes(q) ||
      (m.deptname || '').toLowerCase().includes(q);
    return members.filter(m => m.user_id && match(m)).slice(0, MAX_SUGGESTIONS);
  }, [query, members]);

  const recomputeQuery = useCallback((text: string, caret: number) => {
    const before = text.slice(0, caret);
    const m = before.match(MENTION_QUERY_RE);
    if (m) {
      setQuery(m[1]);
      setMentionStart(caret - m[1].length - 1); // '@' 위치
      setHighlight(0);
    } else {
      setQuery(null);
      setMentionStart(-1);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    const text = e.target.value;
    const caret = e.target.selectionStart ?? text.length;
    onChange(text);
    recomputeQuery(text, caret);
  };

  const selectMember = (m: ProjectMember) => {
    if (mentionStart < 0 || !inputRef.current) return;
    const caret = inputRef.current.selectionStart ?? value.length;
    const token = `@${m.username || m.loginid}`;
    const next = value.slice(0, mentionStart) + token + ' ' + value.slice(caret);
    pendingCaret.current = mentionStart + token.length + 1;
    onChange(next);
    if (m.user_id) {
      const exists = mentioned.some(x => x.userId === m.user_id && x.token === token);
      if (!exists) onMentionedChange([...mentioned, { userId: m.user_id, token }]);
    }
    setQuery(null);
    setMentionStart(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (query != null && suggestions.length > 0) {
      if (e.key === 'ArrowDown') { e.preventDefault(); setHighlight(h => (h + 1) % suggestions.length); return; }
      if (e.key === 'ArrowUp') { e.preventDefault(); setHighlight(h => (h - 1 + suggestions.length) % suggestions.length); return; }
      if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); selectMember(suggestions[highlight]); return; }
      if (e.key === 'Escape') { e.preventDefault(); setQuery(null); return; }
    }
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      onSubmit?.();
    }
  };

  const open = query != null && suggestions.length > 0;

  return (
    <Box ref={anchorRef} sx={{ position: 'relative' }}>
      <TextField
        value={value}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onPaste={onPaste}
        onBlur={() => setTimeout(() => setQuery(null), 120)}  // 클릭 선택 여유
        placeholder={placeholder}
        multiline minRows={minRows} fullWidth size={size}
        disabled={disabled}
        autoFocus={autoFocus}
        inputRef={inputRef}
      />
      {/*
        Portal(Popper) 로 document.body 에 렌더 → Drawer/Modal 의 overflow 에 잘리지 않음.
        flip: 아래 공간이 부족하면 위로 자동 전환. preventOverflow: viewport 안에서 clamp.
        z-index 1600 (Drawer 1200 / Modal 1300 보다 위).
      */}
      <Popper
        open={open}
        anchorEl={anchorRef.current}
        placement="bottom-start"
        style={{ zIndex: 1600, width: anchorRef.current?.offsetWidth }}
        modifiers={[
          { name: 'offset', options: { offset: [0, 8] } },
          { name: 'flip', enabled: true, options: { boundary: 'viewport', padding: 8 } },
          { name: 'preventOverflow', enabled: true, options: { boundary: 'viewport', padding: 8 } },
        ]}
      >
        <Box
          // mousedown 이 textarea blur 를 유발하지 않도록 → 선택 확정 가능
          onMouseDown={(e) => e.preventDefault()}
          sx={{
            bgcolor: '#fff', border: `1px solid ${planAiColors.border.soft}`, borderRadius: 1.5,
            boxShadow: '0 6px 20px rgba(0,0,0,0.12)',
            maxHeight: 'min(260px, 40vh)', overflowY: 'auto', py: 0.5,
          }}
        >
          {suggestions.map((m, idx) => (
            <Box
              key={m.user_id}
              // onMouseDown (blur 이전) 으로 선택 확정
              onMouseDown={(e) => { e.preventDefault(); selectMember(m); }}
              onMouseEnter={() => setHighlight(idx)}
              sx={{
                display: 'flex', alignItems: 'center', gap: 1, px: 1.2, py: 0.7, cursor: 'pointer',
                bgcolor: idx === highlight ? '#EEF2FF' : 'transparent',
              }}
            >
              <Avatar sx={{ width: 24, height: 24, fontSize: '0.7rem', bgcolor: m.avatar_color || planAiColors.brand.primary }}>
                {(m.username || '?').charAt(0).toUpperCase()}
              </Avatar>
              <Box sx={{ minWidth: 0 }}>
                <Typography sx={{ fontSize: '0.8rem', fontWeight: 600, color: planAiColors.text.primary, lineHeight: 1.3 }}>
                  {m.username || m.loginid}
                  <Typography component="span" sx={{ fontSize: '0.7rem', color: planAiColors.text.muted, ml: 0.5, fontWeight: 400 }}>
                    {m.loginid}
                  </Typography>
                </Typography>
                {(m.deptname || m.mail) && (
                  <Typography sx={{ fontSize: '0.66rem', color: planAiColors.text.muted, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {[m.deptname, m.mail].filter(Boolean).join(' · ')}
                  </Typography>
                )}
              </Box>
            </Box>
          ))}
          <Typography sx={{ fontSize: '0.62rem', color: planAiColors.text.muted, px: 1.2, pt: 0.4 }}>
            동명이인은 Knox ID·부서로 구분해 선택하세요.
          </Typography>
        </Box>
      </Popper>
    </Box>
  );
};

export default MentionTextField;
