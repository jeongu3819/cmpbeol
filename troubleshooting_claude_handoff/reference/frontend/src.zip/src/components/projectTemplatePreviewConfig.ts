/**
 * 프로젝트 템플릿 "생성 전 미리보기"용 보조 설정.
 *
 * 대시보드 통계 / Task 구조 / 일정 타임라인 / Note 는 실제 템플릿 정의(PROJECT_TEMPLATES)에서
 * 그대로 파생해 보여준다(= read-only). 여기에는 데이터로부터 뽑아낼 수 없는 "질적인" 설명만 둔다:
 * 주요 기능, 추천 용도, 마일스톤(업무 흐름) 단계, 남기게 될 이력 예시, AI 요약 예시.
 *
 * 미리보기는 mock/정의 데이터만 렌더링하며 실제 API 호출/DB 생성은 일절 하지 않는다.
 * key 는 ProjectTemplate.id 와 일치한다.
 */

export interface ProjectTemplatePreviewMeta {
  /** 한 줄 요약(없으면 template.description 사용) */
  overview?: string;
  /** 주요 기능 3~5개 */
  features: string[];
  /** 추천 용도 (예: "PM / Sprint / 개발 진행관리") */
  recommendedFor: string;
  /** 업무 흐름(마일스톤) 단계 */
  milestones: { title: string; description: string }[];
  /** 이 템플릿에서 남기게 될 이력/메모 예시 */
  historyExamples: string[];
  /** AI 요약 예시 (실제 AI 호출 아님, 정적 샘플) */
  aiSummaryExample: string;
}

export const PROJECT_TEMPLATE_PREVIEWS: Record<string, ProjectTemplatePreviewMeta> = {
  'pm-sprint': {
    overview: '2주 단위 스프린트 목표, 백로그, 개발 진행, 리뷰와 회고를 관리합니다.',
    features: ['Sprint 목표 관리', 'Backlog 정리', '담당자별 Task 관리', '리뷰/회고 기록', 'AI Sprint 요약'],
    recommendedFor: 'PM / Sprint / 개발 진행관리',
    milestones: [
      { title: 'Sprint 시작', description: '목표 정의 및 백로그 확정' },
      { title: 'Sprint Planning', description: '담당자 배정 및 일정 확정' },
      { title: '중간 점검', description: '데일리 스탠드업 / 진행 상황 공유' },
      { title: 'Review', description: '완료 항목 데모 및 리뷰' },
      { title: 'Retrospective', description: '회고 및 다음 Sprint 개선사항 정리' },
    ],
    historyExamples: ['스프린트 목표 변경 기록', '진행 중 블로커 이슈', '담당자 배정 이력', '회고 개선사항 메모'],
    aiSummaryExample:
      '이번 Sprint는 요구사항 정의와 API 개발이 핵심입니다. 현재 데일리 스탠드업이 진행 중이며, 스프린트 리뷰 준비가 마감 임박 항목입니다. 담당자별 Task 배정 확인이 필요합니다.',
  },

  'side-project': {
    overview: '사이드 프로젝트의 아이디어 검증부터 MVP 개발, 런칭까지의 흐름을 관리합니다.',
    features: ['아이디어 검증/리서치', 'MVP 기능 정의', '개발 진행 관리', '배포 및 런칭', 'AI 진행 요약'],
    recommendedFor: '사이드 프로젝트 / MVP / 개인 런칭',
    milestones: [
      { title: '기획', description: '아이디어 검증 및 요구사항 정리' },
      { title: '개발', description: 'MVP 구현 및 테스트' },
      { title: '런칭', description: '배포 및 초기 마케팅' },
    ],
    historyExamples: ['아이디어 검증 결과 메모', '기능 범위 변경 기록', '배포 일정 변경 이력'],
    aiSummaryExample:
      '아이디어 검증과 MVP 기능 정의는 완료되었고 현재 핵심 기능 개발이 진행 중입니다. 런칭 준비 단계가 남아 있으며, 배포 일정 확정이 필요합니다.',
  },

  'weekly-report': {
    overview: '매주 반복하는 주간 업무 보고 루틴(목표·진행·이슈·다음 주 계획)을 체계적으로 관리합니다.',
    features: ['이번 주 목표 설정', '진행 사항 정리', '이슈/리스크 체크', '주간 보고서 작성', 'AI 주간 요약'],
    recommendedFor: '주간 보고 / 업무 루틴 / 팀 리포팅',
    milestones: [
      { title: '월요일 · 주간 목표 설정', description: '이번 주 핵심 목표 정의' },
      { title: '수요일 · 중간 진행 점검', description: '진행 상황 및 이슈 점검' },
      { title: '금요일 · 주간 보고 작성', description: '성과 정리 및 다음 주 계획' },
    ],
    historyExamples: ['주간 목표 변경 기록', '진행 중 이슈 메모', 'KPI 달성률 기록', '다음 주 계획 메모'],
    aiSummaryExample:
      '지난 주 성과 정리는 완료되었고 이번 주 핵심 목표 설정이 진행 중입니다. 이슈/리스크 체크가 진행 중이며, 금요일 주간 보고서 작성이 예정되어 있습니다.',
  },

  'marketing-campaign': {
    overview: '마케팅 캠페인의 기획(전략/타겟), 실행(콘텐츠/채널), 분석(성과)을 한 곳에서 관리합니다.',
    features: ['캠페인 목표/KPI 설정', '타겟 오디언스 분석', '콘텐츠 기획/제작', '채널별 실행', 'AI 성과 요약'],
    recommendedFor: '마케팅 / 캠페인 / 콘텐츠 운영',
    milestones: [
      { title: '기획', description: '캠페인 전략 및 KPI 수립' },
      { title: '실행', description: '콘텐츠 제작 및 채널 집행' },
      { title: '분석', description: '성과 측정 및 리포팅' },
    ],
    historyExamples: ['KPI 목표 변경 기록', '콘텐츠 일정 변경 이력', '채널별 성과 메모'],
    aiSummaryExample:
      '캠페인 목표/KPI 설정과 타겟 분석은 완료되었습니다. 현재 콘텐츠 기획·제작이 진행 중이며, 채널별 실행 계획과 성과 분석이 남아 있습니다.',
  },

  'dev-feature': {
    overview: '새 기능 개발 프로세스를 설계 → 개발 → 테스트 → 배포 흐름으로 관리합니다.',
    features: ['요구사항/기술 설계', 'UI/API 구현', '코드 리뷰', '테스트/QA', '배포 및 릴리즈 노트'],
    recommendedFor: '기능 개발 / 엔지니어링 / 릴리즈 관리',
    milestones: [
      { title: '요구사항 정의', description: '기능 범위 및 요구사항 확정' },
      { title: 'API/UI 설계', description: '기술 설계 및 인터페이스 정의' },
      { title: '구현', description: '개발 및 코드 리뷰' },
      { title: '테스트', description: 'QA 및 버그 수정' },
      { title: '배포', description: '릴리즈 및 릴리즈 노트 작성' },
    ],
    historyExamples: ['요구사항 변경 기록', '진행 중 기술 이슈', 'API 설계 의사결정 메모', '배포/릴리즈 이력'],
    aiSummaryExample:
      '이번 기능 개발은 API 설계와 UI 구현이 핵심입니다. 요구사항 정의는 완료되었고 Backend/Frontend 구현이 진행 중입니다. 테스트 및 배포 단계가 남아 있으며, 담당자 확인이 필요합니다.',
  },

  'cost-reduction': {
    overview: '원가절감 과제를 발굴 → 검증 → 실행 → 효과 확인의 흐름으로 관리합니다.',
    features: ['절감 아이디어 등록', '현황/타당성 분석', '절감 효과 검증', '실행/적용', '정량 효과 기록'],
    recommendedFor: '원가절감 / 개선과제 / 효과 관리',
    milestones: [
      { title: '과제 발굴', description: '절감 아이디어 등록 및 선정' },
      { title: '검증/분석', description: '현황 분석 및 타당성 검토' },
      { title: '승인', description: '절감 효과 검증 및 승인' },
      { title: '실행/적용', description: '개선 실행 및 모니터링' },
      { title: '사후 효과 확인', description: '정량 효과 측정 및 기록' },
    ],
    historyExamples: ['절감 아이디어 등록 기록', '타당성 검토 결과 메모', '승인/반려 이력', '정량 효과 기록'],
    aiSummaryExample:
      '원가절감 과제 발굴과 현황 분석이 진행되고 있습니다. 절감 효과 검증 후 실행 단계로 이어지며, 사후 정량 효과 확인이 필요한 과제가 있습니다.',
  },

  'equipment-mgmt': {
    overview: '설비별 정기 점검, 소모품 교체, 알람/작업 이력, 체크시트 기반 운영 업무를 관리합니다.',
    features: ['설비 점검 Task', '소모품/부품 교체', '알람/작업 이력', '체크시트 점검', 'AI 설비 운영 요약'],
    recommendedFor: '설비 운영 / 점검 / 이슈 관리',
    milestones: [
      { title: '정기 점검', description: '설비별 점검 항목 수행' },
      { title: '부품/소모품 교체', description: '교체 주기 확인 및 작업' },
      { title: '이슈 조치', description: '알람/이상 발생 시 조치' },
      { title: '완료 보고', description: '작업 이력 정리 및 보고' },
    ],
    historyExamples: ['점검 결과 기록', '소모품 교체 이력', '알람/이슈 조치 이력', '작업 이력 정리 메모'],
    aiSummaryExample:
      'CMP 설비 정기 점검과 소모품 교체가 진행 중입니다. 알람 이력 확인과 Recipe/Parameter 점검이 예정되어 있으며, 마감 임박 점검 항목의 담당자 확인이 필요합니다.',
  },
};
