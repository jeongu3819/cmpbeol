import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Box, IconButton, Tooltip, LinearProgress } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import {
    compressPastedImage,
    toAbsoluteAttachmentUrl,
    normalizeImagesInRoot,
} from '../utils/richImage';

interface Props {
    /** 현재 description HTML. */
    value: string;
    /** 편집 결과 HTML 을 알려준다. */
    onChange: (html: string) => void;
    /** 붙여넣은 이미지 파일을 업로드하고 서버 접근 가능한 URL 을 돌려준다. */
    uploadImage: (file: File) => Promise<string>;
    placeholder?: string;
    disabled?: boolean;
    minHeight?: number;
    /** 편집 영역 최대 높이(px 또는 CSS 길이). 확대 편집 팝업에서 크게 쓰기 위해 노출. */
    maxHeight?: number | string;
    /** true 면 부모(flex container) 의 남은 공간을 가로·세로로 꽉 채운다. 확대 편집 팝업의 resize 추종용. */
    fill?: boolean;
}

/**
 * task 작업노트(WorkNoteModal)의 이미지 paste/resize 로직을 단일 필드용으로 재사용한 경량 리치 에디터.
 * - Ctrl+V 이미지 붙여넣기 → 업로드 → <img> 삽입 (data/blob URL 저장 안 함, 서버 URL 만)
 * - 이미지 클릭 → 선택 + 드래그 리사이즈 핸들 / 확대·축소 버튼 (style.width px 로 저장)
 * - 한글 IME: 편집 중에는 innerHTML 을 다시 쓰지 않아 자모 분리가 발생하지 않는다.
 */
const RichDescriptionEditor: React.FC<Props> = ({
    value, onChange, uploadImage, placeholder, disabled, minHeight = 120, maxHeight = 360, fill = false,
}) => {
    const ref = useRef<HTMLDivElement>(null);
    const lastEmitted = useRef<string>('');
    const composing = useRef(false);
    const [isUploading, setIsUploading] = useState(false);

    // 외부 value 가 바뀌었고 현재 DOM 과 다를 때만 innerHTML 동기화(편집 중에는 안 건드림 → IME 안전)
    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        if (composing.current) return;
        if (value === lastEmitted.current) return;
        el.innerHTML = value || '';
        normalizeImagesInRoot(el);
        lastEmitted.current = value || '';
    }, [value]);

    const emit = useCallback(() => {
        const el = ref.current;
        if (!el) return;
        const html = el.innerHTML;
        const normalized = html.replace(/<br\s*\/?>/gi, '').replace(/&nbsp;/gi, '').trim();
        const out = normalized === '' && !el.querySelector('img,table') ? '' : html;
        lastEmitted.current = out;
        onChange(out);
    }, [onChange]);

    // ── 이미지 선택 / 리사이즈 ──
    const [selectedImg, setSelectedImg] = useState<{ el: HTMLImageElement; rect: DOMRect } | null>(null);
    const dragRef = useRef<{ startX: number; startWidth: number; el: HTMLImageElement } | null>(null);

    const refreshSelRect = useCallback(() => {
        setSelectedImg(prev => (prev ? { el: prev.el, rect: prev.el.getBoundingClientRect() } : prev));
    }, []);

    useEffect(() => {
        if (!selectedImg) return;
        window.addEventListener('scroll', refreshSelRect, true);
        window.addEventListener('resize', refreshSelRect);
        return () => {
            window.removeEventListener('scroll', refreshSelRect, true);
            window.removeEventListener('resize', refreshSelRect);
        };
    }, [selectedImg, refreshSelRect]);

    // 바깥 클릭 시 선택 해제
    useEffect(() => {
        if (!selectedImg) return;
        const handler = (e: MouseEvent) => {
            const t = e.target as HTMLElement | null;
            if (!t) return;
            if (t.closest('[data-img-toolbar="1"]')) return;
            if (t.closest('[data-img-resize-handle="1"]')) return;
            if (t === selectedImg.el) return;
            setSelectedImg(null);
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, [selectedImg]);

    const resizeImage = (img: HTMLImageElement, action: 'shrink' | 'grow' | 'fit' | 'reset') => {
        if (action === 'reset') {
            img.style.width = '';
            img.style.height = '';
            img.removeAttribute('data-note-width');
        } else if (action === 'fit') {
            img.style.width = '100%';
            img.style.height = 'auto';
            img.setAttribute('data-note-width', '100%');
        } else {
            const current = img.offsetWidth || img.naturalWidth || 200;
            const delta = action === 'shrink' ? -50 : 50;
            const next = Math.max(50, Math.min(2000, current + delta));
            img.style.width = `${next}px`;
            img.style.height = 'auto';
            img.setAttribute('data-note-width', String(next));
        }
        emit();
        requestAnimationFrame(() => {
            setSelectedImg({ el: img, rect: img.getBoundingClientRect() });
        });
    };

    const startImageDragResize = useCallback((startEvent: React.PointerEvent, img: HTMLImageElement) => {
        startEvent.preventDefault();
        startEvent.stopPropagation();
        const startWidth = img.offsetWidth || img.naturalWidth || 200;
        dragRef.current = { startX: startEvent.clientX, startWidth, el: img };
        (startEvent.target as HTMLElement).setPointerCapture?.(startEvent.pointerId);

        const onMove = (e: PointerEvent) => {
            const r = dragRef.current;
            if (!r) return;
            const dx = e.clientX - r.startX;
            const next = Math.max(50, Math.min(2000, Math.round(r.startWidth + dx)));
            r.el.style.width = `${next}px`;
            r.el.style.height = 'auto';
            r.el.setAttribute('data-note-width', String(next));
            setSelectedImg({ el: r.el, rect: r.el.getBoundingClientRect() });
        };
        const onUp = () => {
            window.removeEventListener('pointermove', onMove);
            window.removeEventListener('pointerup', onUp);
            window.removeEventListener('pointercancel', onUp);
            if (dragRef.current) emit();
            dragRef.current = null;
        };
        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', onUp);
        window.addEventListener('pointercancel', onUp);
    }, [emit]);

    const handlePaste = useCallback(async (e: React.ClipboardEvent<HTMLDivElement>) => {
        if (disabled) return;
        const items = Array.from(e.clipboardData?.items || []);
        const imageItems = items.filter(it => it.type && it.type.startsWith('image/'));
        if (imageItems.length === 0) return; // 일반 텍스트는 기본 동작
        e.preventDefault();

        setIsUploading(true);
        let pending = imageItems.length;
        for (const item of imageItems) {
            const blob = item.getAsFile();
            if (!blob) { pending -= 1; if (pending <= 0) setIsUploading(false); continue; }
            const file = await compressPastedImage(blob, Date.now(), 'calendar-paste');
            try {
                const rawUrl = await uploadImage(file);
                const imageUrl = toAbsoluteAttachmentUrl(rawUrl);
                const img = document.createElement('img');
                img.src = imageUrl;
                img.alt = '붙여넣은 이미지';

                const sel = window.getSelection();
                const range = sel && sel.rangeCount ? sel.getRangeAt(0) : null;
                if (range && ref.current && ref.current.contains(range.commonAncestorContainer)) {
                    range.deleteContents();
                    range.insertNode(img);
                    range.setStartAfter(img);
                    range.collapse(true);
                    sel?.removeAllRanges();
                    sel?.addRange(range);
                } else if (ref.current) {
                    ref.current.appendChild(img);
                }
            } catch (err: any) {
                const status = err?.response?.status;
                const detail = err?.response?.data?.detail;
                let msg = '이미지 업로드에 실패했습니다.';
                if (status === 401 || status === 403) msg = '이미지 업로드 권한이 없습니다.';
                else if (status === 413) msg = '이미지 용량이 너무 커서 업로드할 수 없습니다. (서버 한도 초과)';
                else if (status && status >= 500) msg = '서버 오류로 업로드에 실패했습니다. 잠시 후 다시 시도해주세요.';
                else if (!status) msg = '네트워크 오류로 업로드에 실패했습니다.';
                if (detail && typeof detail === 'string') msg += `\n사유: ${detail}`;
                alert(msg);
            } finally {
                pending -= 1;
                if (pending <= 0) { setIsUploading(false); emit(); }
            }
        }
    }, [disabled, uploadImage, emit]);

    return (
        <Box sx={fill
            ? { position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0 }
            : { position: 'relative' }}>
            {isUploading && <LinearProgress sx={{ borderRadius: 1, mb: 0.5 }} />}
            <Box
                ref={ref}
                contentEditable={!disabled && !isUploading}
                suppressContentEditableWarning
                onInput={emit}
                onBlur={emit}
                onCompositionStart={() => { composing.current = true; }}
                onCompositionEnd={() => { composing.current = false; emit(); }}
                onPaste={handlePaste}
                onClick={(e) => {
                    const target = e.target as HTMLElement;
                    if (target instanceof HTMLImageElement) {
                        e.preventDefault();
                        e.stopPropagation();
                        setSelectedImg({ el: target, rect: target.getBoundingClientRect() });
                    }
                }}
                data-placeholder={placeholder || '설명을 입력하세요. 이미지는 Ctrl+V 로 붙여넣을 수 있습니다.'}
                sx={{
                    fontSize: '0.9rem',
                    lineHeight: 1.7,
                    p: 1.25,
                    ...(fill
                        ? { flex: 1, minHeight: 0, maxHeight: 'none' }
                        : { minHeight, maxHeight }),
                    overflowY: 'auto',
                    outline: 'none',
                    border: '1px solid',
                    borderColor: 'rgba(0,0,0,0.23)',
                    borderRadius: 1,
                    color: '#374151',
                    wordBreak: 'break-word',
                    whiteSpace: 'pre-wrap',
                    transition: 'border-color 0.15s',
                    '&:hover': { borderColor: 'rgba(0,0,0,0.55)' },
                    '&:focus': { borderColor: '#2955FF', borderWidth: '2px', p: '9px' },
                    '&:empty::before': {
                        content: 'attr(data-placeholder)',
                        color: '#9CA3AF',
                        pointerEvents: 'none',
                    },
                    '& b, & strong': { fontWeight: 700 },
                    '& img': {
                        maxWidth: '100%',
                        height: 'auto',
                        cursor: 'pointer',
                        borderRadius: 1,
                        display: 'block',
                        my: 0.5,
                        userSelect: 'none',
                        WebkitUserDrag: 'none',
                    },
                }}
            />

            {!disabled && selectedImg && (
                <>
                    {/* 리사이즈 toolbar */}
                    <Box
                        data-img-toolbar="1"
                        onMouseDown={(e) => e.preventDefault()}
                        sx={{
                            position: 'fixed',
                            top: Math.max(4, selectedImg.rect.top + 4),
                            left: selectedImg.rect.right - 4,
                            transform: 'translateX(-100%)',
                            zIndex: 2000,
                            display: 'flex', alignItems: 'center', gap: 0.25,
                            px: 0.5, py: 0.25, borderRadius: 999,
                            bgcolor: 'rgba(30,30,30,0.92)',
                            backdropFilter: 'blur(6px)',
                            boxShadow: '0 4px 12px rgba(0,0,0,0.35)',
                        }}
                    >
                        <Tooltip title="축소 (-50px)" arrow>
                            <IconButton size="small" onClick={() => resizeImage(selectedImg.el, 'shrink')} sx={{ color: '#fff', p: 0.4 }}>
                                <RemoveIcon sx={{ fontSize: '0.85rem' }} />
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="확대 (+50px)" arrow>
                            <IconButton size="small" onClick={() => resizeImage(selectedImg.el, 'grow')} sx={{ color: '#fff', p: 0.4 }}>
                                <AddIcon sx={{ fontSize: '0.85rem' }} />
                            </IconButton>
                        </Tooltip>
                        <Box sx={{ width: 1, height: 14, bgcolor: 'rgba(255,255,255,0.25)', mx: 0.25 }} />
                        <Tooltip title="폭 맞춤" arrow>
                            <IconButton size="small" onClick={() => resizeImage(selectedImg.el, 'fit')} sx={{ color: '#fff', p: 0.4, fontSize: '0.65rem', fontWeight: 700, minWidth: 32, borderRadius: 999 }}>
                                100%
                            </IconButton>
                        </Tooltip>
                        <Tooltip title="원본 크기" arrow>
                            <IconButton size="small" onClick={() => resizeImage(selectedImg.el, 'reset')} sx={{ color: '#fff', p: 0.4, fontSize: '0.65rem', fontWeight: 700, minWidth: 32, borderRadius: 999 }}>
                                원본
                            </IconButton>
                        </Tooltip>
                    </Box>
                    {/* 선택 테두리 */}
                    <Box sx={{
                        position: 'fixed',
                        top: selectedImg.rect.top - 2,
                        left: selectedImg.rect.left - 2,
                        width: selectedImg.rect.width + 4,
                        height: selectedImg.rect.height + 4,
                        border: '2px solid #2955FF',
                        borderRadius: 1,
                        pointerEvents: 'none',
                        zIndex: 1999,
                        boxSizing: 'border-box',
                    }} />
                    {/* 드래그 리사이즈 핸들 */}
                    <Box
                        data-img-resize-handle="1"
                        onPointerDown={(e) => startImageDragResize(e, selectedImg.el)}
                        onMouseDown={(e) => e.preventDefault()}
                        sx={{
                            position: 'fixed',
                            top: selectedImg.rect.bottom - 8,
                            left: selectedImg.rect.right - 8,
                            width: 16, height: 16,
                            bgcolor: '#2955FF',
                            border: '2px solid #fff',
                            borderRadius: 0.5,
                            cursor: 'nwse-resize',
                            zIndex: 2001,
                            boxShadow: '0 1px 3px rgba(0,0,0,0.35)',
                            touchAction: 'none',
                        }}
                    />
                </>
            )}
        </Box>
    );
};

export default RichDescriptionEditor;
