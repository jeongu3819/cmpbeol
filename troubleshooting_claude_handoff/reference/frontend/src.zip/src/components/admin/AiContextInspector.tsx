import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Button,
  Switch,
  FormControlLabel,
  Drawer,
  Tooltip,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert,
  CircularProgress,
  IconButton,
  Divider,
  Collapse,
  Stack,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import CloseIcon from '@mui/icons-material/Close';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import { api, AiContextPreviewResponse, AiManifestImage, ModelPacketResponse } from '../../api/client';

// ─────────────────────────────────────────────────────────────
// 색상/라벨 헬퍼
// ─────────────────────────────────────────────────────────────
const RECO_COLOR: Record<string, { color: string; bgcolor: string; label: string }> = {
  recommended: { color: '#16A34A', bgcolor: '#DCFCE7', label: 'recommended' },
  conditional: { color: '#B45309', bgcolor: '#FEF3C7', label: 'conditional' },
  not_recommended: { color: '#B91C1C', bgcolor: '#FEE2E2', label: 'not_recommended' },
  unknown: { color: '#6B7280', bgcolor: '#F3F4F6', label: 'unknown' },
};

const READINESS_STATUS_COLOR: Record<string, { color: string; bgcolor: string }> = {
  ok: { color: '#16A34A', bgcolor: '#DCFCE7' },
  needs_review: { color: '#B45309', bgcolor: '#FEF3C7' },
  unknown: { color: '#6B7280', bgcolor: '#F3F4F6' },
  no_images: { color: '#6B7280', bgcolor: '#F3F4F6' },
};

const recoChipSx = (level?: string | null) => {
  const c = RECO_COLOR[level || 'unknown'] || RECO_COLOR.unknown;
  return { color: c.color, bgcolor: c.bgcolor, fontWeight: 700, fontSize: '0.66rem', height: 20 };
};

const truncate = (v: any, n = 40): string => {
  const s = v === null || v === undefined || v === '' ? '-' : String(v);
  return s.length > n ? s.slice(0, n) + '…' : s;
};

const boolText = (v: any): string => (v === true ? 'true' : v === false ? 'false' : '-');

const copyToClipboard = async (obj: any, label: string) => {
  try {
    await navigator.clipboard.writeText(JSON.stringify(obj, null, 2));
    // eslint-disable-next-line no-alert
    alert(`${label} JSON을 클립보드에 복사했습니다.`);
  } catch {
    // eslint-disable-next-line no-alert
    alert('클립보드 복사에 실패했습니다. (브라우저 권한 확인)');
  }
};

// readability_status / recommendation_level 등에서 megapixels 추출
const mpOf = (img: AiManifestImage) => img.image_quality?.megapixels ?? null;
const readabilityOf = (img: AiManifestImage) => img.image_quality?.readability_status ?? null;
const recoLevelOf = (img: AiManifestImage) => img.image_quality?.recommendation_level ?? null;
const recommendedForAiOf = (img: AiManifestImage) => img.image_quality?.recommended_for_ai;
const originalAvailOf = (img: AiManifestImage) => img.ai_image_variants?.original?.available;
const recommendedActionOf = (img: AiManifestImage) => img.ai_image_variants?.ai_readable?.recommended_action ?? null;
const tilesRecOf = (img: AiManifestImage) => img.ai_image_variants?.tiles?.recommended;
const tileReasonOf = (img: AiManifestImage) => img.ai_image_variants?.tiles?.reason ?? null;
const cacheKeyOf = (img: AiManifestImage) => img.analysis_identity?.semantic_cache_key_preview ?? null;
const ctxStrengthOf = (img: AiManifestImage) => img.evidence_card?.context_strength ?? null;
// Model Packet 의 context_strength (text_context 안)
const ctxStrOf = (mp: ModelPacketResponse) => mp.packet?.text_context?.context_strength ?? null;
const extractionTargetOf = (img: AiManifestImage) => img.evidence_card?.extraction_target ?? null;
const instructionKeyOf = (img: AiManifestImage) => img.evidence_card?.model_instruction_key ?? null;

const CTX_STRENGTH_COLOR: Record<string, { color: string; bgcolor: string }> = {
  strong: { color: '#16A34A', bgcolor: '#DCFCE7' },
  medium: { color: '#2563EB', bgcolor: '#DBEAFE' },
  weak: { color: '#B45309', bgcolor: '#FEF3C7' },
  none: { color: '#B91C1C', bgcolor: '#FEE2E2' },
};

// role_confidence=low 단독으론 review_needed 가 아니지만, 이 role 들은 자체 판독 의존도가
// 높아 low confidence 와 결합되면 검토 대상으로 본다.
const REVIEW_LOW_CONF_ROLES = ['unknown', 'text_crop', 'partial_screen_capture'];

// '정상(검토 불필요)' 판정 — 백엔드 _ai_context_image_is_normal 과 동일 기준. 하나라도 어긋나면 review_needed.
// 정상 = readability ok + recommendation recommended + context_strength strong + nearby_text 존재
//        (context_text_source=nearby_text, fallback 미사용) + original 사용 가능 + cache_key 존재 + warning 없음.
// role_confidence=low 는 단독으로는 review 사유 아님(정상 이미지 노이즈 방지). 의심 role 과 결합될 때만 검토 대상.
const isImageNormal = (img: AiManifestImage, warningIds: Set<string>): boolean => {
  if (readabilityOf(img) !== 'ok') return false;
  if (recoLevelOf(img) !== 'recommended') return false;
  if (ctxStrengthOf(img) !== 'strong') return false;
  if (warningIds.has(img.image_id)) return false;
  if (!(img.nearby_text || '').trim()) return false;
  if (img.context_text_source !== 'nearby_text') return false;
  if ((img.fallback_context_text || '').trim()) return false;
  if (originalAvailOf(img) !== true) return false;
  if (!cacheKeyOf(img)) return false;
  if (
    ['low', 'none'].includes(img.image_role_confidence || '') &&
    REVIEW_LOW_CONF_ROLES.includes(img.image_role || '')
  )
    return false;
  return true;
};

// ─────────────────────────────────────────────────────────────
// 작은 카드 라벨/값 표시 헬퍼
// ─────────────────────────────────────────────────────────────
const Field: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <Box sx={{ display: 'flex', gap: 1, alignItems: 'baseline', minWidth: 0 }}>
    <Typography sx={{ fontSize: '0.72rem', color: '#6B7280', minWidth: 132, flexShrink: 0 }}>{label}</Typography>
    <Typography sx={{ fontSize: '0.78rem', color: '#111827', minWidth: 0, overflowWrap: 'anywhere', wordBreak: 'break-word', whiteSpace: 'normal' }}>{value ?? '-'}</Typography>
  </Box>
);

const StatCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <Card variant="outlined" sx={{ borderRadius: 2, width: '100%', minWidth: 0 }}>
    <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
      <Typography sx={{ fontWeight: 700, fontSize: '0.85rem', mb: 1.2, color: '#1A1D29' }}>{title}</Typography>
      <Stack spacing={0.6}>{children}</Stack>
    </CardContent>
  </Card>
);

// ─────────────────────────────────────────────────────────────
// 필터 정의
// ─────────────────────────────────────────────────────────────
type FilterDef = { key: string; label: string; get: (img: AiManifestImage) => string };
const FILTER_DEFS: FilterDef[] = [
  { key: 'readability_status', label: 'readability', get: img => readabilityOf(img) || '' },
  { key: 'recommendation_level', label: 'recommendation', get: img => recoLevelOf(img) || '' },
  { key: 'recommended_for_ai', label: 'recommended_for_ai', get: img => boolText(recommendedForAiOf(img)) },
  { key: 'image_role', label: 'image_role', get: img => img.image_role || '' },
  { key: 'image_role_source', label: 'role_source', get: img => img.image_role_source || '' },
  { key: 'source_entity_type', label: 'source_type', get: img => img.source_entity_type || '' },
  { key: 'relation_type', label: 'relation', get: img => img.relation_type || '' },
  { key: 'context_text_source', label: 'context_src', get: img => img.context_text_source || '' },
  { key: 'context_strength', label: 'ctx_strength', get: img => ctxStrengthOf(img) || '' },
  { key: 'extraction_target', label: 'extraction', get: img => extractionTargetOf(img) || '' },
  { key: 'model_instruction_key', label: 'instruction', get: img => instructionKeyOf(img) || '' },
];

// 명령어/코드/로그/터미널/설정 계열 role
const COMMAND_LIKE_ROLES = ['command_snippet', 'code_snippet', 'log_capture', 'terminal_capture', 'config_capture'];

const QUICK_FILTERS: { key: string; label: string }[] = [
  { key: 'all', label: '전체' },
  { key: 'recommended', label: 'Recommended' },
  { key: 'conditional', label: 'Conditional' },
  { key: 'not_recommended', label: 'Not recommended' },
  { key: 'compact_text_crop', label: 'Compact crop' },
  { key: 'small_but_readable', label: 'Small but readable' },
  { key: 'partial_screen_capture', label: 'Partial screen capture' },
  { key: 'chart_table_error', label: 'Chart/Table/Error' },
  { key: 'fallback_text', label: 'Fallback text 사용' },
  { key: 'has_cache_key', label: 'Cache key 있음' },
  { key: 'warnings', label: 'Warnings 대상' },
  { key: 'ctx_weak', label: 'Context 약함' },
  { key: 'command_like', label: '명령어/코드/로그' },
  { key: 'error_screen', label: '에러 화면' },
  { key: 'table_chart', label: '표/차트' },
  { key: 'equipment', label: '설비 화면' },
  { key: 'need_instruction', label: '모델 지시 필요' },
];

interface Props {
  userId: number;
}

const AiContextInspector: React.FC<Props> = ({ userId }) => {
  const [projectIdInput, setProjectIdInput] = useState('1');
  const [maxImages, setMaxImages] = useState(50);
  const [includeImages, setIncludeImages] = useState(true);

  const [data, setData] = useState<AiContextPreviewResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [quickFilter, setQuickFilter] = useState('all');
  const [filterValues, setFilterValues] = useState<Record<string, string>>({});
  const [taskIdFilter, setTaskIdFilter] = useState('');
  // 기본은 "검토 필요 이미지만" — 정상 이미지는 전체 보기 시에만 표시
  const [showAll, setShowAll] = useState(false);
  // 특정 이미지 직접 찾기
  const [imageIdSearch, setImageIdSearch] = useState('');
  const [sourceIdSearch, setSourceIdSearch] = useState('');

  const [selected, setSelected] = useState<AiManifestImage | null>(null);
  const [warningsOpen, setWarningsOpen] = useState(true);
  const [rawJsonOpen, setRawJsonOpen] = useState(false);
  const [instructionOpen, setInstructionOpen] = useState(false);

  // Model Compatibility Preview (image_id 1개 → model_input_packet + provider_payload).
  // 버튼 클릭 시 생성(엔드포인트가 매번 context 를 rebuild 하므로 row 클릭 자동 생성은 하지 않음).
  const [modelPacket, setModelPacket] = useState<ModelPacketResponse | null>(null);
  const [modelPacketLoading, setModelPacketLoading] = useState(false);
  const [modelPacketError, setModelPacketError] = useState<string | null>(null);
  const [packetProvider, setPacketProvider] = useState('generic');
  const [packetInputMode, setPacketInputMode] = useState('image_with_evidence_card');
  const [payloadOpen, setPayloadOpen] = useState(false);

  // 이미지 preview (선택된 1장만 lazy loading). object URL + AbortController cleanup.
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState(false);
  // 403(권한 없음)은 일반 실패와 구분해 별도 안내한다.
  const [previewForbidden, setPreviewForbidden] = useState(false);
  const previewUrlRef = useRef<string | null>(null);

  const releasePreviewUrl = () => {
    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current);
      previewUrlRef.current = null;
    }
  };

  // 선택 이미지 변경 시: 이전 preview 정리 후 선택된 1장만 요청. 언마운트 시에도 정리.
  useEffect(() => {
    if (!selected || !data) {
      releasePreviewUrl();
      setPreviewUrl(null);
      setPreviewLoading(false);
      setPreviewError(false);
      setPreviewForbidden(false);
      return;
    }
    const controller = new AbortController();
    releasePreviewUrl();
    setPreviewUrl(null);
    setPreviewError(false);
    setPreviewForbidden(false);
    setPreviewLoading(true);
    const pid = data.project_id;
    const imageId = selected.image_id;
    (async () => {
      try {
        const blob = await api.getProjectAiContextPreviewImage(pid, imageId, userId, controller.signal);
        const url = URL.createObjectURL(blob);
        previewUrlRef.current = url;
        setPreviewUrl(url);
      } catch (e: any) {
        if (e?.code === 'ERR_CANCELED' || e?.name === 'CanceledError' || e?.name === 'AbortError') return;
        setPreviewForbidden(e?.response?.status === 403);
        setPreviewError(true);
      } finally {
        setPreviewLoading(false);
      }
    })();
    return () => {
      controller.abort();
      releasePreviewUrl();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.image_id, data?.project_id]);

  // 언마운트 시 object URL 누수 방지
  useEffect(() => releasePreviewUrl, []);

  // 선택 이미지가 바뀌면 이전 Model Packet 결과를 비운다(image_id 단위).
  useEffect(() => {
    setModelPacket(null);
    setModelPacketError(null);
    setPayloadOpen(false);
  }, [selected?.image_id]);

  const generateModelPacket = async () => {
    if (!selected || !data) return;
    setModelPacketLoading(true);
    setModelPacketError(null);
    try {
      const res = await api.getProjectAiContextModelPacket(data.project_id, selected.image_id, userId, {
        provider: packetProvider,
        input_mode: packetInputMode,
      });
      setModelPacket(res);
    } catch (e: any) {
      setModelPacket(null);
      setModelPacketError(e?.response?.data?.detail || e?.message || 'Model Packet 생성 실패');
    } finally {
      setModelPacketLoading(false);
    }
  };

  const load = async () => {
    const pid = parseInt(projectIdInput, 10);
    if (!pid || pid <= 0) {
      setError('유효한 project_id 를 입력하세요.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await api.getProjectAiContextPreview(pid, userId, {
        include_images: includeImages,
        max_images: maxImages,
      });
      setData(res);
      setQuickFilter('all');
      setFilterValues({});
      setTaskIdFilter('');
      setImageIdSearch('');
      setSourceIdSearch('');
      setShowAll(false);
      setSelected(null);
    } catch (e: any) {
      setData(null);
      setError(e?.response?.data?.detail || e?.message || 'Preview 불러오기 실패');
    } finally {
      setLoading(false);
    }
  };

  const manifest = data?.image_manifest || [];

  // warning 에 언급된 image_id 집합 (Warnings 대상 quick filter 용)
  const warningImageIds = useMemo(() => {
    const ids = new Set<string>();
    for (const w of data?.warnings || []) {
      for (const img of manifest) {
        if (img.image_id && w.includes(img.image_id)) ids.add(img.image_id);
      }
    }
    return ids;
  }, [data?.warnings, manifest]);

  // 필터 드롭다운 옵션 (manifest 에서 distinct)
  const filterOptions = useMemo(() => {
    const opts: Record<string, string[]> = {};
    for (const def of FILTER_DEFS) {
      const set = new Set<string>();
      for (const img of manifest) {
        const v = def.get(img);
        if (v) set.add(v);
      }
      opts[def.key] = Array.from(set).sort();
    }
    return opts;
  }, [manifest]);

  const matchesQuick = (img: AiManifestImage): boolean => {
    switch (quickFilter) {
      case 'all':
        return true;
      case 'recommended':
        return recoLevelOf(img) === 'recommended';
      case 'conditional':
        return recoLevelOf(img) === 'conditional';
      case 'not_recommended':
        return recoLevelOf(img) === 'not_recommended';
      case 'compact_text_crop':
        return readabilityOf(img) === 'compact_text_crop';
      case 'small_but_readable':
        return readabilityOf(img) === 'small_but_readable';
      case 'partial_screen_capture':
        return readabilityOf(img) === 'partial_screen_capture';
      case 'chart_table_error':
        return ['chart', 'table', 'error_screen'].includes(img.image_role || '');
      case 'fallback_text':
        return !!img.context_text_source && img.context_text_source !== 'nearby_text';
      case 'has_cache_key':
        return !!cacheKeyOf(img);
      case 'warnings':
        return warningImageIds.has(img.image_id);
      case 'ctx_weak':
        return ['weak', 'none'].includes(ctxStrengthOf(img) || '');
      case 'command_like':
        return COMMAND_LIKE_ROLES.includes(img.image_role || '');
      case 'error_screen':
        return img.image_role === 'error_screen';
      case 'table_chart':
        return ['chart', 'table', 'document_table'].includes(img.image_role || '');
      case 'equipment':
        return img.image_role === 'equipment_screen';
      case 'need_instruction':
        // 모델 지시가 특히 중요한 이미지: 맥락 약하거나 role 신뢰도 낮거나 conditional/not_recommended
        return (
          ['weak', 'none'].includes(ctxStrengthOf(img) || '') ||
          ['low', 'none'].includes(img.image_role_confidence || '') ||
          ['conditional', 'not_recommended'].includes(recoLevelOf(img) || '')
        );
      default:
        return true;
    }
  };

  const reviewNeededCount = useMemo(
    () => manifest.filter(img => !isImageNormal(img, warningImageIds)).length,
    [manifest, warningImageIds]
  );

  const filtered = useMemo(() => {
    return manifest.filter(img => {
      // 기본 스코프: 검토 필요 이미지만(정상 이미지 숨김). 전체 보기 시 모두 표시.
      if (!showAll && isImageNormal(img, warningImageIds)) return false;
      if (!matchesQuick(img)) return false;
      for (const def of FILTER_DEFS) {
        const want = filterValues[def.key];
        if (want && def.get(img) !== want) return false;
      }
      if (taskIdFilter.trim()) {
        if (String(img.task_id ?? '') !== taskIdFilter.trim()) return false;
      }
      if (imageIdSearch.trim()) {
        if (!(img.image_id || '').toLowerCase().includes(imageIdSearch.trim().toLowerCase())) return false;
      }
      if (sourceIdSearch.trim()) {
        if (String(img.source_entity_id ?? '') !== sourceIdSearch.trim()) return false;
      }
      return true;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [manifest, showAll, quickFilter, filterValues, taskIdFilter, imageIdSearch, sourceIdSearch, warningImageIds]);

  const readiness = data?.image_readiness_summary || {};
  const policy = data?.analysis_policy_summary || {};
  const counts = data?.counts || {};

  return (
    <Box>
      <Alert severity="info" sx={{ borderRadius: 2, mb: 2, fontSize: '0.82rem' }}>
        <strong>AI Context Inspector (super_admin 전용)</strong> — 프로젝트가 AI 요약에 전달할 text_context /
        image_manifest / image_quality / image_role / analysis_identity 를 눈으로 검증하는 내부 도구입니다.
        <br />
        이 화면은 <strong>vision 모델을 호출하지 않으며</strong>, 기존 AI Report / AI Query 와 무관합니다.
        <strong> conditional 이미지는 AI 분석 후보이지만 결과 검증이 필요합니다.</strong>
      </Alert>

      {/* ── 입력 영역 ── */}
      <Card variant="outlined" sx={{ borderRadius: 2, mb: 2 }}>
        <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
          <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
            <TextField
              size="small"
              label="project_id"
              value={projectIdInput}
              onChange={e => setProjectIdInput(e.target.value.replace(/[^0-9]/g, ''))}
              onKeyDown={e => {
                if (e.key === 'Enter') load();
              }}
              sx={{ width: 130 }}
            />
            <TextField
              select
              size="small"
              label="max_images"
              value={maxImages}
              onChange={e => setMaxImages(Number(e.target.value))}
              sx={{ width: 130 }}
            >
              {[10, 20, 30, 50, 100, 200].map(n => (
                <MenuItem key={n} value={n}>
                  {n}
                </MenuItem>
              ))}
            </TextField>
            <FormControlLabel
              control={<Switch checked={includeImages} onChange={e => setIncludeImages(e.target.checked)} size="small" />}
              label={<Typography sx={{ fontSize: '0.82rem' }}>include_images</Typography>}
            />
            <Box sx={{ flexGrow: 1 }} />
            <Button
              variant="contained"
              size="small"
              onClick={load}
              disabled={loading}
              startIcon={loading ? <CircularProgress size={15} /> : undefined}
              sx={{ textTransform: 'none', fontWeight: 600 }}
            >
              Preview 불러오기
            </Button>
            <Button
              variant="outlined"
              size="small"
              onClick={load}
              disabled={loading || !data}
              startIcon={<RefreshIcon />}
              sx={{ textTransform: 'none', fontWeight: 600 }}
            >
              새로고침
            </Button>
            <Button
              variant="outlined"
              size="small"
              onClick={() => data && copyToClipboard(data, '전체 응답')}
              disabled={!data}
              startIcon={<ContentCopyIcon />}
              sx={{ textTransform: 'none', fontWeight: 600 }}
            >
              JSON 복사
            </Button>
          </Box>
          <Typography sx={{ fontSize: '0.72rem', color: '#9CA3AF', mt: 1 }}>
            user_id={userId} 로 호출됩니다. (현재 로그인 super_admin)
          </Typography>
        </CardContent>
      </Card>

      {error && (
        <Alert severity="error" sx={{ borderRadius: 2, mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {!data && !error && !loading && (
        <Typography sx={{ color: '#9CA3AF', fontSize: '0.85rem', py: 4, textAlign: 'center' }}>
          project_id 를 입력하고 "Preview 불러오기" 를 눌러주세요.
        </Typography>
      )}

      {data && (
        <>
          {/* ── 요약 카드 3개 (반응형 grid: 넓은 화면 3열 → 좁은 화면 자동 2/1열) ── */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
              gap: 2,
              mb: 2,
              width: '100%',
            }}
          >
            <StatCard title="Project Summary">
              <Field label="project_id" value={data.project_id} />
              <Field label="project_name" value={data.project_name} />
              <Field label="context_schema" value={data.context_schema_version} />
              <Field label="image_manifest_ver" value={data.image_manifest_version} />
              <Field label="readiness_ver" value={data.readiness_version} />
              <Field label="future_prompt_ver" value={data.future_image_analysis_prompt_version} />
              <Divider sx={{ my: 0.6 }} />
              <Field label="sub_projects" value={counts.sub_projects ?? '-'} />
              <Field label="tasks" value={counts.tasks ?? '-'} />
              <Field label="work_notes" value={counts.work_notes ?? '-'} />
              <Field label="project_notes" value={counts.project_notes ?? '-'} />
              <Field label="image_manifest" value={counts.image_manifest ?? '-'} />
            </StatCard>

            <StatCard title="Image Readiness Summary">
              <Box sx={{ mb: 0.5 }}>
                <Chip
                  label={`status: ${readiness.status ?? '-'}`}
                  size="small"
                  sx={{
                    fontWeight: 700,
                    fontSize: '0.68rem',
                    ...(READINESS_STATUS_COLOR[readiness.status] || READINESS_STATUS_COLOR.unknown),
                  }}
                />
              </Box>
              <Field label="total_images" value={readiness.total_images ?? '-'} />
              <Field label="recommended_for_ai" value={readiness.recommended_for_ai ?? '-'} />
              <Field label="fully_recommended" value={readiness.fully_recommended_for_ai ?? '-'} />
              <Field label="conditional_for_ai" value={readiness.conditional_for_ai ?? '-'} />
              <Field label="not_recommended" value={readiness.not_recommended_for_ai ?? '-'} />
              <Divider sx={{ my: 0.6 }} />
              <Field label="compact_text_crop" value={readiness.compact_text_crop ?? '-'} />
              <Field label="small_but_readable" value={readiness.small_but_readable ?? '-'} />
              <Field label="partial_screen_capture" value={readiness.partial_screen_capture ?? '-'} />
              <Field label="missing_dimensions" value={readiness.missing_dimensions ?? '-'} />
              <Field label="too_small" value={readiness.too_small ?? '-'} />
              <Field label="low_resolution" value={readiness.low_resolution ?? '-'} />
              <Field label="tiles_recommended" value={readiness.tiles_recommended ?? '-'} />
            </StatCard>

            <StatCard title="Analysis Policy Summary">
              <Field label="metadata_cacheable" value={policy.metadata_cacheable_images ?? '-'} />
              <Field label="semantic_cacheable" value={policy.semantic_cacheable_by_default ?? '-'} />
              <Field label="requires_reanalysis" value={policy.requires_context_aware_reanalysis ?? '-'} />
              <Field label="has_cache_key_preview" value={policy.has_cache_key_preview ?? '-'} />
              <Field label="policy" value={<span style={{ wordBreak: 'break-all' }}>{policy.policy ?? '-'}</span>} />
              <Typography sx={{ fontSize: '0.7rem', color: '#9CA3AF', mt: 0.8 }}>
                이미지 메타데이터는 재사용 가능하지만, 모델의 이미지 의미 해석 결과는 정답 캐시로 고정하면 안 됩니다.
                모델/프롬프트/주변 텍스트/Task 맥락이 바뀌면 재분석 대상입니다.
              </Typography>
            </StatCard>
          </Box>

          {/* ── Warnings ── */}
          {(data.warnings?.length ?? 0) > 0 && (
            <Card variant="outlined" sx={{ borderRadius: 2, mb: 2, borderColor: '#FCD34D', bgcolor: '#FFFBEB' }}>
              <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
                <Box
                  sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}
                  onClick={() => setWarningsOpen(o => !o)}
                >
                  <Typography sx={{ fontWeight: 700, fontSize: '0.82rem', color: '#92400E', flexGrow: 1 }}>
                    ⚠ Warnings ({data.warnings.length})
                  </Typography>
                  <IconButton size="small">{warningsOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}</IconButton>
                </Box>
                <Collapse in={warningsOpen}>
                  <Box component="ul" sx={{ pl: 2.5, m: 0, mt: 0.5 }}>
                    {data.warnings.map((w, i) => (
                      <Typography
                        component="li"
                        key={i}
                        sx={{ fontSize: '0.74rem', color: '#92400E', mb: 0.3, overflowWrap: 'anywhere', wordBreak: 'break-word' }}
                      >
                        {w}
                      </Typography>
                    ))}
                  </Box>
                </Collapse>
              </CardContent>
            </Card>
          )}

          {/* ── 스코프 토글 + 직접 찾기 ── */}
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', mb: 1.5, alignItems: 'center' }}>
            <FormControlLabel
              control={<Switch checked={!showAll} onChange={e => setShowAll(!e.target.checked)} size="small" />}
              label={
                <Typography sx={{ fontSize: '0.82rem', fontWeight: 700 }}>
                  검토 필요만 ({reviewNeededCount})
                </Typography>
              }
            />
            <Typography sx={{ fontSize: '0.74rem', color: '#9CA3AF' }}>
              {showAll ? '전체 이미지 표시 중' : '정상 이미지는 숨김 — 토글 끄면 전체 보기'}
            </Typography>
            <Box sx={{ flexGrow: 1 }} />
            <TextField
              size="small"
              label="image_id 검색"
              value={imageIdSearch}
              onChange={e => setImageIdSearch(e.target.value)}
              sx={{ width: 220 }}
            />
            <TextField
              size="small"
              label="source_entity_id"
              value={sourceIdSearch}
              onChange={e => setSourceIdSearch(e.target.value.replace(/[^0-9]/g, ''))}
              sx={{ width: 130 }}
            />
          </Box>

          {/* ── 필터 ── */}
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 1.5 }}>
            {QUICK_FILTERS.map(qf => (
              <Chip
                key={qf.key}
                label={qf.label}
                size="small"
                onClick={() => setQuickFilter(qf.key)}
                color={quickFilter === qf.key ? 'primary' : 'default'}
                variant={quickFilter === qf.key ? 'filled' : 'outlined'}
                sx={{ fontSize: '0.7rem', fontWeight: 600 }}
              />
            ))}
          </Box>
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', mb: 1.5, alignItems: 'center' }}>
            {FILTER_DEFS.map(def => (
              <FormControl key={def.key} size="small" sx={{ minWidth: 150 }}>
                <InputLabel sx={{ fontSize: '0.8rem' }}>{def.label}</InputLabel>
                <Select
                  label={def.label}
                  value={filterValues[def.key] || ''}
                  onChange={e => setFilterValues(prev => ({ ...prev, [def.key]: e.target.value }))}
                  sx={{ fontSize: '0.78rem' }}
                >
                  <MenuItem value="">
                    <em>전체</em>
                  </MenuItem>
                  {(filterOptions[def.key] || []).map(opt => (
                    <MenuItem key={opt} value={opt} sx={{ fontSize: '0.78rem' }}>
                      {opt}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            ))}
            <TextField
              size="small"
              label="task_id"
              value={taskIdFilter}
              onChange={e => setTaskIdFilter(e.target.value.replace(/[^0-9]/g, ''))}
              sx={{ width: 110 }}
            />
            <Button
              size="small"
              onClick={() => {
                setQuickFilter('all');
                setFilterValues({});
                setTaskIdFilter('');
                setImageIdSearch('');
                setSourceIdSearch('');
              }}
              sx={{ textTransform: 'none' }}
            >
              필터 초기화
            </Button>
            <Typography sx={{ fontSize: '0.74rem', color: '#6B7280', ml: 'auto' }}>
              {filtered.length} / {manifest.length} images
            </Typography>
          </Box>

          {/* ── Image Manifest Table ── */}
          <TableContainer component={Card} variant="outlined" sx={{ borderRadius: 2, maxWidth: '100%', overflowX: 'auto' }}>
            <Table size="small" sx={{ minWidth: 1900 }}>
              <TableHead>
                <TableRow sx={{ '& th': { fontWeight: 700, fontSize: '0.7rem', whiteSpace: 'nowrap', bgcolor: '#F9FAFB' } }}>
                  <TableCell>no</TableCell>
                  <TableCell>image_id</TableCell>
                  <TableCell>task_id</TableCell>
                  <TableCell>task_title</TableCell>
                  <TableCell>source_type</TableCell>
                  <TableCell>relation</TableCell>
                  <TableCell>nearby_text</TableCell>
                  <TableCell>fallback_text</TableCell>
                  <TableCell>ctx_source</TableCell>
                  <TableCell>ctx_str</TableCell>
                  <TableCell>image_role</TableCell>
                  <TableCell>target</TableCell>
                  <TableCell>role_source</TableCell>
                  <TableCell>role_conf</TableCell>
                  <TableCell>w</TableCell>
                  <TableCell>h</TableCell>
                  <TableCell>MP</TableCell>
                  <TableCell>readability</TableCell>
                  <TableCell>recommendation</TableCell>
                  <TableCell>rec_for_ai</TableCell>
                  <TableCell>original</TableCell>
                  <TableCell>action</TableCell>
                  <TableCell>tiles</TableCell>
                  <TableCell>tile_reason</TableCell>
                  <TableCell>cache_key</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filtered.map((img, idx) => (
                  <TableRow
                    key={img.image_id}
                    hover
                    onClick={() => setSelected(img)}
                    sx={{ cursor: 'pointer', '& td': { fontSize: '0.7rem', whiteSpace: 'nowrap' } }}
                  >
                    <TableCell>{idx + 1}</TableCell>
                    <TableCell>
                      <Tooltip title={img.image_id}>
                        <span>{truncate(img.image_id, 28)}</span>
                      </Tooltip>
                    </TableCell>
                    <TableCell>{img.task_id ?? '-'}</TableCell>
                    <TableCell>
                      <Tooltip title={img.task_title || ''}>
                        <span>{truncate(img.task_title, 18)}</span>
                      </Tooltip>
                    </TableCell>
                    <TableCell>{img.source_entity_type ?? '-'}</TableCell>
                    <TableCell>{img.relation_type ?? '-'}</TableCell>
                    <TableCell>
                      <Tooltip title={img.nearby_text || ''}>
                        <span>{truncate(img.nearby_text, 24)}</span>
                      </Tooltip>
                    </TableCell>
                    <TableCell>
                      <Tooltip title={img.fallback_context_text || ''}>
                        <span>{truncate(img.fallback_context_text, 24)}</span>
                      </Tooltip>
                    </TableCell>
                    <TableCell>{img.context_text_source ?? '-'}</TableCell>
                    <TableCell>
                      {ctxStrengthOf(img) ? (
                        <Chip
                          label={ctxStrengthOf(img)}
                          size="small"
                          sx={{
                            fontSize: '0.62rem',
                            height: 18,
                            ...(CTX_STRENGTH_COLOR[ctxStrengthOf(img) || ''] || {}),
                          }}
                        />
                      ) : (
                        '-'
                      )}
                    </TableCell>
                    <TableCell>{img.image_role ?? '-'}</TableCell>
                    <TableCell>{extractionTargetOf(img) ?? '-'}</TableCell>
                    <TableCell>{img.image_role_source ?? '-'}</TableCell>
                    <TableCell>{img.image_role_confidence ?? '-'}</TableCell>
                    <TableCell>{img.width ?? '-'}</TableCell>
                    <TableCell>{img.height ?? '-'}</TableCell>
                    <TableCell>{mpOf(img) ?? '-'}</TableCell>
                    <TableCell>{readabilityOf(img) ?? '-'}</TableCell>
                    <TableCell>
                      <Chip label={recoLevelOf(img) || 'unknown'} size="small" sx={recoChipSx(recoLevelOf(img))} />
                    </TableCell>
                    <TableCell>{boolText(recommendedForAiOf(img))}</TableCell>
                    <TableCell>{boolText(originalAvailOf(img))}</TableCell>
                    <TableCell>{recommendedActionOf(img) ?? '-'}</TableCell>
                    <TableCell>{boolText(tilesRecOf(img))}</TableCell>
                    <TableCell>{tileReasonOf(img) ?? '-'}</TableCell>
                    <TableCell>{cacheKeyOf(img) ? truncate(cacheKeyOf(img), 10) : '-'}</TableCell>
                  </TableRow>
                ))}
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={25} sx={{ textAlign: 'center', py: 3, color: '#9CA3AF', fontSize: '0.8rem' }}>
                      {manifest.length === 0
                        ? 'image_manifest 가 비어 있습니다. (include_images=true 인지 확인)'
                        : !showAll && reviewNeededCount === 0
                          ? '검토가 필요한 이미지가 없습니다. (모두 정상) — "검토 필요만" 토글을 끄면 전체를 볼 수 있습니다.'
                          : '필터에 해당하는 이미지가 없습니다.'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>

          {/* text_context preview */}
          <Card variant="outlined" sx={{ borderRadius: 2, mt: 2 }}>
            <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
              <Typography sx={{ fontWeight: 700, fontSize: '0.82rem', mb: 1 }}>text_context_preview</Typography>
              <Box
                component="pre"
                sx={{
                  m: 0,
                  p: 1.5,
                  bgcolor: '#F9FAFB',
                  borderRadius: 1,
                  fontSize: '0.72rem',
                  whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word',
                  maxHeight: 240,
                  overflow: 'auto',
                }}
              >
                {data.text_context_preview || '(empty)'}
              </Box>
            </CardContent>
          </Card>
        </>
      )}

      {/* ── Row 상세 Drawer ── */}
      <Drawer anchor="right" open={!!selected} onClose={() => setSelected(null)}>
        <Box sx={{ width: { xs: 360, sm: 520 }, p: 2.5 }}>
          {selected && (
            <>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1.5 }}>
                <Typography sx={{ fontWeight: 800, fontSize: '0.95rem', flexGrow: 1 }}>이미지 상세</Typography>
                <IconButton size="small" onClick={() => setSelected(null)}>
                  <CloseIcon fontSize="small" />
                </IconButton>
              </Box>

              {/* ── 실제 이미지 preview (선택된 1장만 lazy loading) ── */}
              <Box
                sx={{
                  mb: 1.5,
                  borderRadius: 1,
                  border: '1px solid #E5E7EB',
                  bgcolor: '#0F172A',
                  minHeight: 160,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  overflow: 'hidden',
                }}
              >
                {previewLoading ? (
                  <Box sx={{ py: 5, textAlign: 'center' }}>
                    <CircularProgress size={22} sx={{ color: '#fff' }} />
                  </Box>
                ) : previewError ? (
                  <Typography sx={{ color: '#FCA5A5', fontSize: '0.78rem', py: 5, px: 2, textAlign: 'center' }}>
                    {previewForbidden
                      ? '이 이미지에 접근할 권한이 없습니다.'
                      : '이미지 미리보기를 불러오지 못했습니다.'}
                  </Typography>
                ) : previewUrl ? (
                  <Box
                    component="img"
                    src={previewUrl}
                    alt={selected.image_id}
                    sx={{ maxWidth: '100%', maxHeight: 360, objectFit: 'contain', display: 'block' }}
                  />
                ) : (
                  <Typography sx={{ color: '#94A3B8', fontSize: '0.78rem', py: 5 }}>미리보기 없음</Typography>
                )}
              </Box>
              <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mb: 1 }}>
                <Chip label={`role: ${selected.image_role || '-'}`} size="small" sx={{ fontSize: '0.66rem', height: 20 }} />
                <Chip
                  label={`conf: ${selected.image_role_confidence || '-'}`}
                  size="small"
                  sx={{ fontSize: '0.66rem', height: 20 }}
                />
                <Chip
                  label={`readability: ${readabilityOf(selected) || '-'}`}
                  size="small"
                  sx={{ fontSize: '0.66rem', height: 20 }}
                />
                <Chip label={recoLevelOf(selected) || 'unknown'} size="small" sx={recoChipSx(recoLevelOf(selected))} />
              </Box>
              <Typography sx={{ fontSize: '0.7rem', color: '#9CA3AF', mb: 0.3 }}>
                원본 크기: {selected.image_quality?.width ?? '미수집'} × {selected.image_quality?.height ?? '미수집'} · display_size: 미수집
              </Typography>
              <Typography sx={{ fontSize: '0.68rem', color: '#B45309', mb: 1.5 }}>
                이 미리보기는 검증용입니다. 향후 AI 입력은 display 크기가 아니라 original/ai_readable 기준을 사용해야 합니다.
              </Typography>

              {/* ── Image Evidence Card ── */}
              <Box
                sx={{
                  mb: 2,
                  p: 1.5,
                  borderRadius: 1,
                  border: '1px solid #C7D2FE',
                  bgcolor: '#EEF2FF',
                }}
              >
                <Typography sx={{ fontWeight: 800, fontSize: '0.8rem', color: '#3730A3', mb: 0.8 }}>
                  🧩 Image Evidence Card
                </Typography>
                <Stack spacing={0.5}>
                  <Field
                    label="context_strength"
                    value={
                      ctxStrengthOf(selected) ? (
                        <Chip
                          label={ctxStrengthOf(selected)}
                          size="small"
                          sx={{ fontSize: '0.64rem', height: 18, ...(CTX_STRENGTH_COLOR[ctxStrengthOf(selected) || ''] || {}) }}
                        />
                      ) : (
                        '-'
                      )
                    }
                  />
                  <Field label="extraction_target" value={extractionTargetOf(selected) ?? '-'} />
                  <Field label="model_instruction_key" value={instructionKeyOf(selected) ?? '-'} />
                  <Field label="ai_input_strategy" value={selected.evidence_card?.ai_input_strategy ?? '-'} />
                  <Field
                    label="quality_warning"
                    value={
                      selected.evidence_card?.quality_warning ? (
                        <span style={{ color: '#B45309' }}>{selected.evidence_card.quality_warning}</span>
                      ) : (
                        '-'
                      )
                    }
                  />
                </Stack>
                {selected.evidence_card?.model_instruction_text && (
                  <>
                    <Box
                      sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer', mt: 0.8 }}
                      onClick={() => setInstructionOpen(o => !o)}
                    >
                      <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: '#3730A3', flexGrow: 1 }}>
                        Model instruction preview
                      </Typography>
                      <IconButton size="small">
                        {instructionOpen ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
                      </IconButton>
                    </Box>
                    <Collapse in={instructionOpen}>
                      <Typography
                        sx={{
                          fontSize: '0.72rem',
                          color: '#1E1B4B',
                          bgcolor: '#fff',
                          p: 1,
                          borderRadius: 1,
                          border: '1px solid #C7D2FE',
                          whiteSpace: 'pre-wrap',
                        }}
                      >
                        {selected.evidence_card.model_instruction_text}
                      </Typography>
                    </Collapse>
                  </>
                )}
                <Typography sx={{ fontSize: '0.66rem', color: '#6366F1', mt: 0.8 }}>
                  이 카드는 모델 연결 전 프롬프트 품질 검토용입니다. (vision 모델 미호출)
                </Typography>
              </Box>

              {/* ── Model Compatibility Preview ── */}
              <Box
                sx={{
                  mb: 2,
                  p: 1.5,
                  borderRadius: 1,
                  border: '1px solid #BBF7D0',
                  bgcolor: '#F0FDF4',
                }}
              >
                <Typography sx={{ fontWeight: 800, fontSize: '0.8rem', color: '#166534', mb: 0.8 }}>
                  🔌 Model Compatibility Preview
                </Typography>
                <Typography sx={{ fontSize: '0.68rem', color: '#15803D', mb: 1 }}>
                  image_manifest → 사내 모델 API 입력 패킷(힌트 기반). image_role 은 <strong>image_role_hint</strong> 로
                  전달되며, 실제 모델/OCR 은 호출하지 않습니다.
                </Typography>

                <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center', mb: 1 }}>
                  <FormControl size="small" sx={{ minWidth: 120 }}>
                    <InputLabel sx={{ fontSize: '0.78rem' }}>provider</InputLabel>
                    <Select
                      label="provider"
                      value={packetProvider}
                      onChange={e => setPacketProvider(e.target.value)}
                      sx={{ fontSize: '0.76rem' }}
                    >
                      {['generic', 'dsllm'].map(p => (
                        <MenuItem key={p} value={p} sx={{ fontSize: '0.76rem' }}>
                          {p}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ minWidth: 220 }}>
                    <InputLabel sx={{ fontSize: '0.78rem' }}>input_mode</InputLabel>
                    <Select
                      label="input_mode"
                      value={packetInputMode}
                      onChange={e => setPacketInputMode(e.target.value)}
                      sx={{ fontSize: '0.76rem' }}
                    >
                      {['image_only', 'image_with_nearby_text', 'image_with_evidence_card'].map(m => (
                        <MenuItem key={m} value={m} sx={{ fontSize: '0.76rem' }}>
                          {m}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <Button
                    size="small"
                    variant="contained"
                    color="success"
                    onClick={generateModelPacket}
                    disabled={modelPacketLoading}
                    startIcon={modelPacketLoading ? <CircularProgress size={14} color="inherit" /> : undefined}
                    sx={{ textTransform: 'none', fontWeight: 600 }}
                  >
                    Model Packet 생성
                  </Button>
                </Box>

                {modelPacketError && (
                  <Alert severity="error" sx={{ borderRadius: 1, mb: 1, fontSize: '0.72rem', py: 0.5 }}>
                    {modelPacketError}
                  </Alert>
                )}

                {modelPacket && (
                  <>
                    <Stack spacing={0.5} sx={{ mb: 1 }}>
                      <Field label="packet_version" value={modelPacket.packet_version} />
                      <Field label="provider" value={modelPacket.provider} />
                      <Field label="input_mode" value={modelPacket.input_mode} />
                      <Divider sx={{ my: 0.4 }} />
                      <Field
                        label="image_role_hint"
                        value={modelPacket.packet.image_context_hints?.image_role_hint ?? '-'}
                      />
                      <Field
                        label="role_confidence"
                        value={modelPacket.packet.image_context_hints?.role_confidence ?? '-'}
                      />
                      <Field
                        label="context_strength"
                        value={
                          ctxStrOf(modelPacket) ? (
                            <Chip
                              label={ctxStrOf(modelPacket)}
                              size="small"
                              sx={{ fontSize: '0.62rem', height: 18, ...(CTX_STRENGTH_COLOR[ctxStrOf(modelPacket) || ''] || {}) }}
                            />
                          ) : (
                            '-'
                          )
                        }
                      />
                      <Field
                        label="extraction_target"
                        value={modelPacket.packet.image_context_hints?.extraction_target ?? '-'}
                      />
                      <Field
                        label="model_instruction_key"
                        value={modelPacket.packet.image_context_hints?.model_instruction_key ?? '-'}
                      />
                    </Stack>

                    <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: '#166534', mt: 1, mb: 0.3 }}>
                      global_rule
                    </Typography>
                    <Typography
                      sx={{
                        fontSize: '0.7rem',
                        color: '#14532D',
                        bgcolor: '#fff',
                        p: 1,
                        borderRadius: 1,
                        border: '1px solid #BBF7D0',
                        whiteSpace: 'pre-wrap',
                        mb: 1,
                      }}
                    >
                      {modelPacket.packet.model_instruction?.global_rule || '-'}
                    </Typography>

                    {modelPacket.packet.model_instruction?.role_instruction && (
                      <>
                        <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: '#166534', mb: 0.3 }}>
                          role_instruction
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: '0.7rem',
                            color: '#14532D',
                            bgcolor: '#fff',
                            p: 1,
                            borderRadius: 1,
                            border: '1px solid #BBF7D0',
                            whiteSpace: 'pre-wrap',
                            mb: 1,
                          }}
                        >
                          {modelPacket.packet.model_instruction.role_instruction}
                        </Typography>
                      </>
                    )}

                    <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: '#166534', mb: 0.3 }}>
                      output_schema_hint
                    </Typography>
                    <Box
                      component="pre"
                      sx={{
                        m: 0,
                        mb: 1,
                        p: 1,
                        bgcolor: '#fff',
                        borderRadius: 1,
                        border: '1px solid #BBF7D0',
                        fontSize: '0.68rem',
                        whiteSpace: 'pre-wrap',
                        wordBreak: 'break-all',
                        maxHeight: 160,
                        overflow: 'auto',
                      }}
                    >
                      {JSON.stringify(modelPacket.packet.model_instruction?.output_schema_hint ?? {}, null, 2)}
                    </Box>

                    <Box
                      sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}
                      onClick={() => setPayloadOpen(o => !o)}
                    >
                      <Typography sx={{ fontWeight: 700, fontSize: '0.72rem', color: '#166534', flexGrow: 1 }}>
                        provider_payload JSON
                      </Typography>
                      <IconButton size="small">
                        {payloadOpen ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
                      </IconButton>
                    </Box>
                    <Collapse in={payloadOpen}>
                      <Box
                        component="pre"
                        sx={{
                          m: 0,
                          mt: 0.5,
                          p: 1,
                          bgcolor: '#0F172A',
                          color: '#E2E8F0',
                          borderRadius: 1,
                          fontSize: '0.66rem',
                          whiteSpace: 'pre-wrap',
                          wordBreak: 'break-all',
                          maxHeight: 280,
                          overflow: 'auto',
                        }}
                      >
                        {JSON.stringify(modelPacket.provider_payload, null, 2)}
                      </Box>
                    </Collapse>

                    <Box sx={{ display: 'flex', gap: 1, mt: 1, flexWrap: 'wrap' }}>
                      <Button
                        size="small"
                        variant="outlined"
                        color="success"
                        startIcon={<ContentCopyIcon />}
                        onClick={() => copyToClipboard(modelPacket.packet, 'Model Packet')}
                        sx={{ textTransform: 'none' }}
                      >
                        Model Packet JSON 복사
                      </Button>
                      <Button
                        size="small"
                        variant="outlined"
                        color="success"
                        startIcon={<ContentCopyIcon />}
                        onClick={() => copyToClipboard(modelPacket.provider_payload, 'Provider Payload')}
                        sx={{ textTransform: 'none' }}
                      >
                        Provider Payload JSON 복사
                      </Button>
                    </Box>
                  </>
                )}
                <Typography sx={{ fontSize: '0.66rem', color: '#16A34A', mt: 1 }}>
                  payload 에는 이미지 binary/base64/storage path 가 포함되지 않습니다. (image_ref 는 image_id 중심)
                </Typography>
              </Box>

              <Stack spacing={0.5} sx={{ mb: 2 }}>
                <Typography sx={{ fontWeight: 700, fontSize: '0.78rem', color: '#2955FF' }}>연결 정보</Typography>
                <Field label="image_id" value={selected.image_id} />
                <Field label="project_id" value={selected.project_id ?? '-'} />
                <Field label="project_name" value={selected.project_name ?? '-'} />
                <Field label="sub_project_id" value={selected.sub_project_id ?? '-'} />
                <Field label="sub_project_name" value={selected.sub_project_name ?? '-'} />
                <Field label="task_id" value={selected.task_id ?? '-'} />
                <Field label="task_title" value={selected.task_title ?? '-'} />
                <Field label="source_entity_type" value={selected.source_entity_type ?? '-'} />
                <Field label="source_entity_id" value={selected.source_entity_id ?? '-'} />
                <Field label="relation_type" value={selected.relation_type ?? '-'} />
              </Stack>

              <Stack spacing={0.5} sx={{ mb: 2 }}>
                <Typography sx={{ fontWeight: 700, fontSize: '0.78rem', color: '#2955FF' }}>텍스트 맥락</Typography>
                <Field label="nearby_text" value={selected.nearby_text || '-'} />
                <Field label="fallback_context_text" value={selected.fallback_context_text || '-'} />
                <Field label="context_text_source" value={selected.context_text_source ?? '-'} />
              </Stack>

              <Stack spacing={0.5} sx={{ mb: 2 }}>
                <Typography sx={{ fontWeight: 700, fontSize: '0.78rem', color: '#2955FF' }}>이미지 역할</Typography>
                <Field label="image_role" value={selected.image_role ?? '-'} />
                <Field label="image_role_source" value={selected.image_role_source ?? '-'} />
                <Field label="image_role_confidence" value={selected.image_role_confidence ?? '-'} />
              </Stack>

              <Stack spacing={0.5} sx={{ mb: 2 }}>
                <Typography sx={{ fontWeight: 700, fontSize: '0.78rem', color: '#2955FF' }}>이미지 품질</Typography>
                <Field label="width" value={selected.image_quality?.width ?? '-'} />
                <Field label="height" value={selected.image_quality?.height ?? '-'} />
                <Field label="megapixels" value={selected.image_quality?.megapixels ?? '-'} />
                <Field label="readability_status" value={selected.image_quality?.readability_status ?? '-'} />
                <Field
                  label="recommendation_level"
                  value={
                    <Chip
                      label={recoLevelOf(selected) || 'unknown'}
                      size="small"
                      sx={recoChipSx(recoLevelOf(selected))}
                    />
                  }
                />
                <Field label="recommended_for_ai" value={boolText(recommendedForAiOf(selected))} />
                <Field
                  label="quality_notes"
                  value={
                    (selected.image_quality?.quality_notes || []).length
                      ? (selected.image_quality?.quality_notes || []).join(' / ')
                      : '-'
                  }
                />
              </Stack>

              <Stack spacing={0.5} sx={{ mb: 2 }}>
                <Typography sx={{ fontWeight: 700, fontSize: '0.78rem', color: '#2955FF' }}>AI 이미지 variant</Typography>
                <Field label="original.available" value={boolText(selected.ai_image_variants?.original?.available)} />
                <Field label="preview.available" value={boolText(selected.ai_image_variants?.preview?.available)} />
                <Field label="ai_readable.action" value={recommendedActionOf(selected) ?? '-'} />
                <Field label="tiles.recommended" value={boolText(tilesRecOf(selected))} />
                <Field label="tiles.reason" value={tileReasonOf(selected) ?? '-'} />
              </Stack>

              <Stack spacing={0.5} sx={{ mb: 2 }}>
                <Typography sx={{ fontWeight: 700, fontSize: '0.78rem', color: '#2955FF' }}>
                  Display / AI input strategy
                </Typography>
                <Field label="original_width" value={selected.image_quality?.width ?? '미수집'} />
                <Field label="original_height" value={selected.image_quality?.height ?? '미수집'} />
                <Field label="display_width" value="미수집" />
                <Field label="display_height" value="미수집" />
                <Field label="has_display_resize" value="미수집" />
                <Field label="display_to_original_ratio" value="미수집" />
                <Field label="ai_input.preferred_source" value="original (또는 ai_readable variant)" />
                <Field label="ignore_display_resize" value="true (AI 입력은 original 기준 사용 예정)" />
                <Typography sx={{ fontSize: '0.68rem', color: '#9CA3AF' }}>
                  사용자 화면 display size 와 AI 분석용 original size 는 분리됩니다. 작업노트에서 이미지를 작게
                  표시해도 AI 입력은 original / ai_readable variant 기준입니다.
                </Typography>
              </Stack>

              <Stack spacing={0.5} sx={{ mb: 2 }}>
                <Typography sx={{ fontWeight: 700, fontSize: '0.78rem', color: '#2955FF' }}>분석 정책</Typography>
                <Field
                  label="metadata_cacheable"
                  value={boolText(selected.analysis_reuse_policy?.metadata_cacheable)}
                />
                <Field
                  label="semantic_cacheable"
                  value={boolText(selected.analysis_reuse_policy?.semantic_analysis_cacheable)}
                />
                <Field
                  label="requires_reanalysis"
                  value={boolText(selected.analysis_reuse_policy?.requires_context_aware_reanalysis)}
                />
                <Field
                  label="cache_key_preview"
                  value={
                    <Tooltip title={cacheKeyOf(selected) || ''}>
                      <span>{cacheKeyOf(selected) ? truncate(cacheKeyOf(selected), 24) : '-'}</span>
                    </Tooltip>
                  }
                />
                <Field
                  label="reanalysis_triggers"
                  value={`${(selected.reanalysis_triggers || []).length} triggers`}
                />
              </Stack>

              <Divider sx={{ my: 1.5 }} />
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Button
                  size="small"
                  variant="outlined"
                  startIcon={<ContentCopyIcon />}
                  onClick={() => copyToClipboard(selected, '이 이미지')}
                  sx={{ textTransform: 'none', mr: 1 }}
                >
                  이 이미지 JSON 복사
                </Button>
                <Button
                  size="small"
                  variant="outlined"
                  onClick={() => data && copyToClipboard(data, '전체 응답')}
                  sx={{ textTransform: 'none' }}
                >
                  전체 응답 JSON 복사
                </Button>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }} onClick={() => setRawJsonOpen(o => !o)}>
                <Typography sx={{ fontWeight: 700, fontSize: '0.78rem', color: '#6B7280', flexGrow: 1 }}>
                  원본 JSON
                </Typography>
                <IconButton size="small">{rawJsonOpen ? <ExpandLessIcon /> : <ExpandMoreIcon />}</IconButton>
              </Box>
              <Collapse in={rawJsonOpen}>
                <Box
                  component="pre"
                  sx={{
                    m: 0,
                    mt: 0.5,
                    p: 1.5,
                    bgcolor: '#0F172A',
                    color: '#E2E8F0',
                    borderRadius: 1,
                    fontSize: '0.68rem',
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-all',
                    maxHeight: 360,
                    overflow: 'auto',
                  }}
                >
                  {JSON.stringify(selected, null, 2)}
                </Box>
              </Collapse>
            </>
          )}
        </Box>
      </Drawer>
    </Box>
  );
};

export default AiContextInspector;
