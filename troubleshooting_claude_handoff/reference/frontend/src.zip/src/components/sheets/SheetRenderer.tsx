/**
 * SheetRenderer — Excel 원형 유사 렌더링 컴포넌트
 * 병합셀, 색상, 폰트, 테두리, 줄바꿈을 최대한 유지하여 웹에서 표시
 * v3.1: column_roles 기반 체크 + 점검일시 연동, checkedMap/checkedAtMap 직접 지원
 */
import React, { useMemo, useCallback, useState } from 'react';
import { Box, Checkbox, Typography, Tooltip, TextField, Select, MenuItem } from '@mui/material';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import type { SheetStructure, SheetCell, SheetExecutionItem, ColumnRoleMapping } from '../../types';
import type { AddedColumn, AddedRow } from './useAssignmentMappingState';

// 여부성 상태 옵션 (내부값은 O/X/N/A 유지, UI 라벨은 진행/미진행/N/A)
export const STATUS_OPTIONS = ['O', 'X', 'N/A'] as const;
export type StatusValue = typeof STATUS_OPTIONS[number] | '';

/** 내부 상태값 → 사용자에게 보여줄 라벨 */
export function statusLabel(v: StatusValue): string {
  if (v === 'O') return '진행';
  if (v === 'X') return '미진행';
  if (v === 'N/A') return 'N/A';
  return '';
}

interface Props {
  structure: SheetStructure;
  executionItems?: SheetExecutionItem[];
  /** v3.1: 직접 체크 상태 전달 (cell_ref → checked) */
  checkedMap?: Map<string, boolean>;
  /** v3.1: 체크 시 점검일시 전달 (cell_ref → ISO string) */
  checkedAtMap?: Map<string, string>;
  /** v3.1: 컬럼 역할 매핑 (체크상태/점검일시/담당자 등) */
  columnRoles?: ColumnRoleMapping | null;
  onCheckChange?: (cellRef: string, checked: boolean) => void;
  /** v3.1: 텍스트/기타 컬럼 편집 지원 (cell_ref → value) */
  valueMap?: Map<string, string>;
  onValueChange?: (cellRef: string, value: string) => void;
  /** v3.2: 상태(여부성) 컬럼을 O/X/N/A dropdown으로 처리할 때 호출.
   *  onCheckChange 대신 이걸 제공하면 check_status 셀은 Select UI로 렌더된다. */
  onStatusChange?: (cellRef: string, status: StatusValue, rowIdx: number, colIdx: number) => void;
  readOnly?: boolean;
  /** v3.7: 양식 원본 preview 모드 — 진행 유/무 체크박스, 상태 dropdown, 점검일시 자동값을
   *  모두 숨기고 원본 셀 값만 표시한다. SheetTemplatePage 같은 양식 확인용 화면에서 사용.
   *  실제 점검 화면(SheetExecutionPopup)에서는 false로 두어야 한다. */
  templatePreview?: boolean;
  /** 실행본에서 숨김 처리된 컬럼 인덱스. template은 그대로 두고 렌더링 시점에만 가린다. */
  hiddenCols?: number[];
  /** 헤더 셀에 컬럼 삭제 버튼을 표시하고 클릭 시 호출. 미제공 시 버튼 숨김. */
  onDeleteColumn?: (colIdx: number) => void;
  /** 실행본에서 숨김 처리된 행 인덱스. template은 그대로 두고 렌더링 시점에만 가린다. */
  hiddenRows?: number[];
  /** 행의 가장 왼쪽 가시 셀에 행 삭제 버튼을 표시하고 클릭 시 호출. 미제공 시 버튼 숨김. */
  onDeleteRow?: (rowIdx: number) => void;
  /** 모든 일반 텍스트 셀(헤더 아래/체크/상태/점검일시/숨김 제외)을 자유 편집 허용 */
  freeTextEdit?: boolean;
  /** 실행본 단위로 우측에 추가된 컬럼 (structure_overlay.added_columns).
   *  col_idx 는 base total_cols 이상이며, 헤더 + 데이터 행을 자동 렌더한다. */
  addedColumns?: AddedColumn[];
  /** col_idx (string) → 표시명 override (structure_overlay.renamed_headers).
   *  headerRowIdx 위치의 base 컬럼 표시명을 덮어쓴다 (저장값 / role 매핑은 col_idx 기반이라 안전). */
  renamedHeaders?: Record<string, string>;
  /** 헤더 더블클릭으로 rename 커밋. 빈 문자열이면 원래 표시명으로 회귀(=renamedHeaders 에서 제거). */
  onRenameHeader?: (colIdx: number, newHeader: string) => void;
  /** addedColumns 의 ✕ 클릭. 미제공 시 추가 컬럼은 ✕ 가 보이지 않는다. */
  onDeleteAddedColumn?: (colIdx: number) => void;
  /** 실행본 단위로 추가된 행 (structure_overlay.added_rows). row_idx 는 base total_rows 이상.
   *  현재는 셀 컨텐츠 없이 빈 행이 우선 렌더되고, freeTextEdit / onValueChange 로 편집된다. */
  addedRows?: AddedRow[];
  /** 추가 행의 ✕ 클릭. 미제공 시 추가 행은 base 행과 동일하게 onDeleteRow 로 위임된다. */
  onDeleteAddedRow?: (rowIdx: number) => void;
  /** added_columns 표시 순서 (col_idx 배열). 미지정 시 col_idx 오름차순. */
  addedColumnsOrder?: number[];
  /** added_rows 표시 순서 (row_idx 배열). 미지정 시 row_idx 오름차순. */
  addedRowsOrder?: number[];
  /** added 컬럼 reorder 커밋. 미제공 시 드래그 핸들이 비활성. */
  onReorderAddedColumns?: (newOrder: number[]) => void;
  /** added 행 reorder 커밋. 미제공 시 드래그 핸들이 비활성. */
  onReorderAddedRows?: (newOrder: number[]) => void;
  /** base + added 통합 컬럼 렌더 순서. 제공 시 base 컬럼 사이에 added 컬럼을 끼워 넣을 수 있다. */
  columnOrder?: number[];
  /** base + added 통합 행 렌더 순서. 제공 시 base 행 사이에 added 행을 끼워 넣을 수 있다. */
  rowOrder?: number[];
  /** 통합 컬럼 순서 reorder 커밋 — 추가 컬럼을 base 컬럼 사이로 drop 시 호출. */
  onReorderColumns?: (newOrder: number[]) => void;
  /** 통합 행 순서 reorder 커밋. */
  onReorderRows?: (newOrder: number[]) => void;
  searchQuery?: string;
}

const MIN_COL_WIDTH = 24;

function borderStyle(style?: string): string {
  if (!style) return 'none';
  if (style === 'thin') return '1px solid #D1D5DB';
  if (style === 'medium') return '2px solid #9CA3AF';
  if (style === 'thick') return '3px solid #4B5563';
  if (style === 'dashed') return '1px dashed #D1D5DB';
  if (style === 'dotted') return '1px dotted #D1D5DB';
  return '1px solid #D1D5DB';
}

/**
 * InlineCellEditor — 셀 편집 시 자체 state로 입력을 처리해
 * 키 입력마다 SheetRenderer 전체가 리렌더되지 않게 한다.
 */
export interface InlineCellEditorProps {
  initialValue: string;
  editorType: 'text' | 'date' | string;
  fontSizePx: number;
  bold?: boolean;
  fontColor?: string;
  align?: string;
  onCommit: (value: string) => void;
  onCancel: () => void;
}
export const InlineCellEditor = React.memo(function InlineCellEditor({
  initialValue, editorType, fontSizePx, bold, fontColor, align, onCommit, onCancel,
}: InlineCellEditorProps) {
  const [value, setValue] = useState<string>(initialValue);
  return (
    <Box sx={{
      position: 'relative',
      width: '100%',
      minHeight: '100%',
      display: 'flex',
      flexDirection: 'column',
      bgcolor: '#fff',
      boxShadow: '0 0 0 2px #2955FF',
      zIndex: 100,
      borderRadius: '2px',
      overflow: 'visible',
    }}>
      <TextField
        autoFocus
        variant="standard"
        size="small"
        multiline={editorType !== 'date'}
        minRows={editorType !== 'date' ? 2 : 1}
        maxRows={15}
        type={editorType === 'date' ? 'date' : 'text'}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={() => {
          if (value !== initialValue) onCommit(value);
          else onCancel();
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            (e.target as any).blur();
          } else if (e.key === 'Escape') {
            e.preventDefault();
            setValue(initialValue);
            onCancel();
          }
        }}
        InputProps={{
          disableUnderline: true,
          style: {
            fontSize: `${fontSizePx}px`,
            fontWeight: bold ? 700 : 400,
            color: fontColor || '#111827',
            width: '100%',
            textAlign: (align as any) || 'left',
            lineHeight: 1.4,
            padding: '4px 8px',
          },
        }}
        sx={{ p: 0, m: 0, width: '100%' }}
      />
      {editorType !== 'date' && (
        <Box sx={{
          position: 'absolute',
          bottom: -20,
          right: 0,
          bgcolor: 'rgba(26, 29, 41, 0.85)',
          color: '#fff',
          px: 0.8,
          py: 0.2,
          borderRadius: 0.5,
          fontSize: '0.65rem',
          pointerEvents: 'none',
          zIndex: 101,
          whiteSpace: 'nowrap',
        }}>
          Shift+Enter: 줄바꿈
        </Box>
      )}
    </Box>
  );
});

/** 점검일시를 보기 좋은 형식으로 변환 */
export function formatCheckedAt(iso?: string): string {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const hh = String(d.getHours()).padStart(2, '0');
    const mi = String(d.getMinutes()).padStart(2, '0');
    return `${mm}/${dd} ${hh}:${mi}`;
  } catch {
    return iso;
  }
}

export default function SheetRenderer({
  structure, executionItems,
  checkedMap: propCheckedMap,
  checkedAtMap: propCheckedAtMap,
  valueMap: propValueMap,
  columnRoles,
  onCheckChange, onValueChange, onStatusChange, readOnly,
  templatePreview,
  hiddenCols, onDeleteColumn, hiddenRows, onDeleteRow, freeTextEdit,
  addedColumns, renamedHeaders, onRenameHeader, onDeleteAddedColumn,
  addedRows, onDeleteAddedRow,
  addedColumnsOrder, addedRowsOrder, onReorderAddedColumns, onReorderAddedRows,
  columnOrder, rowOrder, onReorderColumns, onReorderRows,
}: Props) {
  const { cells = [], merges = [], col_widths = [], total_rows = 0, total_cols = 0, checkable_cells = [] } = structure || {};

  // columnRoles prop이 없으면 structure.column_roles를 자동 사용 (v3.2)
  const effectiveRoles: ColumnRoleMapping | null | undefined = columnRoles ?? (structure as any).column_roles;

  // Build cell map for O(1) lookup
  const cellMap = useMemo(() => {
    const map = new Map<string, SheetCell>();
    for (const cell of cells) {
      map.set(`${cell.row}-${cell.col}`, cell);
    }
    return map;
  }, [cells]);

  // Build checkable set
  const checkableSet = useMemo(() => {
    const set = new Set<string>();
    for (const c of (checkable_cells || [])) {
      set.add(`${c.row}-${c.col}`);
    }
    return set;
  }, [checkable_cells]);

  // Build execution items map (legacy path)
  const execItemMap = useMemo(() => {
    const map = new Map<string, SheetExecutionItem>();
    for (const item of (executionItems || [])) {
      map.set(`${item.row_idx}-${item.col_idx}`, item);
    }
    return map;
  }, [executionItems]);

  // Build checked state from modern checkedMap or legacy executionItems
  const checkedMap = useMemo<Map<string, boolean>>(() => {
    if (propCheckedMap && propCheckedMap.size > 0) return propCheckedMap;
    const map = new Map<string, boolean>();
    if (executionItems) {
      for (const item of executionItems) {
        map.set(item.cell_ref, item.checked);
      }
    }
    return map;
  }, [propCheckedMap, executionItems]);

  const checkedAtMap = useMemo<Map<string, string>>(() => {
    if (propCheckedAtMap && propCheckedAtMap.size > 0) return propCheckedAtMap;
    const map = new Map<string, string>();
    if (executionItems) {
      for (const item of executionItems) {
        if (item.checked_at) map.set(item.cell_ref, item.checked_at);
      }
    }
    return map;
  }, [propCheckedAtMap, executionItems]);

  const valueMap = useMemo<Map<string, string>>(() => {
    if (propValueMap) return propValueMap;
    const map = new Map<string, string>();
    if (executionItems) {
      for (const item of executionItems) {
        if (item.value) map.set(item.cell_ref, item.value);
      }
    }
    return map;
  }, [propValueMap, executionItems]);

  // v3.1: checked_at 컬럼 인덱스 (0-based)
  const checkedAtCol = effectiveRoles?.checked_at?.col ?? -1;

  // v3.2: 상태 컬럼 (0-based). 진행일 컬럼은 editableCols에서 처리.
  const statusCol = effectiveRoles?.check_status?.col ?? -1;

  // Editable columns
  const editableCols = useMemo(() => {
    const map = new Map<number, string>(); // colIdx -> editorType
    if (effectiveRoles && !readOnly) {
      if (effectiveRoles.assignee?.col !== undefined) map.set(effectiveRoles.assignee.col, effectiveRoles.assignee.editor_type || 'text');
      if (effectiveRoles.due_date?.col !== undefined) map.set(effectiveRoles.due_date.col, effectiveRoles.due_date.editor_type || 'date');
      if (effectiveRoles.planned_date?.col !== undefined) map.set(effectiveRoles.planned_date.col, effectiveRoles.planned_date.editor_type || 'date');
      if (effectiveRoles.progress_date?.col !== undefined) map.set(effectiveRoles.progress_date.col, effectiveRoles.progress_date.editor_type || 'date');
      if (effectiveRoles.remark?.col !== undefined) map.set(effectiveRoles.remark.col, effectiveRoles.remark.editor_type || 'text');
      if (effectiveRoles.cycle?.col !== undefined) map.set(effectiveRoles.cycle.col, effectiveRoles.cycle.editor_type || 'text');
    }
    return map;
  }, [effectiveRoles, readOnly]);

  const [editingCell, setEditingCell] = useState<string | null>(null);
  const [editingHeaderCol, setEditingHeaderCol] = useState<number | null>(null);
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);
  const [dragColIdx, setDragColIdx] = useState<number | null>(null);
  const [dragOverColIdx, setDragOverColIdx] = useState<number | null>(null);
  const [dragRowIdx, setDragRowIdx] = useState<number | null>(null);
  const [dragOverRowIdx, setDragOverRowIdx] = useState<number | null>(null);

  // structure_overlay 로 들어온 추가 컬럼 / rename 정보. 미제공이면 빈 값으로 폴백.
  const addedColsList = useMemo<AddedColumn[]>(
    () => (addedColumns ?? []).slice().sort((a, b) => a.col_idx - b.col_idx),
    [addedColumns],
  );
  const addedColByIdx = useMemo(() => {
    const m = new Map<number, AddedColumn>();
    addedColsList.forEach((c) => m.set(c.col_idx, c));
    return m;
  }, [addedColsList]);
  const renamedMap = useMemo(() => renamedHeaders ?? {}, [renamedHeaders]);

  // 헤더 표시명 — renamed_headers 가 있으면 항상 우선 (base/added 모두 적용 가능).
  // 그다음 추가 컬럼이면 addedColByIdx.header. 마지막 폴백은 호출측이 넘긴 baseHeader.
  const effectiveHeaderText = useCallback((colIdx: number, fallback: string): string => {
    const r = renamedMap[String(colIdx)];
    if (r !== undefined) return r;
    const added = addedColByIdx.get(colIdx);
    if (added) return added.header;
    return fallback;
  }, [addedColByIdx, renamedMap]);

  // 실행본에서 숨긴 컬럼 인덱스 (Set lookup)
  const hiddenColSet = useMemo(() => new Set<number>(hiddenCols || []), [hiddenCols]);
  // 실행본에서 숨긴 행 인덱스 (Set lookup)
  const hiddenRowSet = useMemo(() => new Set<number>(hiddenRows || []), [hiddenRows]);

  // Build hidden cells set + merge origin lookup
  //  v3.5: HTML <table> + rowSpan/colSpan으로 렌더링하므로 hidden 셀은 그냥 skip하면 됨
  //        (브라우저 table layout이 자동으로 병합 영역을 처리)
  //  hiddenCols/hiddenRows가 있으면 병합 origin을 첫 가시 행/컬럼으로 옮기고 span을 가시 개수로 줄인다.
  const { hiddenCells, mergeAt } = useMemo(() => {
    const set = new Set<string>();
    const originMap = new Map<string, { rowSpan: number; colSpan: number }>();
    for (const merge of (merges || [])) {
      let visibleRowCount = 0;
      let firstVisibleRow = -1;
      for (let r = merge.startRow; r <= merge.endRow; r++) {
        if (!hiddenRowSet.has(r)) {
          visibleRowCount++;
          if (firstVisibleRow < 0) firstVisibleRow = r;
        }
      }
      let visibleColCount = 0;
      let firstVisibleCol = -1;
      for (let c = merge.startCol; c <= merge.endCol; c++) {
        if (!hiddenColSet.has(c)) {
          visibleColCount++;
          if (firstVisibleCol < 0) firstVisibleCol = c;
        }
      }
      if (visibleRowCount === 0 || visibleColCount === 0 || firstVisibleRow < 0 || firstVisibleCol < 0) {
        // 병합 전체가 가려진 경우 — 모두 hidden 처리
        for (let r = merge.startRow; r <= merge.endRow; r++) {
          for (let c = merge.startCol; c <= merge.endCol; c++) set.add(`${r}-${c}`);
        }
        continue;
      }
      originMap.set(`${firstVisibleRow}-${firstVisibleCol}`, { rowSpan: visibleRowCount, colSpan: visibleColCount });
      for (let r = merge.startRow; r <= merge.endRow; r++) {
        for (let c = merge.startCol; c <= merge.endCol; c++) {
          if (r === firstVisibleRow && c === firstVisibleCol) continue;
          set.add(`${r}-${c}`);
        }
      }
    }
    return { hiddenCells: set, mergeAt: originMap };
  }, [merges, hiddenColSet, hiddenRowSet]);

  // base 의 마지막 col_idx 와 추가 컬럼들의 max(col_idx) 중 큰 값 + 1 까지 모두 colWidth 가 필요.
  const extendedColCount = useMemo(() => {
    let max = total_cols;
    addedColsList.forEach((c) => { if (c.col_idx + 1 > max) max = c.col_idx + 1; });
    return max;
  }, [total_cols, addedColsList]);

  const colWidths = useMemo(() => {
    const widths: number[] = [];
    for (let c = 0; c < extendedColCount; c++) {
      // base 영역 (c < total_cols) 은 col_widths 사용. 추가 영역은 기본 110px.
      if (c < total_cols) {
        const w = col_widths?.[c] || 8.43;
        widths.push(Math.max(MIN_COL_WIDTH, Math.round(w * 7.5)));
      } else {
        widths.push(110);
      }
    }
    return widths;
  }, [col_widths, total_cols, extendedColCount]);

  // base 0..total_cols-1 다음에 added 컬럼들이 이어진다. added 영역 순서는
  // addedColumnsOrder 가 있으면 해당 배열 순서를, 아니면 col_idx 오름차순을 따른다.
  const orderedAddedColIdxs = useMemo<number[]>(() => {
    const valid = new Set<number>(addedColsList.map((c) => c.col_idx));
    const seen = new Set<number>();
    const out: number[] = [];
    if (addedColumnsOrder) {
      for (const v of addedColumnsOrder) {
        if (valid.has(v) && !seen.has(v)) {
          seen.add(v);
          out.push(v);
        }
      }
    }
    addedColsList.forEach((c) => {
      if (!seen.has(c.col_idx)) {
        seen.add(c.col_idx);
        out.push(c.col_idx);
      }
    });
    return out;
  }, [addedColsList, addedColumnsOrder]);

  // 통합 컬럼 순서. columnOrder 가 제공되면 base + added 를 임의 순서로 섞을 수 있다.
  // 우선순위:
  //   1) columnOrder 안의 valid idx 를 그 순서대로
  //   2) 누락된 base idx 를 0..total_cols-1 오름차순으로 보충
  //   3) 누락된 added idx 를 orderedAddedColIdxs 순으로 보충
  // columnOrder 미제공 시 기존 동작(base asc + added in addedColumnsOrder).
  const colIdxList = useMemo<number[]>(() => {
    const addedSet = new Set<number>(addedColsList.map((c) => c.col_idx));
    const seen = new Set<number>();
    const out: number[] = [];
    if (columnOrder && columnOrder.length > 0) {
      for (const v of columnOrder) {
        const isBase = v >= 0 && v < total_cols;
        if (!isBase && !addedSet.has(v)) continue;
        if (seen.has(v)) continue;
        seen.add(v); out.push(v);
      }
      for (let c = 0; c < total_cols; c++) {
        if (!seen.has(c)) { seen.add(c); out.push(c); }
      }
      orderedAddedColIdxs.forEach((c) => {
        if (!seen.has(c)) { seen.add(c); out.push(c); }
      });
      return out;
    }
    for (let c = 0; c < total_cols; c++) out.push(c);
    orderedAddedColIdxs.forEach((c) => out.push(c));
    return out;
  }, [total_cols, orderedAddedColIdxs, addedColsList, columnOrder]);

  // 추가 행 목록 (row_idx 오름차순) + Set lookup.
  const addedRowsList = useMemo<AddedRow[]>(
    () => (addedRows ?? []).slice().sort((a, b) => a.row_idx - b.row_idx),
    [addedRows],
  );
  const addedRowSet = useMemo(() => {
    const s = new Set<number>();
    addedRowsList.forEach((r) => s.add(r.row_idx));
    return s;
  }, [addedRowsList]);

  // base 0..total_rows-1 다음에 added 행들이 이어진다. added 영역 순서는
  // addedRowsOrder 가 있으면 해당 배열 순서를, 아니면 row_idx 오름차순을 따른다.
  const orderedAddedRowIdxs = useMemo<number[]>(() => {
    const valid = new Set<number>(addedRowsList.map((r) => r.row_idx));
    const seen = new Set<number>();
    const out: number[] = [];
    if (addedRowsOrder) {
      for (const v of addedRowsOrder) {
        if (valid.has(v) && !seen.has(v)) {
          seen.add(v);
          out.push(v);
        }
      }
    }
    addedRowsList.forEach((r) => {
      if (!seen.has(r.row_idx)) {
        seen.add(r.row_idx);
        out.push(r.row_idx);
      }
    });
    return out;
  }, [addedRowsList, addedRowsOrder]);

  // 통합 행 순서. rowOrder 가 제공되면 base + added 를 임의 순서로 섞을 수 있다.
  const rowIdxList = useMemo<number[]>(() => {
    const addedSet = new Set<number>(addedRowsList.map((r) => r.row_idx));
    const seen = new Set<number>();
    const out: number[] = [];
    if (rowOrder && rowOrder.length > 0) {
      for (const v of rowOrder) {
        const isBase = v >= 0 && v < total_rows;
        if (!isBase && !addedSet.has(v)) continue;
        if (seen.has(v)) continue;
        seen.add(v); out.push(v);
      }
      for (let r = 0; r < total_rows; r++) {
        if (!seen.has(r)) { seen.add(r); out.push(r); }
      }
      orderedAddedRowIdxs.forEach((r) => {
        if (!seen.has(r)) { seen.add(r); out.push(r); }
      });
      return out;
    }
    for (let r = 0; r < total_rows; r++) out.push(r);
    orderedAddedRowIdxs.forEach((r) => out.push(r));
    return out;
  }, [total_rows, orderedAddedRowIdxs, addedRowsList, rowOrder]);

  // 보호 컬럼 (삭제 차단): 진행 상태
  const protectedColSet = useMemo(() => {
    const s = new Set<number>();
    if (effectiveRoles) {
      for (const key of ['check_status'] as const) {
        const col = effectiveRoles[key]?.col;
        if (typeof col === 'number' && col >= 0) s.add(col);
      }
    }
    return s;
  }, [effectiveRoles]);

  const totalWidth = colIdxList.reduce(
    (sum, c) => (hiddenColSet.has(c) ? sum : sum + (colWidths[c] ?? 110)),
    0,
  );

  // Helper: get cell ref. v3.4 — 항상 A1 형식 통일.
  //   기존엔 checkable이 아닌 셀에 대해 `${row}-${col}` 폴백을 썼지만,
  //   백엔드는 A1 형식만 row_idx/col_idx로 정확히 파싱한다. 가상 컬럼(진행일자/비고)에
  //   값을 저장해도 위치를 잃지 않도록 항상 A1 형식으로 계산한다.
  const getCellRef = useCallback((row: number, col: number): string => {
    const c = (checkable_cells || []).find(cc => cc.row === row && cc.col === col);
    if (c?.ref) return c.ref;
    let s = '';
    let n = col + 1;
    while (n > 0) {
      n--;
      s = String.fromCharCode(65 + (n % 26)) + s;
      n = Math.floor(n / 26);
    }
    return `${s}${row + 1}`;
  }, [checkable_cells]);

  // Helper: find if row has a checked item (for auto-fill checked_at column)
  const getRowCheckedAt = useCallback((rowIdx: number): string | undefined => {
    for (const c of (checkable_cells || [])) {
      if (c.row === rowIdx) {
        const at = checkedAtMap.get(c.ref);
        if (at) return at;
      }
    }
    return undefined;
  }, [checkable_cells, checkedAtMap]);

  // v3.5: 헤더 행 인덱스
  const headerRowIdx = (structure as any).header_row_idx ?? 0;

  // 드롭 시 source 를 target 직전(또는 마지막)으로 이동.
  // onReorderColumns 가 있으면 full mode — 통합 colIdxList 위에서 splice 후 통합 콜백.
  // 없으면 legacy added-only mode — orderedAddedColIdxs 위에서만 splice.
  const commitColReorder = useCallback((source: number, target: number) => {
    if (source === target) return;
    if (onReorderColumns) {
      if (!colIdxList.includes(source) || !colIdxList.includes(target)) return;
      const next = colIdxList.filter((v) => v !== source);
      const ti = next.indexOf(target);
      next.splice(ti, 0, source);
      onReorderColumns(next);
      return;
    }
    if (!onReorderAddedColumns) return;
    const cur = orderedAddedColIdxs;
    if (!cur.includes(source) || !cur.includes(target)) return;
    const next = cur.filter((v) => v !== source);
    const ti = next.indexOf(target);
    next.splice(ti, 0, source);
    onReorderAddedColumns(next);
  }, [onReorderColumns, onReorderAddedColumns, colIdxList, orderedAddedColIdxs]);

  const commitRowReorder = useCallback((source: number, target: number) => {
    if (source === target) return;
    if (onReorderRows) {
      if (!rowIdxList.includes(source) || !rowIdxList.includes(target)) return;
      const next = rowIdxList.filter((v) => v !== source);
      const ti = next.indexOf(target);
      next.splice(ti, 0, source);
      onReorderRows(next);
      return;
    }
    if (!onReorderAddedRows) return;
    const cur = orderedAddedRowIdxs;
    if (!cur.includes(source) || !cur.includes(target)) return;
    const next = cur.filter((v) => v !== source);
    const ti = next.indexOf(target);
    next.splice(ti, 0, source);
    onReorderAddedRows(next);
  }, [onReorderRows, onReorderAddedRows, rowIdxList, orderedAddedRowIdxs]);

  // 행 삭제 버튼을 어느 셀에 띄울지 — 각 행에서 가장 왼쪽의 "실제로 렌더되는" 셀 위치
  // (hidden col 이거나 merge 로 흡수된 셀은 건너뜀)
  const rowDeleteAnchorCol = useMemo(() => {
    const map = new Map<number, number>();
    if (!onDeleteRow && !onDeleteAddedRow) return map;
    for (const r of rowIdxList) {
      if (hiddenRowSet.has(r)) continue;
      if (r === headerRowIdx) continue;
      // base 행은 onDeleteRow 가 있어야, 추가 행은 onDeleteAddedRow 또는 onDeleteRow 둘 중 하나라도 있으면 anchor.
      const isAddedRow = addedRowSet.has(r);
      if (!isAddedRow && !onDeleteRow) continue;
      if (isAddedRow && !onDeleteAddedRow && !onDeleteRow) continue;
      for (const c of colIdxList) {
        if (hiddenColSet.has(c)) continue;
        if (hiddenCells.has(`${r}-${c}`)) continue;
        map.set(r, c);
        break;
      }
    }
    return map;
  }, [onDeleteRow, onDeleteAddedRow, rowIdxList, addedRowSet, colIdxList, hiddenRowSet, hiddenColSet, hiddenCells, headerRowIdx]);

  return (
    <Box sx={{ overflow: 'auto', border: '1px solid #E5E7EB', borderRadius: 1, bgcolor: '#f3f4f6', p: 2 }}>
      <Box sx={{
        display: 'inline-block',
        minWidth: totalWidth,
        bgcolor: '#fff',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        fontFamily: '"Pretendard", "Noto Sans KR", sans-serif',
      }}>
        {/*
          v3.5: HTML <table> 로 전환.
          이전 flex Box 구조는 병합셀 높이 = sum(static rowHeights)로 계산해서,
          긴 텍스트로 인해 한 행이 minHeight 이상으로 자라면 왼쪽 병합 셀과
          높이가 어긋났다. <table> + rowSpan/colSpan을 쓰면 브라우저 table layout
          알고리즘이 모든 셀의 높이를 함께 맞춰주기 때문에 어긋남이 사라진다.
        */}
        <table
          style={{
            borderCollapse: 'collapse',
            tableLayout: 'auto', // v3.8: auto로 변경하여 내용에 따른 행 높이 증가 허용
            width: totalWidth,
            margin: 0,
          }}
        >
          <colgroup>
            {colIdxList.map((c) => {
              if (hiddenColSet.has(c)) return null;
              const w = colWidths[c] ?? 110;
              return <col key={c} style={{ width: w, minWidth: w, maxWidth: w }} />;
            })}
          </colgroup>
          <tbody>
            {rowIdxList.map((rowIdx) => {
              if (hiddenRowSet.has(rowIdx)) return null;
              const isAddedRow = addedRowSet.has(rowIdx) || rowIdx >= total_rows;
              const showHoverHandler = !!onDeleteRow || !!onDeleteAddedRow;
              return (
              <tr
                key={rowIdx}
                onMouseEnter={showHoverHandler ? () => setHoveredRow(rowIdx) : undefined}
                onMouseLeave={showHoverHandler ? () => setHoveredRow((cur) => (cur === rowIdx ? null : cur)) : undefined}
              >
                {colIdxList.map((colIdx) => {
                  const key = `${rowIdx}-${colIdx}`;
                  // 실행본에서 삭제(숨김)된 컬럼은 렌더 자체를 건너뛴다
                  if (hiddenColSet.has(colIdx)) return null;
                  // hidden cells are absorbed by their merge origin's rowSpan/colSpan
                  if (hiddenCells.has(key)) return null;

                  const isAddedCol = colIdx >= total_cols || addedColByIdx.has(colIdx);
                  const cell = cellMap.get(key);
                  // v3.7: templatePreview 모드면 체크/상태/점검일시 모두 비활성 → 원본 셀 값만 표시
                  const isCheckable = !templatePreview && checkableSet.has(key);
                  const execItem = execItemMap.get(key);
                  // v3.2: 상태(여부성) 셀 — O/X/N/A dropdown 대상
                  const isStatusCell = !templatePreview && !!onStatusChange && statusCol >= 0 && colIdx === statusCol && rowIdx > headerRowIdx;

                  // 병합 origin 우선, 그다음 cell 자체의 span 사용
                  const merge = mergeAt.get(key);
                  const rowSpan = merge?.rowSpan ?? cell?.rowSpan ?? 1;
                  const colSpan = merge?.colSpan ?? cell?.colSpan ?? 1;

                  const bg = cell?.bg || 'transparent';
                  const font = cell?.font;
                  const borders = cell?.borders;

                  // v3.1: 점검일시 컬럼이면 자동으로 체크 시간을 표시
                  // v3.7: templatePreview 모드에선 자동 점검일시 표시 안 함 (원본 값만)
                  const isCheckedAtCol = !templatePreview && checkedAtCol >= 0 && colIdx === checkedAtCol;
                  const rowCheckedAt = isCheckedAtCol ? getRowCheckedAt(rowIdx) : undefined;

                  // 현재 체크 상태 및 기타 수정값
                  const cellRef = getCellRef(rowIdx, colIdx);
                  const isChecked = checkedMap.get(cellRef) ?? execItem?.checked ?? false;
                  const isHeaderCell = rowIdx === headerRowIdx;
                  // 추가 컬럼 헤더는 effectiveHeaderText 의 header, 본문은 valueMap 만 사용 (cell 없음).
                  // base 컬럼 헤더는 renamed_headers 가 있으면 우선, 본문은 기존 로직.
                  const cellValue = isHeaderCell
                    ? effectiveHeaderText(colIdx, String(cell?.value ?? ''))
                    : (valueMap.get(cellRef) ?? execItem?.value ?? cell?.value ?? '');

                  // 헤더 rename: 추가 컬럼이거나 onRenameHeader 가 제공된 base 컬럼.
                  // 보호 컬럼(체크/일시/진행일) 은 base rename 도 막아 의미 혼동을 방지.
                  const canRenameHeader = !readOnly && !templatePreview && isHeaderCell
                    && (isAddedCol || (!!onRenameHeader && !protectedColSet.has(colIdx)));
                  const isHeaderEditing = canRenameHeader && editingHeaderCol === colIdx;

                  // Editable 관련 — 상태셀은 Select로 처리하므로 inline 텍스트 에디터 제외
                  // freeTextEdit: 헤더 아래 / 체크/상태/점검일시/숨김 이외 모든 일반 셀을 텍스트 편집 허용
                  // 추가 컬럼 본문은 항상 텍스트 편집 가능 (onValueChange 가 있을 때만).
                  const roleEditorType = editableCols.get(colIdx);
                  // 추가 행은 base/added 컬럼 모두 자유 편집 — onValueChange 필요.
                  const freeEditable = (!!freeTextEdit || (isAddedCol && !!onValueChange) || (isAddedRow && !!onValueChange))
                    && !readOnly && rowIdx > headerRowIdx
                    && !isCheckable && !isCheckedAtCol && !isStatusCell;
                  const editorType = editingCell === cellRef
                    ? (roleEditorType || (freeEditable ? 'text' : null))
                    : null;
                  const isEditableHoverable =
                    rowIdx > headerRowIdx
                    && !isCheckable && !isCheckedAtCol && !isStatusCell
                    && (editableCols.has(colIdx) || freeEditable);

                  // 안전한 fontSize 계산 (Excel pt -> css px 변환 유지)
                  const fontSizePx = font?.fontSize ? Math.round(font.fontSize * 1.33) : 12;

                  const showDeleteBtn = isHeaderCell && !readOnly && !templatePreview && !isHeaderEditing && (
                    isAddedCol
                      ? !!onDeleteAddedColumn
                      : (!!onDeleteColumn && !protectedColSet.has(colIdx))
                  );
                  const onHeaderDeleteClick = () => {
                    if (isAddedCol) onDeleteAddedColumn?.(colIdx);
                    else onDeleteColumn?.(colIdx);
                  };
                  const rowDeleteHandler = isAddedRow
                    ? (onDeleteAddedRow ?? onDeleteRow)
                    : onDeleteRow;
                  const showRowDeleteBtn = !!rowDeleteHandler && !readOnly && !templatePreview
                    && rowIdx !== headerRowIdx
                    && rowDeleteAnchorCol.get(rowIdx) === colIdx;

                  // 드래그 reorder — source 는 added 컬럼/행 헤더(anchor)에서만 활성.
                  // target(drop) 은 onReorderColumns/onReorderRows 가 있으면 base 셀에도 허용.
                  // 없으면 legacy 동작(added 끼리만).
                  const colReorderSource = !readOnly && !templatePreview && !isHeaderEditing
                    && isAddedCol && isHeaderCell
                    && (!!onReorderColumns || !!onReorderAddedColumns);
                  const rowReorderSource = !readOnly && !templatePreview
                    && isAddedRow && rowDeleteAnchorCol.get(rowIdx) === colIdx
                    && (!!onReorderRows || !!onReorderAddedRows);
                  const colReorderTarget = !readOnly && !templatePreview && !isHeaderEditing
                    && isHeaderCell
                    && (!!onReorderColumns || (!!onReorderAddedColumns && isAddedCol));
                  const rowReorderTarget = !readOnly && !templatePreview
                    && rowDeleteAnchorCol.get(rowIdx) === colIdx
                    && (!!onReorderRows || (!!onReorderAddedRows && isAddedRow));
                  const showColDropIndicator = colReorderTarget
                    && dragColIdx !== null && dragColIdx !== colIdx && dragOverColIdx === colIdx;
                  const showRowDropIndicator = rowReorderTarget
                    && dragRowIdx !== null && dragRowIdx !== rowIdx && dragOverRowIdx === rowIdx;
                  const showDragHandle = (colReorderSource || rowReorderSource);

                  const tdStyle: React.CSSProperties = {
                    padding: '2px 4px',
                    backgroundColor: showColDropIndicator || showRowDropIndicator
                      ? 'rgba(41, 85, 255, 0.10)'
                      : bg,
                    borderRight: borderStyle(borders?.right || 'thin'),
                    borderBottom: borderStyle(borders?.bottom || 'thin'),
                    borderLeft: showColDropIndicator
                      ? '3px solid #2955FF'
                      : (colIdx === 0 ? borderStyle(borders?.left || 'thick') : undefined),
                    borderTop: showRowDropIndicator
                      ? '3px solid #2955FF'
                      : (rowIdx === 0 ? borderStyle(borders?.top || 'thick') : undefined),
                    verticalAlign: 'middle',
                    textAlign: (cell?.align as any) || 'left',
                    cursor: isEditableHoverable ? 'text' : 'default',
                    wordBreak: 'break-word',
                    overflowWrap: 'anywhere',
                    position: (showDeleteBtn || showRowDeleteBtn || showDragHandle) ? 'relative' : undefined,
                    height: 'inherit',
                  };

                  // td 에 부착할 드래그 이벤트.
                  //   draggable: source (added 헤더 / added row anchor) 에서만 true.
                  //   dragOver/drop: target 에서 활성 — col target 은 모든 헤더 셀(full mode), row target 은 모든 row anchor.
                  // dataTransfer 페이로드는 'col:N' / 'row:N' 형식.
                  const tdDraggable = colReorderSource || rowReorderSource;
                  const tdAcceptsDrop = colReorderTarget || rowReorderTarget;
                  const onTdDragStart = tdDraggable
                    ? (e: React.DragEvent<HTMLTableCellElement>) => {
                        if (colReorderSource) {
                          e.dataTransfer.setData('text/plain', `col:${colIdx}`);
                          e.dataTransfer.effectAllowed = 'move';
                          setDragColIdx(colIdx);
                        } else if (rowReorderSource) {
                          e.dataTransfer.setData('text/plain', `row:${rowIdx}`);
                          e.dataTransfer.effectAllowed = 'move';
                          setDragRowIdx(rowIdx);
                        }
                      }
                    : undefined;
                  const onTdDragEnd = tdDraggable
                    ? () => {
                        setDragColIdx(null);
                        setDragOverColIdx(null);
                        setDragRowIdx(null);
                        setDragOverRowIdx(null);
                      }
                    : undefined;
                  const onTdDragOver = tdAcceptsDrop
                    ? (e: React.DragEvent<HTMLTableCellElement>) => {
                        if (colReorderTarget && dragColIdx !== null && dragColIdx !== colIdx) {
                          e.preventDefault();
                          e.dataTransfer.dropEffect = 'move';
                          if (dragOverColIdx !== colIdx) setDragOverColIdx(colIdx);
                        } else if (rowReorderTarget && dragRowIdx !== null && dragRowIdx !== rowIdx) {
                          e.preventDefault();
                          e.dataTransfer.dropEffect = 'move';
                          if (dragOverRowIdx !== rowIdx) setDragOverRowIdx(rowIdx);
                        }
                      }
                    : undefined;
                  const onTdDragLeave = tdAcceptsDrop
                    ? () => {
                        if (dragOverColIdx === colIdx) setDragOverColIdx(null);
                        if (dragOverRowIdx === rowIdx) setDragOverRowIdx(null);
                      }
                    : undefined;
                  const onTdDrop = tdAcceptsDrop
                    ? (e: React.DragEvent<HTMLTableCellElement>) => {
                        const payload = e.dataTransfer.getData('text/plain') || '';
                        if (colReorderTarget && payload.startsWith('col:')) {
                          e.preventDefault();
                          const src = Number(payload.slice(4));
                          if (Number.isFinite(src)) commitColReorder(src, colIdx);
                        } else if (rowReorderTarget && payload.startsWith('row:')) {
                          e.preventDefault();
                          const src = Number(payload.slice(4));
                          if (Number.isFinite(src)) commitRowReorder(src, rowIdx);
                        }
                        setDragColIdx(null);
                        setDragOverColIdx(null);
                        setDragRowIdx(null);
                        setDragOverRowIdx(null);
                      }
                    : undefined;

                  return (
                    <td
                      key={key}
                      rowSpan={rowSpan}
                      colSpan={colSpan}
                      draggable={tdDraggable || undefined}
                      onDragStart={onTdDragStart}
                      onDragEnd={onTdDragEnd}
                      onDragOver={onTdDragOver}
                      onDragLeave={onTdDragLeave}
                      onDrop={onTdDrop}
                      onClick={() => {
                        if (isHeaderEditing) return;
                        if (isEditableHoverable && !readOnly) {
                          setEditingCell(cellRef);
                        }
                      }}
                      onDoubleClick={canRenameHeader ? () => setEditingHeaderCol(colIdx) : undefined}
                      title={canRenameHeader && !isHeaderEditing ? '더블클릭으로 헤더 이름 변경' : (tdDraggable ? '드래그하여 순서 변경' : undefined)}
                      onMouseEnter={(e) => {
                        if (isEditableHoverable) (e.currentTarget as HTMLTableCellElement).style.backgroundColor = 'rgba(41, 85, 255, 0.04)';
                      }}
                      onMouseLeave={(e) => {
                        if (isEditableHoverable) (e.currentTarget as HTMLTableCellElement).style.backgroundColor = bg;
                      }}
                      style={tdStyle}
                    >
                      {isHeaderEditing ? (
                    <InlineCellEditor
                      initialValue={cellValue}
                      editorType="text"
                      fontSizePx={fontSizePx}
                      bold={font?.bold}
                      fontColor={font?.fontColor}
                      align={cell?.align}
                      onCommit={(v) => {
                        onRenameHeader?.(colIdx, v);
                        setEditingHeaderCol(null);
                      }}
                      onCancel={() => setEditingHeaderCol(null)}
                    />
                  ) : editorType ? (
                    <InlineCellEditor
                      initialValue={cellValue}
                      editorType={editorType}
                      fontSizePx={fontSizePx}
                      bold={font?.bold}
                      fontColor={font?.fontColor}
                      align={cell?.align}
                      onCommit={(v) => {
                        onValueChange?.(cellRef, v);
                        setEditingCell(null);
                      }}
                      onCancel={() => setEditingCell(null)}
                    />
                  ) : isStatusCell ? (
                    (() => {
                      // 현재 상태값: execItem.value > valueMap > parsed_status > raw > ''
                      const raw = (execItem?.value ?? valueMap.get(cellRef) ?? cell?.value ?? '').toString().trim();
                      const upper = raw.toUpperCase().replace(/\s/g, '');
                      let current: StatusValue = '';
                      if (upper === 'O' || upper === '○' || upper === '●' || upper === '완료' || upper === 'OK' || upper === 'PASS' || upper === '양호' || upper === '정상') current = 'O';
                      else if (upper === 'X' || upper === '×' || upper === '미완료' || upper === 'NG' || upper === 'FAIL' || upper === '불량' || upper === '이상') current = 'X';
                      else if (upper === 'N/A' || upper === 'NA' || upper === '해당없음') current = 'N/A';
                      else if (STATUS_OPTIONS.includes(raw as any)) current = raw as StatusValue;
                      const color = current === 'O' ? '#16A34A' : current === 'X' ? '#DC2626' : current === 'N/A' ? '#9CA3AF' : '#6B7280';
                      return (
                        <Tooltip title={execItem?.memo || ''} placement="top" arrow>
                          <Select
                            size="small"
                            value={current}
                            disabled={readOnly}
                            onChange={(e) => onStatusChange?.(cellRef, e.target.value as StatusValue, rowIdx, colIdx)}
                            variant="standard"
                            disableUnderline
                            displayEmpty
                            renderValue={(v) => (
                              <Box component="span" sx={{
                                fontSize: `${Math.max(fontSizePx, 12)}px`,
                                fontWeight: 700,
                                color,
                                opacity: current === 'N/A' ? 0.7 : 1,
                              }}>
                                {statusLabel(v as StatusValue) || '—'}
                              </Box>
                            )}
                            sx={{
                              width: '100%',
                              border: readOnly ? 'none' : '1px solid #E5E7EB',
                              borderRadius: '6px',
                              bgcolor: readOnly ? 'transparent' : '#FAFAFA',
                              transition: 'border-color 0.15s, background-color 0.15s, box-shadow 0.15s',
                              '&:hover': readOnly ? {} : {
                                bgcolor: '#F3F4F6',
                                borderColor: '#9CA3AF',
                              },
                              '&.Mui-focused, &:focus-within': readOnly ? {} : {
                                borderColor: '#2955FF',
                                bgcolor: '#fff',
                                boxShadow: '0 0 0 2px rgba(41, 85, 255, 0.12)',
                              },
                              '& .MuiSelect-select': {
                                p: '3px 22px 3px 8px !important',
                                textAlign: 'center',
                                minHeight: 'unset',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                              },
                              '& .MuiSelect-icon': {
                                color: '#6B7280',
                                right: 4,
                                fontSize: 16,
                              },
                            }}
                            MenuProps={{ PaperProps: { sx: { mt: 0.5, borderRadius: 1.5, boxShadow: '0 4px 12px rgba(0,0,0,0.12)' } } }}
                          >
                            <MenuItem value=""><em style={{ color: '#9CA3AF' }}>— 선택</em></MenuItem>
                            <MenuItem value="O" sx={{ fontWeight: 700, color: '#16A34A' }}>진행</MenuItem>
                            <MenuItem value="X" sx={{ fontWeight: 700, color: '#DC2626' }}>미진행</MenuItem>
                            <MenuItem value="N/A" sx={{ fontWeight: 700, color: '#9CA3AF' }}>N/A</MenuItem>
                          </Select>
                        </Tooltip>
                      );
                    })()
                  ) : isCheckable ? (
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, width: '100%', justifyContent: cell?.align === 'center' ? 'center' : 'flex-start' }}>
                      <Tooltip title={execItem?.memo || ''} placement="top" arrow>
                        <span>
                          <Checkbox
                            size="small"
                            checked={isChecked}
                            disabled={readOnly}
                            onChange={(e) => onCheckChange?.(cellRef, e.target.checked)}
                            sx={{
                              p: 0, '& .MuiSvgIcon-root': { fontSize: 18 },
                              color: isChecked ? '#22C55E' : '#D1D5DB',
                              '&.Mui-checked': { color: '#22C55E' },
                            }}
                          />
                        </span>
                      </Tooltip>
                      {(execItem?.value || cell?.value) && (
                        <Typography
                          variant="caption"
                          sx={{
                            fontSize: `${fontSizePx}px`,
                            fontWeight: font?.bold ? 700 : 500,
                            color: (execItem?.value || cell?.value || '').includes('미완료') ? '#DC2626'
                              : (execItem?.value || cell?.value || '').includes('완료') ? '#16A34A'
                              : font?.fontColor || '#374151',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {execItem?.value ?? cell?.value ?? ''}
                        </Typography>
                      )}
                    </Box>
                  ) : isCheckedAtCol && rowCheckedAt ? (
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.3, width: '100%', justifyContent: cell?.align === 'center' ? 'center' : 'flex-start' }}>
                      <AccessTimeIcon sx={{ fontSize: 12, color: '#2955FF', flexShrink: 0 }} />
                      <Typography
                        variant="caption"
                        sx={{
                          fontSize: '11px', color: '#2955FF', fontWeight: 600,
                          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                        }}
                      >
                        {formatCheckedAt(rowCheckedAt)}
                      </Typography>
                    </Box>
                  ) : (
                    <Tooltip title={String(cellValue || '').length > 60 ? cellValue : ''} placement="top" arrow enterDelay={500}>
                      <Typography
                        variant="body2"
                        sx={{
                          fontSize: `${fontSizePx}px`,
                          fontWeight: font?.bold ? 700 : 400,
                          fontStyle: font?.italic ? 'italic' : 'normal',
                          color: font?.fontColor || '#111827',
                          // v3.4: 항상 줄바꿈 허용 — 긴 텍스트가 잘리지 않게
                          whiteSpace: 'pre-wrap',
                          wordBreak: 'break-word',
                          overflowWrap: 'anywhere',
                          lineHeight: 1.35,
                          width: '100%',
                          textAlign: (cell?.align as any) || 'left',
                          py: 0.2,
                        }}
                      >
                        {cellValue}
                      </Typography>
                    </Tooltip>
                  )}
                  {showDeleteBtn && (
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); onHeaderDeleteClick(); }}
                      title={isAddedCol ? '추가 컬럼 삭제' : '이 컬럼 삭제'}
                      style={{
                        position: 'absolute',
                        top: 1,
                        right: 1,
                        width: 16,
                        height: 16,
                        padding: 0,
                        border: 'none',
                        borderRadius: '50%',
                        background: 'rgba(239, 68, 68, 0.85)',
                        color: '#fff',
                        fontSize: 11,
                        lineHeight: '14px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: 0.55,
                        transition: 'opacity 0.15s',
                      }}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = '1'; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = '0.55'; }}
                    >
                      ×
                    </button>
                  )}
                  {showRowDeleteBtn && (
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); rowDeleteHandler?.(rowIdx); }}
                      title={isAddedRow ? '추가 행 삭제' : '이 행 삭제'}
                      style={{
                        position: 'absolute',
                        left: 1,
                        top: '50%',
                        transform: 'translateY(-50%)',
                        width: 16,
                        height: 16,
                        padding: 0,
                        border: 'none',
                        borderRadius: '50%',
                        background: 'rgba(239, 68, 68, 0.85)',
                        color: '#fff',
                        fontSize: 11,
                        lineHeight: '14px',
                        cursor: 'pointer',
                        display: hoveredRow === rowIdx ? 'flex' : 'none',
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: 0.85,
                        transition: 'opacity 0.15s',
                        zIndex: 5,
                      }}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = '1'; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = '0.85'; }}
                    >
                      ×
                    </button>
                  )}
                  {showDragHandle && (
                    <span
                      title="드래그하여 순서 변경"
                      style={{
                        position: 'absolute',
                        ...(colReorderSource
                          ? { top: 1, left: 1 }
                          : { top: 1, right: 18 }),
                        width: 14,
                        height: 14,
                        fontSize: 10,
                        lineHeight: '14px',
                        color: '#6B7280',
                        cursor: 'grab',
                        userSelect: 'none',
                        textAlign: 'center',
                        opacity: 0.55,
                        pointerEvents: 'none',
                      }}
                    >
                      ⋮⋮
                    </span>
                  )}
                    </td>
                  );
                })}
              </tr>
              );
            })}
          </tbody>
        </table>
      </Box>
    </Box>
  );
}
