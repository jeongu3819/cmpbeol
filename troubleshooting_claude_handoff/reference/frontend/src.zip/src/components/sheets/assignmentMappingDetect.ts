/**
 * Assignment-mapping helpers.
 *
 * Detection is intentionally based on **the parsed Excel structure**, not on
 * any persisted sheet_type/category flag, because uploads in the wild can
 * end up with sheet_type='inspection' even when they are obviously an
 * equipment-mapping table. If the structure has 설비/장비/EQP/Equipment N
 * columns, we treat it as an equipment mapping and switch to the new viewer.
 */
import type { SheetStructure, SheetCell, SheetType } from '../../types';

const ASSIGNMENT_MAPPING_TYPE_NAMES: ReadonlySet<string> = new Set([
  'assignment_mapping',
  'equipment_mapping',
  'chemical_equipment_mapping',
  'part_equipment_mapping',
  'group_mapping',
  '설비 배치 매핑형',
  '설비-배치 매핑형',
  '약품-설비 매핑표',
  '부품-설비 매핑표',
  '그룹 매핑표',
]);

function normalizeTypeName(value: unknown): string {
  return String(value ?? '')
    .trim()
    .replace(/\s+/g, '')
    .replace(/-/g, '')
    .toLowerCase();
}

const NORMALIZED_TYPE_NAMES: ReadonlySet<string> = new Set(
  Array.from(ASSIGNMENT_MAPPING_TYPE_NAMES, normalizeTypeName),
);

export function isAssignmentMappingType(type?: SheetType | string | null): boolean {
  if (!type) return false;
  return NORMALIZED_TYPE_NAMES.has(normalizeTypeName(type));
}

/**
 * 시트 유형 판별용 느슨한 입력 타입 — SheetExecution / SheetTemplate / summary row 등
 * 화면마다 모양이 조금씩 달라도 같은 기준으로 분기할 수 있게 한다.
 */
export interface SheetTypeLike {
  sheet_type?: string | null;
  template_type?: string | null;
  category?: string | null;
  template_category?: string | null;
  template_structure?: SheetStructure | null;
  structure?: SheetStructure | null;
}

/**
 * "설비-배치 매핑형" 시트인지 — 업로드 시 선택해 저장된 유형(assignment_mapping 등) 우선,
 * 없으면 구조에 설비/장비/EQP/Equipment N 컬럼이 있으면 매핑형으로 간주(legacy 폴백).
 * 이 한 함수를 Task Details / Sheet 상세 / Dashboard / 연결정보 등 모든 화면이 공유한다.
 */
export function isEquipmentMappingSheet(sheet?: SheetTypeLike | null): boolean {
  if (!sheet) return false;
  if (
    isAssignmentMappingType(sheet.sheet_type)
    || isAssignmentMappingType(sheet.template_type)
    || isAssignmentMappingType(sheet.category)
    || isAssignmentMappingType(sheet.template_category)
  ) {
    return true;
  }
  const structure = sheet.template_structure ?? sheet.structure ?? null;
  if (structure && hasEquipmentColumns(structure)) return true;
  return false;
}

/** 진행률/완료율/항목완료 UI 를 보여줘도 되는 시트인지 — 점검 수행형(체크리스트)만 true. */
export function shouldShowSheetProgress(sheet?: SheetTypeLike | null): boolean {
  return !isEquipmentMappingSheet(sheet);
}

const EQUIPMENT_COLUMN_PATTERNS: RegExp[] = [
  /^설비\d+$/,
  /^장비\d+$/,
  /^eqp\d+$/i,
  /^equipment\d+$/i,
];

/**
 * Does this header text look like a 설비/장비/EQP/Equipment column?
 * Comparison is whitespace-insensitive so "설비 1" and "설비1" both match.
 */
export function isEquipmentColumnHeader(text: unknown): boolean {
  if (text === null || text === undefined) return false;
  const collapsed = String(text).replace(/\s+/g, '').trim();
  if (!collapsed) return false;
  return EQUIPMENT_COLUMN_PATTERNS.some((re) => re.test(collapsed));
}

interface EquipmentDetection {
  headerRow: number;
  equipmentCols: number[];
}

/**
 * Scan the structure for the row with the most equipment-pattern cells. We do
 * NOT trust structure.header_row_idx blindly — many real uploads put the
 * equipment headers on a different row than the auto-picked header.
 */
export function detectEquipmentLayout(structure: SheetStructure | null | undefined): EquipmentDetection | null {
  if (!structure) return null;
  const cells = structure.cells || [];
  if (cells.length === 0) return null;

  const matchesByRow = new Map<number, number[]>();
  for (const c of cells) {
    if (isEquipmentColumnHeader(c.value)) {
      const arr = matchesByRow.get(c.row) ?? [];
      arr.push(c.col);
      matchesByRow.set(c.row, arr);
    }
  }
  if (matchesByRow.size === 0) return null;

  // Pick the row with the most equipment-pattern cells; tie-break by smaller
  // row index so we prefer an earlier (true header) row over a footer.
  let best: { row: number; cols: number[] } | null = null;
  matchesByRow.forEach((cols, row) => {
    if (
      !best
      || cols.length > best.cols.length
      || (cols.length === best.cols.length && row < best.row)
    ) {
      best = { row, cols };
    }
  });
  if (!best) return null;
  const detection = best as { row: number; cols: number[] };

  return {
    headerRow: detection.row,
    equipmentCols: Array.from(new Set(detection.cols)).sort((a, b) => a - b),
  };
}

export function resolveHeaderRowIdx(structure: SheetStructure | null | undefined): number | null {
  const det = detectEquipmentLayout(structure);
  if (det) return det.headerRow;
  if (structure && typeof structure.header_row_idx === 'number') return structure.header_row_idx;
  return null;
}

export function getEquipmentColumnIndices(structure: SheetStructure | null | undefined): number[] {
  const det = detectEquipmentLayout(structure);
  return det ? det.equipmentCols : [];
}

export function hasEquipmentColumns(structure: SheetStructure | null | undefined): boolean {
  const det = detectEquipmentLayout(structure);
  return det !== null && det.equipmentCols.length > 0;
}

/**
 * Required column headers — columns that must not be deletable from the viewer.
 * The pattern collapses whitespace so "약품 코드" and "약품코드" both match.
 */
const REQUIRED_HEADER_PATTERN = /^(약품|부품|그룹|마스터)(코드|명)$/;

export function isRequiredHeader(text: unknown): boolean {
  if (text === null || text === undefined) return false;
  const collapsed = String(text).replace(/\s+/g, '').trim();
  if (!collapsed) return false;
  return REQUIRED_HEADER_PATTERN.test(collapsed);
}

/**
 * Last column index that has any non-empty cell anywhere in the sheet.
 * Used by the viewer to trim trailing empty columns.
 */
export function getLastNonEmptyCol(structure: SheetStructure | null | undefined): number {
  if (!structure) return -1;
  let last = -1;
  const cells: SheetCell[] = structure.cells || [];
  for (const c of cells) {
    const v = c.value;
    if (v !== null && v !== undefined && String(v).trim() !== '') {
      if (c.col > last) last = c.col;
    }
  }
  return last;
}
