/**
 * SheetExecutionPopup — 풀스크린 팝업에서 체크시트 직접 사용
 * Excel과 유사한 형태로 렌더링, 웹에서 직접 체크, 진행률 실시간 표시
 */
import { useCallback, useMemo } from 'react';
import {
  Dialog, AppBar, Toolbar, Typography, IconButton, Box,
  LinearProgress, Chip, alpha, Button, DialogTitle, DialogContent, DialogActions,
  TextField, InputAdornment
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ScheduleIcon from '@mui/icons-material/Schedule';
import AssignmentIcon from '@mui/icons-material/Assignment';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import SaveIcon from '@mui/icons-material/Save';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../../api/client';
import { useAppStore } from '../../stores/useAppStore';
import { useUser } from '../../context/UserContext';
import SheetRenderer, { type StatusValue } from './SheetRenderer';
import VirtualizedSheetRenderer from './VirtualizedSheetRenderer';
import AssignmentMappingExcelViewer from './AssignmentMappingExcelViewer';
import { hasEquipmentColumns, isEquipmentMappingSheet } from './assignmentMappingDetect';
import type { AddedColumn, AddedRow } from './useAssignmentMappingState';
import type { SheetExecution, Task } from '../../types';

/** 0-based col index → Excel A1 column letter */
function colToLetter(col: number): string {
  let s = '';
  let n = col + 1;
  while (n > 0) {
    n--;
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26);
  }
  return s;
}
function refOf(rowIdx: number, colIdx: number): string {
  return `${colToLetter(colIdx)}${rowIdx + 1}`;
}
function todayYmd(): string {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${mm}-${dd}`;
}

/** 담당자 셀이 비어있는지 판정 — 빈 문자열, 공백, '-' 만 비어있다고 본다. */
function isAssigneeEmpty(v: string | undefined | null): boolean {
  const s = (v ?? '').toString().trim();
  return s === '' || s === '-';
}

interface Props {
  open: boolean;
  onClose: () => void;
  executionId: number | null;
  userId: number;
}

export default function SheetExecutionPopup({ open, executionId, userId, onClose }: Props) {
  const queryClient = useQueryClient();
  const { user: me } = useUser();
  // 사이드바 하단과 동일 소스: SSO 로그인 사용자 이름. 빈 문자열이면 자동 입력 비활성.
  const currentUserName = (me?.username || '').trim();

  // 로컬 변경 사항 (수동 저장용)
  const [pendingChanges, setPendingChanges] = useState<Map<string, { checked?: boolean; value?: string; memo?: string }>>(new Map());

  // structure_overlay (added_columns / renamed_headers / added_rows / 제거 슬롯) 변경 staging.
  // removedServerCols/Rows: 서버에 이미 저장된 항목을 ✕ 로 제거 의도 표시한 idx 집합.
  const [pendingOverlay, setPendingOverlay] = useState<{
    addedColumns: AddedColumn[];
    renamedHeaders: Record<string, string>;
    removedServerCols: Set<number>;
    addedRows: AddedRow[];
    removedServerRows: Set<number>;
    /** 사용자가 드래그로 변경한 added 컬럼 순서. null 이면 override 없음(서버 순서 유지). */
    colsOrderOverride: number[] | null;
    /** 사용자가 드래그로 변경한 added 행 순서. */
    rowsOrderOverride: number[] | null;
    /** base+added 통합 컬럼 순서 override — 추가 컬럼을 base 컬럼 사이로 drop 시 채워진다. */
    columnOrderOverride: number[] | null;
    rowOrderOverride: number[] | null;
  }>({
    addedColumns: [],
    renamedHeaders: {},
    removedServerCols: new Set(),
    addedRows: [],
    removedServerRows: new Set(),
    colsOrderOverride: null,
    rowsOrderOverride: null,
    columnOrderOverride: null,
    rowOrderOverride: null,
  });

  const { data: execution, isLoading } = useQuery<SheetExecution>({
    queryKey: ['sheetExecution', executionId],
    queryFn: () => api.getSheetExecution(executionId!),
    enabled: open && !!executionId,
    refetchInterval: 30000,
  });

  // 데이터 로드 시 pending 초기화
  useEffect(() => {
    if (open) {
      setPendingChanges(new Map());
      setPendingOverlay({
        addedColumns: [],
        renamedHeaders: {},
        removedServerCols: new Set(),
        addedRows: [],
        removedServerRows: new Set(),
        colsOrderOverride: null,
        rowsOrderOverride: null,
        columnOrderOverride: null,
        rowOrderOverride: null,
      });
    }
  }, [open, executionId]);

  // v3.11: 응답의 task_progress + task_status 를 caches/store 에 즉시 반영
  const applyTaskSync = (response: any) => {
    const taskId: number | null | undefined = response?.task_id;
    const taskProgress: number | null | undefined = response?.task_progress;
    const taskStatus: string | null | undefined = response?.task_status;
    if (taskId != null && (typeof taskProgress === 'number' || typeof taskStatus === 'string')) {
      queryClient.setQueriesData<Task[]>(
        { queryKey: ['tasks'] },
        (old) => Array.isArray(old)
          ? old.map(t => {
              if (t.id !== taskId) return t;
              const patch: Partial<Task> = {};
              if (typeof taskProgress === 'number') patch.progress = taskProgress;
              if (typeof taskStatus === 'string') patch.status = taskStatus as Task['status'];
              return { ...t, ...patch };
            })
          : old,
      );
      const sel = useAppStore.getState().selectedTask;
      if (sel && sel.id === taskId) {
        const patch: Partial<Task> = {};
        if (typeof taskProgress === 'number') patch.progress = taskProgress;
        if (typeof taskStatus === 'string') patch.status = taskStatus as Task['status'];
        useAppStore.setState({ selectedTask: { ...sel, ...patch } });
      }
      queryClient.invalidateQueries({ queryKey: ['taskSheetSummary', taskId] });
    } else {
      queryClient.invalidateQueries({ queryKey: ['taskSheetSummary'] });
    }
    // Dashboard / Sheets 화면도 즉시 갱신
    queryClient.invalidateQueries({ queryKey: ['spaceOverview'] });
    queryClient.invalidateQueries({ queryKey: ['sheetExecutions'] });
  };

  const upsertMut = useMutation({
    mutationFn: ({ cellRef, data }: { cellRef: string; data: any }) =>
      api.upsertSheetExecutionCell(executionId!, cellRef, data, userId),
  });

  // 서버에 저장된 structure_overlay (있으면). 없으면 빈 값.
  const serverAdded = useMemo<AddedColumn[]>(
    () => (execution?.structure_overlay?.added_columns ?? []) as AddedColumn[],
    [execution?.structure_overlay],
  );
  const serverRenamed = useMemo<Record<string, string>>(
    () => execution?.structure_overlay?.renamed_headers ?? {},
    [execution?.structure_overlay],
  );
  const serverAddedRows = useMemo(
    () => execution?.structure_overlay?.added_rows ?? [],
    [execution?.structure_overlay],
  );

  // SheetRenderer 에 넘길 합쳐진 overlay (서버값 + pending - removedServerCols).
  const effectiveAdded = useMemo<AddedColumn[]>(() => {
    const filteredServer = serverAdded.filter((c) => !pendingOverlay.removedServerCols.has(c.col_idx));
    return [...filteredServer, ...pendingOverlay.addedColumns].sort((a, b) => a.col_idx - b.col_idx);
  }, [serverAdded, pendingOverlay.addedColumns, pendingOverlay.removedServerCols]);
  const effectiveRenamed = useMemo<Record<string, string>>(() => {
    const out = { ...serverRenamed, ...pendingOverlay.renamedHeaders };
    // 제거 의도된 컬럼은 rename 표시도 빼서 UI 깨끗하게
    pendingOverlay.removedServerCols.forEach((col) => { delete out[String(col)]; });
    return out;
  }, [serverRenamed, pendingOverlay.renamedHeaders, pendingOverlay.removedServerCols]);

  // 추가 행: 서버 + pending - removed.
  const effectiveAddedRowsList = useMemo<AddedRow[]>(() => {
    const filtered = (serverAddedRows as AddedRow[]).filter(
      (r) => !pendingOverlay.removedServerRows.has(r.row_idx),
    );
    return [...filtered, ...pendingOverlay.addedRows].sort((a, b) => a.row_idx - b.row_idx);
  }, [serverAddedRows, pendingOverlay.addedRows, pendingOverlay.removedServerRows]);

  // 서버에 저장된 added_columns_order / added_rows_order.
  const serverColsOrder = useMemo<number[] | undefined>(
    () => execution?.structure_overlay?.added_columns_order,
    [execution?.structure_overlay],
  );
  const serverRowsOrder = useMemo<number[] | undefined>(
    () => execution?.structure_overlay?.added_rows_order,
    [execution?.structure_overlay],
  );

  // 렌더러에 넘길 effective order — pending override 우선, 없으면 서버 order(있으면)에서 제거된 idx 빼기.
  const effectiveColsOrder = useMemo<number[] | undefined>(() => {
    if (pendingOverlay.colsOrderOverride) return pendingOverlay.colsOrderOverride;
    if (!serverColsOrder) return undefined;
    return serverColsOrder.filter((c) => !pendingOverlay.removedServerCols.has(c));
  }, [serverColsOrder, pendingOverlay.colsOrderOverride, pendingOverlay.removedServerCols]);

  const effectiveRowsOrder = useMemo<number[] | undefined>(() => {
    if (pendingOverlay.rowsOrderOverride) return pendingOverlay.rowsOrderOverride;
    if (!serverRowsOrder) return undefined;
    return serverRowsOrder.filter((r) => !pendingOverlay.removedServerRows.has(r));
  }, [serverRowsOrder, pendingOverlay.rowsOrderOverride, pendingOverlay.removedServerRows]);

  // 서버에 저장된 column_order / row_order (base + added 통합).
  const serverColumnOrder = useMemo<number[] | undefined>(
    () => execution?.structure_overlay?.column_order,
    [execution?.structure_overlay],
  );
  const serverRowOrder = useMemo<number[] | undefined>(
    () => execution?.structure_overlay?.row_order,
    [execution?.structure_overlay],
  );

  // 렌더러에 넘길 통합 순서 — pending override 우선, 없으면 서버 order(있으면)에서 제거된 idx 빼기.
  // base 컬럼 idx 는 0..total_cols-1, added 컬럼 idx 는 그 이상이라 removedServerCols 만 걸러도 충분.
  const effectiveColumnOrder = useMemo<number[] | undefined>(() => {
    if (pendingOverlay.columnOrderOverride) return pendingOverlay.columnOrderOverride;
    if (!serverColumnOrder) return undefined;
    return serverColumnOrder.filter((c) => !pendingOverlay.removedServerCols.has(c));
  }, [serverColumnOrder, pendingOverlay.columnOrderOverride, pendingOverlay.removedServerCols]);

  const effectiveRowOrder = useMemo<number[] | undefined>(() => {
    if (pendingOverlay.rowOrderOverride) return pendingOverlay.rowOrderOverride;
    if (!serverRowOrder) return undefined;
    return serverRowOrder.filter((r) => !pendingOverlay.removedServerRows.has(r));
  }, [serverRowOrder, pendingOverlay.rowOrderOverride, pendingOverlay.removedServerRows]);

  const overlayDirty = pendingOverlay.addedColumns.length > 0
    || Object.keys(pendingOverlay.renamedHeaders).length > 0
    || pendingOverlay.removedServerCols.size > 0
    || pendingOverlay.addedRows.length > 0
    || pendingOverlay.removedServerRows.size > 0
    || pendingOverlay.colsOrderOverride !== null
    || pendingOverlay.rowsOrderOverride !== null
    || pendingOverlay.columnOrderOverride !== null
    || pendingOverlay.rowOrderOverride !== null;

  const handleSave = async () => {
    if (pendingChanges.size === 0 && !overlayDirty) return;
    try {
      // 1) overlay 먼저 — 추가 컬럼이 서버에 있어야 셀 저장이 의미를 갖는다.
      if (overlayDirty) {
        const removed = pendingOverlay.removedServerCols;
        const survivingServer = serverAdded.filter((c) => !removed.has(c.col_idx));
        const addedColIdxSet = new Set<number>([
          ...survivingServer.map((c) => c.col_idx),
          ...pendingOverlay.addedColumns.map((c) => c.col_idx),
        ]);
        // 추가 컬럼 rename → header 직접 적용. base 컬럼 rename → renamed_headers.
        const mergedAdded = [...survivingServer, ...pendingOverlay.addedColumns]
          .map((c) => {
            const r = pendingOverlay.renamedHeaders[String(c.col_idx)];
            return r !== undefined ? { ...c, header: r } : c;
          })
          .sort((a, b) => a.col_idx - b.col_idx);
        // base rename 머지 — 제거된 col 의 rename 도 정리.
        const mergedRenamed: Record<string, string> = { ...serverRenamed };
        removed.forEach((col) => { delete mergedRenamed[String(col)]; });
        Object.entries(pendingOverlay.renamedHeaders).forEach(([k, v]) => {
          const colIdx = Number(k);
          if (removed.has(colIdx)) return; // 제거된 컬럼의 rename 은 흘리지 않는다
          if (addedColIdxSet.has(colIdx)) return;
          mergedRenamed[k] = v;
        });
        // added_rows 머지 — 제거 의도 행 빼고 + pending 추가 행.
        const removedRows = pendingOverlay.removedServerRows;
        const survivingRows = (serverAddedRows as AddedRow[]).filter(
          (r) => !removedRows.has(r.row_idx),
        );
        const mergedAddedRows: AddedRow[] = [...survivingRows, ...pendingOverlay.addedRows]
          .sort((a, b) => a.row_idx - b.row_idx);
        // order 머지 — override 가 있으면 그걸로, 아니면 서버값에서 제거된 idx 빼기.
        const mergedColsOrder: number[] | undefined = (() => {
          if (pendingOverlay.colsOrderOverride) return pendingOverlay.colsOrderOverride;
          if (!serverColsOrder) return undefined;
          return serverColsOrder.filter((c) => !removed.has(c));
        })();
        const mergedRowsOrder: number[] | undefined = (() => {
          if (pendingOverlay.rowsOrderOverride) return pendingOverlay.rowsOrderOverride;
          if (!serverRowsOrder) return undefined;
          return serverRowsOrder.filter((r) => !removedRows.has(r));
        })();
        // base + added 통합 순서: override 가 있으면 그걸, 없으면 서버값에서 제거된 idx 빼기.
        const mergedColumnOrder: number[] | undefined = (() => {
          if (pendingOverlay.columnOrderOverride) return pendingOverlay.columnOrderOverride;
          if (!serverColumnOrder) return undefined;
          return serverColumnOrder.filter((c) => !removed.has(c));
        })();
        const mergedRowOrder: number[] | undefined = (() => {
          if (pendingOverlay.rowOrderOverride) return pendingOverlay.rowOrderOverride;
          if (!serverRowOrder) return undefined;
          return serverRowOrder.filter((r) => !removedRows.has(r));
        })();
        const overlayPayload: any = {
          added_columns: mergedAdded,
          added_rows: mergedAddedRows,
          renamed_headers: mergedRenamed,
        };
        if (mergedColsOrder !== undefined) overlayPayload.added_columns_order = mergedColsOrder;
        if (mergedRowsOrder !== undefined) overlayPayload.added_rows_order = mergedRowsOrder;
        if (mergedColumnOrder !== undefined) overlayPayload.column_order = mergedColumnOrder;
        if (mergedRowOrder !== undefined) overlayPayload.row_order = mergedRowOrder;
        await api.updateSheetStructureOverlay(executionId!, overlayPayload, userId);
      }
      // 2) 셀 저장.
      let lastResult: any;
      if (pendingChanges.size > 0) {
        const promises = Array.from(pendingChanges.entries()).map(([cellRef, data]) =>
          upsertMut.mutateAsync({ cellRef, data })
        );
        const results = await Promise.all(promises);
        if (results.length > 0) lastResult = results[results.length - 1];
      }
      setPendingChanges(new Map());
      setPendingOverlay({
        addedColumns: [],
        renamedHeaders: {},
        removedServerCols: new Set(),
        addedRows: [],
        removedServerRows: new Set(),
        colsOrderOverride: null,
        rowsOrderOverride: null,
        columnOrderOverride: null,
        rowOrderOverride: null,
      });
      queryClient.invalidateQueries({ queryKey: ['sheetExecution', executionId] });
      if (lastResult) applyTaskSync(lastResult);
    } catch (err) {
      console.error('Failed to save changes:', err);
      alert('저장 중 오류가 발생했습니다.');
    }
  };

  const handleClose = () => {
    if (pendingChanges.size > 0 || overlayDirty) {
      if (!window.confirm('저장하지 않은 변경사항이 있습니다. 닫으시겠습니까?')) {
        return;
      }
    }
    onClose();
  };

  // 삭제(숨김) 컬럼 관리 — execution 단위로 저장
  const hiddenCols: number[] = (execution as any)?.hidden_cols || [];
  const [pendingDeleteCol, setPendingDeleteCol] = useState<number | null>(null);
  const hiddenColsMut = useMutation({
    mutationFn: (cols: number[]) => api.updateSheetHiddenCols(executionId!, cols, userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sheetExecution', executionId] });
    },
    onError: (e: any) => alert(e?.response?.data?.detail || '컬럼 삭제 실패'),
  });
  const handleDeleteColumn = useCallback((colIdx: number) => {
    setPendingDeleteCol(colIdx);
  }, []);
  const confirmDeleteColumn = () => {
    if (pendingDeleteCol == null) return;
    const next = Array.from(new Set([...hiddenCols, pendingDeleteCol])).sort((a, b) => a - b);
    hiddenColsMut.mutate(next);
    setPendingDeleteCol(null);
  };

  // 삭제(숨김) 행 관리 — execution 단위로 저장
  const hiddenRows: number[] = (execution as any)?.hidden_rows || [];
  const [pendingDeleteRow, setPendingDeleteRow] = useState<number | null>(null);
  const hiddenRowsMut = useMutation({
    mutationFn: (rows: number[]) => api.updateSheetHiddenRows(executionId!, rows, userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sheetExecution', executionId] });
    },
    onError: (e: any) => alert(e?.response?.data?.detail || '행 삭제 실패'),
  });
  const handleDeleteRow = useCallback((rowIdx: number) => {
    setPendingDeleteRow(rowIdx);
  }, []);
  const confirmDeleteRow = () => {
    if (pendingDeleteRow == null) return;
    const next = Array.from(new Set([...hiddenRows, pendingDeleteRow])).sort((a, b) => a - b);
    hiddenRowsMut.mutate(next);
    setPendingDeleteRow(null);
  };

  const [confirmAllOpen, setConfirmAllOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const [searchInput, setSearchInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setSearchQuery(searchInput), 300);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const handleCheckChange = useCallback((cellRef: string, checked: boolean) => {
    setPendingChanges(prev => {
      const next = new Map(prev);
      const existing = next.get(cellRef) || {};
      next.set(cellRef, { ...existing, checked });
      return next;
    });
  }, []);

  const handleValueChange = useCallback((cellRef: string, value: string) => {
    setPendingChanges(prev => {
      const next = new Map(prev);
      const existing = next.get(cellRef) || {};
      next.set(cellRef, { ...existing, value });
      return next;
    });
  }, []);

  // Structure overlay 액션: + 컬럼 추가 / 헤더 rename / pending 추가컬럼 ✕.
  const totalCols = execution?.template_structure?.total_cols ?? 0;
  const handleAddColumn = useCallback(() => {
    setPendingOverlay((prev) => {
      const allTaken = new Set<number>([
        ...serverAdded.map((c) => c.col_idx),
        ...prev.addedColumns.map((c) => c.col_idx),
      ]);
      let nextCol = totalCols;
      while (allTaken.has(nextCol)) nextCol += 1;
      // 자동명명 "새 컬럼N" — base/server-added/pending-added 의 헤더에서 N 수집해 빈 N 부여.
      const re = /^새 컬럼(\d+)$/;
      const used = new Set<number>();
      const harvest = (h: string) => { const m = re.exec(h.replace(/\s+/g, ' ')); if (m) used.add(Number(m[1])); };
      serverAdded.forEach((c) => harvest(c.header));
      prev.addedColumns.forEach((c) => harvest(c.header));
      let n = 1;
      while (used.has(n)) n += 1;
      return {
        ...prev,
        addedColumns: [...prev.addedColumns, { col_idx: nextCol, header: `새 컬럼${n}`, kind: 'plain' }],
      };
    });
  }, [serverAdded, totalCols]);

  const handleRenameHeader = useCallback((colIdx: number, newHeader: string) => {
    const text = newHeader.trim();
    setPendingOverlay((prev) => {
      // pending 으로 추가된 컬럼이면 entry header 를 직접 업데이트 (빈 입력은 무시)
      const idx = prev.addedColumns.findIndex((c) => c.col_idx === colIdx);
      if (idx >= 0) {
        if (text === '') return prev;
        const next = prev.addedColumns.slice();
        next[idx] = { ...next[idx], header: text };
        return { ...prev, addedColumns: next };
      }
      const renamedNext = { ...prev.renamedHeaders };
      if (text === '') delete renamedNext[String(colIdx)];
      else renamedNext[String(colIdx)] = text;
      return { ...prev, renamedHeaders: renamedNext };
    });
  }, []);

  const totalRows = execution?.template_structure?.total_rows ?? 0;
  const handleAddRow = useCallback(() => {
    setPendingOverlay((prev) => {
      const allTaken = new Set<number>([
        ...(serverAddedRows as AddedRow[]).map((r) => r.row_idx),
        ...prev.addedRows.map((r) => r.row_idx),
      ]);
      let nextRow = totalRows;
      while (allTaken.has(nextRow)) nextRow += 1;
      return { ...prev, addedRows: [...prev.addedRows, { row_idx: nextRow }] };
    });
  }, [serverAddedRows, totalRows]);

  const handleDeleteAddedRow = useCallback((rowIdx: number) => {
    setPendingOverlay((prev) => {
      const idx = prev.addedRows.findIndex((r) => r.row_idx === rowIdx);
      if (idx >= 0) {
        const next = prev.addedRows.slice();
        next.splice(idx, 1);
        return { ...prev, addedRows: next };
      }
      // server-added row 면 removed 슬롯에 등록
      if (!(serverAddedRows as AddedRow[]).some((r) => r.row_idx === rowIdx)) return prev;
      if (prev.removedServerRows.has(rowIdx)) return prev;
      const removedNext = new Set(prev.removedServerRows);
      removedNext.add(rowIdx);
      return { ...prev, removedServerRows: removedNext };
    });
  }, [serverAddedRows]);

  const handleDeleteAddedColumn = useCallback((colIdx: number) => {
    setPendingOverlay((prev) => {
      // 1) pending 추가 컬럼이면 즉시 제거 (서버에 미반영)
      const idx = prev.addedColumns.findIndex((c) => c.col_idx === colIdx);
      if (idx >= 0) {
        const next = prev.addedColumns.slice();
        next.splice(idx, 1);
        const renamedNext = { ...prev.renamedHeaders };
        delete renamedNext[String(colIdx)];
        return { ...prev, addedColumns: next, renamedHeaders: renamedNext };
      }
      // 2) server-added 컬럼이면 removed 슬롯에 등록 (저장 시 제외)
      if (!serverAdded.some((c) => c.col_idx === colIdx)) return prev;
      if (prev.removedServerCols.has(colIdx)) return prev;
      const removedNext = new Set(prev.removedServerCols);
      removedNext.add(colIdx);
      // 해당 컬럼의 pending rename 도 정리
      const renamedNext = { ...prev.renamedHeaders };
      delete renamedNext[String(colIdx)];
      return { ...prev, removedServerCols: removedNext, renamedHeaders: renamedNext };
    });
  }, [serverAdded]);

  const handleReorderAddedColumns = useCallback((newOrder: number[]) => {
    setPendingOverlay((prev) => ({ ...prev, colsOrderOverride: newOrder.slice() }));
  }, []);

  const handleReorderAddedRows = useCallback((newOrder: number[]) => {
    setPendingOverlay((prev) => ({ ...prev, rowsOrderOverride: newOrder.slice() }));
  }, []);

  // 추가 컬럼/행을 base 컬럼/행 사이로 drop 했을 때 호출. base+added 통합 순서를 staging.
  const handleReorderColumns = useCallback((newOrder: number[]) => {
    setPendingOverlay((prev) => ({ ...prev, columnOrderOverride: newOrder.slice() }));
  }, []);

  const handleReorderRows = useCallback((newOrder: number[]) => {
    setPendingOverlay((prev) => ({ ...prev, rowOrderOverride: newOrder.slice() }));
  }, []);

  // v3.4: 상태 select 변경 — value/checked 동시 갱신 + 진행일자 자동 연동
  const progressDateCol = execution?.template_structure?.column_roles?.progress_date?.col;
  const assigneeCol = execution?.template_structure?.column_roles?.assignee?.col;

  const handleStatusChange = useCallback(
    (cellRef: string, status: StatusValue, rowIdx: number, _colIdx: number) => {
      const checked = status === 'O';
      setPendingChanges(prev => {
        const next = new Map(prev);
        // 상태값 변경
        const existing = next.get(cellRef) || {};
        next.set(cellRef, { ...existing, value: status, checked });

        // 점검일 자동 기록 (staging)
        if (progressDateCol !== undefined && progressDateCol >= 0) {
          const dateRef = refOf(rowIdx, progressDateCol);
          const dateValue = status === 'O' ? todayYmd() : '';
          const existingDate = next.get(dateRef) || {};
          next.set(dateRef, { ...existingDate, value: dateValue });
        }

        // 담당자 자동 기록 — 진행(O) 선택 시에만, 비어있을 때만 채운다.
        // 미진행으로 되돌려도 담당자는 유지(자동 클리어 X). 사용자가 직접 수정 가능.
        if (status === 'O' && currentUserName && assigneeCol !== undefined && assigneeCol >= 0) {
          const assigneeRef = refOf(rowIdx, assigneeCol);
          const pendingAssignee = next.get(assigneeRef)?.value;
          const serverAssignee = execution?.items?.find(i => i.cell_ref === assigneeRef)?.value;
          const currentAssignee = pendingAssignee !== undefined ? pendingAssignee : serverAssignee;
          if (isAssigneeEmpty(currentAssignee)) {
            const existingAssignee = next.get(assigneeRef) || {};
            next.set(assigneeRef, { ...existingAssignee, value: currentUserName });
          }
        }
        return next;
      });
    },
    [progressDateCol, assigneeCol, currentUserName, execution?.items],
  );

  // v3.13: ALL 진행 — 서버 호출 대신 pendingChanges 에 staging.
  //  · 저장하기 버튼이 활성화되어 사용자가 명시 저장해야 반영된다.
  //  · 저장은 기존 upsert 경로를 통과하므로 진행률 재계산이 항상 현재 시트 상태 기준이다.
  //  · 이미 "O" 또는 "N/A" 인 항목은 건너뛴다.
  const handleApplyMarkAllPending = useCallback(() => {
    const checkable = execution?.template_structure?.checkable_cells || [];
    if (checkable.length === 0) return;
    setPendingChanges(prev => {
      const next = new Map(prev);
      const today = todayYmd();
      const progressedRows = new Set<number>();
      for (const c of checkable) {
        const cellRef = c.ref;
        // 현재 값 — pending 우선, 없으면 서버 항목.
        const pendingVal = next.get(cellRef)?.value;
        const serverItem = execution?.items?.find(i => i.cell_ref === cellRef);
        const currentValue = (pendingVal !== undefined ? pendingVal : (serverItem?.value ?? '')).toString().trim().toUpperCase();
        if (currentValue === 'N/A') continue;
        if (currentValue === 'O') continue;
        const existing = next.get(cellRef) || {};
        next.set(cellRef, { ...existing, value: 'O', checked: true });
        progressedRows.add(c.row);
      }
      if (progressDateCol !== undefined && progressDateCol >= 0) {
        for (const rowIdx of progressedRows) {
          const dateRef = refOf(rowIdx, progressDateCol);
          const existingDate = next.get(dateRef) || {};
          next.set(dateRef, { ...existingDate, value: today });
        }
      }

      // ALL 진행 — 새로 'O' 가 된 행의 담당자 셀도 비어있으면 채운다.
      if (currentUserName && assigneeCol !== undefined && assigneeCol >= 0) {
        for (const rowIdx of progressedRows) {
          const assigneeRef = refOf(rowIdx, assigneeCol);
          const pendingAssignee = next.get(assigneeRef)?.value;
          const serverAssignee = execution?.items?.find(i => i.cell_ref === assigneeRef)?.value;
          const currentAssignee = pendingAssignee !== undefined ? pendingAssignee : serverAssignee;
          if (isAssigneeEmpty(currentAssignee)) {
            const existingAssignee = next.get(assigneeRef) || {};
            next.set(assigneeRef, { ...existingAssignee, value: currentUserName });
          }
        }
      }
      return next;
    });
  }, [execution?.template_structure?.checkable_cells, execution?.items, progressDateCol, assigneeCol, currentUserName]);

  const handleDownloadClick = async () => {
    if (!executionId || downloading) return;
    setDownloading(true);
    try {
      await api.downloadSheetExecutionXlsx(executionId, execution?.title || 'sheet');
    } catch (e: any) {
      alert(e?.response?.data?.detail || '엑셀 다운로드 실패');
    } finally {
      setDownloading(false);
    }
  };
  // queryClient referenced to keep mutation hook patterns consistent (no-op)
  void queryClient;

  const structure = execution?.template_structure;
  const progress = execution?.progress ?? 0;
  const checkedCount = execution?.checked_items ?? 0;
  const totalCount = execution?.total_items ?? 0;
  const columnRoles = structure?.column_roles;

  // 관리형 시트 판정 — sheet_type 이 명시되어 있으면 그걸, 아니면 설비 컬럼 감지 휴리스틱.
  // assignment_mapping / inventory_management / general_table 같은 비-inspection 타입은 진행률
  // 개념이 의미 없으므로 진행 UI(완료/퍼센트/LinearProgress/ALL 진행)를 모두 숨긴다.
  const isManagementSheet = isEquipmentMappingSheet(execution);

  // Phase 2: 대용량 시트는 가상화 렌더러로 전환. 임계값 = 50,000 셀 (예: 1736×211 ≈ 366K).
  // 현재 inspection 외 sheet_type 은 AssignmentMappingExcelViewer 가 분기 처리하므로
  // 여기 분기는 inspection / 미지정 시트에만 적용된다.
  const cellCount = structure ? (structure.total_rows || 0) * (structure.total_cols || 0) : 0;
  const useVirtualizedRenderer = cellCount > 50000;

  // 항목별 매핑 — execution.items가 바뀔 때만 재생성
  const { checkedMap, checkedAtMap, valueMap } = useMemo(() => {
    const cMap = new Map<string, boolean>();
    const aMap = new Map<string, string>();
    const vMap = new Map<string, string>();
    if (execution?.items) {
      for (const item of execution.items) {
        cMap.set(item.cell_ref, item.checked);
        if (item.checked_at) aMap.set(item.cell_ref, item.checked_at);
        if (item.value) vMap.set(item.cell_ref, item.value);
      }
    }

    // Overlay Pending
    pendingChanges.forEach((data, ref) => {
      if (data.checked !== undefined) cMap.set(ref, data.checked);
      if (data.value !== undefined) vMap.set(ref, data.value);
    });

    return { checkedMap: cMap, checkedAtMap: aMap, valueMap: vMap };
  }, [execution?.items, pendingChanges]);

  const isDirty = pendingChanges.size > 0 || overlayDirty;

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      fullScreen
      PaperProps={{ sx: { bgcolor: '#F9FAFB' } }}
    >
      {/* Top Bar */}
      <AppBar position="static" elevation={0} sx={{ bgcolor: '#1A1D29' }}>
        <Toolbar sx={{ gap: 2 }}>
          <AssignmentIcon sx={{ color: '#2955FF', fontSize: 22 }} />
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#fff', fontSize: '0.92rem', lineHeight: 1.2 }}>
              {execution?.title || '체크시트'}
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.68rem' }}>
              {execution?.template_name || ''}
            </Typography>
          </Box>

          {/* Summary chips — 관리형 시트는 진행률 개념이 없으므로 "관리 시트" 배지로 대체 */}
          {isManagementSheet ? (
            <Chip
              label="관리 시트"
              size="small"
              sx={{
                bgcolor: alpha('#9CA3AF', 0.15), color: '#D1D5DB',
                fontWeight: 700, fontSize: '0.72rem', height: 26,
              }}
            />
          ) : (
            <>
              <Chip
                icon={<CheckCircleIcon sx={{ fontSize: 14 }} />}
                label={`${checkedCount}/${totalCount} 완료`}
                size="small"
                sx={{
                  bgcolor: alpha('#22C55E', 0.15), color: '#22C55E',
                  fontWeight: 700, fontSize: '0.72rem', height: 26,
                }}
              />
              <Chip
                icon={<ScheduleIcon sx={{ fontSize: 14 }} />}
                label={`${progress}%`}
                size="small"
                sx={{
                  bgcolor: alpha('#2955FF', 0.15), color: '#93B4FF',
                  fontWeight: 700, fontSize: '0.72rem', height: 26,
                }}
              />

              {/* Progress bar */}
              <Box sx={{ width: 120, flexShrink: 0 }}>
                <LinearProgress
                  variant="determinate"
                  value={progress}
                  sx={{
                    height: 6, borderRadius: 3,
                    bgcolor: 'rgba(255,255,255,0.1)',
                    '& .MuiLinearProgress-bar': {
                      bgcolor: progress >= 100 ? '#22C55E' : '#2955FF',
                      borderRadius: 3,
                      transition: 'width 0.3s ease',
                    },
                  }}
                />
              </Box>
            </>
          )}

          {/* 저장 버튼 */}
          <Chip
            icon={<SaveIcon sx={{ fontSize: '1.1rem !important', color: isDirty ? '#fff !important' : 'inherit' }} />}
            label={upsertMut.isPending ? '저장 중...' : '저장하기'}
            clickable
            onClick={handleSave}
            disabled={!isDirty || upsertMut.isPending}
            sx={{
              fontWeight: 800,
              bgcolor: isDirty ? '#2955FF' : 'rgba(255,255,255,0.05)',
              color: isDirty ? '#fff' : '#6B7280',
              border: isDirty ? 'none' : '1px solid rgba(255,255,255,0.1)',
              '&:hover': { bgcolor: isDirty ? '#1E40AF' : 'rgba(255,255,255,0.1)' },
              transition: 'all 0.2s',
              height: 26,
              fontSize: '0.72rem',
            }}
          />

          {(upsertMut.isPending || downloading) && (
            <Chip
              label={downloading ? "다운로드 중..." : "저장 중..."}
              size="small"
              sx={{ bgcolor: alpha('#F59E0B', 0.15), color: '#F59E0B', height: 22, fontSize: '0.62rem' }}
            />
          )}

          {/* v3.13: ALL 진행 — 미진행/빈/X 항목을 일괄 진행으로 staging (저장 시 서버 반영).
              관리형 시트는 진행 개념 자체가 없으므로 노출하지 않는다. */}
          {execution?.status !== 'completed' && !isManagementSheet && (
            <Chip
              icon={<DoneAllIcon sx={{ fontSize: 14, color: '#fff !important' }} />}
              label="ALL 진행"
              onClick={() => setConfirmAllOpen(true)}
              size="small"
              disabled={upsertMut.isPending}
              sx={{
                bgcolor: alpha('#22C55E', 0.85), color: '#fff',
                fontWeight: 700, fontSize: '0.72rem', height: 26, cursor: 'pointer',
                '&:hover': { bgcolor: '#22C55E' },
              }}
            />
          )}

          {/* + 컬럼 추가 / + 행 추가 — 일반 시트 (assignment-mapping 이 아닌 경우)에만 노출.
              assignment-mapping 뷰어는 자체 툴바에 + 설비/컬럼/행 버튼이 이미 있다. */}
          {execution?.status !== 'completed' && structure && !hasEquipmentColumns(structure) && (
            <Chip
              label="+ 컬럼 추가"
              onClick={handleAddColumn}
              size="small"
              sx={{
                bgcolor: 'rgba(255,255,255,0.1)', color: '#fff',
                fontWeight: 600, fontSize: '0.72rem', height: 26, cursor: 'pointer',
                '&:hover': { bgcolor: 'rgba(255,255,255,0.2)' },
              }}
              title="새 컬럼을 우측에 추가 (저장 전 헤더 ✕ 또는 미저장)"
            />
          )}
          {execution?.status !== 'completed' && structure && !hasEquipmentColumns(structure) && (
            <Chip
              label="+ 행 추가"
              onClick={handleAddRow}
              size="small"
              sx={{
                bgcolor: 'rgba(255,255,255,0.1)', color: '#fff',
                fontWeight: 600, fontSize: '0.72rem', height: 26, cursor: 'pointer',
                '&:hover': { bgcolor: 'rgba(255,255,255,0.2)' },
              }}
              title="새 행을 마지막에 추가 (저장 전 ✕ 또는 미저장)"
            />
          )}

          <Chip
            icon={<FileDownloadIcon sx={{ fontSize: 14, color: '#fff !important' }} />}
            label="엑셀 다운로드"
            onClick={handleDownloadClick}
            size="small"
            disabled={downloading}
            sx={{
              bgcolor: 'rgba(255,255,255,0.1)', color: '#fff',
              fontWeight: 600, fontSize: '0.72rem', height: 26, cursor: 'pointer',
              '&:hover': { bgcolor: 'rgba(255,255,255,0.2)' }
            }}
          />

          {/* Search Input */}
          <TextField
            size="small"
            placeholder="시트 검색..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: 'rgba(255,255,255,0.5)', fontSize: 18 }} />
                </InputAdornment>
              ),
              endAdornment: searchInput ? (
                <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setSearchInput('')} sx={{ p: 0.5, color: 'rgba(255,255,255,0.5)' }}>
                    <ClearIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </InputAdornment>
              ) : null,
              sx: {
                color: '#fff',
                bgcolor: 'rgba(255,255,255,0.05)',
                borderRadius: 1.5,
                fontSize: '0.8rem',
                height: 28,
                '& fieldset': { border: 'none' },
                '&:hover': { bgcolor: 'rgba(255,255,255,0.1)' },
                '&.Mui-focused': { bgcolor: 'rgba(255,255,255,0.15)' },
              }
            }}
            sx={{ width: 160 }}
          />

          <IconButton onClick={handleClose} sx={{ color: 'rgba(255,255,255,0.7)' }}>
            <CloseIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* Content — virtualized renderer 또는 Assignment 뷰어 내부에서 스크롤을 관리하므로 외곽은 overflow:hidden */}
      <Box sx={{ flex: 1, overflow: (useVirtualizedRenderer || hasEquipmentColumns(structure)) ? 'hidden' : 'auto', p: 2, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
        {isLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
            <Box sx={{ textAlign: 'center' }}>
              <LinearProgress sx={{ width: 200, mb: 2, borderRadius: 2 }} />
              <Typography variant="body2" color="text.secondary">체크시트 로딩 중...</Typography>
            </Box>
          </Box>
        ) : structure ? (
          <>
          {useVirtualizedRenderer && !hasEquipmentColumns(structure) && (
            <Box sx={{
              mb: 1, px: 1.5, py: 0.75, borderRadius: 1,
              bgcolor: '#EFF6FF', border: '1px solid #BFDBFE',
              display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0,
            }}>
              <Typography variant="caption" sx={{ fontSize: '12px', color: '#1E40AF', fontWeight: 600 }}>
                대용량 시트 최적화 모드로 표시 중입니다 ({(structure.total_rows || 0).toLocaleString()}행 × {(structure.total_cols || 0).toLocaleString()}열).
                병합 셀은 그룹 라벨로 간략화되어 보일 수 있습니다.
              </Typography>
            </Box>
          )}
          <Box sx={{
            bgcolor: '#fff', borderRadius: 2, boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
            overflow: (useVirtualizedRenderer || hasEquipmentColumns(structure)) ? 'hidden' : 'auto',
            ...((useVirtualizedRenderer || hasEquipmentColumns(structure)) ? { flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' } : { maxHeight: 'calc(100vh - 80px)' }),
            p: hasEquipmentColumns(structure) ? 1.5 : 0,
          }}>
            {hasEquipmentColumns(structure) ? (
              <AssignmentMappingExcelViewer
                executionId={executionId!}
                structure={structure}
                items={execution?.items || []}
                userId={userId}
                readOnly={execution?.status === 'completed'}
                baseHiddenRows={hiddenRows}
                baseHiddenCols={hiddenCols}
                structureOverlay={execution?.structure_overlay ?? null}
                searchQuery={searchQuery}
              />
            ) : (
              useVirtualizedRenderer ? (
                <VirtualizedSheetRenderer
                  structure={structure}
                  checkedMap={checkedMap}
                  checkedAtMap={checkedAtMap}
                  valueMap={valueMap}
                  columnRoles={columnRoles}
                  onCheckChange={handleCheckChange}
                  onValueChange={handleValueChange}
                  onStatusChange={handleStatusChange}
                  readOnly={execution?.status === 'completed'}
                  hiddenCols={hiddenCols}
                  onDeleteColumn={execution?.status === 'completed' ? undefined : handleDeleteColumn}
                  hiddenRows={hiddenRows}
                  onDeleteRow={execution?.status === 'completed' ? undefined : handleDeleteRow}
                  freeTextEdit
                  addedColumns={effectiveAdded}
                  renamedHeaders={effectiveRenamed}
                  onRenameHeader={execution?.status === 'completed' ? undefined : handleRenameHeader}
                  onDeleteAddedColumn={execution?.status === 'completed' ? undefined : handleDeleteAddedColumn}
                  addedRows={effectiveAddedRowsList}
                  onDeleteAddedRow={execution?.status === 'completed' ? undefined : handleDeleteAddedRow}
                  addedColumnsOrder={effectiveColsOrder}
                  addedRowsOrder={effectiveRowsOrder}
                  columnOrder={effectiveColumnOrder}
                  rowOrder={effectiveRowOrder}
                  searchQuery={searchQuery}
                />
              ) : (
                <SheetRenderer
                  structure={structure}
                  checkedMap={checkedMap}
                  checkedAtMap={checkedAtMap}
                  valueMap={valueMap}
                  columnRoles={columnRoles}
                  onCheckChange={handleCheckChange}
                  onValueChange={handleValueChange}
                  onStatusChange={handleStatusChange}
                  readOnly={execution?.status === 'completed'}
                  hiddenCols={hiddenCols}
                  onDeleteColumn={execution?.status === 'completed' ? undefined : handleDeleteColumn}
                  hiddenRows={hiddenRows}
                  onDeleteRow={execution?.status === 'completed' ? undefined : handleDeleteRow}
                  freeTextEdit
                  addedColumns={effectiveAdded}
                  renamedHeaders={effectiveRenamed}
                  onRenameHeader={execution?.status === 'completed' ? undefined : handleRenameHeader}
                  onDeleteAddedColumn={execution?.status === 'completed' ? undefined : handleDeleteAddedColumn}
                  addedRows={effectiveAddedRowsList}
                  onDeleteAddedRow={execution?.status === 'completed' ? undefined : handleDeleteAddedRow}
                  addedColumnsOrder={effectiveColsOrder}
                  addedRowsOrder={effectiveRowsOrder}
                  onReorderAddedColumns={execution?.status === 'completed' ? undefined : handleReorderAddedColumns}
                  onReorderAddedRows={execution?.status === 'completed' ? undefined : handleReorderAddedRows}
                  columnOrder={effectiveColumnOrder}
                  rowOrder={effectiveRowOrder}
                  onReorderColumns={execution?.status === 'completed' ? undefined : handleReorderColumns}
                  onReorderRows={execution?.status === 'completed' ? undefined : handleReorderRows}
                  searchQuery={searchQuery}
                />
              )
            )}
          </Box>
          </>
        ) : (
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <Typography variant="body2" color="text.secondary">
              시트 구조를 불러올 수 없습니다.
            </Typography>
          </Box>
        )}
      </Box>

      {/* v3.13: ALL 진행 확인 모달 — staging 만 수행하고 저장 버튼으로 명시 저장. */}
      <Dialog open={confirmAllOpen} onClose={() => setConfirmAllOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 700 }}>모든 항목을 진행 처리할까요?</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ color: '#374151', lineHeight: 1.7 }}>
            · 미진행 / 빈 값 항목을 모두 <b>진행</b>으로 변경합니다.<br />
            · 진행으로 바뀐 행의 <b>진행일자</b>는 오늘 날짜로 자동 입력됩니다.<br />
            · 이미 <b>N/A</b>로 표시된 항목은 그대로 유지됩니다.<br />
            · 변경 사항은 <b>저장하기</b> 버튼을 눌러야 서버에 반영됩니다.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setConfirmAllOpen(false)} sx={{ color: '#6B7280' }}>취소</Button>
          <Button
            variant="contained"
            onClick={() => {
              handleApplyMarkAllPending();
              setConfirmAllOpen(false);
            }}
            sx={{ bgcolor: '#22C55E', '&:hover': { bgcolor: '#16A34A' } }}
          >
            모두 진행
          </Button>
        </DialogActions>
      </Dialog>

      {/* 컬럼 삭제 확인 */}
      <Dialog open={pendingDeleteCol != null} onClose={() => setPendingDeleteCol(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 700 }}>이 컬럼을 삭제할까요?</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ color: '#374151', lineHeight: 1.7 }}>
            · 컬럼 <b>{pendingDeleteCol != null ? colToLetter(pendingDeleteCol) : ''}</b> 가 이 실행본에서 숨겨집니다.<br />
            · <b>원본 양식(template)</b> 은 변경되지 않으며 다른 실행본에는 영향이 없습니다.<br />
            · 이미 입력된 데이터는 보존됩니다 (다시 표시할 수 있음).
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setPendingDeleteCol(null)} sx={{ color: '#6B7280' }}>취소</Button>
          <Button
            variant="contained"
            disabled={hiddenColsMut.isPending}
            onClick={confirmDeleteColumn}
            sx={{ bgcolor: '#DC2626', '&:hover': { bgcolor: '#B91C1C' } }}
          >
            삭제
          </Button>
        </DialogActions>
      </Dialog>

      {/* 행 삭제 확인 */}
      <Dialog open={pendingDeleteRow != null} onClose={() => setPendingDeleteRow(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontWeight: 700 }}>이 행을 삭제하시겠습니까?</DialogTitle>
        <DialogContent>
          <Typography variant="body2" sx={{ color: '#374151', lineHeight: 1.7 }}>
            · 행 <b>{pendingDeleteRow != null ? pendingDeleteRow + 1 : ''}</b> 이(가) 이 실행본에서 숨겨집니다.<br />
            · <b>원본 양식(template)</b> 은 변경되지 않으며 다른 실행본에는 영향이 없습니다.<br />
            · 병합 셀이 포함된 경우 가시 영역에 맞춰 표시 범위가 자동 조정됩니다.<br />
            · 이미 입력된 데이터는 보존됩니다.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setPendingDeleteRow(null)} sx={{ color: '#6B7280' }}>취소</Button>
          <Button
            variant="contained"
            disabled={hiddenRowsMut.isPending}
            onClick={confirmDeleteRow}
            sx={{ bgcolor: '#DC2626', '&:hover': { bgcolor: '#B91C1C' } }}
          >
            삭제
          </Button>
        </DialogActions>
      </Dialog>
    </Dialog>
  );
}
