/**
 * VirtualizedSheetRenderer — Phase 2 (행 + 열 가상화): 대용량 시트(예: 1736×211)에서
 * OOM/렌더 버벅임을 피하기 위한 가상화 렌더러. SheetRenderer 와 같은 Props 를 받지만 다음 trade-off 를 둔다.
 *
 *   1. 행 높이는 고정 32px (편집 중인 셀만 InlineCellEditor 가 absolute overlay 로 자라남).
 *   2. 헤더 행(0..headerRowIdx)은 sticky 로 별도 <table> 렌더 — 여기서는 rowSpan/colSpan 모두 지원.
 *   3. 본문 행은 행+열 모두 가상화. rowSpan 은 시각적으로 깨지지 않도록 비-origin 행에서도
 *      origin 값을 약한 opacity 로 표시 (정확한 Excel-수준 병합 재현은 후속 Phase).
 *      colSpan (동일 행 내 가로 병합) 은 그대로 지원되며 가상화 경계에서도 origin 셀이 보이도록
 *      MAX_COLSPAN_LOOKBACK 만큼 lookback 하여 렌더한다.
 *   4. 첫 번째 컬럼은 sticky-left 로 가로 스크롤 중에도 항상 보인다 (분류/구분 컬럼 가시성 보장).
 *   5. 드래그 reorder / 행·열 삭제 버튼 / 헤더 rename 등의 부가 UI 는 그대로 동작한다.
 *   6. 본문 cell 은 React.memo 로 최소 props 로 분리되어 스크롤/편집 시 영향 없는 셀은 재렌더하지 않는다.
 *
 * 렌더러 선택은 SheetExecutionPopup 에서 (rows*cols > 50000) 기준으로 결정된다.
 * SheetRenderer / AssignmentMappingExcelViewer 는 변경하지 않는다 (Option A: 병행 렌더러).
 */
import React, { useMemo, useCallback, useState, useRef, useEffect, useLayoutEffect } from 'react';
import { Box, Checkbox, Typography, Tooltip, Select, MenuItem } from '@mui/material';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import type { SheetStructure, SheetCell, SheetExecutionItem, ColumnRoleMapping } from '../../types';
import type { AddedColumn, AddedRow } from './useAssignmentMappingState';
import ImagePreviewModal from '../ImagePreviewModal';
import {
  STATUS_OPTIONS,
  statusLabel,
  formatCheckedAt,
  InlineCellEditor,
  type StatusValue,
} from './SheetRenderer';

/**
 * 자체 미니 행 가상화 훅 — 사내 Nexus 에서 @tanstack/react-virtual 이 403 차단되어
 * 외부 의존 없이 동등한 인터페이스만 직접 구현. 행 높이 고정 (rowHeight) 일 때만 정확하다.
 * (편집 중 행 높이 확장은 InlineCellEditor 가 absolute overlay 로 처리하므로 측정 불필요.)
 */
interface VirtualItem {
  key: React.Key;
  index: number;
  start: number;
  size: number;
}
function useFixedRowVirtualizer(opts: {
  count: number;
  rowHeight: number;
  overscan: number;
  getScrollElement: () => HTMLElement | null;
  getItemKey?: (index: number) => React.Key;
}): {
  getTotalSize: () => number;
  getVirtualItems: () => VirtualItem[];
  scrollLeft: number;
  viewportW: number;
} {
  const { count, rowHeight, overscan, getScrollElement, getItemKey } = opts;
  const [scrollTop, setScrollTop] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const [viewportH, setViewportH] = useState(0);
  const [viewportW, setViewportW] = useState(0);

  useEffect(() => {
    const el = getScrollElement();
    if (!el) return;
    let rafId = 0;
    const onScroll = () => {
      if (rafId) return;
      rafId = requestAnimationFrame(() => {
        rafId = 0;
        setScrollTop(el.scrollTop);
        setScrollLeft(el.scrollLeft);
      });
    };
    const onResize = () => {
      setViewportH(el.clientHeight);
      setViewportW(el.clientWidth);
    };
    setScrollTop(el.scrollTop);
    setScrollLeft(el.scrollLeft);
    setViewportH(el.clientHeight);
    setViewportW(el.clientWidth);
    el.addEventListener('scroll', onScroll, { passive: true });
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(onResize) : null;
    ro?.observe(el);
    window.addEventListener('resize', onResize);
    return () => {
      el.removeEventListener('scroll', onScroll);
      if (rafId) cancelAnimationFrame(rafId);
      ro?.disconnect();
      window.removeEventListener('resize', onResize);
    };
  }, [getScrollElement]);

  const getTotalSize = useCallback(() => count * rowHeight, [count, rowHeight]);

  const getVirtualItems = useCallback((): VirtualItem[] => {
    if (count === 0 || rowHeight <= 0) return [];
    const vh = viewportH > 0 ? viewportH : 600;
    const startIdx = Math.max(0, Math.floor(scrollTop / rowHeight) - overscan);
    const endIdx = Math.min(count - 1, Math.ceil((scrollTop + vh) / rowHeight) + overscan);
    const out: VirtualItem[] = [];
    for (let i = startIdx; i <= endIdx; i++) {
      out.push({
        key: getItemKey ? getItemKey(i) : i,
        index: i,
        start: i * rowHeight,
        size: rowHeight,
      });
    }
    return out;
  }, [count, rowHeight, overscan, scrollTop, viewportH, getItemKey]);

  return { getTotalSize, getVirtualItems, scrollLeft, viewportW };
}

interface Props {
  structure: SheetStructure;
  executionItems?: SheetExecutionItem[];
  checkedMap?: Map<string, boolean>;
  checkedAtMap?: Map<string, string>;
  columnRoles?: ColumnRoleMapping | null;
  onCheckChange?: (cellRef: string, checked: boolean) => void;
  valueMap?: Map<string, string>;
  onValueChange?: (cellRef: string, value: string) => void;
  onStatusChange?: (cellRef: string, status: StatusValue, rowIdx: number, colIdx: number) => void;
  readOnly?: boolean;
  templatePreview?: boolean;
  hiddenCols?: number[];
  onDeleteColumn?: (colIdx: number) => void;
  hiddenRows?: number[];
  onDeleteRow?: (rowIdx: number) => void;
  freeTextEdit?: boolean;
  addedColumns?: AddedColumn[];
  renamedHeaders?: Record<string, string>;
  onRenameHeader?: (colIdx: number, newHeader: string) => void;
  onDeleteAddedColumn?: (colIdx: number) => void;
  addedRows?: AddedRow[];
  onDeleteAddedRow?: (rowIdx: number) => void;
  addedColumnsOrder?: number[];
  addedRowsOrder?: number[];
  onReorderAddedColumns?: (newOrder: number[]) => void;
  onReorderAddedRows?: (newOrder: number[]) => void;
  columnOrder?: number[];
  rowOrder?: number[];
  onReorderColumns?: (newOrder: number[]) => void;
  onReorderRows?: (newOrder: number[]) => void;
  searchQuery?: string;
}

const ROW_HEIGHT = 32;
const MIN_COL_WIDTH = 24;
const OVERSCAN = 20;
const COL_OVERSCAN = 6;
// 가상화 경계 바깥에서 시작하지만 콘텐츠가 visible 영역으로 확장되는 colSpan 셀을
// 놓치지 않기 위한 lookback. 일반적으로 colSpan 은 매우 크지 않음.
const MAX_COLSPAN_LOOKBACK = 24;

function borderStyle(style?: string): string {
  if (!style) return 'none';
  if (style === 'thin') return '1px solid #D1D5DB';
  if (style === 'medium') return '2px solid #9CA3AF';
  if (style === 'thick') return '3px solid #4B5563';
  if (style === 'dashed') return '1px dashed #D1D5DB';
  if (style === 'dotted') return '1px dotted #D1D5DB';
  return '1px solid #D1D5DB';
}

function colLabelOf(col: number): string {
  let s = '';
  let n = col + 1;
  while (n > 0) {
    n--;
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26);
  }
  return s;
}

// 상태 매핑 (status select)에서 raw 값 -> StatusValue 변환. 기존 SheetRenderer 와 동일한 매핑 유지.
function mapRawToStatus(raw: string): StatusValue {
  const upper = raw.toUpperCase().replace(/\s/g, '');
  if (upper === 'O' || upper === '○' || upper === '●' || upper === '완료' || upper === 'OK' || upper === 'PASS' || upper === '양호' || upper === '정상') return 'O';
  if (upper === 'X' || upper === '×' || upper === '미완료' || upper === 'NG' || upper === 'FAIL' || upper === '불량' || upper === '이상') return 'X';
  if (upper === 'N/A' || upper === 'NA' || upper === '해당없음') return 'N/A';
  if ((STATUS_OPTIONS as readonly string[]).includes(raw)) return raw as StatusValue;
  return '';
}

// React.memo 본문 셀 — props 가 동일하면 재렌더 skip. 스크롤/편집 시 영향 없는 셀이 그대로 유지된다.
type BodyCellProps = {
  cellRef: string;
  rowIdx: number;
  colIdx: number;
  width: number;
  sticky: boolean;
  cell: SheetCell | undefined;
  cellValue: string;
  rowSpanLabel: string | undefined;
  isCheckable: boolean;
  isStatusCell: boolean;
  isCheckedAtCol: boolean;
  rowCheckedAt: string | undefined;
  isChecked: boolean;
  execMemo: string | undefined;
  editorType: 'text' | 'date' | null;
  isEditableHoverable: boolean;
  readOnly: boolean | undefined;
  onCheckChange?: (cellRef: string, checked: boolean) => void;
  onValueChange?: (cellRef: string, value: string) => void;
  onStatusChange?: (cellRef: string, status: StatusValue, rowIdx: number, colIdx: number) => void;
  onEditStart: (cellRef: string, rowIdx: number) => void;
  onEditCancel: () => void;
  images?: any[];
  onImageClick?: (url: string) => void;
};

const BodyCell = React.memo(function BodyCell({
  cellRef, rowIdx, colIdx, width, sticky, cell,
  cellValue, rowSpanLabel,
  isCheckable, isStatusCell, isCheckedAtCol, rowCheckedAt,
  isChecked, execMemo,
  editorType, isEditableHoverable, readOnly,
  onCheckChange, onValueChange, onStatusChange, onEditStart, onEditCancel,
  images, onImageClick,
}: BodyCellProps) {
  const cellBg = cell?.bg;
  // sticky 첫 컬럼은 transparent 면 뒤 행이 비치므로 #fff 강제. 셀 자체 배경이 있으면 그대로 사용.
  const bg = sticky && (!cellBg || cellBg === 'transparent') ? '#fff' : (cellBg || 'transparent');
  const font = cell?.font;
  const borders = cell?.borders;
  const fontSizePx = font?.fontSize ? Math.round(font.fontSize * 1.33) : 12;

  const cellStyle: React.CSSProperties = {
    width,
    minWidth: width,
    maxWidth: width,
    height: ROW_HEIGHT,
    padding: '2px 4px',
    backgroundColor: bg,
    borderRight: borderStyle(borders?.right || 'thin'),
    borderBottom: borderStyle(borders?.bottom || 'thin'),
    borderLeft: colIdx === 0 ? borderStyle(borders?.left || 'thick') : undefined,
    display: 'flex',
    alignItems: 'center',
    justifyContent: (cell?.align === 'center') ? 'center' : (cell?.align === 'right' ? 'flex-end' : 'flex-start'),
    cursor: isEditableHoverable ? 'text' : 'default',
    overflow: editorType ? 'visible' : 'hidden',
    position: sticky ? 'sticky' : (editorType ? 'relative' : undefined),
    left: sticky ? 0 : undefined,
    zIndex: sticky ? 5 : (editorType ? 4 : undefined),
    boxSizing: 'border-box',
    boxShadow: sticky ? 'inset -1px 0 0 #E5E7EB, 2px 0 4px -2px rgba(0,0,0,0.06)' : undefined,
    flexShrink: 0,
  };

  const handleClick = () => {
    if (isEditableHoverable && !readOnly) onEditStart(cellRef, rowIdx);
  };

  let content: React.ReactNode;
  if (editorType) {
    content = (
      <InlineCellEditor
        initialValue={cellValue}
        editorType={editorType}
        fontSizePx={fontSizePx}
        bold={font?.bold}
        fontColor={font?.fontColor}
        align={cell?.align}
        onCommit={(v) => { onValueChange?.(cellRef, v); onEditCancel(); }}
        onCancel={onEditCancel}
      />
    );
  } else if (isStatusCell) {
    const current = mapRawToStatus(cellValue.trim());
    const color = current === 'O' ? '#16A34A' : current === 'X' ? '#DC2626' : current === 'N/A' ? '#9CA3AF' : '#6B7280';
    content = (
      <Select
        size="small"
        value={current}
        disabled={readOnly}
        onChange={(e) => onStatusChange?.(cellRef, e.target.value as StatusValue, rowIdx, colIdx)}
        variant="standard"
        disableUnderline
        displayEmpty
        renderValue={(v) => (
          <Box component="span" sx={{
            fontSize: `${Math.max(fontSizePx, 12)}px`,
            fontWeight: 700, color,
            opacity: current === 'N/A' ? 0.7 : 1,
          }}>
            {statusLabel(v as StatusValue) || '—'}
          </Box>
        )}
        sx={{
          width: '100%',
          border: readOnly ? 'none' : '1px solid #E5E7EB',
          borderRadius: '6px',
          bgcolor: readOnly ? 'transparent' : '#FAFAFA',
          '& .MuiSelect-select': { p: '3px 22px 3px 8px !important', textAlign: 'center', minHeight: 'unset' },
          '& .MuiSelect-icon': { color: '#6B7280', right: 4, fontSize: 16 },
        }}
        MenuProps={{ PaperProps: { sx: { mt: 0.5 } } }}
      >
        <MenuItem value=""><em style={{ color: '#9CA3AF' }}>— 선택</em></MenuItem>
        <MenuItem value="O" sx={{ fontWeight: 700, color: '#16A34A' }}>진행</MenuItem>
        <MenuItem value="X" sx={{ fontWeight: 700, color: '#DC2626' }}>미진행</MenuItem>
        <MenuItem value="N/A" sx={{ fontWeight: 700, color: '#9CA3AF' }}>N/A</MenuItem>
      </Select>
    );
  } else if (isCheckable) {
    content = (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, width: '100%', justifyContent: cell?.align === 'center' ? 'center' : 'flex-start' }}>
        <Tooltip title={execMemo || ''} placement="top" arrow>
          <span>
            <Checkbox
              size="small"
              checked={isChecked}
              disabled={readOnly}
              onChange={(e) => onCheckChange?.(cellRef, e.target.checked)}
              sx={{
                p: 0, '& .MuiSvgIcon-root': { fontSize: 18 },
                color: isChecked ? '#22C55E' : '#D1D5DB',
                '&.Mui-checked': { color: '#22C55E' },
              }}
            />
          </span>
        </Tooltip>
      </Box>
    );
  } else if (isCheckedAtCol && rowCheckedAt) {
    content = (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.3, width: '100%' }}>
        <AccessTimeIcon sx={{ fontSize: 12, color: '#2955FF', flexShrink: 0 }} />
        <Typography variant="caption" sx={{ fontSize: '11px', color: '#2955FF', fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {formatCheckedAt(rowCheckedAt)}
        </Typography>
      </Box>
    );
  } else if (!cellValue && rowSpanLabel) {
    // rowSpan 그룹 비-origin 행: origin 라벨을 약한 opacity 로 표시 (사용자가 그룹 컨텍스트 잃지 않도록)
    content = (
      <Typography
        variant="body2"
        sx={{
          fontSize: `${fontSizePx}px`,
          fontWeight: 500,
          color: font?.fontColor || '#9CA3AF',
          opacity: 0.5,
          fontStyle: 'italic',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          width: '100%',
          textAlign: (cell?.align as any) || 'left',
        }}
        title={`그룹: ${rowSpanLabel}`}
      >
        {rowSpanLabel}
      </Typography>
    );
  } else {
    content = (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, width: '100%', overflow: 'hidden' }}>
        <Typography
          variant="body2"
          sx={{
            fontSize: `${fontSizePx}px`,
            fontWeight: font?.bold ? 700 : 400,
            fontStyle: font?.italic ? 'italic' : 'normal',
            color: font?.fontColor || '#111827',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            flex: 1,
            textAlign: (cell?.align as any) || 'left',
          }}
          title={cellValue.length > 20 ? cellValue : undefined}
        >
          {cellValue}
        </Typography>
        {images && images.length > 0 && (
          <Box sx={{ display: 'flex', gap: '2px', flexShrink: 0 }}>
            {images.map((img, i) => (
              <img
                key={i}
                src={img.thumbnail_url}
                alt="img"
                style={{ height: 24, cursor: 'pointer', border: '1px solid #ccc', borderRadius: 2 }}
                onClick={(e) => {
                  e.stopPropagation();
                  onImageClick?.(img.original_url || img.thumbnail_url);
                }}
              />
            ))}
          </Box>
        )}
      </Box>
    );
  }

  return (
    <div style={cellStyle} onClick={handleClick}>
      {content}
    </div>
  );
});

export default function VirtualizedSheetRenderer({
  structure, executionItems,
  checkedMap: propCheckedMap,
  checkedAtMap: propCheckedAtMap,
  valueMap: propValueMap,
  columnRoles,
  onCheckChange, onValueChange, onStatusChange, readOnly,
  templatePreview,
  hiddenCols, onDeleteColumn, hiddenRows, onDeleteRow, freeTextEdit,
  addedColumns, renamedHeaders, onRenameHeader, onDeleteAddedColumn,
  addedRows, onDeleteAddedRow,
  addedColumnsOrder, addedRowsOrder,
  columnOrder, rowOrder,
}: Props) {
  const { cells = [], merges = [], col_widths = [], total_rows = 0, total_cols = 0, checkable_cells = [] } = structure || {};

  const effectiveRoles: ColumnRoleMapping | null | undefined = columnRoles ?? (structure as any).column_roles;
  const headerRowIdx = (structure as any).header_row_idx ?? 0;

  const cellMap = useMemo(() => {
    const map = new Map<string, SheetCell>();
    for (const cell of cells) map.set(`${cell.row}-${cell.col}`, cell);
    return map;
  }, [cells]);

  const checkableSet = useMemo(() => {
    const set = new Set<string>();
    for (const c of (checkable_cells || [])) set.add(`${c.row}-${c.col}`);
    return set;
  }, [checkable_cells]);

  const execItemMap = useMemo(() => {
    const map = new Map<string, SheetExecutionItem>();
    for (const item of (executionItems || [])) map.set(`${item.row_idx}-${item.col_idx}`, item);
    return map;
  }, [executionItems]);

  const checkedMap = useMemo<Map<string, boolean>>(() => {
    if (propCheckedMap && propCheckedMap.size > 0) return propCheckedMap;
    const map = new Map<string, boolean>();
    if (executionItems) for (const item of executionItems) map.set(item.cell_ref, item.checked);
    return map;
  }, [propCheckedMap, executionItems]);

  const checkedAtMap = useMemo<Map<string, string>>(() => {
    if (propCheckedAtMap && propCheckedAtMap.size > 0) return propCheckedAtMap;
    const map = new Map<string, string>();
    if (executionItems) for (const item of executionItems) if (item.checked_at) map.set(item.cell_ref, item.checked_at);
    return map;
  }, [propCheckedAtMap, executionItems]);

  const valueMap = useMemo<Map<string, string>>(() => {
    if (propValueMap) return propValueMap;
    const map = new Map<string, string>();
    if (executionItems) for (const item of executionItems) if (item.value) map.set(item.cell_ref, item.value);
    return map;
  }, [propValueMap, executionItems]);

  const checkedAtCol = effectiveRoles?.checked_at?.col ?? -1;
  const statusCol = effectiveRoles?.check_status?.col ?? -1;

  const editableCols = useMemo(() => {
    const map = new Map<number, string>();
    if (effectiveRoles && !readOnly) {
      if (effectiveRoles.assignee?.col !== undefined) map.set(effectiveRoles.assignee.col, effectiveRoles.assignee.editor_type || 'text');
      if (effectiveRoles.due_date?.col !== undefined) map.set(effectiveRoles.due_date.col, effectiveRoles.due_date.editor_type || 'date');
      if (effectiveRoles.planned_date?.col !== undefined) map.set(effectiveRoles.planned_date.col, effectiveRoles.planned_date.editor_type || 'date');
      if (effectiveRoles.progress_date?.col !== undefined) map.set(effectiveRoles.progress_date.col, effectiveRoles.progress_date.editor_type || 'date');
      if (effectiveRoles.remark?.col !== undefined) map.set(effectiveRoles.remark.col, effectiveRoles.remark.editor_type || 'text');
      if (effectiveRoles.cycle?.col !== undefined) map.set(effectiveRoles.cycle.col, effectiveRoles.cycle.editor_type || 'text');
    }
    return map;
  }, [effectiveRoles, readOnly]);

  const [editingCell, setEditingCell] = useState<string | null>(null);
  const [editingHeaderCol, setEditingHeaderCol] = useState<number | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const imagesByCell = useMemo(() => {
    const map = new Map<string, any[]>();
    if (!structure || !(structure as any).images) return map;
    (structure as any).images.forEach((img: any) => {
      const key = `${img.row}-${img.col}`;
      const arr = map.get(key) || [];
      arr.push(img);
      map.set(key, arr);
    });
    return map;
  }, [structure]);

  const addedColsList = useMemo<AddedColumn[]>(
    () => (addedColumns ?? []).slice().sort((a, b) => a.col_idx - b.col_idx),
    [addedColumns],
  );
  const addedColByIdx = useMemo(() => {
    const m = new Map<number, AddedColumn>();
    addedColsList.forEach((c) => m.set(c.col_idx, c));
    return m;
  }, [addedColsList]);
  const renamedMap = useMemo(() => renamedHeaders ?? {}, [renamedHeaders]);

  const effectiveHeaderText = useCallback((colIdx: number, fallback: string): string => {
    const r = renamedMap[String(colIdx)];
    if (r !== undefined) return r;
    const added = addedColByIdx.get(colIdx);
    if (added) return added.header;
    return fallback;
  }, [addedColByIdx, renamedMap]);

  const hiddenColSet = useMemo(() => new Set<number>(hiddenCols || []), [hiddenCols]);
  const hiddenRowSet = useMemo(() => new Set<number>(hiddenRows || []), [hiddenRows]);

  // Header 영역 (rowIdx <= headerRowIdx) 만 rowSpan/colSpan 모두 지원.
  // 본문 영역에서는 colSpan 은 그대로, rowSpan 은 시각적 컨텍스트만 유지 (origin row 의 값을
  // 비-origin row 에 약한 opacity 로 표시 — bodyRowSpanLabelAt 에 저장).
  const { headerHiddenCells, headerMergeAt, bodyHiddenCells, bodyMergeAt, bodyRowSpanLabelAt } = useMemo(() => {
    const hHidden = new Set<string>();
    const hMerge = new Map<string, { rowSpan: number; colSpan: number }>();
    const bHidden = new Set<string>();
    const bMerge = new Map<string, { rowSpan: number; colSpan: number }>();
    // (row, firstVisibleCol) -> origin 셀의 표시 텍스트 (비-origin 행에서 약한 opacity 로 보여줄 라벨)
    const bRowSpanLabel = new Map<string, string>();
    for (const merge of (merges || [])) {
      const isHeaderMerge = merge.endRow <= headerRowIdx;
      let visibleRowCount = 0;
      let firstVisibleRow = -1;
      for (let r = merge.startRow; r <= merge.endRow; r++) {
        if (!hiddenRowSet.has(r)) {
          visibleRowCount++;
          if (firstVisibleRow < 0) firstVisibleRow = r;
        }
      }
      let visibleColCount = 0;
      let firstVisibleCol = -1;
      for (let c = merge.startCol; c <= merge.endCol; c++) {
        if (!hiddenColSet.has(c)) {
          visibleColCount++;
          if (firstVisibleCol < 0) firstVisibleCol = c;
        }
      }
      if (visibleRowCount === 0 || visibleColCount === 0 || firstVisibleRow < 0 || firstVisibleCol < 0) {
        for (let r = merge.startRow; r <= merge.endRow; r++) {
          for (let c = merge.startCol; c <= merge.endCol; c++) {
            if (isHeaderMerge) hHidden.add(`${r}-${c}`);
            else bHidden.add(`${r}-${c}`);
          }
        }
        continue;
      }
      if (isHeaderMerge) {
        hMerge.set(`${firstVisibleRow}-${firstVisibleCol}`, { rowSpan: visibleRowCount, colSpan: visibleColCount });
        for (let r = merge.startRow; r <= merge.endRow; r++) {
          for (let c = merge.startCol; c <= merge.endCol; c++) {
            if (r === firstVisibleRow && c === firstVisibleCol) continue;
            hHidden.add(`${r}-${c}`);
          }
        }
      } else {
        // 본문: rowSpan 은 origin row 외에서도 group 라벨을 약하게 표시하기 위해 origin 값을 캐시.
        // colSpan 은 각 행마다 첫 가시 col 를 origin 으로 두고 width 를 확장.
        const isRowSpan = visibleRowCount > 1;
        let originLabel = '';
        if (isRowSpan) {
          // origin row 의 첫 가시 col 값을 origin 셀에서 읽음 (cells map 의 startRow/startCol).
          const originCell = cells.find((c) => c.row === merge.startRow && c.col === merge.startCol);
          originLabel = String(originCell?.value ?? '');
        }
        for (let r = merge.startRow; r <= merge.endRow; r++) {
          if (hiddenRowSet.has(r)) continue;
          let firstColInRow = -1;
          for (let c = merge.startCol; c <= merge.endCol; c++) {
            if (hiddenColSet.has(c)) continue;
            if (firstColInRow < 0) {
              firstColInRow = c;
            } else {
              bHidden.add(`${r}-${c}`);
            }
          }
          if (firstColInRow >= 0 && visibleColCount > 1) {
            bMerge.set(`${r}-${firstColInRow}`, { rowSpan: 1, colSpan: visibleColCount });
          }
          // 비-origin 행에 group 라벨 표시 (origin 셀이 없는 셀이라 cellMap.get 으로는 빈 값)
          if (isRowSpan && r !== firstVisibleRow && firstColInRow >= 0 && originLabel) {
            bRowSpanLabel.set(`${r}-${firstColInRow}`, originLabel);
          }
        }
      }
    }
    return { headerHiddenCells: hHidden, headerMergeAt: hMerge, bodyHiddenCells: bHidden, bodyMergeAt: bMerge, bodyRowSpanLabelAt: bRowSpanLabel };
  }, [merges, hiddenColSet, hiddenRowSet, headerRowIdx, cells]);

  const extendedColCount = useMemo(() => {
    let max = total_cols;
    addedColsList.forEach((c) => { if (c.col_idx + 1 > max) max = c.col_idx + 1; });
    return max;
  }, [total_cols, addedColsList]);

  const colWidths = useMemo(() => {
    const widths: number[] = [];
    for (let c = 0; c < extendedColCount; c++) {
      if (c < total_cols) {
        const w = col_widths?.[c] || 8.43;
        widths.push(Math.max(MIN_COL_WIDTH, Math.round(w * 7.5)));
      } else {
        widths.push(110);
      }
    }
    return widths;
  }, [col_widths, total_cols, extendedColCount]);

  const orderedAddedColIdxs = useMemo<number[]>(() => {
    const valid = new Set<number>(addedColsList.map((c) => c.col_idx));
    const seen = new Set<number>();
    const out: number[] = [];
    if (addedColumnsOrder) {
      for (const v of addedColumnsOrder) {
        if (valid.has(v) && !seen.has(v)) { seen.add(v); out.push(v); }
      }
    }
    addedColsList.forEach((c) => {
      if (!seen.has(c.col_idx)) { seen.add(c.col_idx); out.push(c.col_idx); }
    });
    return out;
  }, [addedColsList, addedColumnsOrder]);

  const colIdxList = useMemo<number[]>(() => {
    const addedSet = new Set<number>(addedColsList.map((c) => c.col_idx));
    const seen = new Set<number>();
    const out: number[] = [];
    if (columnOrder && columnOrder.length > 0) {
      for (const v of columnOrder) {
        const isBase = v >= 0 && v < total_cols;
        if (!isBase && !addedSet.has(v)) continue;
        if (seen.has(v)) continue;
        seen.add(v); out.push(v);
      }
      for (let c = 0; c < total_cols; c++) {
        if (!seen.has(c)) { seen.add(c); out.push(c); }
      }
      orderedAddedColIdxs.forEach((c) => {
        if (!seen.has(c)) { seen.add(c); out.push(c); }
      });
      return out;
    }
    for (let c = 0; c < total_cols; c++) out.push(c);
    orderedAddedColIdxs.forEach((c) => out.push(c));
    return out;
  }, [total_cols, orderedAddedColIdxs, addedColsList, columnOrder]);

  const visibleColIdxList = useMemo(() => colIdxList.filter((c) => !hiddenColSet.has(c)), [colIdxList, hiddenColSet]);

  const addedRowsList = useMemo<AddedRow[]>(
    () => (addedRows ?? []).slice().sort((a, b) => a.row_idx - b.row_idx),
    [addedRows],
  );
  const addedRowSet = useMemo(() => {
    const s = new Set<number>();
    addedRowsList.forEach((r) => s.add(r.row_idx));
    return s;
  }, [addedRowsList]);

  const orderedAddedRowIdxs = useMemo<number[]>(() => {
    const valid = new Set<number>(addedRowsList.map((r) => r.row_idx));
    const seen = new Set<number>();
    const out: number[] = [];
    if (addedRowsOrder) {
      for (const v of addedRowsOrder) {
        if (valid.has(v) && !seen.has(v)) { seen.add(v); out.push(v); }
      }
    }
    addedRowsList.forEach((r) => {
      if (!seen.has(r.row_idx)) { seen.add(r.row_idx); out.push(r.row_idx); }
    });
    return out;
  }, [addedRowsList, addedRowsOrder]);

  const rowIdxList = useMemo<number[]>(() => {
    const addedSet = new Set<number>(addedRowsList.map((r) => r.row_idx));
    const seen = new Set<number>();
    const out: number[] = [];
    if (rowOrder && rowOrder.length > 0) {
      for (const v of rowOrder) {
        const isBase = v >= 0 && v < total_rows;
        if (!isBase && !addedSet.has(v)) continue;
        if (seen.has(v)) continue;
        seen.add(v); out.push(v);
      }
      for (let r = 0; r < total_rows; r++) {
        if (!seen.has(r)) { seen.add(r); out.push(r); }
      }
      orderedAddedRowIdxs.forEach((r) => {
        if (!seen.has(r)) { seen.add(r); out.push(r); }
      });
      return out;
    }
    for (let r = 0; r < total_rows; r++) out.push(r);
    orderedAddedRowIdxs.forEach((r) => out.push(r));
    return out;
  }, [total_rows, orderedAddedRowIdxs, addedRowsList, rowOrder]);

  // 헤더 행과 본문 행 분리. 헤더는 sticky 별도 table, 본문은 가상화.
  const headerRowIdxList = useMemo(() => rowIdxList.filter((r) => r <= headerRowIdx && !hiddenRowSet.has(r)), [rowIdxList, headerRowIdx, hiddenRowSet]);
  const bodyRowIdxList = useMemo(() => rowIdxList.filter((r) => r > headerRowIdx && !hiddenRowSet.has(r)), [rowIdxList, headerRowIdx, hiddenRowSet]);

  // 행 삭제 버튼은 본 가상화 렌더러 v1 에선 노출하지 않는다 (자주 쓰이지 않으며,
  // 가상 위치 위에 hover 버튼을 띄우는 것은 UX 가 어색하다). 대용량 시트에서 행 삭제가
  // 필요하면 SheetRenderer 모드(임계값 미만)에서 처리한다. props 는 그대로 받아 API 일관성만 유지.
  void onDeleteRow;
  void onDeleteAddedRow;

  const protectedColSet = useMemo(() => {
    const s = new Set<number>();
    if (effectiveRoles) {
      for (const key of ['check_status'] as const) {
        const col = effectiveRoles[key]?.col;
        if (typeof col === 'number' && col >= 0) s.add(col);
      }
    }
    return s;
  }, [effectiveRoles]);

  const totalWidth = useMemo(
    () => visibleColIdxList.reduce((sum, c) => sum + (colWidths[c] ?? 110), 0),
    [visibleColIdxList, colWidths],
  );

  // Column virtualization 셋업.
  // 첫 번째 가시 컬럼은 sticky-left 로 항상 보이게 두고, 나머지(restCols)만 가상화한다.
  const firstColIdx = visibleColIdxList.length > 0 ? visibleColIdxList[0] : -1;
  const firstColWidth = firstColIdx >= 0 ? (colWidths[firstColIdx] ?? 110) : 0;
  const restCols = useMemo(() => visibleColIdxList.slice(1), [visibleColIdxList]);
  // restCols 누적 prefix sum (rest col 시작 기준 좌측 offset)
  const restColOffsets = useMemo(() => {
    const offs: number[] = [0];
    for (const c of restCols) offs.push(offs[offs.length - 1] + (colWidths[c] ?? 110));
    return offs;
  }, [restCols, colWidths]);

  const getCellRef = useCallback((row: number, col: number): string => {
    const c = (checkable_cells || []).find(cc => cc.row === row && cc.col === col);
    if (c?.ref) return c.ref;
    return `${colLabelOf(col)}${row + 1}`;
  }, [checkable_cells]);

  const getRowCheckedAt = useCallback((rowIdx: number): string | undefined => {
    for (const c of (checkable_cells || [])) {
      if (c.row === rowIdx) {
        const at = checkedAtMap.get(c.ref);
        if (at) return at;
      }
    }
    return undefined;
  }, [checkable_cells, checkedAtMap]);

  // 가상화 — body 행만 대상으로. 행 높이는 고정 32px.
  const scrollParentRef = useRef<HTMLDivElement | null>(null);
  const rowVirtualizer = useFixedRowVirtualizer({
    count: bodyRowIdxList.length,
    rowHeight: ROW_HEIGHT,
    overscan: OVERSCAN,
    getScrollElement: () => scrollParentRef.current,
    getItemKey: (i) => bodyRowIdxList[i] ?? i,
  });

  // 편집 중인 셀이 viewport 밖으로 나가면 자동 commit (cancel) — 메모리/UX 모두 안전.
  const editingCellRef = useRef<string | null>(null);
  useEffect(() => { editingCellRef.current = editingCell; }, [editingCell]);
  const editingRowIdxRef = useRef<number | null>(null);
  const handleEditStart = useCallback((cellRef: string, rowIdx: number) => {
    editingRowIdxRef.current = rowIdx;
    setEditingCell(cellRef);
  }, []);
  const handleEditCancel = useCallback(() => {
    setEditingCell(null);
    editingRowIdxRef.current = null;
  }, []);
  const virtualItems = rowVirtualizer.getVirtualItems();
  useLayoutEffect(() => {
    const er = editingRowIdxRef.current;
    if (er === null || editingCellRef.current === null) return;
    const visible = virtualItems.some((v) => bodyRowIdxList[v.index] === er);
    if (!visible) {
      // viewport 밖 — 편집 취소 (값은 InlineCellEditor 내부에서 onBlur 로 commit 되도록 setState 만 닫음)
      setEditingCell(null);
      editingRowIdxRef.current = null;
    }
  }, [virtualItems, bodyRowIdxList]);

  // Column virtualization 가시 범위 계산 — 가로 scroll 위치/뷰포트 너비 기반.
  // 첫 sticky 컬럼은 별도 처리하므로 restCols(visibleColIdxList[1..]) 만 대상으로 한다.
  const { scrollLeft, viewportW } = rowVirtualizer;
  const colRange = useMemo(() => {
    const n = restCols.length;
    if (n === 0) {
      return { renderStart: 0, renderEnd: -1, bodyRenderStart: 0, leftSpacerW: 0, rightSpacerW: 0 };
    }
    const vw = viewportW > 0 ? viewportW : 1000;
    // sticky 첫 컬럼이 viewport 좌측 firstColWidth 만큼 가리므로, rest 의 effective viewport 는
    // 그만큼 줄어든다. rest col i 의 자연 위치는 restColOffsets[i] (= 0 부터 시작).
    // viewport 에서 rest 영역으로 보이는 범위: [scrollLeft, scrollLeft + vw - firstColWidth]
    const visLeft = scrollLeft;
    const visRight = scrollLeft + Math.max(0, vw - firstColWidth);

    // visStart: 우측 edge 가 visLeft 보다 큰 첫 i (binary search)
    let visStart = 0;
    {
      let lo = 0, hi = n - 1;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (restColOffsets[mid + 1] <= visLeft) lo = mid + 1; else hi = mid;
      }
      visStart = lo;
    }
    // visEnd: 좌측 edge 가 visRight 보다 작은 마지막 i (binary search)
    let visEnd = n - 1;
    {
      let lo = 0, hi = n - 1;
      while (lo < hi) {
        const mid = (lo + hi + 1) >> 1;
        if (restColOffsets[mid] >= visRight) hi = mid - 1; else lo = mid;
      }
      visEnd = lo;
    }
    const renderStart = Math.max(0, visStart - COL_OVERSCAN);
    const renderEnd = Math.min(n - 1, visEnd + COL_OVERSCAN);
    // 가상화 경계 바깥의 colSpan origin 이 viewport 로 확장되는 경우를 위한 lookback
    const bodyRenderStart = Math.max(0, renderStart - MAX_COLSPAN_LOOKBACK);
    const leftSpacerW = restColOffsets[bodyRenderStart] ?? 0;
    const rightSpacerW = Math.max(0, (restColOffsets[n] ?? 0) - (restColOffsets[renderEnd + 1] ?? 0));
    return { renderStart, renderEnd, bodyRenderStart, leftSpacerW, rightSpacerW };
  }, [scrollLeft, viewportW, restColOffsets, restCols.length, firstColWidth]);

  return (
    <Box sx={{ overflow: 'hidden', border: '1px solid #E5E7EB', borderRadius: 1, bgcolor: '#f3f4f6', p: 2, height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column' }}>
      <Box
        ref={scrollParentRef}
        sx={{
          flex: 1,
          minHeight: 0,
          overflow: 'auto',
          // 단일 스크롤 컨테이너 — 가로/세로 모두 여기서 스크롤됨. 부모가 height 를 주면 fill, 안주면 viewport 기반 maxHeight 사용.
          maxHeight: 'calc(100vh - 220px)',
          position: 'relative',
          bgcolor: '#fff',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          fontFamily: '"Pretendard", "Noto Sans KR", sans-serif',
          // 스크롤바 가시성 향상
          '&::-webkit-scrollbar': { width: 10, height: 10 },
          '&::-webkit-scrollbar-track': { bgcolor: '#F3F4F6' },
          '&::-webkit-scrollbar-thumb': { bgcolor: '#D1D5DB', borderRadius: 5 },
          '&::-webkit-scrollbar-thumb:hover': { bgcolor: '#9CA3AF' },
        }}
      >
          {/* Sticky Header — 세로 sticky, 가로는 body 와 함께 이동 (width: totalWidth). */}
          <Box sx={{ position: 'sticky', top: 0, zIndex: 10, bgcolor: '#fff', width: totalWidth }}>
            <table
              style={{
                borderCollapse: 'collapse',
                tableLayout: 'fixed',
                width: totalWidth,
                margin: 0,
              }}
            >
              <colgroup>
                {visibleColIdxList.map((c) => {
                  const w = colWidths[c] ?? 110;
                  return <col key={c} style={{ width: w, minWidth: w, maxWidth: w }} />;
                })}
              </colgroup>
              <tbody>
                {headerRowIdxList.map((rowIdx) => (
                  <tr key={rowIdx}>
                    {visibleColIdxList.map((colIdx) => {
                      const key = `${rowIdx}-${colIdx}`;
                      if (headerHiddenCells.has(key)) return null;
                      const cell = cellMap.get(key);
                      const merge = headerMergeAt.get(key);
                      const rowSpan = merge?.rowSpan ?? cell?.rowSpan ?? 1;
                      const colSpan = merge?.colSpan ?? cell?.colSpan ?? 1;
                      const bg = cell?.bg || '#F9FAFB';
                      const font = cell?.font;
                      const borders = cell?.borders;
                      const fontSizePx = font?.fontSize ? Math.round(font.fontSize * 1.33) : 12;

                      const isAddedCol = colIdx >= total_cols || addedColByIdx.has(colIdx);
                      const cellValue = effectiveHeaderText(colIdx, String(cell?.value ?? ''));

                      const canRenameHeader = !readOnly && !templatePreview && rowIdx === headerRowIdx
                        && (isAddedCol || (!!onRenameHeader && !protectedColSet.has(colIdx)));
                      const isHeaderEditing = canRenameHeader && editingHeaderCol === colIdx;

                      const showDeleteBtn = rowIdx === headerRowIdx && !readOnly && !templatePreview && !isHeaderEditing && (
                        isAddedCol ? !!onDeleteAddedColumn : (!!onDeleteColumn && !protectedColSet.has(colIdx))
                      );
                      const onHeaderDeleteClick = () => {
                        if (isAddedCol) onDeleteAddedColumn?.(colIdx);
                        else onDeleteColumn?.(colIdx);
                      };

                      // 첫 번째 가시 컬럼은 header 에서도 sticky-left 처리 → 가로 스크롤 시 corner 고정.
                      const isFirstCol = colIdx === firstColIdx;
                      const tdStyle: React.CSSProperties = {
                        padding: '2px 4px',
                        backgroundColor: bg,
                        borderRight: borderStyle(borders?.right || 'thin'),
                        borderBottom: borderStyle(borders?.bottom || 'thin'),
                        borderLeft: colIdx === 0 ? borderStyle(borders?.left || 'thick') : undefined,
                        borderTop: rowIdx === 0 ? borderStyle(borders?.top || 'thick') : undefined,
                        verticalAlign: 'middle',
                        textAlign: (cell?.align as any) || 'center',
                        wordBreak: 'break-word',
                        overflowWrap: 'anywhere',
                        position: isFirstCol ? 'sticky' : (showDeleteBtn ? 'relative' : undefined),
                        left: isFirstCol ? 0 : undefined,
                        zIndex: isFirstCol ? 11 : undefined,
                        height: 'inherit',
                        fontWeight: font?.bold ? 700 : 600,
                        // sticky 첫 컬럼은 우측에 살짝 그림자로 분리감 (스크롤 중 가시성 향상)
                        boxShadow: isFirstCol ? 'inset -1px 0 0 #E5E7EB, 2px 0 4px -2px rgba(0,0,0,0.08)' : undefined,
                      };

                      return (
                        <td
                          key={key}
                          rowSpan={rowSpan}
                          colSpan={colSpan}
                          style={tdStyle}
                          onDoubleClick={canRenameHeader ? () => setEditingHeaderCol(colIdx) : undefined}
                          title={canRenameHeader && !isHeaderEditing ? '더블클릭으로 헤더 이름 변경' : undefined}
                        >
                          {isHeaderEditing ? (
                            <InlineCellEditor
                              initialValue={cellValue}
                              editorType="text"
                              fontSizePx={fontSizePx}
                              bold={font?.bold}
                              fontColor={font?.fontColor}
                              align={cell?.align}
                              onCommit={(v) => { onRenameHeader?.(colIdx, v); setEditingHeaderCol(null); }}
                              onCancel={() => setEditingHeaderCol(null)}
                            />
                          ) : (
                            <Typography
                              variant="body2"
                              sx={{
                                fontSize: `${fontSizePx}px`,
                                fontWeight: font?.bold ? 700 : 600,
                                color: font?.fontColor || '#111827',
                                whiteSpace: 'pre-wrap',
                                wordBreak: 'break-word',
                                overflowWrap: 'anywhere',
                                lineHeight: 1.35,
                                width: '100%',
                                textAlign: (cell?.align as any) || 'center',
                              }}
                            >
                              {cellValue}
                            </Typography>
                          )}
                          {showDeleteBtn && (
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); onHeaderDeleteClick(); }}
                              title={isAddedCol ? '추가 컬럼 삭제' : '이 컬럼 삭제'}
                              style={{
                                position: 'absolute', top: 1, right: 1,
                                width: 16, height: 16, padding: 0, border: 'none',
                                borderRadius: '50%', background: 'rgba(239, 68, 68, 0.85)',
                                color: '#fff', fontSize: 11, lineHeight: '14px', cursor: 'pointer',
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                opacity: 0.55, transition: 'opacity 0.15s',
                              }}
                              onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = '1'; }}
                              onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = '0.55'; }}
                            >×</button>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </Box>

          {/* Virtualized body — 행+열 가상화 + sticky 첫 컬럼 + memoized cell */}
          <Box sx={{ position: 'relative', height: rowVirtualizer.getTotalSize(), width: totalWidth }}>
            {virtualItems.map((virtualRow) => {
              const rowIdx = bodyRowIdxList[virtualRow.index];
              const isAddedRow = addedRowSet.has(rowIdx) || rowIdx >= total_rows;

              const renderCell = (colIdx: number, isSticky: boolean): React.ReactNode => {
                const key = `${rowIdx}-${colIdx}`;
                if (bodyHiddenCells.has(key)) return null;

                const isAddedCol = colIdx >= total_cols || addedColByIdx.has(colIdx);
                const cell = cellMap.get(key);
                const isCheckable = !templatePreview && checkableSet.has(key);
                const execItem = execItemMap.get(key);
                const isStatusCell = !templatePreview && !!onStatusChange && statusCol >= 0 && colIdx === statusCol;
                const merge = bodyMergeAt.get(key);
                const colSpan = merge?.colSpan ?? cell?.colSpan ?? 1;

                // 행 합계 폭(병합 고려) — flex 배치라 width 직접 계산.
                let cellWidth = colWidths[colIdx] ?? 110;
                if (colSpan > 1) {
                  const startIdxInVisible = visibleColIdxList.indexOf(colIdx);
                  cellWidth = 0;
                  for (let i = 0; i < colSpan && startIdxInVisible + i < visibleColIdxList.length; i++) {
                    const c = visibleColIdxList[startIdxInVisible + i];
                    cellWidth += (colWidths[c] ?? 110);
                  }
                }

                const isCheckedAtCol = !templatePreview && checkedAtCol >= 0 && colIdx === checkedAtCol;
                const rowCheckedAt = isCheckedAtCol ? getRowCheckedAt(rowIdx) : undefined;

                const cellRef = getCellRef(rowIdx, colIdx);
                const isChecked = checkedMap.get(cellRef) ?? execItem?.checked ?? false;
                const cellValue = String(valueMap.get(cellRef) ?? execItem?.value ?? cell?.value ?? '');

                const roleEditorType = editableCols.get(colIdx);
                const freeEditable = (!!freeTextEdit || (isAddedCol && !!onValueChange) || (isAddedRow && !!onValueChange))
                  && !readOnly
                  && !isCheckable && !isCheckedAtCol && !isStatusCell;
                const editorType = editingCell === cellRef
                  ? ((roleEditorType as 'text' | 'date' | undefined) || (freeEditable ? 'text' : null))
                  : null;
                const isEditableHoverable =
                  !isCheckable && !isCheckedAtCol && !isStatusCell
                  && (editableCols.has(colIdx) || freeEditable);

                const rowSpanLabel = bodyRowSpanLabelAt.get(key);

                return (
                  <BodyCell
                    key={key}
                    cellRef={cellRef}
                    rowIdx={rowIdx}
                    colIdx={colIdx}
                    width={cellWidth}
                    sticky={isSticky}
                    cell={cell}
                    cellValue={cellValue}
                    rowSpanLabel={rowSpanLabel}
                    isCheckable={isCheckable}
                    isStatusCell={isStatusCell}
                    isCheckedAtCol={isCheckedAtCol}
                    rowCheckedAt={rowCheckedAt}
                    isChecked={isChecked}
                    execMemo={execItem?.memo}
                    editorType={editorType ?? null}
                    isEditableHoverable={isEditableHoverable}
                    readOnly={readOnly}
                    onCheckChange={onCheckChange}
                    onValueChange={onValueChange}
                    onStatusChange={onStatusChange}
                    onEditStart={handleEditStart}
                    onEditCancel={handleEditCancel}
                    images={imagesByCell.get(key)}
                    onImageClick={setPreviewImage}
                  />
                );
              };

              // 가상화 가시 범위(rest) 인덱스 → colIdx 변환 (bodyRenderStart..renderEnd)
              const renderRestColIdxs: number[] = [];
              if (colRange.renderEnd >= 0) {
                for (let i = colRange.bodyRenderStart; i <= colRange.renderEnd; i++) {
                  const c = restCols[i];
                  if (c !== undefined) renderRestColIdxs.push(c);
                }
              }

              return (
                <Box
                  key={virtualRow.key}
                  data-row-idx={rowIdx}
                  sx={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: totalWidth,
                    height: ROW_HEIGHT,
                    transform: `translateY(${virtualRow.start}px)`,
                    display: 'flex',
                  }}
                >
                  {firstColIdx >= 0 && renderCell(firstColIdx, true)}
                  {colRange.leftSpacerW > 0 && (
                    <Box sx={{ width: colRange.leftSpacerW, height: ROW_HEIGHT, flexShrink: 0 }} />
                  )}
                  {renderRestColIdxs.map((colIdx) => renderCell(colIdx, false))}
                  {colRange.rightSpacerW > 0 && (
                    <Box sx={{ width: colRange.rightSpacerW, height: ROW_HEIGHT, flexShrink: 0 }} />
                  )}
                </Box>
              );
            })}
          </Box>
      </Box>
      <ImagePreviewModal src={previewImage} onClose={() => setPreviewImage(null)} />
    </Box>
  );
}
