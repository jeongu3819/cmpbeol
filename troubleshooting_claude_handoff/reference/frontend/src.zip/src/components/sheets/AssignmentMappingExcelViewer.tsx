/**
 * AssignmentMappingExcelViewer
 *
 * 약품/부품/그룹-설비 매핑 시트 전용 편집 뷰어.
 *  - 설비 컬럼: 칩 + DnD swap, 인라인 편집(더블클릭), × 삭제
 *  - 일반 텍스트 컬럼: 클릭으로 인라인 편집
 *  - 행 숨김(삭제): 호버 시 ✕ 버튼, 값이 있으면 확인 다이얼로그
 *  - 컬럼 숨김(삭제): 헤더 호버 시 ✕ 버튼, 필수 컬럼은 비활성
 *
 * 변경사항(셀 값 / 숨김 행 / 숨김 컬럼)은 useAssignmentMappingState 훅이
 * pendingChanges 로 보관하다가, "저장" 버튼 클릭 시 한 번에 flush 한다.
 * Phase B 슬롯(addedRows / addedColumns / renamedColumns)은 훅 측에서만
 * 미리 자리를 잡아둔 상태이며 본 화면에서는 노출하지 않는다.
 */
import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Paper, Typography, Chip, Button, Alert, CircularProgress, IconButton,
  Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, Tooltip
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ImagePreviewModal from '../ImagePreviewModal';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useDraggable,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from '@dnd-kit/core';
import type { SheetStructure, SheetCell, SheetExecutionItem, StructureOverlay } from '../../types';
import {
  getEquipmentColumnIndices,
  resolveHeaderRowIdx,
  isRequiredHeader,
} from './assignmentMappingDetect';
import { useAssignmentMappingState, makeCellRef, type AddedColumn } from './useAssignmentMappingState';

interface Props {
  executionId: number;
  structure: SheetStructure;
  items: SheetExecutionItem[];
  userId: number;
  readOnly?: boolean;
  baseHiddenRows?: number[];
  baseHiddenCols?: number[];
  /** 서버에서 받아온 structure_overlay (실행본 단위 추가 컬럼/행/헤더 rename). */
  structureOverlay?: StructureOverlay | null;
  searchQuery?: string;
}

function isEmptyText(v: unknown): boolean {
  if (v === null || v === undefined) return true;
  return String(v).trim() === '';
}

interface BuiltGrid {
  cellByPos: Map<string, SheetCell>;
  baseValueByRef: Map<string, string>;
  headerRow: number;
  colIndices: number[];
  dataRowIndices: number[];
  equipmentColSet: Set<number>;
}

function buildGrid(structure: SheetStructure, items: SheetExecutionItem[]): BuiltGrid | null {
  const headerRow = resolveHeaderRowIdx(structure);
  if (headerRow === null) return null;
  const cells = structure.cells || [];
  const equipmentColSet = new Set(getEquipmentColumnIndices(structure));

  const cellByPos = new Map<string, SheetCell>();
  const headerColsAll = new Set<number>();
  const baseValueByRef = new Map<string, string>();
  const rowsWithText = new Set<number>();
  let lastNonEmptyColInHeader = -1;
  const colHasValueInData = new Set<number>();

  for (const c of cells) {
    cellByPos.set(`${c.row},${c.col}`, c);
    if (c.row === headerRow) headerColsAll.add(c.col);
    if (!isEmptyText(c.value)) {
      rowsWithText.add(c.row);
      baseValueByRef.set(makeCellRef(c.row, c.col), c.value ?? '');
      if (c.row === headerRow && c.col > lastNonEmptyColInHeader) lastNonEmptyColInHeader = c.col;
      if (c.row > headerRow) colHasValueInData.add(c.col);
    }
  }

  for (const it of items) {
    if (!it.cell_ref) continue;
    if (it.value !== undefined && it.value !== null) {
      baseValueByRef.set(it.cell_ref, it.value);
      if (!isEmptyText(it.value)) {
        rowsWithText.add(it.row_idx);
        if (it.row_idx > headerRow) colHasValueInData.add(it.col_idx);
      }
    }
  }

  let lastNonEmptyRow = headerRow;
  rowsWithText.forEach((r) => { if (r > lastNonEmptyRow) lastNonEmptyRow = r; });

  let lastNonEmptyCol = lastNonEmptyColInHeader;
  colHasValueInData.forEach((c) => { if (c > lastNonEmptyCol) lastNonEmptyCol = c; });
  equipmentColSet.forEach((c) => { if (c > lastNonEmptyCol) lastNonEmptyCol = c; });

  const colIndices = Array.from(headerColsAll)
    .filter((c) => c <= lastNonEmptyCol)
    .sort((a, b) => a - b);

  const dataRowIndices: number[] = [];
  for (let r = headerRow + 1; r <= lastNonEmptyRow; r++) dataRowIndices.push(r);

  return { cellByPos, baseValueByRef, headerRow, colIndices, dataRowIndices, equipmentColSet };
}

function parseDragId(id: string | number | null | undefined, prefix: string): { row: number; col: number } | null {
  if (typeof id !== 'string') return null;
  if (!id.startsWith(prefix)) return null;
  const rest = id.slice(prefix.length);
  const [r, c] = rest.split('-');
  const row = Number(r);
  const col = Number(c);
  if (!Number.isFinite(row) || !Number.isFinite(col)) return null;
  return { row, col };
}

interface HeaderCellProps {
  label: string;
  isEquipment: boolean;
  canDelete: boolean;
  required: boolean;
  canRename: boolean;
  isEditing: boolean;
  /** 드래그 핸들 표시 여부 — 추가 컬럼만 true. */
  dragSourceEnabled?: boolean;
  /** drop target 활성 — 모든 비-readOnly 컬럼. 추가 컬럼이 base 사이로도 떨어지게. */
  dropTargetEnabled?: boolean;
  isDragging?: boolean;
  isDropTarget?: boolean;
  onReorderDragStart?: (e: React.DragEvent<HTMLSpanElement>) => void;
  onReorderDragEnd?: () => void;
  onReorderDragOver?: (e: React.DragEvent<HTMLTableCellElement>) => void;
  onReorderDragLeave?: () => void;
  onReorderDrop?: (e: React.DragEvent<HTMLTableCellElement>) => void;
  onDelete: () => void;
  onBeginRename: () => void;
  onCommitRename: (value: string) => void;
  onCancelRename: () => void;
}
const HeaderCell = memo(function HeaderCell({
  label, isEquipment, canDelete, required, canRename, isEditing,
  dragSourceEnabled, dropTargetEnabled, isDragging, isDropTarget,
  onReorderDragStart, onReorderDragEnd, onReorderDragOver, onReorderDragLeave, onReorderDrop,
  onDelete, onBeginRename, onCommitRename, onCancelRename,
}: HeaderCellProps) {
  return (
    <th
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 1,
        background: isDropTarget
          ? 'rgba(41,85,255,0.10)'
          : isEquipment ? '#E0F2FE' : '#F3F4F6',
        color: isEquipment ? '#075985' : '#111827',
        border: '1px solid #D1D5DB',
        borderLeft: isDropTarget ? '3px solid #2955FF' : '1px solid #D1D5DB',
        padding: '6px 22px 6px 10px',
        fontSize: '0.75rem',
        fontWeight: 700,
        textAlign: 'center',
        whiteSpace: 'nowrap',
        opacity: isDragging ? 0.4 : 1,
      }}
      className="amx-header"
      onDoubleClick={() => { if (canRename && !isEditing) onBeginRename(); }}
      onDragOver={dropTargetEnabled ? onReorderDragOver : undefined}
      onDragLeave={dropTargetEnabled ? onReorderDragLeave : undefined}
      onDrop={dropTargetEnabled ? onReorderDrop : undefined}
      title={canRename ? '더블클릭으로 헤더 이름 변경' : undefined}
    >
      {isEditing ? (
        <InlineEditor
          initial={label}
          onCommit={onCommitRename}
          onCancel={onCancelRename}
        />
      ) : (
        <span style={{ cursor: canRename ? 'text' : 'default' }}>{label || '\u00A0'}</span>
      )}
      {dragSourceEnabled && !isEditing && (
        <span
          draggable
          onDragStart={onReorderDragStart}
          onDragEnd={onReorderDragEnd}
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
          title="드래그해서 컬럼 위치 변경 (base 컬럼 사이로도 이동 가능)"
          style={{
            position: 'absolute',
            top: 2,
            left: 2,
            width: 14,
            height: 16,
            padding: 0,
            userSelect: 'none',
            cursor: 'grab',
            color: '#6B7280',
            fontSize: 10,
            lineHeight: '16px',
            textAlign: 'center',
          }}
        >⋮⋮</span>
      )}
      {required && !isEditing && (
        <span style={{ marginLeft: 4, color: '#DC2626', fontWeight: 700 }} title="필수 컬럼">*</span>
      )}
      {canDelete && !isEditing && (
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
          title="이 컬럼 숨김 (Ctrl+Z 로 되돌리기)"
          className="amx-col-del"
          style={{
            position: 'absolute',
            top: 2,
            right: 2,
            width: 16,
            height: 16,
            padding: 0,
            border: 'none',
            borderRadius: '50%',
            background: 'rgba(239, 68, 68, 0.85)',
            color: '#fff',
            fontSize: 11,
            lineHeight: '14px',
            cursor: 'pointer',
            opacity: 0.7,
            transition: 'opacity 120ms',
          }}
        >×</button>
      )}
    </th>
  );
});

interface InlineEditorProps {
  initial: string;
  pillStyle?: boolean;
  /** true 면 textarea 로 렌더 (Shift+Enter 줄바꿈, Enter 커밋). 기본 false. */
  multiline?: boolean;
  onCommit: (value: string) => void;
  onCancel: () => void;
}
function InlineEditor({ initial, pillStyle, multiline, onCommit, onCancel }: InlineEditorProps) {
  const [val, setVal] = useState(initial);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const taRef = useRef<HTMLTextAreaElement | null>(null);
  useEffect(() => {
    if (multiline) {
      const el = taRef.current;
      if (el) {
        el.focus();
        el.select();
      }
    } else {
      inputRef.current?.select();
    }
  }, [multiline]);
  // pillStyle 은 칩 셀 인라인편집 전용 — 절대 multiline 과 같이 쓰지 않는다.
  if (multiline) {
    return (
      <textarea
        ref={taRef}
        value={val}
        onChange={(e) => setVal(e.target.value)}
        onBlur={() => onCommit(val)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            onCommit(val);
          } else if (e.key === 'Escape') {
            e.preventDefault();
            onCancel();
          }
        }}
        onPointerDown={(e) => e.stopPropagation()}
        rows={Math.max(1, Math.min(6, (val.match(/\n/g)?.length ?? 0) + 1))}
        style={{
          width: '100%',
          minWidth: 80,
          padding: '4px 6px',
          borderRadius: 4,
          border: '1px solid #1D4ED8',
          outline: 'none',
          fontSize: '0.78rem',
          background: '#fff',
          resize: 'vertical',
          fontFamily: 'inherit',
          lineHeight: 1.4,
          whiteSpace: 'pre-wrap',
        }}
      />
    );
  }
  return (
    <input
      ref={inputRef}
      autoFocus
      value={val}
      onChange={(e) => setVal(e.target.value)}
      onBlur={() => onCommit(val.trim())}
      onKeyDown={(e) => {
        if (e.key === 'Enter') { e.preventDefault(); onCommit(val.trim()); }
        else if (e.key === 'Escape') { e.preventDefault(); onCancel(); }
      }}
      onPointerDown={(e) => e.stopPropagation()}
      style={pillStyle ? {
        minWidth: 64,
        padding: '4px 8px',
        borderRadius: 999,
        border: '1px solid #1D4ED8',
        outline: 'none',
        textAlign: 'center',
        fontSize: '0.72rem',
        fontWeight: 600,
        color: '#1D4ED8',
        background: '#fff',
      } : {
        width: '100%',
        minWidth: 80,
        padding: '4px 6px',
        borderRadius: 4,
        border: '1px solid #1D4ED8',
        outline: 'none',
        fontSize: '0.78rem',
        background: '#fff',
      }}
    />
  );
}

interface TextCellProps {
  row: number;
  col: number;
  value: string;
  readOnly: boolean;
  isDirty: boolean;
  isEditing: boolean;
  onBeginEdit: (row: number, col: number) => void;
  onCommitEdit: (row: number, col: number, value: string) => void;
  onCancelEdit: () => void;
  /** 첫 컬럼에 행 핸들/삭제버튼을 absolute 로 얹기 위한 슬롯. 별도 <td> 로 감싸지 않고
      이 cell 의 <td> 안에 직접 렌더해 nested-<td> invalid HTML 을 피한다. */
  overlay?: React.ReactNode;
  images?: any[];
  onImageClick?: (url: string) => void;
}
const TextCell = memo(function TextCell(props: TextCellProps) {
  const { row, col, value, readOnly, isDirty, isEditing, onBeginEdit, onCommitEdit, onCancelEdit, overlay, images, onImageClick } = props;
  return (
    <td
      onClick={() => { if (!readOnly && !isEditing) onBeginEdit(row, col); }}
      style={{
        position: 'relative',
        border: '1px solid #E5E7EB',
        padding: '6px 10px',
        fontSize: '0.78rem',
        whiteSpace: 'pre-wrap',
        wordBreak: 'break-word',
        verticalAlign: 'top',
        background: isDirty ? '#FFF7ED' : 'transparent',
        cursor: readOnly ? 'default' : 'text',
      }}
    >
      {isEditing ? (
        <InlineEditor
          initial={value}
          multiline
          onCommit={(v) => onCommitEdit(row, col, v)}
          onCancel={onCancelEdit}
        />
      ) : (
        <Box>
          {value || '\u00A0'}
          {images && images.length > 0 && (
            <Box sx={{ mt: 1, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              {images.map((img, i) => (
                <img
                  key={i}
                  src={img.thumbnail_url}
                  alt="img"
                  style={{ maxHeight: 60, cursor: 'pointer', border: '1px solid #ccc', borderRadius: 4 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onImageClick?.(img.original_url || img.thumbnail_url);
                  }}
                />
              ))}
            </Box>
          )}
        </Box>
      )}
      {overlay}
    </td>
  );
});

interface EquipmentCellProps {
  row: number;
  col: number;
  value: string;
  readOnly: boolean;
  isDirty: boolean;
  isEditing: boolean;
  onBeginEdit: (row: number, col: number) => void;
  onCommitEdit: (row: number, col: number, value: string) => void;
  onCancelEdit: () => void;
  onDelete: (row: number, col: number) => void;
  /** 첫 컬럼 행 핸들/삭제버튼 슬롯. TextCell 과 동일 — nested-<td> 회피. */
  overlay?: React.ReactNode;
}
const EquipmentCell = memo(function EquipmentCell(props: EquipmentCellProps) {
  const { row, col, value, readOnly, isDirty, isEditing, onBeginEdit, onCommitEdit, onCancelEdit, onDelete, overlay } = props;
  const dragId = `chip-${row}-${col}`;
  const dropId = `slot-${row}-${col}`;

  const draggable = useDraggable({ id: dragId, disabled: readOnly || !value || isEditing });
  const droppable = useDroppable({ id: dropId, disabled: readOnly || isEditing });

  const isOver = droppable.isOver;
  const isActive = draggable.isDragging;

  const handleDelete = useCallback(
    (e: React.MouseEvent | React.PointerEvent) => {
      e.stopPropagation();
      e.preventDefault();
      onDelete(row, col);
    },
    [row, col, onDelete],
  );

  return (
    <td
      ref={droppable.setNodeRef}
      style={{
        position: 'relative',
        border: '1px solid #E5E7EB',
        padding: '4px 6px',
        textAlign: 'center',
        verticalAlign: 'middle',
        background: isOver ? '#F0F9FF' : isDirty ? '#FFF7ED' : '#FAFBFF',
        outline: isOver ? '2px dashed #38BDF8' : 'none',
        outlineOffset: -2,
      }}
    >
      {isEditing ? (
        <InlineEditor
          initial={value}
          pillStyle
          onCommit={(v) => onCommitEdit(row, col, v)}
          onCancel={onCancelEdit}
        />
      ) : value ? (
        <Box
          ref={draggable.setNodeRef}
          {...draggable.listeners}
          {...draggable.attributes}
          onDoubleClick={() => !readOnly && onBeginEdit(row, col)}
          sx={{
            position: 'relative',
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            minWidth: 64,
            px: 1.2,
            py: '4px',
            pr: readOnly ? 1.2 : '22px',
            borderRadius: '999px',
            bgcolor: '#EEF4FF',
            color: '#1D4ED8',
            border: '1px solid #BFDBFE',
            fontSize: '0.72rem',
            fontWeight: 600,
            cursor: readOnly ? 'default' : 'grab',
            opacity: isActive ? 0.4 : 1,
            userSelect: 'none',
            '&:hover .equip-del': { opacity: 1 },
          }}
        >
          {value}
          {!readOnly && (
            <IconButton
              size="small"
              className="equip-del"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={handleDelete}
              sx={{
                position: 'absolute',
                right: 2,
                top: '50%',
                transform: 'translateY(-50%)',
                width: 16,
                height: 16,
                p: 0,
                opacity: 0,
                transition: 'opacity 120ms',
                color: '#1D4ED8',
                '&:hover': { color: '#DC2626', bgcolor: 'transparent' },
              }}
            >
              <CloseIcon sx={{ fontSize: 12 }} />
            </IconButton>
          )}
        </Box>
      ) : (
        <Box
          onClick={() => !readOnly && onBeginEdit(row, col)}
          sx={{
            display: 'inline-block',
            minWidth: 64,
            px: 1,
            py: '2px',
            border: '1px dashed #CBD5E1',
            borderRadius: '999px',
            color: '#9CA3AF',
            fontSize: '0.68rem',
            cursor: readOnly ? 'default' : 'pointer',
            '&:hover': readOnly ? undefined : { borderColor: '#1D4ED8', color: '#1D4ED8' },
          }}
        >
          + 설비 배치
        </Box>
      )}
      {overlay}
    </td>
  );
});

interface DataRowProps {
  rowIdx: number;
  colIndices: number[];
  equipmentColSet: Set<number>;
  values: string[];
  dirtyByCol: Set<number>;
  editingCol: number | null;
  readOnly: boolean;
  showRowDelete: boolean;
  /** 추가 행이면서 readOnly 가 아닐 때만 reorder 핸들/drop 처리. */
  reorderEnabled?: boolean;
  isDragging?: boolean;
  isDropTarget?: boolean;
  onReorderDragStart?: (e: React.DragEvent<HTMLSpanElement>) => void;
  onReorderDragEnd?: () => void;
  onReorderDragOver?: (e: React.DragEvent<HTMLTableRowElement>) => void;
  onReorderDragLeave?: () => void;
  onReorderDrop?: (e: React.DragEvent<HTMLTableRowElement>) => void;
  onRowDelete: (rowIdx: number) => void;
  onBeginEdit: (row: number, col: number) => void;
  onCommitEdit: (row: number, col: number, value: string) => void;
  onCancelEdit: () => void;
  onChipDelete: (row: number, col: number) => void;
  imagesByCell?: Map<string, any[]>;
  onImageClick?: (url: string) => void;
}
const DataRow = memo(function DataRow(props: DataRowProps) {
  const {
    rowIdx, colIndices, equipmentColSet, values, dirtyByCol,
    editingCol, readOnly, showRowDelete, onRowDelete,
    reorderEnabled, isDragging, isDropTarget,
    onReorderDragStart, onReorderDragEnd, onReorderDragOver, onReorderDragLeave, onReorderDrop,
    onBeginEdit, onCommitEdit, onCancelEdit, onChipDelete,
    imagesByCell, onImageClick,
  } = props;
  const [hovered, setHovered] = useState(false);
  return (
    <tr
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onDragOver={reorderEnabled ? onReorderDragOver : undefined}
      onDragLeave={reorderEnabled ? onReorderDragLeave : undefined}
      onDrop={reorderEnabled ? onReorderDrop : undefined}
      style={{
        position: 'relative',
        opacity: isDragging ? 0.4 : 1,
        outline: isDropTarget ? '2px solid #2955FF' : 'none',
        outlineOffset: -2,
        background: isDropTarget ? 'rgba(41,85,255,0.06)' : 'transparent',
      }}
    >
      {colIndices.map((col, idx) => {
        const v = values[idx] ?? '';
        const isFirstCol = idx === 0;
        const overlay = isFirstCol && (showRowDelete || reorderEnabled) ? (
          <>
            {showRowDelete && hovered && (
              <button
                type="button"
                title="이 행 삭제"
                onClick={(e) => { e.stopPropagation(); onRowDelete(rowIdx); }}
                style={{
                  position: 'absolute',
                  left: 2,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  width: 16,
                  height: 16,
                  padding: 0,
                  border: 'none',
                  borderRadius: '50%',
                  background: 'rgba(239, 68, 68, 0.85)',
                  color: '#fff',
                  fontSize: 11,
                  lineHeight: '14px',
                  cursor: 'pointer',
                  zIndex: 5,
                }}
              >×</button>
            )}
            {reorderEnabled && (
              <span
                draggable
                onDragStart={onReorderDragStart}
                onDragEnd={onReorderDragEnd}
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
                title="드래그해서 추가 행끼리 순서 변경"
                style={{
                  position: 'absolute',
                  left: 2,
                  top: 2,
                  width: 14,
                  height: 12,
                  padding: 0,
                  userSelect: 'none',
                  cursor: 'grab',
                  color: '#6B7280',
                  fontSize: 9,
                  lineHeight: '12px',
                  textAlign: 'center',
                  zIndex: 6,
                }}
              >⋮⋮</span>
            )}
          </>
        ) : undefined;
        return equipmentColSet.has(col) ? (
          <EquipmentCell
            key={col}
            row={rowIdx}
            col={col}
            value={v}
            readOnly={readOnly}
            isDirty={dirtyByCol.has(col)}
            isEditing={editingCol === col}
            onBeginEdit={onBeginEdit}
            onCommitEdit={onCommitEdit}
            onCancelEdit={onCancelEdit}
            onDelete={onChipDelete}
            overlay={overlay}
          />
        ) : (
          <TextCell
            key={col}
            row={rowIdx}
            col={col}
            value={v}
            readOnly={readOnly}
            isDirty={dirtyByCol.has(col)}
            isEditing={editingCol === col}
            onBeginEdit={onBeginEdit}
            onCommitEdit={onCommitEdit}
            onCancelEdit={onCancelEdit}
            overlay={overlay}
            images={imagesByCell?.get(`${rowIdx}-${col}`)}
            onImageClick={onImageClick}
          />
        );
      })}
    </tr>
  );
});

export default function AssignmentMappingExcelViewer({
  executionId, structure, items, userId, readOnly,
  baseHiddenRows, baseHiddenCols, structureOverlay,
  searchQuery,
}: Props) {
  const grid = useMemo(() => buildGrid(structure, items), [structure, items]);

  const baseValueByRef = useMemo(
    () => grid?.baseValueByRef ?? new Map<string, string>(),
    [grid],
  );

  const baseAddedColumns = useMemo<AddedColumn[]>(
    () => structureOverlay?.added_columns ?? [],
    [structureOverlay],
  );
  const baseAddedRows = useMemo(
    () => structureOverlay?.added_rows ?? [],
    [structureOverlay],
  );
  const baseRenamedHeaders = useMemo(
    () => structureOverlay?.renamed_headers ?? {},
    [structureOverlay],
  );
  const baseAddedColumnsOrder = useMemo(
    () => structureOverlay?.added_columns_order,
    [structureOverlay],
  );
  const baseAddedRowsOrder = useMemo(
    () => structureOverlay?.added_rows_order,
    [structureOverlay],
  );
  const baseColumnOrder = useMemo(
    () => structureOverlay?.column_order,
    [structureOverlay],
  );
  const baseRowOrder = useMemo(
    () => structureOverlay?.row_order,
    [structureOverlay],
  );

  // 새 추가 컬럼이 받을 수 있는 첫 col_idx. base 시트 마지막 헤더 col + 1 부터.
  const nextAddedColIdx = useMemo(() => {
    if (!grid || grid.colIndices.length === 0) return structure?.total_cols ?? 0;
    return grid.colIndices[grid.colIndices.length - 1] + 1;
  }, [grid, structure?.total_cols]);

  // 새 추가 행이 받을 수 있는 첫 row_idx. base 시트 마지막 데이터 row + 1 부터.
  const nextAddedRowIdx = useMemo(() => {
    if (!grid || grid.dataRowIndices.length === 0) return structure?.total_rows ?? 0;
    return grid.dataRowIndices[grid.dataRowIndices.length - 1] + 1;
  }, [grid, structure?.total_rows]);

  const state = useAssignmentMappingState({
    executionId,
    userId,
    baseValueByRef,
    baseHiddenRows: baseHiddenRows ?? [],
    baseHiddenCols: baseHiddenCols ?? [],
    baseAddedColumns,
    baseAddedRows,
    baseRenamedHeaders,
    baseAddedColumnsOrder,
    baseAddedRowsOrder,
    baseColIndices: grid?.colIndices,
    baseRowIndices: grid?.dataRowIndices,
    baseColumnOrder,
    baseRowOrder,
    nextAddedColIdx,
    nextAddedRowIdx,
  });

  const {
    pending, dirtyCount, isDirty, saving, saveError, clearError,
    resolveCellValue, isCellDirty,
    effectiveHiddenRows, effectiveHiddenCols,
    setCellValue, swapEquipment, hideRow, hideCol,
    addEquipmentColumn, addPlainColumn, removeAddedColumn, isAddedColumn, effectiveAddedColumns,
    addRow, removeAddedRow, isAddedRow, effectiveAddedRows,
    effectiveColumnOrder, effectiveRowOrder,
    reorderColumns, reorderRows,
    renameColumn, effectiveHeaderFor,
    clearPendingHidden, undo, canUndo,
    save,
  } = state;

  const [activeDragId, setActiveDragId] = useState<string | null>(null);
  const [editing, setEditing] = useState<{ row: number; col: number } | null>(null);
  const [editingHeader, setEditingHeader] = useState<number | null>(null);
  const [confirmRow, setConfirmRow] = useState<number | null>(null);
  // 추가 컬럼/행 reorder 드래그 상태. 칩 DnD(@dnd-kit)와는 완전히 별개의 native HTML5 drag.
  const [dragColIdx, setDragColIdx] = useState<number | null>(null);
  const [dragOverColIdx, setDragOverColIdx] = useState<number | null>(null);
  const [dragRowIdx, setDragRowIdx] = useState<number | null>(null);
  const [dragOverRowIdx, setDragOverRowIdx] = useState<number | null>(null);

  const [showEmptyCols, setShowEmptyCols] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const imagesByCell = useMemo(() => {
    const map = new Map<string, any[]>();
    if (!structure || !(structure as any).images) return map;
    (structure as any).images.forEach((img: any) => {
      const key = `${img.row}-${img.col}`;
      const arr = map.get(key) || [];
      arr.push(img);
      map.set(key, arr);
    });
    return map;
  }, [structure]);

  // 빈 컬럼 계산 (모든 데이터가 빈 컬럼)
  const emptyCols = useMemo(() => {
    const empty = new Set<number>();
    if (!grid) return empty;
    grid.colIndices.forEach((col) => {
      const headerVal = grid.cellByPos.get(`${grid.headerRow},${col}`)?.value?.trim() ?? '';
      if (headerVal !== '') return;
      let hasData = false;
      for (const r of grid.dataRowIndices) {
        const val = grid.cellByPos.get(`${r},${col}`)?.value?.trim() ?? '';
        if (val !== '') {
          hasData = true;
          break;
        }
      }
      if (!hasData) empty.add(col);
    });
    return empty;
  }, [grid]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  // 통합 컬럼 순서 (base + added). 추가 컬럼이 base 컬럼 사이에 끼어 있을 수 있다.
  // 숨김 컬럼은 양쪽 모두에서 제외. effectiveColumnOrder 가 base+added 합집합을 보장한다.
  const visibleColIndices = useMemo(() => {
    if (!grid) return [] as number[];
    return effectiveColumnOrder.filter((c) => {
      if (effectiveHiddenCols.has(c)) return false;
      if (!showEmptyCols && emptyCols.has(c)) return false;
      return true;
    });
  }, [grid, effectiveHiddenCols, effectiveColumnOrder, showEmptyCols, emptyCols]);

  // 헤더 텍스트: base 는 grid.cellByPos 에서, 추가 컬럼은 effectiveAddedColumns 에서.
  // pending.renamedColumns 가 있으면 base/added 모두 표시명을 덮어씀 (effectiveHeaderFor).
  const headerByCol = useMemo(() => {
    const m = new Map<number, string>();
    if (!grid) return m;
    grid.colIndices.forEach((col) => {
      const v = grid.cellByPos.get(`${grid.headerRow},${col}`)?.value ?? '';
      m.set(col, effectiveHeaderFor(col, v));
    });
    // effectiveAddedColumns 의 header 는 이미 pending.renamedColumns 가 머지된 값이라 그대로 사용.
    effectiveAddedColumns.forEach((c) => m.set(c.col_idx, c.header));
    return m;
  }, [grid, effectiveAddedColumns, effectiveHeaderFor]);

  // 설비 컬럼 set: base 검출 결과 + 추가 컬럼 중 kind='equipment' (legacy 미지정도 equipment 로 간주).
  const equipmentColSet = useMemo(() => {
    const s = new Set<number>(grid?.equipmentColSet ?? []);
    effectiveAddedColumns.forEach((c) => {
      if (c.kind === undefined || c.kind === 'equipment') s.add(c.col_idx);
    });
    return s;
  }, [grid, effectiveAddedColumns]);

  const searchMatchedRows = useMemo(() => {
    if (!searchQuery || !searchQuery.trim() || !grid) return null;
    const q = searchQuery.toLowerCase();
    const matched = new Set<number>();
    
    // Evaluate base rows
    for (const r of grid.dataRowIndices) {
      let match = false;
      for (const c of grid.colIndices) {
        const ref = makeCellRef(r, c);
        const val = resolveCellValue(ref) ?? '';
        if (String(val).toLowerCase().includes(q)) {
          match = true;
          break;
        }
      }
      if (match) matched.add(r);
    }
    // Evaluate added rows
    effectiveAddedRows.forEach((row) => {
      const r = row.row_idx;
      let match = false;
      for (const c of effectiveColumnOrder) {
        const ref = makeCellRef(r, c);
        const val = resolveCellValue(ref) ?? '';
        if (String(val).toLowerCase().includes(q)) {
          match = true;
          break;
        }
      }
      if (match) matched.add(r);
    });
    return matched;
  }, [searchQuery, grid, effectiveAddedRows, effectiveColumnOrder, resolveCellValue]);

  const visibleRowIndices = useMemo(() => {
    if (!grid) return [] as number[];
    return effectiveRowOrder.filter((r) => {
      if (effectiveHiddenRows.has(r)) return false;
      if (searchMatchedRows && !searchMatchedRows.has(r)) return false;
      return true;
    });
  }, [grid, effectiveHiddenRows, effectiveRowOrder, searchMatchedRows]);

  const { rowValuesByRow, rowDirtyByRow } = useMemo(() => {
    const rv = new Map<number, string[]>();
    const rd = new Map<number, Set<number>>();
    if (!grid) return { rowValuesByRow: rv, rowDirtyByRow: rd };
    visibleRowIndices.forEach((r) => {
      const vals: string[] = [];
      const dirty = new Set<number>();
      visibleColIndices.forEach((c) => {
        const ref = makeCellRef(r, c);
        vals.push(resolveCellValue(ref));
        if (isCellDirty(ref)) dirty.add(c);
      });
      rv.set(r, vals);
      rd.set(r, dirty);
    });
    return { rowValuesByRow: rv, rowDirtyByRow: rd };
    // pending is the actual driver — when it changes, resolveCellValue/isCellDirty are
    // re-bound by the hook, so depending on `pending` keeps row values fresh.
  }, [grid, visibleRowIndices, visibleColIndices, resolveCellValue, isCellDirty, pending]);

  const handleDragStart = useCallback((evt: DragStartEvent) => {
    setActiveDragId(typeof evt.active.id === 'string' ? evt.active.id : null);
  }, []);

  const handleDragEnd = useCallback(
    (evt: DragEndEvent) => {
      setActiveDragId(null);
      if (!grid) return;
      const src = parseDragId(evt.active.id, 'chip-');
      const dst = parseDragId(evt.over?.id, 'slot-');
      if (!src || !dst) return;
      if (src.row === dst.row && src.col === dst.col) return;
      if (!equipmentColSet.has(src.col) || !equipmentColSet.has(dst.col)) return;
      const srcVal = resolveCellValue(makeCellRef(src.row, src.col));
      if (!srcVal) return;
      swapEquipment(src, dst);
    },
    [grid, equipmentColSet, resolveCellValue, swapEquipment],
  );

  const handleDragCancel = useCallback(() => setActiveDragId(null), []);

  // ───── 컬럼/행 reorder (native HTML5 drag) ─────
  // dataTransfer payload: 'amx-col:N' / 'amx-row:N'. 칩 DnD(@dnd-kit pointer event)와 충돌하지 않게 prefix 분리.
  // source 는 추가 컬럼/행만 (drag 핸들이 추가 항목 헤더에만 표시), target 은 모든 컬럼/행 — 추가
  // 컬럼을 base 컬럼 사이에 drop 할 수 있게 하기 위함. effectiveColumnOrder 전체를 다시 정렬한다.
  const commitColReorder = useCallback((source: number, target: number) => {
    if (source === target) return;
    const cur = effectiveColumnOrder;
    if (!cur.includes(source) || !cur.includes(target)) return;
    const next = cur.filter((v) => v !== source);
    const ti = next.indexOf(target);
    next.splice(ti, 0, source);
    reorderColumns(next);
  }, [effectiveColumnOrder, reorderColumns]);
  const commitRowReorder = useCallback((source: number, target: number) => {
    if (source === target) return;
    const cur = effectiveRowOrder;
    if (!cur.includes(source) || !cur.includes(target)) return;
    const next = cur.filter((v) => v !== source);
    const ti = next.indexOf(target);
    next.splice(ti, 0, source);
    reorderRows(next);
  }, [effectiveRowOrder, reorderRows]);

  const makeColDragStart = useCallback((colIdx: number) => (e: React.DragEvent<HTMLSpanElement>) => {
    e.stopPropagation();
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', `amx-col:${colIdx}`);
    setDragColIdx(colIdx);
  }, []);
  const handleColDragEnd = useCallback(() => {
    setDragColIdx(null);
    setDragOverColIdx(null);
  }, []);
  const makeColDragOver = useCallback((colIdx: number) => (e: React.DragEvent<HTMLTableCellElement>) => {
    if (dragColIdx === null) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverColIdx !== colIdx) setDragOverColIdx(colIdx);
  }, [dragColIdx, dragOverColIdx]);
  const handleColDragLeave = useCallback(() => {
    // dragleave fires per-child. Clearing here can flicker; commit-on-drop handles cleanup.
  }, []);
  const makeColDrop = useCallback((colIdx: number) => (e: React.DragEvent<HTMLTableCellElement>) => {
    const payload = e.dataTransfer.getData('text/plain');
    if (!payload.startsWith('amx-col:')) return;
    e.preventDefault();
    e.stopPropagation();
    const src = Number(payload.slice('amx-col:'.length));
    if (Number.isFinite(src)) commitColReorder(src, colIdx);
    setDragColIdx(null);
    setDragOverColIdx(null);
  }, [commitColReorder]);

  const makeRowDragStart = useCallback((rowIdx: number) => (e: React.DragEvent<HTMLSpanElement>) => {
    e.stopPropagation();
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', `amx-row:${rowIdx}`);
    setDragRowIdx(rowIdx);
  }, []);
  const handleRowDragEnd = useCallback(() => {
    setDragRowIdx(null);
    setDragOverRowIdx(null);
  }, []);
  const makeRowDragOver = useCallback((rowIdx: number) => (e: React.DragEvent<HTMLTableRowElement>) => {
    if (dragRowIdx === null) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverRowIdx !== rowIdx) setDragOverRowIdx(rowIdx);
  }, [dragRowIdx, dragOverRowIdx]);
  const handleRowDragLeave = useCallback(() => {
    // see colDragLeave note
  }, []);
  const makeRowDrop = useCallback((rowIdx: number) => (e: React.DragEvent<HTMLTableRowElement>) => {
    const payload = e.dataTransfer.getData('text/plain');
    if (!payload.startsWith('amx-row:')) return;
    e.preventDefault();
    e.stopPropagation();
    const src = Number(payload.slice('amx-row:'.length));
    if (Number.isFinite(src)) commitRowReorder(src, rowIdx);
    setDragRowIdx(null);
    setDragOverRowIdx(null);
  }, [commitRowReorder]);

  const beginEdit = useCallback((row: number, col: number) => setEditing({ row, col }), []);
  const cancelEdit = useCallback(() => setEditing(null), []);
  const commitEdit = useCallback((row: number, col: number, newValue: string) => {
    setCellValue(row, col, newValue);
    setEditing(null);
  }, [setCellValue]);
  const handleChipDelete = useCallback((row: number, col: number) => {
    setCellValue(row, col, '');
  }, [setCellValue]);

  const requestRowDelete = useCallback((rowIdx: number) => {
    if (!grid) return;
    const cols = [...grid.colIndices, ...effectiveAddedColumns.map((c) => c.col_idx)];
    const hasAnyValue = cols.some((c) => {
      const ref = makeCellRef(rowIdx, c);
      return !isEmptyText(resolveCellValue(ref));
    });
    if (hasAnyValue) {
      setConfirmRow(rowIdx);
    } else if (isAddedRow(rowIdx)) {
      removeAddedRow(rowIdx);
    } else {
      hideRow(rowIdx);
    }
  }, [grid, effectiveAddedColumns, resolveCellValue, hideRow, isAddedRow, removeAddedRow]);

  const confirmRowDelete = useCallback(() => {
    if (confirmRow !== null) {
      if (isAddedRow(confirmRow)) removeAddedRow(confirmRow);
      else hideRow(confirmRow);
    }
    setConfirmRow(null);
  }, [confirmRow, hideRow, isAddedRow, removeAddedRow]);

  // 헤더 ✕: base 컬럼은 hideCol (숨김 슬롯), 추가 컬럼은 removeAddedColumn (구조 슬롯).
  const handleColDelete = useCallback((colIdx: number) => {
    if (isAddedColumn(colIdx)) removeAddedColumn(colIdx);
    else hideCol(colIdx);
  }, [hideCol, isAddedColumn, removeAddedColumn]);

  const beginHeaderEdit = useCallback((colIdx: number) => setEditingHeader(colIdx), []);
  const cancelHeaderEdit = useCallback(() => setEditingHeader(null), []);
  const commitHeaderEdit = useCallback((colIdx: number, newLabel: string) => {
    renameColumn(colIdx, newLabel);
    setEditingHeader(null);
  }, [renameColumn]);

  // Ctrl+Z (Cmd+Z on macOS) → undo last pending change. Ignored when the
  // event target is an editable element so the browser's native input undo
  // takes precedence inside cell editors.
  useEffect(() => {
    if (readOnly) return;
    const handler = (e: KeyboardEvent) => {
      const isMod = e.ctrlKey || e.metaKey;
      if (!isMod) return;
      if (e.key !== 'z' && e.key !== 'Z') return;
      if (e.shiftKey) return; // leave Ctrl+Shift+Z (redo) for now
      const t = e.target as HTMLElement | null;
      if (t) {
        const tag = t.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || t.isContentEditable) return;
      }
      if (!canUndo) return;
      e.preventDefault();
      undo();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [readOnly, canUndo, undo]);

  if (!grid) {
    return (
      <Paper variant="outlined" sx={{ p: 2, borderRadius: 2 }}>
        <Typography color="text.secondary">설비 컬럼이 있는 헤더를 찾지 못했습니다.</Typography>
      </Paper>
    );
  }

  const equipmentCount = visibleColIndices.filter((c) => equipmentColSet.has(c)).length;
  const activeDragValue = (() => {
    const parsed = parseDragId(activeDragId, 'chip-');
    if (!parsed) return null;
    return resolveCellValue(makeCellRef(parsed.row, parsed.col));
  })();
  const localHiddenRowCount = pending.hiddenRows.size;
  const localHiddenColCount = pending.hiddenCols.size;

  return (
    <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2, display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1, flexWrap: 'wrap' }}>
        <Typography variant="subtitle2" fontWeight={700}>
          설비 배치 매핑 (편집형)
        </Typography>
        <Typography variant="caption" color="text.secondary">
          데이터 행 {visibleRowIndices.length}개 · 설비 컬럼 {equipmentCount}개
          {(localHiddenRowCount > 0 || localHiddenColCount > 0) && (
            <> · 숨김 대기 {localHiddenRowCount}행 / {localHiddenColCount}열</>
          )}
        </Typography>
        <Box sx={{ flex: 1 }} />
        <Tooltip title="텍스트/데이터가 없는 컬럼을 숨깁니다. (직접 추가한 컬럼 제외)">
          <Button
            size="small"
            variant={showEmptyCols ? "contained" : "outlined"}
            color="secondary"
            onClick={() => setShowEmptyCols(!showEmptyCols)}
            sx={{ fontSize: '0.72rem' }}
          >
            {showEmptyCols ? "빈 컬럼 보기 켬" : "빈 컬럼 숨김"}
          </Button>
        </Tooltip>
        {!readOnly && (
          <Button
            size="small"
            variant="outlined"
            onClick={() => addEquipmentColumn()}
            sx={{ fontSize: '0.72rem' }}
            title="새 설비 컬럼을 우측에 추가 (저장 전 ↶ 또는 헤더 ✕ 로 취소)"
          >
            + 설비 컬럼
          </Button>
        )}
        {!readOnly && (
          <Button
            size="small"
            variant="outlined"
            onClick={() => addPlainColumn()}
            sx={{ fontSize: '0.72rem' }}
            title="새 일반 컬럼을 우측에 추가 (텍스트 입력)"
          >
            + 컬럼 추가
          </Button>
        )}
        {!readOnly && (
          <Button
            size="small"
            variant="outlined"
            onClick={() => addRow()}
            sx={{ fontSize: '0.72rem' }}
            title="새 행을 마지막에 추가 (저장 전 ↶ 또는 행 ✕ 로 취소)"
          >
            + 행 추가
          </Button>
        )}
        {!readOnly && (localHiddenRowCount > 0 || localHiddenColCount > 0) && (
          <Button
            size="small"
            variant="outlined"
            color="warning"
            onClick={clearPendingHidden}
            sx={{ fontSize: '0.72rem' }}
            title="저장 전 숨김 행/열을 모두 다시 표시"
          >
            숨김 되돌리기
          </Button>
        )}
        {!readOnly && (
          <Button
            size="small"
            variant="text"
            disabled={!canUndo}
            onClick={undo}
            sx={{ fontSize: '0.72rem' }}
            title="마지막 변경 되돌리기 (Ctrl+Z)"
          >
            ↶ 되돌리기
          </Button>
        )}
        {!readOnly && isDirty && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Typography variant="caption" sx={{ color: '#B45309', fontWeight: 600 }}>
              저장되지 않은 변경사항 {dirtyCount}건
            </Typography>
            <Button
              size="small"
              variant="contained"
              disabled={saving}
              onClick={save}
              startIcon={saving ? <CircularProgress size={14} color="inherit" /> : undefined}
              sx={{ fontSize: '0.72rem' }}
            >
              {saving ? '저장 중…' : '저장'}
            </Button>
          </Box>
        )}
      </Box>
      {saveError && (
        <Alert severity="error" onClose={clearError} sx={{ mb: 1, py: 0 }}>
          {saveError}
        </Alert>
      )}

      <DndContext
        sensors={sensors}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onDragCancel={handleDragCancel}
      >
        <Box
          sx={{
            overflow: 'auto',
            flex: 1,
            minHeight: 0,
            '& .amx-header:hover .amx-col-del': { opacity: 1 },
          }}
        >
          <table style={{ borderCollapse: 'collapse', tableLayout: 'auto', width: '100%' }}>
            <thead>
              <tr>
                {visibleColIndices.map((col) => {
                  const header = headerByCol.get(col) ?? '';
                  const isEquip = equipmentColSet.has(col);
                  // 추가 컬럼은 항상 ✕ 가능. base 컬럼은 필수가 아니어야 ✕.
                  const isAdded = isAddedColumn(col);
                  const required = !isAdded && isRequiredHeader(header);
                  const canDelete = !readOnly && !required;
                  // rename 가능 여부: 필수 컬럼은 표시명 바꿔도 role 매핑은 col_idx 기반이라 안전하지만,
                  // 필수 컬럼은 의미가 고정되어야 하므로 보수적으로 막는다.
                  const canRename = !readOnly && !required;
                  // 드래그 source: 추가 컬럼만 (사용자 요구 "최소 요구 = added 가 base 사이로 drop").
                  const dragSourceEnabled = !readOnly && isAdded;
                  // drop target: 모든 비-readOnly 컬럼. base 컬럼 사이/옆으로도 떨어질 수 있게.
                  const dropTargetEnabled = !readOnly;
                  return (
                    <HeaderCell
                      key={col}
                      label={header}
                      isEquipment={isEquip}
                      canDelete={canDelete}
                      required={required}
                      canRename={canRename}
                      isEditing={editingHeader === col}
                      dragSourceEnabled={dragSourceEnabled}
                      dropTargetEnabled={dropTargetEnabled}
                      isDragging={dragSourceEnabled && dragColIdx === col}
                      isDropTarget={
                        dropTargetEnabled && dragColIdx !== null && dragColIdx !== col && dragOverColIdx === col
                      }
                      onReorderDragStart={dragSourceEnabled ? makeColDragStart(col) : undefined}
                      onReorderDragEnd={dragSourceEnabled ? handleColDragEnd : undefined}
                      onReorderDragOver={dropTargetEnabled ? makeColDragOver(col) : undefined}
                      onReorderDragLeave={dropTargetEnabled ? handleColDragLeave : undefined}
                      onReorderDrop={dropTargetEnabled ? makeColDrop(col) : undefined}
                      onDelete={() => handleColDelete(col)}
                      onBeginRename={() => beginHeaderEdit(col)}
                      onCommitRename={(v) => commitHeaderEdit(col, v)}
                      onCancelRename={cancelHeaderEdit}
                    />
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {visibleRowIndices.map((r) => {
                const isAdded = isAddedRow(r);
                const reorderRowEnabled = !readOnly && isAdded;
                return (
                  <DataRow
                    key={r}
                    rowIdx={r}
                    colIndices={visibleColIndices}
                    equipmentColSet={equipmentColSet}
                    values={rowValuesByRow.get(r) ?? []}
                    dirtyByCol={rowDirtyByRow.get(r) ?? new Set<number>()}
                    editingCol={editing && editing.row === r ? editing.col : null}
                    readOnly={!!readOnly}
                    showRowDelete={!readOnly}
                    reorderEnabled={reorderRowEnabled}
                    isDragging={reorderRowEnabled && dragRowIdx === r}
                    isDropTarget={
                      reorderRowEnabled && dragRowIdx !== null && dragRowIdx !== r && dragOverRowIdx === r
                    }
                    onReorderDragStart={reorderRowEnabled ? makeRowDragStart(r) : undefined}
                    onReorderDragEnd={reorderRowEnabled ? handleRowDragEnd : undefined}
                    onReorderDragOver={reorderRowEnabled ? makeRowDragOver(r) : undefined}
                    onReorderDragLeave={reorderRowEnabled ? handleRowDragLeave : undefined}
                    onReorderDrop={reorderRowEnabled ? makeRowDrop(r) : undefined}
                    onRowDelete={requestRowDelete}
                    onBeginEdit={beginEdit}
                    onCommitEdit={commitEdit}
                    onCancelEdit={cancelEdit}
                    onChipDelete={handleChipDelete}
                    imagesByCell={imagesByCell}
                    onImageClick={setPreviewImage}
                  />
                );
              })}
            </tbody>
          </table>
        </Box>

        <DragOverlay>
          {activeDragValue ? (
            <Chip
              label={activeDragValue}
              size="small"
              sx={{
                bgcolor: '#EEF4FF',
                color: '#1D4ED8',
                border: '1px solid #BFDBFE',
                fontSize: '0.72rem',
                fontWeight: 600,
                minWidth: 64,
                cursor: 'grabbing',
                boxShadow: '0 4px 12px rgba(29, 78, 216, 0.25)',
              }}
            />
          ) : null}
        </DragOverlay>
      </DndContext>

      <Dialog open={confirmRow !== null} onClose={() => setConfirmRow(null)}>
        <DialogTitle>이 행을 삭제할까요?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            행에 입력된 값이 있습니다. 삭제(숨김) 후 저장하면 이 행은 더 이상 표시되지 않습니다.
            저장 전에는 변경 취소가 가능합니다.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmRow(null)}>취소</Button>
          <Button color="error" variant="contained" onClick={confirmRowDelete}>삭제</Button>
        </DialogActions>
      </Dialog>
      <ImagePreviewModal src={previewImage} onClose={() => setPreviewImage(null)} />
    </Paper>
  );
}
