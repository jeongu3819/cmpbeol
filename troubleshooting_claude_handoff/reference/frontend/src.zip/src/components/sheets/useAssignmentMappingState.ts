/**
 * useAssignmentMappingState
 *
 * Owns the "pending changes" model for the assignment-mapping Excel viewer
 * and the network calls that flush them on Save.
 *
 * The shape carries six slots so Phase B (add row / add column / rename
 * header via a future structure-overlay endpoint) can plug in without
 * reshaping the viewer:
 *
 *   pending = {
 *     dirtyCells:      Map<cellRef, value>      // Phase A — flushed via upsertSheetExecutionCell
 *     hiddenRows:      Set<rowIdx>              // Phase A — flushed via updateSheetHiddenRows
 *     hiddenCols:      Set<colIdx>              // Phase A — flushed via updateSheetHiddenCols
 *     addedRows:       AddedRow[]               // Phase B (stub)
 *     addedColumns:    AddedColumn[]            // Phase B (stub)
 *     renamedColumns:  Map<colIdx, header>      // Phase B (stub)
 *   }
 *
 * Phase B slots are part of the public surface but stay empty in Phase A.
 * The save() routine intentionally refuses to flush them so a stray
 * mutation can't reach the server before its endpoint exists.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { api } from '../../api/client';

/**
 * AddedColumn / AddedRow / renamed_headers 의 모양은 백엔드 structure_overlay
 * 와 1:1 로 맞춘다. col_idx 는 base 시트 마지막 col + 1 부터 단조 증가.
 */
/**
 * kind:
 *   'equipment' — 칩/DnD 셀로 렌더 (legacy 미지정 시 기본).
 *   'plain'     — 일반 텍스트 셀로 렌더 (행마다 textarea 편집).
 */
export type AddedColumnKind = 'equipment' | 'plain';
export interface AddedColumn {
  col_idx: number;
  header: string;
  kind?: AddedColumnKind;
}
export interface AddedRow {
  row_idx: number;
}

export interface PendingChanges {
  dirtyCells: Map<string, string>;
  hiddenRows: Set<number>;
  hiddenCols: Set<number>;
  addedRows: AddedRow[];
  addedColumns: AddedColumn[];
  renamedColumns: Map<number, string>;
}

interface UseArgs {
  executionId: number;
  userId: number;
  baseValueByRef: Map<string, string>;
  baseHiddenRows: number[];
  baseHiddenCols: number[];
  /** 서버에서 받아온 structure_overlay.added_columns */
  baseAddedColumns: AddedColumn[];
  baseAddedRows?: AddedRow[];
  baseRenamedHeaders?: Record<string, string>;
  /** 서버에서 받아온 structure_overlay.added_columns_order (added col_idx 만 포함, 렌더 순서). */
  baseAddedColumnsOrder?: number[];
  baseAddedRowsOrder?: number[];
  /**
   * base 시트 헤더 컬럼 idx (오름차순). 제공되면 effectiveColumnOrder 가 base+added 통합 순서를
   * 반환하고, 추가 컬럼을 base 컬럼 사이에 끼워 넣을 수 있다. 미제공 시 기존 added-only 동작.
   */
  baseColIndices?: number[];
  baseRowIndices?: number[];
  /** 서버에서 받아온 structure_overlay.column_order (base+added 통합). 없으면 폴백. */
  baseColumnOrder?: number[];
  baseRowOrder?: number[];
  /** + 설비 컬럼 자동 명명 시 시작 col_idx (보통 base 시트 lastCol + 1) */
  nextAddedColIdx: number;
  /** + 행 추가 시 시작 row_idx (보통 base 시트 lastRow + 1). */
  nextAddedRowIdx: number;
}

/**
 * History stack entries — one per user-visible undoable action. Stored as
 * "what to do to revert", so undo() just consumes the top entry.
 */
type HistoryEntry =
  | { kind: 'cell'; ref: string; prev: string | undefined } // undefined ⇒ was clean (no pending entry)
  | { kind: 'swap'; srcRef: string; dstRef: string; prevSrc: string | undefined; prevDst: string | undefined }
  | { kind: 'hideRow'; row: number }
  | { kind: 'unhideRow'; row: number }
  | { kind: 'hideCol'; col: number }
  | { kind: 'unhideCol'; col: number }
  // 사용자가 + 설비 컬럼 / + 컬럼 추가 클릭 → undo 시 pending.addedColumns 에서 제거.
  | { kind: 'addCol'; column: AddedColumn }
  // 사용자가 헤더 ✕ 클릭 → undo 시 pending 또는 pendingRemovedAdded 에서 원상복구.
  | { kind: 'removeAddedCol'; column: AddedColumn; wasInBase: boolean }
  // 사용자가 헤더 더블클릭으로 rename → undo 시 이전 값으로 복구. prev 가 undefined 면 rename 자체가 없던 상태.
  | { kind: 'rename'; col: number; prev: string | undefined }
  // 사용자가 + 행 추가 클릭 → undo 시 pending.addedRows 에서 제거.
  | { kind: 'addRow'; row: AddedRow }
  // 사용자가 추가 행 ✕ 클릭 → undo 시 pending 또는 pendingRemovedAddedRows 에서 원상복구.
  | { kind: 'removeAddedRow'; row: AddedRow; wasInBase: boolean }
  // added 컬럼/행 드래그 reorder. prev = 이전 override(없으면 null) 로 그대로 복구.
  | { kind: 'reorderCols'; prev: number[] | null }
  | { kind: 'reorderRows'; prev: number[] | null }
  // base+added 통합 순서 reorder.
  | { kind: 'reorderColumnsAll'; prev: number[] | null }
  | { kind: 'reorderRowsAll'; prev: number[] | null };

interface UseReturn {
  pending: PendingChanges;
  dirtyCount: number;
  isDirty: boolean;
  saving: boolean;
  saveError: string | null;
  clearError: () => void;
  resolveCellValue: (cellRef: string) => string;
  isCellDirty: (cellRef: string) => boolean;
  isRowHiddenLocally: (rowIdx: number) => boolean;
  isColHiddenLocally: (colIdx: number) => boolean;
  effectiveHiddenRows: Set<number>;
  effectiveHiddenCols: Set<number>;
  setCellValue: (rowIdx: number, colIdx: number, value: string) => void;
  swapEquipment: (
    src: { row: number; col: number },
    dst: { row: number; col: number },
  ) => void;
  hideRow: (rowIdx: number) => void;
  unhideRow: (rowIdx: number) => void;
  hideCol: (colIdx: number) => void;
  unhideCol: (colIdx: number) => void;
  /**
   * 새 설비 컬럼 추가. col_idx 는 다음 사용 가능한 값(base last + base addedColumns.length + 1)
   * 으로 자동 부여, header 는 "설비1"부터 단조 증가. pending.addedColumns 에 들어가고
   * save() 에서 structure_overlay 로 flush.
   */
  addEquipmentColumn: () => AddedColumn;
  /** 일반 컬럼 추가. 자동명 "새 컬럼N", kind='plain'. 일반 텍스트 셀로 렌더. */
  addPlainColumn: () => AddedColumn;
  /** 추가했던 컬럼을 롤백. 저장 전이면 사라지고, 저장 후라면 다음 save 에서 빠진 상태로 덮어써짐. */
  removeAddedColumn: (col_idx: number) => void;
  isAddedColumn: (col_idx: number) => boolean;
  /** base + pending 합친 added_columns (rename 적용된 header) */
  effectiveAddedColumns: AddedColumn[];
  /** + 행 추가. 기존 base/pending 에 없는 다음 row_idx 를 부여. */
  addRow: () => AddedRow;
  /** 추가했던 행을 롤백. 저장 전이면 사라지고, 저장 후라면 다음 save 에서 제외 저장. */
  removeAddedRow: (row_idx: number) => void;
  isAddedRow: (row_idx: number) => boolean;
  /** base + pending - removed 합친 added_rows (row_idx 오름차순). */
  effectiveAddedRows: AddedRow[];
  /**
   * added 컬럼의 렌더 순서. effectiveAddedColumns 와 동일한 col_idx 집합이지만,
   * 사용자가 드래그 reorder 했으면 그 순서, 아니면 서버 순서(없으면 col_idx asc).
   */
  effectiveAddedColsOrder: number[];
  effectiveAddedRowsOrder: number[];
  /** added 컬럼/행의 렌더 순서를 newOrder 로 덮어쓴다. base 컬럼/행은 영향 없음. */
  reorderAddedColumns: (newOrder: number[]) => void;
  reorderAddedRows: (newOrder: number[]) => void;
  /**
   * 전체 컬럼(base + added) 의 렌더 순서. baseColIndices 가 제공된 경우에만 동작.
   * 우선순위: 사용자 override → 서버 column_order → base asc + added(=effectiveAddedColsOrder).
   */
  effectiveColumnOrder: number[];
  effectiveRowOrder: number[];
  /** 전체 컬럼(base + added) 순서 override. 추가 컬럼을 base 컬럼 사이에 끼워 넣을 때 사용. */
  reorderColumns: (newOrder: number[]) => void;
  reorderRows: (newOrder: number[]) => void;
  /**
   * 헤더 이름 변경. 추가 컬럼이든 base 컬럼이든 같은 인터페이스.
   *   · 추가 컬럼 → effectiveAddedColumns 의 header 가 바뀐다 (저장 시 added_columns header 로 flush)
   *   · base  컬럼 → renamed_headers 에 저장 (저장 시 renamed_headers 로 flush)
   * 빈 문자열을 넘기면 base header 로 회귀(=renamed_headers 에서 제거).
   */
  renameColumn: (colIdx: number, newHeader: string) => void;
  /** 렌더링용: col 의 표시 헤더 (rename 적용). base header 계산은 호출측에서. */
  effectiveHeaderFor: (colIdx: number, baseHeader: string) => string;
  /** drop all *pending* hidden rows/cols (does not affect already-saved hides). */
  clearPendingHidden: () => void;
  /** undo last user action (cell edit / swap / hide / unhide). No-op if stack empty. */
  undo: () => void;
  canUndo: boolean;
  save: () => Promise<void>;
}

function colLetter(col0: number): string {
  let n = col0 + 1;
  let out = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    out = String.fromCharCode(65 + rem) + out;
    n = Math.floor((n - 1) / 26);
  }
  return out;
}
export function makeCellRef(row0: number, col0: number): string {
  return `${colLetter(col0)}${row0 + 1}`;
}

function emptyPending(): PendingChanges {
  return {
    dirtyCells: new Map<string, string>(),
    hiddenRows: new Set<number>(),
    hiddenCols: new Set<number>(),
    addedRows: [],
    addedColumns: [],
    renamedColumns: new Map<number, string>(),
  };
}

export function useAssignmentMappingState({
  executionId,
  userId,
  baseValueByRef,
  baseHiddenRows,
  baseHiddenCols,
  baseAddedColumns,
  baseAddedRows,
  baseRenamedHeaders,
  baseAddedColumnsOrder,
  baseAddedRowsOrder,
  baseColIndices,
  baseRowIndices,
  baseColumnOrder,
  baseRowOrder,
  nextAddedColIdx,
  nextAddedRowIdx,
}: UseArgs): UseReturn {
  const queryClient = useQueryClient();
  const [pending, setPending] = useState<PendingChanges>(() => emptyPending());
  // 최신 pending 스냅샷 ref.
  // Save 버튼 클릭 직전, 편집 중이던 셀의 onBlur 커밋(setCellValue → setPending)이
  // save() 클로저에 아직 반영되지 않아 첫 클릭이 "변경 없음"으로 조기 반환되는 문제
  // (="두 번 저장해야 반영")를 막는다. setCellValue/swapEquipment 는 업데이터 안에서
  // 이 ref 를 동기 갱신하고, save() 는 closure 대신 이 ref 에서 최신 pending 을 읽는다.
  const pendingRef = useRef<PendingChanges>(pending);
  useEffect(() => { pendingRef.current = pending; }, [pending]);
  // base added_columns 중 사용자가 ✕ 클릭으로 제거 의도를 표시한 col_idx 들.
  // pending.addedColumns 가 "추가" 슬롯이라면 이건 "삭제" 슬롯.
  const [pendingRemovedAdded, setPendingRemovedAdded] = useState<Set<number>>(() => new Set());
  // base added_rows 중 사용자가 ✕ 클릭으로 제거 의도를 표시한 row_idx 들 (행 버전).
  const [pendingRemovedAddedRows, setPendingRemovedAddedRows] = useState<Set<number>>(() => new Set());
  // 사용자가 드래그 reorder 한 순서. null = 사용자 변경 없음 (서버 순서 또는 asc 폴백 사용).
  // 배열 안에는 added col_idx / row_idx 만 들어있고 base 는 포함하지 않는다.
  const [pendingColsOrderOverride, setPendingColsOrderOverride] = useState<number[] | null>(null);
  const [pendingRowsOrderOverride, setPendingRowsOrderOverride] = useState<number[] | null>(null);
  // 전체 컬럼/행 순서 override (base + added 통합). null = 변경 없음.
  // 사용자가 추가 컬럼을 base 컬럼 사이로 drag 하면 이쪽이 채워진다.
  const [pendingColumnOrderOverride, setPendingColumnOrderOverride] = useState<number[] | null>(null);
  const [pendingRowOrderOverride, setPendingRowOrderOverride] = useState<number[] | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  // history is a ref, not state — undo reads/writes synchronously without forcing re-render.
  // The pending state update inside undo() drives any visual change.
  const historyRef = useRef<HistoryEntry[]>([]);
  const [historyVersion, setHistoryVersion] = useState(0);

  // Keep a ref to base values for the cell-dirty diff so callbacks don't
  // have to be re-bound on every items refetch.
  const baseValueRef = useRef(baseValueByRef);
  useEffect(() => { baseValueRef.current = baseValueByRef; }, [baseValueByRef]);

  // base added_columns 도 ref 로 보관 — save() 에서 stale 한 closure 가 잡히지 않게.
  const baseAddedColsKey = useMemo(
    () => baseAddedColumns.map((c) => `${c.col_idx}:${c.header}`).join('|'),
    [baseAddedColumns],
  );
  const baseAddedColsRef = useRef(baseAddedColumns);
  useEffect(() => { baseAddedColsRef.current = baseAddedColumns; }, [baseAddedColsKey]); // eslint-disable-line react-hooks/exhaustive-deps
  const baseAddedRowsRef = useRef(baseAddedRows ?? []);
  useEffect(() => { baseAddedRowsRef.current = baseAddedRows ?? []; }, [baseAddedRows]);
  const baseRenamedRef = useRef(baseRenamedHeaders ?? {});
  useEffect(() => { baseRenamedRef.current = baseRenamedHeaders ?? {}; }, [baseRenamedHeaders]);
  const baseAddedColsOrderRef = useRef<number[] | undefined>(baseAddedColumnsOrder);
  useEffect(() => { baseAddedColsOrderRef.current = baseAddedColumnsOrder; }, [baseAddedColumnsOrder]);
  const baseAddedRowsOrderRef = useRef<number[] | undefined>(baseAddedRowsOrder);
  useEffect(() => { baseAddedRowsOrderRef.current = baseAddedRowsOrder; }, [baseAddedRowsOrder]);
  const baseColIndicesRef = useRef<number[] | undefined>(baseColIndices);
  useEffect(() => { baseColIndicesRef.current = baseColIndices; }, [baseColIndices]);
  const baseRowIndicesRef = useRef<number[] | undefined>(baseRowIndices);
  useEffect(() => { baseRowIndicesRef.current = baseRowIndices; }, [baseRowIndices]);
  const baseColumnOrderRef = useRef<number[] | undefined>(baseColumnOrder);
  useEffect(() => { baseColumnOrderRef.current = baseColumnOrder; }, [baseColumnOrder]);
  const baseRowOrderRef = useRef<number[] | undefined>(baseRowOrder);
  useEffect(() => { baseRowOrderRef.current = baseRowOrder; }, [baseRowOrder]);
  const nextAddedColIdxRef = useRef(nextAddedColIdx);
  useEffect(() => { nextAddedColIdxRef.current = nextAddedColIdx; }, [nextAddedColIdx]);
  const nextAddedRowIdxRef = useRef(nextAddedRowIdx);
  useEffect(() => { nextAddedRowIdxRef.current = nextAddedRowIdx; }, [nextAddedRowIdx]);

  const baseHiddenRowsKey = useMemo(() => baseHiddenRows.slice().sort((a, b) => a - b).join(','), [baseHiddenRows]);
  const baseHiddenColsKey = useMemo(() => baseHiddenCols.slice().sort((a, b) => a - b).join(','), [baseHiddenCols]);

  const baseHiddenRowSet = useMemo(() => new Set(baseHiddenRows), [baseHiddenRowsKey]); // eslint-disable-line react-hooks/exhaustive-deps
  const baseHiddenColSet = useMemo(() => new Set(baseHiddenCols), [baseHiddenColsKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const effectiveHiddenRows = useMemo(() => {
    const s = new Set(baseHiddenRowSet);
    pending.hiddenRows.forEach((r) => s.add(r));
    return s;
  }, [baseHiddenRowSet, pending.hiddenRows]);

  const effectiveHiddenCols = useMemo(() => {
    const s = new Set(baseHiddenColSet);
    pending.hiddenCols.forEach((c) => s.add(c));
    return s;
  }, [baseHiddenColSet, pending.hiddenCols]);

  const resolveCellValue = useCallback(
    (cellRef: string) => {
      const overridden = pending.dirtyCells.get(cellRef);
      if (overridden !== undefined) return overridden;
      return baseValueRef.current.get(cellRef) ?? '';
    },
    [pending.dirtyCells],
  );

  const isCellDirty = useCallback(
    (cellRef: string) => pending.dirtyCells.has(cellRef),
    [pending.dirtyCells],
  );

  const isRowHiddenLocally = useCallback(
    (rowIdx: number) => pending.hiddenRows.has(rowIdx),
    [pending.hiddenRows],
  );
  const isColHiddenLocally = useCallback(
    (colIdx: number) => pending.hiddenCols.has(colIdx),
    [pending.hiddenCols],
  );

  const pushHistory = useCallback((entry: HistoryEntry) => {
    historyRef.current.push(entry);
    setHistoryVersion((v) => v + 1);
  }, []);

  const setCellValue = useCallback(
    (rowIdx: number, colIdx: number, value: string) => {
      const ref = makeCellRef(rowIdx, colIdx);
      let prevForHistory: string | undefined;
      setPending((prev) => {
        prevForHistory = prev.dirtyCells.get(ref); // undefined ⇒ no pending entry yet
        const next = { ...prev, dirtyCells: new Map(prev.dirtyCells) };
        const base = baseValueRef.current.get(ref) ?? '';
        if (value === base) {
          next.dirtyCells.delete(ref);
        } else {
          next.dirtyCells.set(ref, value);
        }
        pendingRef.current = next; // save() 가 동기적으로 최신 값을 읽도록
        return next;
      });
      pushHistory({ kind: 'cell', ref, prev: prevForHistory });
    },
    [pushHistory],
  );

  const swapEquipment = useCallback(
    (src: { row: number; col: number }, dst: { row: number; col: number }) => {
      const srcRef = makeCellRef(src.row, src.col);
      const dstRef = makeCellRef(dst.row, dst.col);
      let prevSrcForHistory: string | undefined;
      let prevDstForHistory: string | undefined;
      setPending((prev) => {
        prevSrcForHistory = prev.dirtyCells.get(srcRef);
        prevDstForHistory = prev.dirtyCells.get(dstRef);
        const next = { ...prev, dirtyCells: new Map(prev.dirtyCells) };
        // resolve current values from this same pending snapshot so two-step
        // swaps inside one user action stay consistent.
        const cur = (ref: string) => {
          const o = next.dirtyCells.get(ref);
          if (o !== undefined) return o;
          return baseValueRef.current.get(ref) ?? '';
        };
        const srcVal = cur(srcRef);
        const dstVal = cur(dstRef);
        const writeRef = (ref: string, v: string) => {
          const base = baseValueRef.current.get(ref) ?? '';
          if (v === base) next.dirtyCells.delete(ref);
          else next.dirtyCells.set(ref, v);
        };
        writeRef(srcRef, dstVal);
        writeRef(dstRef, srcVal);
        pendingRef.current = next; // save() 가 동기적으로 최신 값을 읽도록
        return next;
      });
      pushHistory({
        kind: 'swap', srcRef, dstRef,
        prevSrc: prevSrcForHistory, prevDst: prevDstForHistory,
      });
    },
    [pushHistory],
  );

  const hideRow = useCallback((rowIdx: number) => {
    let actuallyAdded = false;
    setPending((prev) => {
      if (prev.hiddenRows.has(rowIdx)) return prev;
      const next = { ...prev, hiddenRows: new Set(prev.hiddenRows) };
      next.hiddenRows.add(rowIdx);
      actuallyAdded = true;
      return next;
    });
    if (actuallyAdded) pushHistory({ kind: 'hideRow', row: rowIdx });
  }, [pushHistory]);
  const unhideRow = useCallback((rowIdx: number) => {
    let actuallyRemoved = false;
    setPending((prev) => {
      if (!prev.hiddenRows.has(rowIdx)) return prev;
      const next = { ...prev, hiddenRows: new Set(prev.hiddenRows) };
      next.hiddenRows.delete(rowIdx);
      actuallyRemoved = true;
      return next;
    });
    if (actuallyRemoved) pushHistory({ kind: 'unhideRow', row: rowIdx });
  }, [pushHistory]);
  const hideCol = useCallback((colIdx: number) => {
    let actuallyAdded = false;
    setPending((prev) => {
      if (prev.hiddenCols.has(colIdx)) return prev;
      const next = { ...prev, hiddenCols: new Set(prev.hiddenCols) };
      next.hiddenCols.add(colIdx);
      actuallyAdded = true;
      return next;
    });
    if (actuallyAdded) pushHistory({ kind: 'hideCol', col: colIdx });
  }, [pushHistory]);
  const unhideCol = useCallback((colIdx: number) => {
    let actuallyRemoved = false;
    setPending((prev) => {
      if (!prev.hiddenCols.has(colIdx)) return prev;
      const next = { ...prev, hiddenCols: new Set(prev.hiddenCols) };
      next.hiddenCols.delete(colIdx);
      actuallyRemoved = true;
      return next;
    });
    if (actuallyRemoved) pushHistory({ kind: 'unhideCol', col: colIdx });
  }, [pushHistory]);

  /**
   * base + pending - removed 합친 added_columns. col_idx 오름차순.
   * pending 과 base 에 동일 col_idx 가 있으면 pending 이 우선(rename 대비).
   * pending.renamedColumns 가 있으면 header 를 덮어쓴다 (추가 컬럼 rename 도 동일 슬롯 사용).
   */
  const effectiveAddedColumns = useMemo<AddedColumn[]>(() => {
    const map = new Map<number, AddedColumn>();
    baseAddedColumns.forEach((c) => {
      if (pendingRemovedAdded.has(c.col_idx)) return;
      map.set(c.col_idx, c);
    });
    pending.addedColumns.forEach((c) => { map.set(c.col_idx, c); });
    // rename 적용
    pending.renamedColumns.forEach((header, col) => {
      const existing = map.get(col);
      if (existing) map.set(col, { ...existing, header });
    });
    return Array.from(map.values()).sort((a, b) => a.col_idx - b.col_idx);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseAddedColsKey, pending.addedColumns, pending.renamedColumns, pendingRemovedAdded]);

  const isAddedColumn = useCallback(
    (colIdx: number) => effectiveAddedColumns.some((c) => c.col_idx === colIdx),
    [effectiveAddedColumns],
  );

  /**
   * 표시용 헤더. 우선순위: pending.renamedColumns → baseRenamedHeaders(서버 저장) →
   * 인자로 받은 baseHeader (호출측이 grid 에서 계산한 원본 헤더 텍스트).
   * 추가 컬럼은 effectiveAddedColumns 가 이미 rename 적용된 header 를 갖고 있으므로
   * 호출측에서 baseHeader 자리에 added column 의 header 를 넘기면 OK.
   */
  const effectiveHeaderFor = useCallback(
    (colIdx: number, baseHeader: string): string => {
      const pendingRename = pending.renamedColumns.get(colIdx);
      if (pendingRename !== undefined) return pendingRename;
      const serverRename = baseRenamedRef.current[String(colIdx)];
      if (serverRename !== undefined) return serverRename;
      return baseHeader;
    },
    [pending.renamedColumns],
  );

  /**
   * 새 컬럼 추가 — 자동 명명/자동 col_idx 로직 공통.
   *   prefix='설비'    → "설비1, 설비2…" 자동 명명, kind='equipment'
   *   prefix='새 컬럼' → "새 컬럼1, 새 컬럼2…" 자동 명명, kind='plain'
   * 이미 사용된 N 은 건너뛰고, col_idx 도 base/pending 에서 빈 idx 를 찾는다.
   */
  const addColumnInternal = useCallback((kind: AddedColumnKind, prefix: string): AddedColumn => {
    let assigned: AddedColumn = { col_idx: 0, header: `${prefix}1`, kind };
    setPending((prev) => {
      const used = new Set<number>();
      const re = new RegExp(`^${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\d+)$`);
      const harvest = (h: string) => {
        const m = re.exec(h.replace(/\s+/g, ''));
        if (m) used.add(Number(m[1]));
      };
      baseAddedColsRef.current.forEach((c) => {
        if (pendingRemovedAdded.has(c.col_idx)) return;
        const renamed = prev.renamedColumns.get(c.col_idx);
        harvest(renamed !== undefined ? renamed : c.header);
      });
      prev.addedColumns.forEach((c) => {
        const renamed = prev.renamedColumns.get(c.col_idx);
        harvest(renamed !== undefined ? renamed : c.header);
      });
      let n = 1;
      while (used.has(n)) n += 1;
      const allTaken = new Set<number>([
        ...baseAddedColsRef.current.map((c) => c.col_idx),
        ...prev.addedColumns.map((c) => c.col_idx),
      ]);
      let nextCol = nextAddedColIdxRef.current;
      while (allTaken.has(nextCol)) nextCol += 1;
      assigned = { col_idx: nextCol, header: `${prefix}${n}`, kind };
      return { ...prev, addedColumns: [...prev.addedColumns, assigned] };
    });
    pushHistory({ kind: 'addCol', column: assigned });
    return assigned;
  }, [pushHistory, pendingRemovedAdded]);

  const addEquipmentColumn = useCallback(
    () => addColumnInternal('equipment', '설비'),
    [addColumnInternal],
  );
  const addPlainColumn = useCallback(
    () => addColumnInternal('plain', '새 컬럼'),
    [addColumnInternal],
  );

  /**
   * 헤더 이름 변경. base/added 동일 슬롯(pending.renamedColumns) 사용.
   * 빈 문자열을 넘기면 rename 자체를 취소한다 (base header 로 회귀).
   * 변경이 없는 호출은 history 를 쌓지 않는다.
   */
  const renameColumn = useCallback((colIdx: number, newHeader: string) => {
    const next = newHeader.trim();
    let prev: string | undefined;
    let actuallyChanged = false;
    setPending((prevState) => {
      const renamedNext = new Map(prevState.renamedColumns);
      prev = renamedNext.get(colIdx);
      if (next === '') {
        if (!renamedNext.has(colIdx)) return prevState;
        renamedNext.delete(colIdx);
      } else {
        if (renamedNext.get(colIdx) === next) return prevState;
        renamedNext.set(colIdx, next);
      }
      actuallyChanged = true;
      return { ...prevState, renamedColumns: renamedNext };
    });
    if (actuallyChanged) pushHistory({ kind: 'rename', col: colIdx, prev });
  }, [pushHistory]);

  /**
   * base + pending - removed 합친 added_rows. row_idx 오름차순.
   */
  const baseAddedRowsKey = useMemo(
    () => (baseAddedRows ?? []).map((r) => r.row_idx).sort((a, b) => a - b).join(','),
    [baseAddedRows],
  );
  const effectiveAddedRows = useMemo<AddedRow[]>(() => {
    const base = baseAddedRowsRef.current ?? [];
    const map = new Map<number, AddedRow>();
    base.forEach((r) => {
      if (pendingRemovedAddedRows.has(r.row_idx)) return;
      map.set(r.row_idx, r);
    });
    pending.addedRows.forEach((r) => map.set(r.row_idx, r));
    return Array.from(map.values()).sort((a, b) => a.row_idx - b.row_idx);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseAddedRowsKey, pending.addedRows, pendingRemovedAddedRows]);

  const isAddedRow = useCallback(
    (rowIdx: number) => effectiveAddedRows.some((r) => r.row_idx === rowIdx),
    [effectiveAddedRows],
  );

  /**
   * added 컬럼/행의 렌더 순서. 우선순위:
   *   1) 사용자가 드래그 reorder 한 override (pending)
   *   2) 서버에 저장된 순서 (base*Order)
   *   3) col_idx / row_idx 오름차순 (effectiveAdded* 와 동일)
   * 어느 단계든 effectiveAdded* 에 없는 idx 는 무시하고, 누락된 idx 는 끝에 asc 로 덧붙인다.
   */
  const normalizeOrder = (raw: number[] | null | undefined, validIdxs: number[]): number[] => {
    const valid = new Set(validIdxs);
    const seen = new Set<number>();
    const out: number[] = [];
    if (raw) {
      for (const v of raw) {
        if (!valid.has(v) || seen.has(v)) continue;
        seen.add(v); out.push(v);
      }
    }
    validIdxs.slice().sort((a, b) => a - b).forEach((v) => {
      if (!seen.has(v)) out.push(v);
    });
    return out;
  };
  const effectiveAddedColsOrder = useMemo(() => {
    const idxs = effectiveAddedColumns.map((c) => c.col_idx);
    const raw = pendingColsOrderOverride ?? baseAddedColsOrderRef.current ?? null;
    return normalizeOrder(raw, idxs);
  }, [effectiveAddedColumns, pendingColsOrderOverride]);
  const effectiveAddedRowsOrder = useMemo(() => {
    const idxs = effectiveAddedRows.map((r) => r.row_idx);
    const raw = pendingRowsOrderOverride ?? baseAddedRowsOrderRef.current ?? null;
    return normalizeOrder(raw, idxs);
  }, [effectiveAddedRows, pendingRowsOrderOverride]);

  /**
   * 전체 컬럼/행 통합 순서. baseColIndices 가 제공된 경우만 의미가 있다.
   * 우선순위: 사용자 override → 서버 column_order → (base asc + added in effectiveAddedColsOrder).
   * raw 에 등장한 base/added idx 만 그대로 따르고, 누락된 idx 는
   *   1) 누락 base 는 base asc 기준 가능한 가까운 위치
   *   2) 누락 added 는 끝에 effectiveAddedColsOrder 순으로 덧붙임
   * 으로 보충한다 (간단히 base 누락은 앞에, added 누락은 뒤에 추가).
   */
  const baseColIndicesKey = useMemo(
    () => (baseColIndices ?? []).slice().sort((a, b) => a - b).join(','),
    [baseColIndices],
  );
  const baseRowIndicesKey = useMemo(
    () => (baseRowIndices ?? []).slice().sort((a, b) => a - b).join(','),
    [baseRowIndices],
  );
  const effectiveColumnOrder = useMemo(() => {
    const baseIdxs = baseColIndicesRef.current ?? [];
    const addedIdxs = effectiveAddedColumns.map((c) => c.col_idx);
    if (baseIdxs.length === 0 && addedIdxs.length === 0) return [];
    const validSet = new Set<number>([...baseIdxs, ...addedIdxs]);
    const raw = pendingColumnOrderOverride ?? baseColumnOrderRef.current ?? null;
    const seen = new Set<number>();
    const out: number[] = [];
    if (raw) {
      for (const v of raw) {
        if (!validSet.has(v) || seen.has(v)) continue;
        seen.add(v); out.push(v);
      }
    }
    // 누락된 base 는 asc, 누락된 added 는 effectiveAddedColsOrder 순으로 뒤에 보충.
    baseIdxs.slice().sort((a, b) => a - b).forEach((v) => {
      if (!seen.has(v)) { seen.add(v); out.push(v); }
    });
    effectiveAddedColsOrder.forEach((v) => {
      if (!seen.has(v)) { seen.add(v); out.push(v); }
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseColIndicesKey, effectiveAddedColumns, effectiveAddedColsOrder, pendingColumnOrderOverride]);
  const effectiveRowOrder = useMemo(() => {
    const baseIdxs = baseRowIndicesRef.current ?? [];
    const addedIdxs = effectiveAddedRows.map((r) => r.row_idx);
    if (baseIdxs.length === 0 && addedIdxs.length === 0) return [];
    const validSet = new Set<number>([...baseIdxs, ...addedIdxs]);
    const raw = pendingRowOrderOverride ?? baseRowOrderRef.current ?? null;
    const seen = new Set<number>();
    const out: number[] = [];
    if (raw) {
      for (const v of raw) {
        if (!validSet.has(v) || seen.has(v)) continue;
        seen.add(v); out.push(v);
      }
    }
    baseIdxs.slice().sort((a, b) => a - b).forEach((v) => {
      if (!seen.has(v)) { seen.add(v); out.push(v); }
    });
    effectiveAddedRowsOrder.forEach((v) => {
      if (!seen.has(v)) { seen.add(v); out.push(v); }
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseRowIndicesKey, effectiveAddedRows, effectiveAddedRowsOrder, pendingRowOrderOverride]);

  const reorderAddedColumns = useCallback((newOrder: number[]) => {
    let actuallyChanged = false;
    let prevSnapshot: number[] | null = null;
    setPendingColsOrderOverride((prev) => {
      prevSnapshot = prev === null ? null : prev.slice();
      const same = prev !== null && prev.length === newOrder.length && prev.every((v, i) => v === newOrder[i]);
      if (same) return prev;
      actuallyChanged = true;
      return newOrder.slice();
    });
    if (actuallyChanged) pushHistory({ kind: 'reorderCols', prev: prevSnapshot });
  }, [pushHistory]);
  const reorderAddedRows = useCallback((newOrder: number[]) => {
    let actuallyChanged = false;
    let prevSnapshot: number[] | null = null;
    setPendingRowsOrderOverride((prev) => {
      prevSnapshot = prev === null ? null : prev.slice();
      const same = prev !== null && prev.length === newOrder.length && prev.every((v, i) => v === newOrder[i]);
      if (same) return prev;
      actuallyChanged = true;
      return newOrder.slice();
    });
    if (actuallyChanged) pushHistory({ kind: 'reorderRows', prev: prevSnapshot });
  }, [pushHistory]);

  const reorderColumns = useCallback((newOrder: number[]) => {
    let actuallyChanged = false;
    let prevSnapshot: number[] | null = null;
    setPendingColumnOrderOverride((prev) => {
      prevSnapshot = prev === null ? null : prev.slice();
      const same = prev !== null && prev.length === newOrder.length && prev.every((v, i) => v === newOrder[i]);
      if (same) return prev;
      actuallyChanged = true;
      return newOrder.slice();
    });
    if (actuallyChanged) pushHistory({ kind: 'reorderColumnsAll', prev: prevSnapshot });
  }, [pushHistory]);
  const reorderRows = useCallback((newOrder: number[]) => {
    let actuallyChanged = false;
    let prevSnapshot: number[] | null = null;
    setPendingRowOrderOverride((prev) => {
      prevSnapshot = prev === null ? null : prev.slice();
      const same = prev !== null && prev.length === newOrder.length && prev.every((v, i) => v === newOrder[i]);
      if (same) return prev;
      actuallyChanged = true;
      return newOrder.slice();
    });
    if (actuallyChanged) pushHistory({ kind: 'reorderRowsAll', prev: prevSnapshot });
  }, [pushHistory]);

  const addRow = useCallback((): AddedRow => {
    let assigned: AddedRow = { row_idx: 0 };
    setPending((prev) => {
      const allTaken = new Set<number>([
        ...(baseAddedRowsRef.current ?? []).map((r) => r.row_idx),
        ...prev.addedRows.map((r) => r.row_idx),
      ]);
      let nextRow = nextAddedRowIdxRef.current;
      while (allTaken.has(nextRow)) nextRow += 1;
      assigned = { row_idx: nextRow };
      return { ...prev, addedRows: [...prev.addedRows, assigned] };
    });
    pushHistory({ kind: 'addRow', row: assigned });
    return assigned;
  }, [pushHistory]);

  const removeAddedRow = useCallback((rowIdx: number) => {
    let pendingEntry: AddedRow | null = null;
    setPending((prev) => {
      const idx = prev.addedRows.findIndex((r) => r.row_idx === rowIdx);
      if (idx < 0) return prev;
      pendingEntry = prev.addedRows[idx];
      const next = { ...prev, addedRows: prev.addedRows.slice() };
      next.addedRows.splice(idx, 1);
      return next;
    });
    if (pendingEntry) {
      pushHistory({ kind: 'removeAddedRow', row: pendingEntry, wasInBase: false });
      return;
    }
    const baseHit = (baseAddedRowsRef.current ?? []).find((r) => r.row_idx === rowIdx);
    if (baseHit) {
      setPendingRemovedAddedRows((prev) => {
        if (prev.has(rowIdx)) return prev;
        const next = new Set(prev);
        next.add(rowIdx);
        return next;
      });
      pushHistory({ kind: 'removeAddedRow', row: baseHit, wasInBase: true });
    }
  }, [pushHistory]);

  const removeAddedColumn = useCallback((colIdx: number) => {
    // 1) pending 에 있으면 거기서 splice
    let pendingEntry: AddedColumn | null = null;
    setPending((prev) => {
      const idx = prev.addedColumns.findIndex((c) => c.col_idx === colIdx);
      if (idx < 0) return prev;
      pendingEntry = prev.addedColumns[idx];
      const next = { ...prev, addedColumns: prev.addedColumns.slice() };
      next.addedColumns.splice(idx, 1);
      return next;
    });
    if (pendingEntry) {
      pushHistory({ kind: 'removeAddedCol', column: pendingEntry, wasInBase: false });
      return;
    }
    // 2) base 측에 있으면 제거 set 에 등록
    const baseHit = baseAddedColsRef.current.find((c) => c.col_idx === colIdx);
    if (baseHit) {
      setPendingRemovedAdded((prev) => {
        if (prev.has(colIdx)) return prev;
        const next = new Set(prev);
        next.add(colIdx);
        return next;
      });
      pushHistory({ kind: 'removeAddedCol', column: baseHit, wasInBase: true });
    }
  }, [pushHistory]);

  /**
   * Drop pending hidden rows/cols *without* recording history entries — used
   * by the "되돌리기" bulk button. Cell edits stay; only the local hide
   * intentions are dropped.
   */
  const clearPendingHidden = useCallback(() => {
    setPending((prev) => {
      if (prev.hiddenRows.size === 0 && prev.hiddenCols.size === 0) return prev;
      return { ...prev, hiddenRows: new Set<number>(), hiddenCols: new Set<number>() };
    });
    // collapse history: drop any hide/unhide entries so a later undo doesn't
    // resurrect a row we just bulk-cleared.
    historyRef.current = historyRef.current.filter(
      (e) => e.kind === 'cell' || e.kind === 'swap',
    );
    setHistoryVersion((v) => v + 1);
  }, []);

  /**
   * Pop the latest history entry and revert it. Cell edits revert by
   * restoring whatever was in dirtyCells before (undefined ⇒ remove the
   * entry, so the cell goes back to base value).
   */
  const undo = useCallback(() => {
    const entry = historyRef.current.pop();
    if (!entry) return;
    setHistoryVersion((v) => v + 1);
    setPending((prev) => {
      const next: PendingChanges = {
        ...prev,
        dirtyCells: new Map(prev.dirtyCells),
        hiddenRows: new Set(prev.hiddenRows),
        hiddenCols: new Set(prev.hiddenCols),
      };
      const restoreCell = (ref: string, prevVal: string | undefined) => {
        if (prevVal === undefined) next.dirtyCells.delete(ref);
        else next.dirtyCells.set(ref, prevVal);
      };
      switch (entry.kind) {
        case 'cell':
          restoreCell(entry.ref, entry.prev);
          break;
        case 'swap':
          restoreCell(entry.srcRef, entry.prevSrc);
          restoreCell(entry.dstRef, entry.prevDst);
          break;
        case 'hideRow':
          next.hiddenRows.delete(entry.row);
          break;
        case 'unhideRow':
          next.hiddenRows.add(entry.row);
          break;
        case 'hideCol':
          next.hiddenCols.delete(entry.col);
          break;
        case 'unhideCol':
          next.hiddenCols.add(entry.col);
          break;
        case 'addCol': {
          // 사용자가 추가했던 컬럼 → pending 에서 제거
          const idx = next.addedColumns.findIndex((c) => c.col_idx === entry.column.col_idx);
          if (idx >= 0) {
            next.addedColumns = next.addedColumns.slice();
            next.addedColumns.splice(idx, 1);
          }
          break;
        }
        case 'removeAddedCol': {
          if (entry.wasInBase) {
            // base 컬럼 제거 의도를 취소 → removed set 에서 제거
            setPendingRemovedAdded((rm) => {
              if (!rm.has(entry.column.col_idx)) return rm;
              const nrm = new Set(rm);
              nrm.delete(entry.column.col_idx);
              return nrm;
            });
          } else {
            // pending 에서 제거했던 컬럼을 다시 추가
            const exists = next.addedColumns.some((c) => c.col_idx === entry.column.col_idx);
            if (!exists) {
              next.addedColumns = [...next.addedColumns, entry.column].sort((a, b) => a.col_idx - b.col_idx);
            }
          }
          break;
        }
        case 'rename': {
          const renamedNext = new Map(prev.renamedColumns);
          if (entry.prev === undefined) renamedNext.delete(entry.col);
          else renamedNext.set(entry.col, entry.prev);
          next.renamedColumns = renamedNext;
          break;
        }
        case 'addRow': {
          const idx = next.addedRows.findIndex((r) => r.row_idx === entry.row.row_idx);
          if (idx >= 0) {
            next.addedRows = next.addedRows.slice();
            next.addedRows.splice(idx, 1);
          }
          break;
        }
        case 'removeAddedRow': {
          if (entry.wasInBase) {
            setPendingRemovedAddedRows((rm) => {
              if (!rm.has(entry.row.row_idx)) return rm;
              const nrm = new Set(rm);
              nrm.delete(entry.row.row_idx);
              return nrm;
            });
          } else {
            const exists = next.addedRows.some((r) => r.row_idx === entry.row.row_idx);
            if (!exists) {
              next.addedRows = [...next.addedRows, entry.row].sort((a, b) => a.row_idx - b.row_idx);
            }
          }
          break;
        }
        case 'reorderCols':
          setPendingColsOrderOverride(entry.prev === null ? null : entry.prev.slice());
          break;
        case 'reorderRows':
          setPendingRowsOrderOverride(entry.prev === null ? null : entry.prev.slice());
          break;
        case 'reorderColumnsAll':
          setPendingColumnOrderOverride(entry.prev === null ? null : entry.prev.slice());
          break;
        case 'reorderRowsAll':
          setPendingRowOrderOverride(entry.prev === null ? null : entry.prev.slice());
          break;
      }
      return next;
    });
  }, []);

  const canUndo = historyVersion > 0 && historyRef.current.length > 0;

  const dirtyCount =
    pending.dirtyCells.size +
    pending.hiddenRows.size +
    pending.hiddenCols.size +
    pending.addedColumns.length +
    pendingRemovedAdded.size +
    pending.renamedColumns.size +
    pending.addedRows.length +
    pendingRemovedAddedRows.size +
    (pendingColsOrderOverride !== null ? 1 : 0) +
    (pendingRowsOrderOverride !== null ? 1 : 0) +
    (pendingColumnOrderOverride !== null ? 1 : 0) +
    (pendingRowOrderOverride !== null ? 1 : 0);
  const isDirty = dirtyCount > 0;

  // beforeunload guard
  useEffect(() => {
    if (!isDirty) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [isDirty]);

  const save = useCallback(async () => {
    if (saving) return;
    // closure 의 stale pending 대신 최신 스냅샷을 사용 (Save 직전 blur 커밋 누락 방지).
    const pending = pendingRef.current;
    const hadStructureChange =
      pending.addedColumns.length > 0 ||
      pendingRemovedAdded.size > 0 ||
      pending.renamedColumns.size > 0 ||
      pending.addedRows.length > 0 ||
      pendingRemovedAddedRows.size > 0 ||
      pendingColsOrderOverride !== null ||
      pendingRowsOrderOverride !== null ||
      pendingColumnOrderOverride !== null ||
      pendingRowOrderOverride !== null;
    if (
      pending.dirtyCells.size === 0 &&
      pending.hiddenRows.size === 0 &&
      pending.hiddenCols.size === 0 &&
      !hadStructureChange
    ) {
      return;
    }
    setSaving(true);
    setSaveError(null);

    // 1) structure_overlay flush (full overwrite). 추가 컬럼들이 서버에 먼저
    //    존재해야 그 셀 ref 들이 의미를 갖기 때문에 셀/숨김보다 먼저.
    let structureFailed = false;
    if (hadStructureChange) {
      try {
        // 추가 컬럼 col_idx 집합 — rename 이 추가 컬럼이면 added_columns.header 에 직접 반영,
        // base 컬럼이면 renamed_headers 에 반영.
        const addedColIdxSet = new Set<number>([
          ...baseAddedColsRef.current.map((c) => c.col_idx),
          ...pending.addedColumns.map((c) => c.col_idx),
        ]);
        const mergedAdded: AddedColumn[] = (() => {
          const map = new Map<number, AddedColumn>();
          baseAddedColsRef.current.forEach((c) => {
            if (pendingRemovedAdded.has(c.col_idx)) return;
            map.set(c.col_idx, c);
          });
          pending.addedColumns.forEach((c) => map.set(c.col_idx, c));
          // 추가 컬럼 rename → header 직접 덮어쓰기
          pending.renamedColumns.forEach((header, col) => {
            const existing = map.get(col);
            if (existing) map.set(col, { ...existing, header });
          });
          return Array.from(map.values()).sort((a, b) => a.col_idx - b.col_idx);
        })();
        // base 컬럼 rename 만 renamed_headers 에 누적. 서버 기존값과 머지.
        const mergedRenamedHeaders: Record<string, string> = { ...baseRenamedRef.current };
        pending.renamedColumns.forEach((header, col) => {
          if (addedColIdxSet.has(col)) return; // 추가 컬럼은 added_columns header 로 흘러감
          mergedRenamedHeaders[String(col)] = header;
        });
        // added_rows 머지 — 제거 의도 행 빼고, pending 추가 행 누적.
        const mergedAddedRows: AddedRow[] = (() => {
          const map = new Map<number, AddedRow>();
          (baseAddedRowsRef.current ?? []).forEach((r) => {
            if (pendingRemovedAddedRows.has(r.row_idx)) return;
            map.set(r.row_idx, r);
          });
          pending.addedRows.forEach((r) => map.set(r.row_idx, r));
          return Array.from(map.values()).sort((a, b) => a.row_idx - b.row_idx);
        })();
        // 순서 머지: 사용자 override 가 있으면 그걸, 없으면 서버 기존값(있으면). 서버가 잘못된
        // idx 도 _normalize_order 로 정리해 주니 클라에서는 가능한 그대로 보낸다.
        const mergedColsOrder: number[] = (() => {
          const validIdxs = new Set(mergedAdded.map((c) => c.col_idx));
          const raw = pendingColsOrderOverride ?? baseAddedColsOrderRef.current ?? null;
          const seen = new Set<number>();
          const out: number[] = [];
          if (raw) {
            for (const v of raw) {
              if (!validIdxs.has(v) || seen.has(v)) continue;
              seen.add(v); out.push(v);
            }
          }
          [...validIdxs].sort((a, b) => a - b).forEach((v) => { if (!seen.has(v)) out.push(v); });
          return out;
        })();
        const mergedRowsOrder: number[] = (() => {
          const validIdxs = new Set(mergedAddedRows.map((r) => r.row_idx));
          const raw = pendingRowsOrderOverride ?? baseAddedRowsOrderRef.current ?? null;
          const seen = new Set<number>();
          const out: number[] = [];
          if (raw) {
            for (const v of raw) {
              if (!validIdxs.has(v) || seen.has(v)) continue;
              seen.add(v); out.push(v);
            }
          }
          [...validIdxs].sort((a, b) => a - b).forEach((v) => { if (!seen.has(v)) out.push(v); });
          return out;
        })();
        // 전체 컬럼/행 통합 순서 머지: 사용자 override 우선, 없으면 서버 기존값.
        // valid 검증은 백엔드에서도 진행하지만, 클라에서도 base + added 합집합으로 한 번 거른다.
        const mergedColumnOrder: number[] | undefined = (() => {
          const baseIdxs = baseColIndicesRef.current ?? [];
          const validSet = new Set<number>([...baseIdxs, ...mergedAdded.map((c) => c.col_idx)]);
          const raw = pendingColumnOrderOverride ?? baseColumnOrderRef.current ?? null;
          if (raw === null && pendingColumnOrderOverride === null) return undefined;
          if (!raw) return undefined;
          const seen = new Set<number>();
          const out: number[] = [];
          for (const v of raw) {
            if (!validSet.has(v) || seen.has(v)) continue;
            seen.add(v); out.push(v);
          }
          baseIdxs.slice().sort((a, b) => a - b).forEach((v) => {
            if (!seen.has(v)) { seen.add(v); out.push(v); }
          });
          mergedAdded.forEach((c) => {
            if (!seen.has(c.col_idx)) { seen.add(c.col_idx); out.push(c.col_idx); }
          });
          return out;
        })();
        const mergedRowOrder: number[] | undefined = (() => {
          const baseIdxs = baseRowIndicesRef.current ?? [];
          const validSet = new Set<number>([...baseIdxs, ...mergedAddedRows.map((r) => r.row_idx)]);
          const raw = pendingRowOrderOverride ?? baseRowOrderRef.current ?? null;
          if (raw === null && pendingRowOrderOverride === null) return undefined;
          if (!raw) return undefined;
          const seen = new Set<number>();
          const out: number[] = [];
          for (const v of raw) {
            if (!validSet.has(v) || seen.has(v)) continue;
            seen.add(v); out.push(v);
          }
          baseIdxs.slice().sort((a, b) => a - b).forEach((v) => {
            if (!seen.has(v)) { seen.add(v); out.push(v); }
          });
          mergedAddedRows.forEach((r) => {
            if (!seen.has(r.row_idx)) { seen.add(r.row_idx); out.push(r.row_idx); }
          });
          return out;
        })();
        const overlayPayload: {
          added_columns: AddedColumn[];
          added_rows: AddedRow[];
          renamed_headers: Record<string, string>;
          added_columns_order: number[];
          added_rows_order: number[];
          column_order?: number[];
          row_order?: number[];
        } = {
          added_columns: mergedAdded,
          added_rows: mergedAddedRows,
          renamed_headers: mergedRenamedHeaders,
          added_columns_order: mergedColsOrder,
          added_rows_order: mergedRowsOrder,
        };
        if (mergedColumnOrder !== undefined) overlayPayload.column_order = mergedColumnOrder;
        if (mergedRowOrder !== undefined) overlayPayload.row_order = mergedRowOrder;
        await api.updateSheetStructureOverlay(executionId, overlayPayload, userId);
      } catch {
        structureFailed = true;
      }
    }

    const cellEntries = Array.from(pending.dirtyCells.entries());
    const hadHiddenRows = pending.hiddenRows.size > 0;
    const hadHiddenCols = pending.hiddenCols.size > 0;

    const cellResults = await Promise.allSettled(
      cellEntries.map(([cellRef, value]) =>
        api.upsertSheetExecutionCell(executionId, cellRef, { value }, userId),
      ),
    );
    const failedCellRefs: string[] = [];
    cellResults.forEach((r, i) => {
      if (r.status === 'rejected') failedCellRefs.push(cellEntries[i][0]);
    });

    let hiddenRowsFailed = false;
    if (hadHiddenRows) {
      try {
        const merged = Array.from(new Set([...baseHiddenRows, ...pending.hiddenRows]))
          .sort((a, b) => a - b);
        await api.updateSheetHiddenRows(executionId, merged, userId);
      } catch {
        hiddenRowsFailed = true;
      }
    }
    let hiddenColsFailed = false;
    if (hadHiddenCols) {
      try {
        const merged = Array.from(new Set([...baseHiddenCols, ...pending.hiddenCols]))
          .sort((a, b) => a - b);
        await api.updateSheetHiddenCols(executionId, merged, userId);
      } catch {
        hiddenColsFailed = true;
      }
    }

    setPending((prev) => {
      const next: PendingChanges = {
        ...prev,
        dirtyCells: new Map(prev.dirtyCells),
        hiddenRows: new Set(prev.hiddenRows),
        hiddenCols: new Set(prev.hiddenCols),
        addedColumns: prev.addedColumns.slice(),
        renamedColumns: new Map(prev.renamedColumns),
      };
      // succeeded cells removed; failed cells retained
      cellEntries.forEach(([ref], i) => {
        if (cellResults[i].status === 'fulfilled') next.dirtyCells.delete(ref);
      });
      if (!hiddenRowsFailed) next.hiddenRows.clear();
      if (!hiddenColsFailed) next.hiddenCols.clear();
      // structure flush 가 성공했으면 pending 추가/rename 슬롯 비움. 실패면 유지.
      if (!structureFailed) {
        next.addedColumns = [];
        next.renamedColumns = new Map();
        next.addedRows = [];
      }
      return next;
    });
    if (!structureFailed) {
      setPendingRemovedAdded((prev) => (prev.size === 0 ? prev : new Set()));
      setPendingRemovedAddedRows((prev) => (prev.size === 0 ? prev : new Set()));
      setPendingColsOrderOverride((prev) => (prev === null ? prev : null));
      setPendingRowsOrderOverride((prev) => (prev === null ? prev : null));
      setPendingColumnOrderOverride((prev) => (prev === null ? prev : null));
      setPendingRowOrderOverride((prev) => (prev === null ? prev : null));
    }

    setSaving(false);

    // After a save attempt: drop history entries that correspond to changes
    // we just successfully flushed. Easiest correct rule: clear the whole
    // history if everything succeeded; on partial failure, keep it (user
    // may want to undo failed-cell entries).
    const allSucceeded =
      failedCellRefs.length === 0 && !hiddenRowsFailed && !hiddenColsFailed && !structureFailed;
    if (allSucceeded) {
      historyRef.current = [];
      setHistoryVersion((v) => v + 1);
    }

    const errParts: string[] = [];
    if (structureFailed) errParts.push('컬럼 구조 저장 실패');
    if (failedCellRefs.length > 0) errParts.push(`${failedCellRefs.length}개 셀 저장 실패: ${failedCellRefs.slice(0, 6).join(', ')}${failedCellRefs.length > 6 ? '…' : ''}`);
    if (hiddenRowsFailed) errParts.push('행 숨김 저장 실패');
    if (hiddenColsFailed) errParts.push('컬럼 숨김 저장 실패');
    if (errParts.length > 0) setSaveError(errParts.join(' · '));

    queryClient.invalidateQueries({ queryKey: ['sheetExecution', String(executionId)] });
    queryClient.invalidateQueries({ queryKey: ['sheetExecution', executionId] });
  }, [saving, pending, pendingRemovedAdded, pendingRemovedAddedRows, pendingColsOrderOverride, pendingRowsOrderOverride, pendingColumnOrderOverride, pendingRowOrderOverride, executionId, userId, baseHiddenRows, baseHiddenCols, queryClient]);

  return {
    pending,
    dirtyCount,
    isDirty,
    saving,
    saveError,
    clearError: useCallback(() => setSaveError(null), []),
    resolveCellValue,
    isCellDirty,
    isRowHiddenLocally,
    isColHiddenLocally,
    effectiveHiddenRows,
    effectiveHiddenCols,
    setCellValue,
    swapEquipment,
    hideRow,
    unhideRow,
    hideCol,
    unhideCol,
    addEquipmentColumn,
    addPlainColumn,
    removeAddedColumn,
    isAddedColumn,
    effectiveAddedColumns,
    addRow,
    removeAddedRow,
    isAddedRow,
    effectiveAddedRows,
    effectiveAddedColsOrder,
    effectiveAddedRowsOrder,
    reorderAddedColumns,
    reorderAddedRows,
    effectiveColumnOrder,
    effectiveRowOrder,
    reorderColumns,
    reorderRows,
    renameColumn,
    effectiveHeaderFor,
    clearPendingHidden,
    undo,
    canUndo,
    save,
  };
}
