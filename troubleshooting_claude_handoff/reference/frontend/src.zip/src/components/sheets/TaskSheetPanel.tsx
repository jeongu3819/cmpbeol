/**
 * TaskSheetPanel — Task Details 내부 Check Sheet 패널
 * - 해당 Task 에 연결된 SheetExecution 목록을 보여주고
 * - 템플릿을 선택해 새 실행을 시작한다 (task_id 를 자동으로 함께 보냄)
 * v3.1: 클릭 시 SheetExecutionPopup 으로 열기 옵션 추가
 */
import { useState } from 'react';
import {
  Box, Typography, Button, Chip, LinearProgress, Dialog,
  DialogTitle, DialogContent, DialogActions, FormControl,
  InputLabel, Select, MenuItem, alpha, Link, Tooltip, IconButton,
} from '@mui/material';
import DescriptionIcon from '@mui/icons-material/Description';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import AddIcon from '@mui/icons-material/Add';
import OpenInFullIcon from '@mui/icons-material/OpenInFull';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import LinkOffIcon from '@mui/icons-material/LinkOff';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../../api/client';
import { useAppStore } from '../../stores/useAppStore';
import { useNavigate } from 'react-router-dom';
import { useSpaceNav } from '../../hooks/useSpaceNav';
import SheetExecutionPopup from './SheetExecutionPopup';
import { isEquipmentMappingSheet } from './assignmentMappingDetect';
import type { SheetTemplate, Task } from '../../types';

interface Props {
  taskId: number;
  projectId?: number;
  canEdit: boolean;
  pendingSheets?: { templateId: number; title: string }[];
  onAddPendingSheet?: (sheet: { templateId: number; title: string }) => void;
  onRemovePendingSheet?: (index: number) => void;
}

export default function TaskSheetPanel({ taskId, projectId, canEdit, pendingSheets = [], onAddPendingSheet, onRemovePendingSheet }: Props) {
  const currentUserId = useAppStore(state => state.currentUserId);
  const currentSpaceId = useAppStore(state => state.currentSpaceId);
  const navigate = useNavigate();
  const { spacePath } = useSpaceNav();
  const queryClient = useQueryClient();

  const [pickerOpen, setPickerOpen] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | ''>('');
  const [execTitle, setExecTitle] = useState('');
  const [starting, setStarting] = useState(false);

  // v3.1: 팝업 상태
  const [popupExecId, setPopupExecId] = useState<number | null>(null);

  const { data: summary, refetch } = useQuery({
    queryKey: ['taskSheetSummary', taskId],
    queryFn: () => api.getTaskSheetSummary(taskId),
    enabled: !!taskId && taskId > 0,
  });

  const { data: templatesData } = useQuery({
    queryKey: ['sheetTemplates', currentSpaceId],
    queryFn: () => api.getSheetTemplates(currentSpaceId!),
    enabled: !!currentSpaceId && pickerOpen,
  });

  const unlinkMut = useMutation({
    mutationFn: (executionId: number) => api.unlinkSheetExecutionTask(executionId, currentUserId),
    onSuccess: (response: any) => {
      // v3.6: 백엔드가 force_zero_if_empty=true로 동기화 → response.task_progress 사용 (없으면 0).
      //       전체 task list invalidate 대신 해당 task만 setQueryData로 패치한다.
      const newProgress: number =
        typeof response?.task_progress === 'number' ? response.task_progress : 0;
      queryClient.setQueriesData<Task[]>(
        { queryKey: ['tasks'] },
        (old) => Array.isArray(old)
          ? old.map(t => t.id === taskId ? { ...t, progress: newProgress } : t)
          : old,
      );
      // TaskDrawer는 store의 selectedTask를 표시 → 즉시 0% 반영
      const sel = useAppStore.getState().selectedTask;
      if (sel && sel.id === taskId) {
        useAppStore.setState({ selectedTask: { ...sel, progress: newProgress } });
      }
      // v3.9: Dashboard 진행 중 sheet count / Sheets 관리 화면도 즉시 반영
      queryClient.invalidateQueries({ queryKey: ['spaceOverview'] });
      queryClient.invalidateQueries({ queryKey: ['sheetExecutions'] });
      // 연결정보(연결 약품) 카드는 개별 시트 상세(['sheetExecution', id])를 보고
      // status='unlinked' 인 시트를 제외하므로, 상세 캐시도 무효화해 새로고침 없이 사라지게 한다.
      queryClient.invalidateQueries({ queryKey: ['sheetExecution'] });
      refetch();
    },
    onError: (e: any) => alert(e?.response?.data?.detail || '연결 해제 실패'),
  });

  const handleUnlink = (e: React.MouseEvent, exec: any) => {
    e.stopPropagation();
    if (!confirm(`'${exec.title}' 체크시트를 이 Task에서 연결 해제할까요?\n(시트 자체는 보존됩니다)`)) return;
    unlinkMut.mutate(exec.id);
  };
  const templates: SheetTemplate[] = templatesData?.templates || [];

  const active = summary?.active_executions || [];
  const completed = summary?.recent_completed || [];
  const hasAny = (summary?.total_executions || 0) > 0 || pendingSheets.length > 0;

  const openPicker = () => {
    setSelectedTemplateId('');
    setExecTitle('');
    setPickerOpen(true);
  };

  const startExecution = async () => {
    if (!selectedTemplateId || !currentSpaceId) return;
    
    if (!taskId || taskId === 0) {
      if (onAddPendingSheet) {
        onAddPendingSheet({ templateId: Number(selectedTemplateId), title: execTitle.trim() });
        setPickerOpen(false);
      }
      return;
    }

    setStarting(true);
    try {
      const exec = await api.createSheetExecution({
        template_id: Number(selectedTemplateId),
        task_id: taskId,
        project_id: projectId,
        title: execTitle.trim() || undefined,
      }, currentSpaceId, currentUserId);
      setPickerOpen(false);
      refetch();
      // v3.1: 바로 팝업으로 열기
      setPopupExecId(exec.id);
    } catch (e) {
      console.error(e);
    } finally {
      setStarting(false);
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
        <Typography variant="caption" sx={{ fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', fontSize: '0.7rem' }}>
          <DescriptionIcon sx={{ fontSize: '0.8rem', mr: 0.5, verticalAlign: 'text-bottom', color: '#7C3AED' }} />
          Check Sheets ({(summary?.total_executions || 0) + pendingSheets.length})
        </Typography>
        {canEdit && (
          <Button
            size="small"
            startIcon={<AddIcon sx={{ fontSize: '0.8rem' }} />}
            onClick={openPicker}
            sx={{ textTransform: 'none', fontSize: '0.7rem', color: '#7C3AED' }}
          >
            체크시트 연결
          </Button>
        )}
      </Box>

      {!hasAny ? (
        <Typography variant="caption" sx={{ color: '#9CA3AF' }}>
          이 Task 에 연결된 체크시트가 없습니다.{' '}
          <Link component="button" onClick={() => navigate(`${spacePath}/sheets`)} sx={{ fontSize: '0.7rem', color: '#7C3AED' }}>
            양식 저장소로 이동
          </Link>
        </Typography>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.8 }}>
          {pendingSheets.map((sheet, idx) => {
            const templateName = templates.find(t => t.id === sheet.templateId)?.name || 'Check Sheet';
            return (
              <Box
                key={`pending-${idx}`}
                sx={{
                  display: 'flex', alignItems: 'center', gap: 1, p: 1, borderRadius: 1.5,
                  bgcolor: '#F3F4F6', border: '1px dashed #D1D5DB',
                }}
              >
                <DescriptionIcon sx={{ fontSize: 14, color: '#9CA3AF', flexShrink: 0 }} />
                <Typography variant="body2" sx={{ fontSize: '0.78rem', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#6B7280' }}>
                  {sheet.title || `${templateName} (저장 후 시작)`}
                </Typography>
                <Chip label="대기 중" size="small" sx={{ height: 16, fontSize: '0.55rem', bgcolor: '#E5E7EB', color: '#4B5563' }} />
                {canEdit && onRemovePendingSheet && (
                  <IconButton size="small" onClick={() => onRemovePendingSheet(idx)} sx={{ p: 0.3, ml: 0.3 }}>
                    <LinkOffIcon sx={{ fontSize: 13, color: '#9CA3AF' }} />
                  </IconButton>
                )}
              </Box>
            );
          })}
          {active.map((exec: any) => (
            <Box
              key={exec.id}
              onClick={() => setPopupExecId(exec.id)}
              sx={{
                display: 'flex', alignItems: 'center', gap: 1, p: 1, borderRadius: 1.5,
                cursor: 'pointer', bgcolor: '#FFFBEB', border: '1px solid #FDE68A',
                '&:hover': { bgcolor: '#FEF3C7' },
                transition: 'all 0.15s',
              }}
            >
              <PlayArrowIcon sx={{ fontSize: 14, color: '#F59E0B', flexShrink: 0 }} />
              <Typography variant="body2" sx={{ fontSize: '0.78rem', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {exec.title}
              </Typography>
              {/* 설비-배치 매핑형 시트는 진행률/완료 개념이 없으므로 진행률 bar/% 대신 배지 표시 */}
              {isEquipmentMappingSheet(exec) ? (
                <Chip label="설비-배치 매핑형" size="small" sx={{ height: 16, fontSize: '0.55rem', bgcolor: '#E5E7EB', color: '#4B5563', flexShrink: 0 }} />
              ) : (
                <>
                  <Box sx={{ width: 60, flexShrink: 0 }}>
                    <LinearProgress
                      variant="determinate" value={exec.progress}
                      sx={{ height: 4, borderRadius: 2, bgcolor: '#FDE68A', '& .MuiLinearProgress-bar': { bgcolor: '#F59E0B' } }}
                    />
                  </Box>
                  <Typography variant="caption" sx={{ fontSize: '0.65rem', color: '#D97706', flexShrink: 0, fontWeight: 700 }}>
                    {exec.progress}%
                  </Typography>
                </>
              )}
              <Tooltip title="전체 화면으로 열기">
                <OpenInFullIcon sx={{ fontSize: 12, color: '#D97706', flexShrink: 0 }} />
              </Tooltip>
              {canEdit && (
                <Tooltip title="이 Task에서 연결 해제">
                  <IconButton
                    size="small"
                    onClick={(e) => handleUnlink(e, exec)}
                    sx={{ p: 0.3, ml: 0.3 }}
                  >
                    <LinkOffIcon sx={{ fontSize: 13, color: '#9CA3AF' }} />
                  </IconButton>
                </Tooltip>
              )}
            </Box>
          ))}
          {completed.slice(0, 5).map((exec: any) => (
            <Box
              key={exec.id}
              onClick={() => setPopupExecId(exec.id)}
              sx={{
                display: 'flex', alignItems: 'center', gap: 1, p: 1, borderRadius: 1.5, cursor: 'pointer',
                '&:hover': { bgcolor: '#F9FAFB' },
                transition: 'all 0.15s',
              }}
            >
              <CheckCircleOutlineIcon sx={{ fontSize: 14, color: '#22C55E', flexShrink: 0 }} />
              <Typography variant="body2" sx={{ fontSize: '0.76rem', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#6B7280' }}>
                {exec.title}
              </Typography>
              <Chip label="완료" size="small"
                sx={{ height: 16, fontSize: '0.55rem', bgcolor: alpha('#22C55E', 0.1), color: '#16A34A' }} />
              {canEdit && (
                <Tooltip title="이 Task에서 연결 해제">
                  <IconButton
                    size="small"
                    onClick={(e) => handleUnlink(e, exec)}
                    sx={{ p: 0.3 }}
                  >
                    <LinkOffIcon sx={{ fontSize: 13, color: '#9CA3AF' }} />
                  </IconButton>
                </Tooltip>
              )}
            </Box>
          ))}
        </Box>
      )}

      {/* Template picker dialog */}
      <Dialog open={pickerOpen} onClose={() => setPickerOpen(false)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
        <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>체크시트 연결</DialogTitle>
        <DialogContent>
          <Typography variant="caption" color="text.secondary" sx={{ mb: 2, display: 'block' }}>
            이 Task 에서 사용할 체크시트 양식을 선택하세요. 연결 후 엔지니어가 직접 항목별로 체크하며 진행합니다.
          </Typography>
          <FormControl fullWidth size="small" sx={{ mb: 1.5 }}>
            <InputLabel>체크시트 양식</InputLabel>
            <Select
              value={selectedTemplateId === '' ? '' : String(selectedTemplateId)}
              label="체크시트 양식"
              onChange={e => setSelectedTemplateId(e.target.value === '' ? '' : Number(e.target.value))}
            >
              <MenuItem value=""><em>선택</em></MenuItem>
              {templates.map(t => (
                <MenuItem key={t.id} value={String(t.id)}>
                  {t.name} (체크 {t.checkable_count}개)
                  {t.column_role_mapping && ' ✓ 역할매핑'}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <Box>
            <Typography variant="caption" fontWeight={600}>시트 이름 (선택)</Typography>
            <input
              value={execTitle}
              onChange={e => setExecTitle(e.target.value)}
              placeholder="미입력 시 양식 이름 + 날짜로 자동 생성"
              style={{ width: '100%', padding: '8px 12px', border: '1px solid #D1D5DB', borderRadius: 8, fontSize: '0.85rem', marginTop: 4 }}
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setPickerOpen(false)} sx={{ color: '#6B7280' }}>취소</Button>
          <Button
            variant="contained"
            onClick={startExecution}
            disabled={!selectedTemplateId || starting}
            sx={{ bgcolor: '#7C3AED' }}
          >
            {starting ? '연결 중…' : '연결하고 열기'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* v3.1: SheetExecution 팝업 */}
      <SheetExecutionPopup
        open={!!popupExecId}
        onClose={() => { setPopupExecId(null); refetch(); }}
        executionId={popupExecId}
        userId={currentUserId}
      />
    </Box>
  );
}
