import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Tabs,
  Tab,
  Box,
  Button,
  Typography,
  Paper,
  Chip,
  TextField,
  Autocomplete,
  MenuItem,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  api,
  Project,
  AiManifestImage,
  VisionAiTestResult,
  ProjectImageVisionTestResult,
} from '../api/client';

interface Props {
  open: boolean;
  onClose: () => void;
  userId: number;
  provider: string;   // 현재 AI 설정에서 선택된 provider (dsllm/openai)
  model: string;      // 현재 선택된 model
}

const fmtBytes = (n?: number | null): string => {
  if (n == null) return '-';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
};

const fmtDims = (w?: number | null, h?: number | null): string =>
  w != null && h != null ? `${w}×${h}` : '-';

// §10 두 결과 자동 해석.
const buildComparison = (
  builtin: VisionAiTestResult | null,
  project: ProjectImageVisionTestResult | null,
): { text: string; severity: 'success' | 'warning' | 'error' } | null => {
  if (!builtin || !project) return null;
  const b = builtin.ok;
  const p = project.ok;
  if (b && p) {
    return { text: '현재 Provider/Model에서 실제 Vision 입력이 정상 작동합니다.', severity: 'success' };
  }
  if (b && !p) {
    return {
      text:
        'Provider와 멀티모달 형식은 정상입니다. 실제 이미지의 크기·전처리·처리 시간 문제일 가능성이 높습니다.',
      severity: 'warning',
    };
  }
  if (!b && !p) {
    return {
      text: 'Provider 연결, 모델 권한 또는 멀티모달 요청 형식 문제일 수 있습니다.',
      severity: 'error',
    };
  }
  // 내장 실패 + 실제 성공(드묾)
  return { text: '내장 이미지 테스트는 실패했지만 실제 이미지는 성공했습니다. 내장 테스트 경로를 확인하세요.', severity: 'warning' };
};

const ProjectImageVisionTestDialog: React.FC<Props> = ({ open, onClose, userId, provider, model }) => {
  const [tab, setTab] = useState(0);

  // ── 실제 프로젝트 이미지 탭 ──
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectsLoading, setProjectsLoading] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [manifest, setManifest] = useState<AiManifestImage[]>([]);
  const [manifestLoading, setManifestLoading] = useState(false);
  const [manifestError, setManifestError] = useState<string | null>(null);
  const [selectedTaskId, setSelectedTaskId] = useState<string>('');
  const [selectedImageId, setSelectedImageId] = useState<string>('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const previewUrlRef = useRef<string | null>(null);
  const [running, setRunning] = useState(false);
  const [projectResult, setProjectResult] = useState<ProjectImageVisionTestResult | null>(null);
  const [runError, setRunError] = useState<string | null>(null);

  // ── 내장 이미지 탭 ──
  const [builtinRunning, setBuiltinRunning] = useState(false);
  const [builtinResult, setBuiltinResult] = useState<VisionAiTestResult | null>(null);

  // 프로젝트 목록 로드(다이얼로그 열릴 때 1회).
  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setProjectsLoading(true);
    api
      .getProjects(userId)
      .then(list => {
        if (cancelled) return;
        const sorted = [...list].sort((a, b) =>
          String(b.created_at || '').localeCompare(String(a.created_at || '')),
        );
        setProjects(sorted);
      })
      .catch(() => !cancelled && setProjects([]))
      .finally(() => !cancelled && setProjectsLoading(false));
    return () => {
      cancelled = true;
    };
  }, [open, userId]);

  // 프로젝트 선택 → 이미지 manifest 로드.
  useEffect(() => {
    if (!selectedProject) {
      setManifest([]);
      return;
    }
    let cancelled = false;
    setManifestLoading(true);
    setManifestError(null);
    setSelectedTaskId('');
    setSelectedImageId('');
    api
      .getProjectAiContextPreview(selectedProject.id, userId, { include_images: true, max_images: 100 })
      .then(resp => {
        if (cancelled) return;
        const imgs = (resp.image_manifest || []).filter(
          it => it.source_entity_type && String(it.source_entity_type).startsWith('task_'),
        );
        setManifest(imgs);
        if (imgs.length === 0) setManifestError('이 프로젝트에는 Task/작업노트 이미지가 없습니다.');
      })
      .catch(() => !cancelled && setManifestError('이미지 목록을 불러오지 못했습니다.'))
      .finally(() => !cancelled && setManifestLoading(false));
    return () => {
      cancelled = true;
    };
  }, [selectedProject, userId]);

  // 이미지가 있는 Task 목록.
  const tasks = useMemo(() => {
    const map = new Map<string, string>();
    manifest.forEach(it => {
      const tid = it.task_id != null ? String(it.task_id) : '';
      if (tid && !map.has(tid)) map.set(tid, it.task_title || `Task ${tid}`);
    });
    return Array.from(map.entries()).map(([id, title]) => ({ id, title }));
  }, [manifest]);

  const taskImages = useMemo(
    () => manifest.filter(it => selectedTaskId && String(it.task_id) === selectedTaskId),
    [manifest, selectedTaskId],
  );

  // Task 선택 시 가장 최근 이미지를 기본 선택(사용자가 최종 확인).
  useEffect(() => {
    if (taskImages.length === 0) {
      setSelectedImageId('');
      return;
    }
    const latest = [...taskImages].sort((a, b) =>
      String(b.created_at || '').localeCompare(String(a.created_at || '')),
    )[0];
    setSelectedImageId(latest.image_id);
  }, [taskImages]);

  const selectedImage = useMemo(
    () => manifest.find(it => it.image_id === selectedImageId) || null,
    [manifest, selectedImageId],
  );

  // 선택 이미지 미리보기(lazy blob → object URL). 이전 URL revoke.
  useEffect(() => {
    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current);
      previewUrlRef.current = null;
    }
    setPreviewUrl(null);
    if (!selectedProject || !selectedImageId) return;
    let cancelled = false;
    api
      .getProjectAiContextPreviewImage(selectedProject.id, selectedImageId, userId)
      .then(blob => {
        if (cancelled) return;
        const url = URL.createObjectURL(blob);
        previewUrlRef.current = url;
        setPreviewUrl(url);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [selectedProject, selectedImageId, userId]);

  // 언마운트 시 object URL 정리.
  useEffect(
    () => () => {
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    },
    [],
  );

  const runProjectTest = async () => {
    if (!selectedProject || !selectedImageId) return;
    setRunning(true);
    setRunError(null);
    setProjectResult(null);
    try {
      const res = await api.runProjectImageVisionTest({
        user_id: userId,
        project_id: selectedProject.id,
        image_id: selectedImageId,
        provider,
        model_name: model,
      });
      setProjectResult(res);
    } catch (err: any) {
      const reqId = err?.response?.headers?.['x-request-id'];
      const base = err?.response?.data?.detail || err?.message || '실제 이미지 테스트 실행 실패';
      setRunError(reqId ? `${base}\n시스템 로그에서 Request ID ${reqId} 를 확인하세요.` : base);
    } finally {
      setRunning(false);
    }
  };

  const runBuiltinTest = async () => {
    setBuiltinRunning(true);
    try {
      const res = await api.testVisionAiVisionInput({ provider, model_name: model }, userId);
      setBuiltinResult(res);
    } catch {
      setBuiltinResult({ ok: false, model, error: '내장 이미지 테스트 요청 중 오류가 발생했습니다.' });
    } finally {
      setBuiltinRunning(false);
    }
  };

  const comparison = buildComparison(builtinResult, projectResult);
  const isExternal = provider === 'openai';

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ fontWeight: 700, fontSize: '1rem' }}>Vision 입력 테스트</DialogTitle>
      <DialogContent dividers>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
          <Tab label="실제 프로젝트 이미지" />
          <Tab label="기본 내장 이미지" />
        </Tabs>

        <Box sx={{ mb: 1.5, fontSize: '0.8rem', color: '#6B7280' }}>
          Provider / Model: <strong>{provider || '-'}</strong> / <strong>{model || '-'}</strong>
          {isExternal && (
            <Alert severity="warning" sx={{ mt: 1, fontSize: '0.78rem' }}>
              선택한 Provider가 외부 OpenAI API입니다. 실제 프로젝트 이미지가 외부로 전송됩니다.
            </Alert>
          )}
          {!isExternal && (
            <Typography sx={{ fontSize: '0.75rem', color: '#9CA3AF', mt: 0.5 }}>
              사내 DSLLM Provider로 내부 전송됩니다.
            </Typography>
          )}
        </Box>

        {tab === 0 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            <Autocomplete
              size="small"
              options={projects}
              loading={projectsLoading}
              value={selectedProject}
              onChange={(_, v) => setSelectedProject(v)}
              getOptionLabel={p => `${p.name} (#${p.id})`}
              isOptionEqualToValue={(a, b) => a.id === b.id}
              renderInput={params => <TextField {...params} label="프로젝트 선택" placeholder="프로젝트명 검색" />}
            />

            {manifestLoading && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <CircularProgress size={16} />
                <Typography sx={{ fontSize: '0.8rem' }}>이미지 목록 불러오는 중…</Typography>
              </Box>
            )}
            {manifestError && <Alert severity="info" sx={{ fontSize: '0.8rem' }}>{manifestError}</Alert>}

            {tasks.length > 0 && (
              <TextField
                select
                size="small"
                label="Task 선택 (이미지 있는 Task만)"
                value={selectedTaskId}
                onChange={e => setSelectedTaskId(e.target.value)}
              >
                {tasks.map(t => (
                  <MenuItem key={t.id} value={t.id}>
                    {t.title} (#{t.id})
                  </MenuItem>
                ))}
              </TextField>
            )}

            {taskImages.length > 0 && (
              <TextField
                select
                size="small"
                label="이미지 선택"
                value={selectedImageId}
                onChange={e => setSelectedImageId(e.target.value)}
                helperText="가장 최근 이미지가 기본 선택됩니다. 최종 선택을 확인하세요."
              >
                {taskImages.map(it => (
                  <MenuItem key={it.image_id} value={it.image_id}>
                    {it.filename || it.image_id} · {it.content_type || '-'} · {fmtBytes(it.file_size)} ·{' '}
                    {fmtDims(it.width, it.height)}
                  </MenuItem>
                ))}
              </TextField>
            )}

            {selectedImage && (
              <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 1 }}>
                <Box sx={{ display: 'flex', gap: 1.5 }}>
                  <Box
                    sx={{
                      width: 160,
                      height: 120,
                      flexShrink: 0,
                      bgcolor: '#F3F4F6',
                      borderRadius: 1,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      overflow: 'hidden',
                    }}
                  >
                    {previewUrl ? (
                      <img src={previewUrl} alt="preview" style={{ maxWidth: '100%', maxHeight: '100%' }} />
                    ) : (
                      <CircularProgress size={18} />
                    )}
                  </Box>
                  <Box sx={{ fontSize: '0.76rem', lineHeight: 1.7, wordBreak: 'break-all' }}>
                    <div><strong>image_id:</strong> {selectedImage.image_id}</div>
                    <div><strong>MIME:</strong> {selectedImage.content_type || '-'}</div>
                    <div><strong>원본 크기:</strong> {fmtBytes(selectedImage.file_size)}</div>
                    <div><strong>해상도:</strong> {fmtDims(selectedImage.width, selectedImage.height)}</div>
                    <div><strong>role:</strong> {selectedImage.image_role || '-'}</div>
                    <div><strong>등록:</strong> {selectedImage.created_at || '-'}</div>
                  </Box>
                </Box>
              </Paper>
            )}

            <Button
              variant="contained"
              disabled={!selectedImageId || running}
              startIcon={running ? <CircularProgress size={16} color="inherit" /> : undefined}
              onClick={runProjectTest}
            >
              {running ? `${model || '모델'}로 실제 프로젝트 이미지 1장 분석 중…` : '이 이미지로 테스트 실행'}
            </Button>

            {runError && (
              <Alert severity="error" sx={{ whiteSpace: 'pre-line', fontSize: '0.8rem' }}>{runError}</Alert>
            )}

            {projectResult && <ProjectResultView result={projectResult} />}
          </Box>
        )}

        {tab === 1 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            <Typography sx={{ fontSize: '0.82rem', color: '#6B7280' }}>
              프로젝트 데이터와 무관한 최소 payload(내장 빨강 PNG)로 Provider 멀티모달 연결만 확인합니다.
            </Typography>
            <Button
              variant="outlined"
              disabled={builtinRunning}
              startIcon={builtinRunning ? <CircularProgress size={16} /> : undefined}
              onClick={runBuiltinTest}
            >
              {builtinRunning ? '내장 이미지 테스트 중…' : '내장 빨강 이미지 테스트'}
            </Button>
            {builtinResult && (
              <Alert severity={builtinResult.ok ? 'success' : 'error'} sx={{ fontSize: '0.8rem' }}>
                {builtinResult.ok
                  ? `인식 성공 — 응답: ${builtinResult.answer || '-'} (기대: ${builtinResult.expected || '빨강'})`
                  : `실패 — ${builtinResult.error || '알 수 없는 오류'}`}
              </Alert>
            )}
          </Box>
        )}

        {comparison && (
          <Alert severity={comparison.severity} sx={{ mt: 2, fontSize: '0.8rem' }}>
            <strong>자동 비교</strong> · 내장 이미지: {builtinResult?.ok ? '성공' : '실패'} / 실제 프로젝트 이미지:{' '}
            {projectResult?.ok ? '성공' : '실패'}
            <br />
            {comparison.text}
          </Alert>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>닫기</Button>
      </DialogActions>
    </Dialog>
  );
};

const MetricRow: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <>
    <div style={{ color: '#6B7280' }}>{label}</div>
    <div style={{ wordBreak: 'break-all' }}>{value}</div>
  </>
);

const ProjectResultView: React.FC<{ result: ProjectImageVisionTestResult }> = ({ result }) => {
  const m = result.metrics || {};
  const metricsGrid = (
    <Box sx={{ display: 'grid', gridTemplateColumns: '150px 1fr', rowGap: 0.3, fontSize: '0.76rem', fontFamily: 'monospace', mt: 0.5 }}>
      <MetricRow label="원본" value={`${m.original_mime || '-'} · ${fmtBytes(m.original_bytes)} · ${fmtDims(m.original_width, m.original_height)}`} />
      <MetricRow label="전처리" value={`${m.mime || '-'} · ${fmtBytes(m.processed_bytes)} · ${fmtDims(m.width, m.height)}`} />
      <MetricRow label="base64 문자수" value={m.base64_chars ?? '-'} />
      <MetricRow label="payload" value={fmtBytes(m.payload_bytes)} />
      <MetricRow label="max_tokens" value={m.max_tokens ?? '-'} />
      <MetricRow label="timeout(s)" value={m.timeout_seconds ?? '-'} />
      <MetricRow label="응답 시간(ms)" value={m.elapsed_ms ?? '-'} />
    </Box>
  );

  if (result.ok) {
    const r = result.recognition || {};
    return (
      <Paper variant="outlined" sx={{ p: 1.4, borderRadius: 1, bgcolor: '#F0FDF4' }}>
        <Typography sx={{ fontWeight: 700, color: '#15803D', mb: 0.5 }}>Vision 입력 인식 성공</Typography>
        <Box sx={{ fontSize: '0.8rem', lineHeight: 1.7 }}>
          <div><strong>프로젝트:</strong> #{result.project_id} / Task: {result.task_title || '-'}</div>
          <div><strong>이미지:</strong> {result.canonical_image_id}</div>
          <div><strong>Provider / Model:</strong> {result.provider} / {result.model}</div>
          <div><strong>이미지 유형:</strong> {r.image_type || r.image_role_hint || '-'}</div>
          {Array.isArray(r.visible_facts) && r.visible_facts.length > 0 && (
            <div><strong>보이는 사실:</strong> {r.visible_facts.join(' · ')}</div>
          )}
          <div><strong>해석:</strong> {r.interpretation || '-'}</div>
          <div><strong>불확실성:</strong> {r.uncertainty || '-'}</div>
        </Box>
        {metricsGrid}
        <Typography sx={{ fontSize: '0.72rem', color: '#9CA3AF', mt: 0.8 }}>
          Request ID: {result.request_id || '-'}
        </Typography>
      </Paper>
    );
  }

  const d = result.diagnosis || {};
  return (
    <Paper variant="outlined" sx={{ p: 1.4, borderRadius: 1, bgcolor: '#FEF2F2' }}>
      <Typography sx={{ fontWeight: 700, color: '#B91C1C', mb: 0.5 }}>Vision 입력 테스트 실패</Typography>
      <Box sx={{ fontSize: '0.8rem', lineHeight: 1.7 }}>
        <div><strong>실패 단계:</strong> {d.failure_stage_label || d.failure_stage || '-'}</div>
        <div>
          <strong>오류:</strong>{' '}
          <Chip size="small" label={d.error_type || '-'} sx={{ height: 18, fontSize: '0.68rem' }} />
          {d.http_status != null ? ` (HTTP ${d.http_status})` : ''}
        </div>
        <div><strong>Provider / Model:</strong> {result.provider} / {result.model}</div>
        <div><strong>판단:</strong> {d.summary || '-'}</div>
        <div><strong>추정 원인:</strong> {d.likely_cause || '-'}</div>
        <div><strong>권장 대응:</strong> {d.recommended_action || '-'}</div>
      </Box>
      {metricsGrid}
      <Typography sx={{ fontSize: '0.72rem', color: '#9CA3AF', mt: 0.8 }}>
        Request ID: {result.request_id || '-'}
      </Typography>
    </Paper>
  );
};

export default ProjectImageVisionTestDialog;
