import React from 'react';
import { Box, Tooltip } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { deriveSidebarColor, autoTextColor } from '../utils/colorUtils';
import { planAiColors, planAiShadows, planAiRadius } from '../theme/tokens';
import { colorNameOf } from '../theme/customTheme';

interface Props {
  /** Background color this swatch represents (a BG_PALETTE entry). */
  color: string;
  selected: boolean;
  onClick: () => void;
  /** Preview height in px (default 46). Larger when shown in the theme popover. */
  height?: number;
}

/**
 * A miniature live preview of the whole app shell for one background color.
 *
 * Instead of a plain colored circle, each swatch renders a tiny mockup —
 * derived sidebar + main background + an elevated card + a text line — so the
 * user can judge how bg / sidebar / card / text contrast work together before
 * committing. Uses the exact same derivation as MainLayout (deriveSidebarColor /
 * autoTextColor), so the preview is faithful.
 */
const ThemePreviewSwatch: React.FC<Props> = ({ color, selected, onClick, height = 46 }) => {
  const sidebar = deriveSidebarColor(color);
  const sidebarText = autoTextColor(sidebar);
  const isDarkSidebar = sidebarText === '#FFFFFF';
  const sidebarLine = isDarkSidebar ? 'rgba(255,255,255,0.55)' : 'rgba(15,23,42,0.45)';
  const sidebarDot = planAiColors.brand.primary;
  const colorName = colorNameOf(color);

  return (
    <Tooltip title={colorName} placement="top">
      <Box
        onClick={onClick}
        role="button"
        aria-label={`테마 ${colorName}`}
        aria-pressed={selected}
        sx={{
          width: '100%',
          height,
          borderRadius: `${planAiRadius.sm}px`,
          overflow: 'hidden',
          display: 'flex',
          cursor: 'pointer',
          position: 'relative',
          border: selected
            ? `2px solid ${planAiColors.brand.primary}`
            : `1px solid ${planAiColors.border.soft}`,
          boxShadow: selected ? planAiShadows.focus : planAiShadows.sm,
          transition: 'transform 0.15s ease, box-shadow 0.15s ease',
          '&:hover': { transform: 'translateY(-1px)', boxShadow: planAiShadows.md },
          '@media (prefers-reduced-motion: reduce)': {
            transition: 'none',
            '&:hover': { transform: 'none' },
          },
        }}
      >
        {/* Sidebar strip */}
        <Box
          sx={{
            width: '32%',
            bgcolor: sidebar,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            gap: '3px',
            px: '5px',
          }}
        >
          <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: sidebarDot }} />
          <Box sx={{ height: 2, borderRadius: 1, bgcolor: sidebarLine, width: '85%' }} />
          <Box sx={{ height: 2, borderRadius: 1, bgcolor: sidebarLine, width: '60%' }} />
        </Box>

        {/* Main canvas + a tiny elevated card */}
        <Box sx={{ flex: 1, bgcolor: color, position: 'relative', p: '5px' }}>
          <Box
            sx={{
              height: '100%',
              bgcolor: planAiColors.background.surface,
              borderRadius: '4px',
              border: `1px solid ${planAiColors.border.soft}`,
              boxShadow: planAiShadows.sm,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              gap: '3px',
              px: '5px',
            }}
          >
            <Box sx={{ height: 2.5, borderRadius: 1, bgcolor: planAiColors.text.secondary, width: '70%' }} />
            <Box sx={{ height: 2, borderRadius: 1, bgcolor: planAiColors.text.muted, width: '45%' }} />
          </Box>
        </Box>

        {/* Selected check badge */}
        {selected && (
          <Box
            sx={{
              position: 'absolute',
              top: 4,
              right: 4,
              display: 'flex',
              borderRadius: '50%',
              bgcolor: '#fff',
              lineHeight: 0,
            }}
          >
            <CheckCircleIcon sx={{ fontSize: 16, color: planAiColors.brand.primary }} />
          </Box>
        )}
      </Box>
    </Tooltip>
  );
};

export default ThemePreviewSwatch;
