import React, { useEffect, useRef, useState } from 'react';
import { useIsFetching, useIsMutating } from '@tanstack/react-query';
import { Box, Fade, LinearProgress, Chip } from '@mui/material';
import SyncIcon from '@mui/icons-material/Sync';
import { useSnackbar } from 'notistack';

/**
 * 전역 요청 진행 상태 표시 (현재 사용자 브라우저 기준).
 *
 * - TanStack Query 의 in-flight 조회(useIsFetching) + 변경(useIsMutating) 수를 합산.
 * - 진행 중이면 화면 상단에 얇은 LinearProgress + 작은 "저장/동기화 중 N건" 배지 표시.
 * - 응답이 일정 시간(SLOW_MS) 이상 지속되면 "요청이 많아 처리 중" 안내 스낵바를 1회 노출.
 *
 * ⚠️ 이 값은 서버 전체 사용자 수가 아니라 **현재 브라우저에서 진행 중인 요청 수**입니다.
 * 화면 구조를 바꾸지 않는 오버레이 형태(최소 침습)로만 동작합니다.
 */
const SLOW_MS = 8000; // 이 시간 이상 요청이 끝나지 않으면 지연 안내

const GlobalRequestIndicator: React.FC = () => {
  const fetching = useIsFetching();
  const mutating = useIsMutating();
  const active = fetching + mutating;
  const { enqueueSnackbar } = useSnackbar();

  const [showBadge, setShowBadge] = useState(false);
  const slowTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const slowNotified = useRef(false);

  // 배지는 깜빡임 방지를 위해 active>0 가 살짝 지속될 때만 노출
  useEffect(() => {
    let t: ReturnType<typeof setTimeout> | null = null;
    if (active > 0) {
      t = setTimeout(() => setShowBadge(true), 250);
    } else {
      setShowBadge(false);
    }
    return () => {
      if (t) clearTimeout(t);
    };
  }, [active]);

  // 지연 안내: active>0 가 SLOW_MS 이상 지속되면 1회 안내
  useEffect(() => {
    if (active > 0) {
      if (!slowTimer.current && !slowNotified.current) {
        slowTimer.current = setTimeout(() => {
          slowNotified.current = true;
          enqueueSnackbar('요청이 많아 처리 중입니다. 잠시만 기다려주세요.', {
            variant: 'info',
            autoHideDuration: 4000,
          });
        }, SLOW_MS);
      }
    } else {
      if (slowTimer.current) {
        clearTimeout(slowTimer.current);
        slowTimer.current = null;
      }
      slowNotified.current = false;
    }
    return () => {
      if (slowTimer.current) {
        clearTimeout(slowTimer.current);
        slowTimer.current = null;
      }
    };
  }, [active, enqueueSnackbar]);

  const label =
    mutating > 0
      ? `저장 중… ${active > 1 ? `(${active}건)` : ''}`
      : `동기화 중… ${active > 1 ? `(${active}건)` : ''}`;

  return (
    <>
      {/* 상단 얇은 진행 바 */}
      <Fade in={active > 0} unmountOnExit>
        <LinearProgress
          sx={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            height: 3,
            zIndex: (theme) => theme.zIndex.snackbar + 1,
          }}
        />
      </Fade>

      {/* 작은 진행 배지 (우하단, 스낵바보다 위) */}
      <Fade in={showBadge} unmountOnExit>
        <Box
          sx={{
            position: 'fixed',
            bottom: 12,
            left: 12,
            zIndex: (theme) => theme.zIndex.snackbar,
            pointerEvents: 'none',
          }}
        >
          <Chip
            size="small"
            icon={<SyncIcon sx={{ fontSize: 16, animation: 'spin 1s linear infinite', '@keyframes spin': { '100%': { transform: 'rotate(360deg)' } } }} />}
            label={label.trim()}
            sx={{
              bgcolor: 'rgba(41,85,255,0.10)',
              color: 'primary.dark',
              fontWeight: 600,
              border: '1px solid rgba(41,85,255,0.20)',
            }}
          />
        </Box>
      </Fade>
    </>
  );
};

export default GlobalRequestIndicator;
