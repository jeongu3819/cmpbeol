import React, { useMemo } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button,
  List, ListItemButton, ListItemText, IconButton, Typography, Box,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import type { Project, Task, SheetExecution } from '../../types';
import {
  getKpiDetailItems,
  KPI_LABELS,
  type KpiKey,
  type KpiDetailItem,
  type EquipmentSummary,
} from './equipmentDashboardUtils';

interface Props {
  open: boolean;
  kpiKey: KpiKey | null;
  projects: Project[];
  /** 공간 전체 task (이미 projectIds 로 필터된 것). */
  spaceTasks: Task[];
  /** 공간 전체 sheet (이미 filterValidSheets 통과한 것). */
  spaceSheets: SheetExecution[];
  /** totalEquipment 카드용 — 이미 계산된 EquipmentSummary 가 있으면 재사용. */
  equipments?: EquipmentSummary[];
  onClose: () => void;
  onOpenTask?: (task: Task) => void;
  onOpenSheet?: (executionId: number) => void;
  /** project 행 클릭 시. (선택사항 — 미지정 시 Dialog 닫고 onSelectProject 호출) */
  onOpenProject?: (projectId: number) => void;
}

const KpiDetailDialog: React.FC<Props> = ({
  open, kpiKey, projects, spaceTasks, spaceSheets, equipments,
  onClose, onOpenTask, onOpenSheet, onOpenProject,
}) => {
  const items: KpiDetailItem[] = useMemo(() => {
    if (!kpiKey) return [];
    return getKpiDetailItems(kpiKey, projects, spaceTasks, spaceSheets, equipments);
  }, [kpiKey, projects, spaceTasks, spaceSheets, equipments]);

  const title = kpiKey ? KPI_LABELS[kpiKey] : '';

  const handleItemClick = (item: KpiDetailItem) => {
    if (item.kind === 'task') {
      onOpenTask?.(item.task);
      onClose();
    } else if (item.kind === 'sheet') {
      onOpenSheet?.(item.sheet.id);
      onClose();
    } else if (item.kind === 'project') {
      onOpenProject?.(item.project.id);
      onClose();
    } else if (item.kind === 'change') {
      if (item.ref.type === 'task') {
        onOpenTask?.(item.ref.task);
      } else {
        onOpenSheet?.(item.ref.sheet.id);
      }
      onClose();
    }
  };

  const renderRow = (item: KpiDetailItem, idx: number) => {
    let primary = '';
    let secondary = item.kind === 'change' ? item.meta : (('meta' in item ? item.meta : '') || '');
    if (item.kind === 'project') primary = item.project.name || '(이름 없음)';
    else if (item.kind === 'task') primary = item.task.title || '(제목 없음)';
    else if (item.kind === 'sheet') primary = item.sheet.title || item.sheet.template_name || `시트 #${item.sheet.id}`;
    else if (item.kind === 'change') primary = item.title;

    const stableKey =
      item.kind === 'project' ? `p-${item.project.id}` :
      item.kind === 'task'    ? `t-${item.task.id}` :
      item.kind === 'sheet'   ? `s-${item.sheet.id}` :
      item.id;

    return (
      <ListItemButton key={stableKey || idx} onClick={() => handleItemClick(item)}>
        <ListItemText
          primary={primary}
          secondary={secondary}
          primaryTypographyProps={{ fontWeight: 600, fontSize: 14 }}
          secondaryTypographyProps={{ fontSize: 12 }}
        />
      </ListItemButton>
    );
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pr: 1 }}>
        <Box>
          <Typography component="span" sx={{ fontWeight: 800, fontSize: 18 }}>
            {title}
          </Typography>
          <Typography component="span" sx={{ ml: 1, fontSize: 13, color: 'text.secondary', fontWeight: 600 }}>
            {items.length}건
          </Typography>
        </Box>
        <IconButton onClick={onClose} size="small" aria-label="닫기">
          <CloseIcon fontSize="small" />
        </IconButton>
      </DialogTitle>
      <DialogContent dividers sx={{ p: 0 }}>
        {items.length === 0 ? (
          <Box sx={{ p: 3, textAlign: 'center', color: 'text.secondary', fontSize: 13 }}>
            해당 항목이 없습니다.
          </Box>
        ) : (
          <List dense disablePadding>
            {items.map(renderRow)}
          </List>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>닫기</Button>
      </DialogActions>
    </Dialog>
  );
};

export default KpiDetailDialog;
