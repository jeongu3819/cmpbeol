import React from 'react';
import PrecisionManufacturingIcon from '@mui/icons-material/PrecisionManufacturing';
import ScheduleIcon from '@mui/icons-material/Schedule';
import EventRepeatIcon from '@mui/icons-material/EventRepeat';
import ReportProblemIcon from '@mui/icons-material/ReportProblem';
import HistoryIcon from '@mui/icons-material/History';
import FactCheckIcon from '@mui/icons-material/FactCheck';
import type { EquipmentKpis, KpiKey } from './equipmentDashboardUtils';

type Tone = 'blue' | 'orange' | 'red' | 'green' | 'purple' | 'gray';

interface KpiDef {
  key: KpiKey;
  label: string;
  icon: React.ReactNode;
  tone: Tone;
  unit?: string;
}

const KPI_DEFS: KpiDef[] = [
  { key: 'totalEquipment',    label: '가동 설비',       icon: <PrecisionManufacturingIcon fontSize="small" />, tone: 'gray',   unit: '대' },
  { key: 'todayTasks',        label: '오늘 할 일',      icon: <ScheduleIcon fontSize="small" />,                tone: 'blue',   unit: '건' },
  { key: 'weekInspections',   label: '이번주 점검',     icon: <EventRepeatIcon fontSize="small" />,             tone: 'orange', unit: '건' },
  { key: 'openIssues',        label: '미해결 이슈',     icon: <ReportProblemIcon fontSize="small" />,           tone: 'red',    unit: '건' },
  { key: 'recentChanges',     label: '변경 이력 (7일)', icon: <HistoryIcon fontSize="small" />,                 tone: 'purple', unit: '건' },
  { key: 'inProgressSheets',  label: '체크시트 진행중', icon: <FactCheckIcon fontSize="small" />,               tone: 'green',  unit: '건' },
];

interface Props {
  kpis: EquipmentKpis;
  /** 카드 클릭 시 호출. 미지정 시 카드는 비활성(클릭 무반응). */
  onSelect?: (key: KpiKey) => void;
  /**
   * 표시할 KPI 키 집합. undefined 이면 전체 표시.
   * Widget Settings 의 개별 KPI 토글과 연결된다.
   */
  visibleKeys?: Set<KpiKey>;
}

const EquipmentKpiCards: React.FC<Props> = ({ kpis, onSelect, visibleKeys }) => {
  const defs = visibleKeys ? KPI_DEFS.filter(d => visibleKeys.has(d.key)) : KPI_DEFS;
  if (defs.length === 0) return null;
  return (
    <div className="equipment-ops-kpi-grid">
      {defs.map(def => {
        const clickable = !!onSelect;
        return (
          <button
            key={def.key}
            type="button"
            className={`equipment-ops-kpi-card tone-${def.tone}${clickable ? ' is-clickable' : ''}`}
            onClick={clickable ? () => onSelect!(def.key) : undefined}
            disabled={!clickable}
            aria-label={`${def.label} 상세 보기`}
          >
            <div className="equipment-ops-kpi-label">
              {def.icon}
              <span>{def.label}</span>
            </div>
            <div className="equipment-ops-kpi-value">
              {kpis[def.key].toLocaleString()}
              {def.unit && <span style={{ fontSize: 13, color: 'var(--eq-text-secondary)', fontWeight: 600, marginLeft: 4 }}>{def.unit}</span>}
            </div>
          </button>
        );
      })}
    </div>
  );
};

export default EquipmentKpiCards;
