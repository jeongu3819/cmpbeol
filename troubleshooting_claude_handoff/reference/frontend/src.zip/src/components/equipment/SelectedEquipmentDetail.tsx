import React, { useState } from 'react';
import type { Project, Task, SheetExecution } from '../../types';
import {
  isIssueTask,
  isOpen,
  sortByNearestDue,
  summarizeSheetStatus,
  summarizeEquipment,
  statusChipColor,
  dDayLabel,
} from './equipmentDashboardUtils';
import { isEquipmentMappingSheet } from '../sheets/assignmentMappingDetect';
import { EquipmentStatModal, StatRow, type StatModalState } from './EquipmentStatModal';
import EquipmentDetailInfoTab from './tabs/EquipmentDetailInfoTab';
import EquipmentHistoryTab from './tabs/EquipmentHistoryTab';
import EquipmentLinksTab from './tabs/EquipmentLinksTab';
import EquipmentFilesTab from './tabs/EquipmentFilesTab';

type Tab = 'overview' | 'detail' | 'history' | 'links' | 'files';

interface Props {
  project: Project | null;
  projectTasks: Task[];
  projectSheets: SheetExecution[];
  /** 사용자 ID (파일 다운로드, AI 리포트 등 권한 체크용) */
  currentUserId: number;
  /** 클릭 시 해당 task 의 TaskDrawer 열기 */
  onOpenTask?: (task: Task) => void;
  /** 클릭 시 해당 시트 실행으로 이동 */
  onOpenSheet?: (executionId: number) => void;
  /** "작업 보드 보기" / "전체 일정 보기" 등 ProjectPage 탭으로 이동 */
  onOpenProjectTab?: (projectId: number, tab: 'board' | 'list' | 'calendar' | 'roadmap' | 'report' | 'settings') => void;
  /** 점검 예약 = QuickAdd / Drawer 신규 task 모달 */
  onQuickAddTask?: (projectId: number) => void;
  /** 약품관리 시트 페이지 이동 */
  onOpenSheetsPage?: () => void;
}

// 탭 순서: 설비정보 → 설비현황 → 이력 → 연결정보 → 문서/파일.
// (id 는 기존 값 유지 — 'detail'=설비정보, 'overview'=설비현황. 기본 진입 탭은 'overview'=설비현황)
const TABS: { id: Tab; label: string }[] = [
  { id: 'detail',   label: '설비정보' },
  { id: 'overview', label: '설비현황' },
  { id: 'history',  label: '이력' },
  { id: 'links',    label: '연결정보' },
  { id: 'files',    label: '문서/파일' },
];

const SelectedEquipmentDetail: React.FC<Props> = ({
  project, projectTasks, projectSheets, currentUserId,
  onOpenTask, onOpenSheet, onOpenProjectTab, onQuickAddTask, onOpenSheetsPage,
}) => {
  const [tab, setTab] = useState<Tab>('overview');
  // 체크시트 현황: 완료 항목은 기본 숨김, 토글로만 표시
  const [showCompletedSheets, setShowCompletedSheets] = useState(false);
  // 요약 통계 클릭 시 뜨는 필터 목록 모달
  const [statModal, setStatModal] = useState<StatModalState | null>(null);

  if (!project) {
    return (
      <div className="equipment-ops-detail">
        <div className="equipment-ops-empty">선택된 설비가 없습니다. 위에서 설비 카드를 클릭하세요.</div>
      </div>
    );
  }

  // ── 데이터 가공 ──
  const issues = projectTasks.filter(isIssueTask);

  // 체크시트 현황/완료율은 점검 수행형(체크리스트) 시트만 모수. 설비-배치 매핑형은 제외.
  const checklistSheets = projectSheets.filter(s => !isEquipmentMappingSheet(s));
  const mappingSheetCount = projectSheets.length - checklistSheets.length;

  const taskByTaskId = new Map<number, Task>(projectTasks.map(t => [t.id, t]));
  const sheetSummary = summarizeSheetStatus(checklistSheets, taskByTaskId);

  // 설비 상태 요약 (status / 다음 점검 / 진행률 등)
  const eqSummary = summarizeEquipment(project, projectTasks, projectSheets);
  const statusChip = statusChipColor(eqSummary.status);
  const nextDue = eqSummary.nextPeriodicTask || eqSummary.nextDueTask;
  const incompleteSheetCount = sheetSummary.total - sheetSummary.completed;

  // 체크시트 완료 판정 — status completed 또는 진행률 100%
  const isSheetDone = (s: SheetExecution) => s.status === 'completed' || (s.progress || 0) >= 100;
  const sheetStatusText = (s: SheetExecution): string => {
    if (isSheetDone(s)) return '완료';
    if (s.status === 'in_progress' || (s.progress || 0) > 0) return '진행 중';
    return '완료 전';
  };
  // 기본은 미완료(진행중/지연/미착수)만, 토글 ON 이면 완료 포함 (체크리스트 시트만)
  const visibleSheets = showCompletedSheets ? checklistSheets : checklistSheets.filter(s => !isSheetDone(s));
  const SHEET_LIST_LIMIT = 5;

  // 다음 예정 작업 — open task 중 due_date 가까운 순 5개
  const nextTasks = sortByNearestDue(projectTasks.filter(isOpen)).slice(0, 5);

  // ── 요약 통계 클릭 → 필터 목록 모달 ──
  const incompleteChecklistSheets = checklistSheets.filter(s => !isSheetDone(s));
  const mappingSheets = projectSheets.filter(isEquipmentMappingSheet);

  const issueRow = (t: Task) => ({
    id: `task-${t.id}`,
    primary: (
      <>
        {t.priority === 'high' && (
          <span style={{
            fontSize: 10, fontWeight: 700, color: 'var(--eq-error)',
            background: 'var(--eq-error-soft-bg)', padding: '1px 6px', borderRadius: 999, marginRight: 6,
          }}>HIGH</span>
        )}
        {t.title}
      </>
    ),
    secondary: t.due_date ? dDayLabel(t.due_date) : t.status,
    onClick: onOpenTask ? () => { onOpenTask(t); setStatModal(null); } : undefined,
  });
  const sheetRow = (s: SheetExecution, secondary: React.ReactNode) => ({
    id: `sheet-${s.id}`,
    primary: s.title || s.template_name || `Sheet #${s.id}`,
    secondary,
    onClick: onOpenSheet ? () => { onOpenSheet(s.id); setStatModal(null); } : undefined,
  });
  const boardFooter = onOpenProjectTab
    ? { footerLabel: '작업 보드에서 전체 보기', onFooter: () => { onOpenProjectTab(project.id, 'board'); setStatModal(null); } }
    : {};

  const openIssuesModal = () => setStatModal({
    title: '활성 이슈',
    items: issues.map(issueRow),
    emptyText: '활성 이슈가 없습니다.',
    ...boardFooter,
  });
  const openIncompleteSheetsModal = () => setStatModal({
    title: '미완료 체크시트',
    items: incompleteChecklistSheets.map(s => sheetRow(s, `진행률 ${s.progress || 0}%`)),
    emptyText: '미완료 체크시트가 없습니다.',
  });
  const openMappingSheetsModal = () => setStatModal({
    title: '운영 매핑 시트',
    items: mappingSheets.map(s => sheetRow(s, '설비-배치 매핑형')),
    emptyText: '연결된 매핑 시트가 없습니다.',
  });

  return (
    <div className="equipment-ops-detail">
      <div className="equipment-ops-detail-head">
        <div>
          <h2>{project.name}</h2>
          {project.description && (
            <div className="equipment-ops-detail-subtitle" style={{ marginTop: 4 }}>
              {project.description}
            </div>
          )}
        </div>
        <div className="equipment-ops-actions">
          <button
            type="button"
            className="equipment-ops-btn primary"
            onClick={() => onQuickAddTask?.(project.id)}
          >
            + 점검 예약
          </button>
          <button
            type="button"
            className="equipment-ops-btn"
            onClick={() => onOpenProjectTab?.(project.id, 'board')}
          >
            작업 보드 보기
          </button>
          <button
            type="button"
            className="equipment-ops-btn"
            onClick={() => onOpenProjectTab?.(project.id, 'calendar')}
          >
            전체 일정 보기
          </button>
          <button
            type="button"
            className="equipment-ops-btn"
            onClick={() => onOpenProjectTab?.(project.id, 'settings')}
          >
            설비 편집
          </button>
        </div>
      </div>

      <div className="equipment-ops-tabs">
        {TABS.map(t => (
          <button
            key={t.id}
            type="button"
            className={`equipment-ops-tab${tab === t.id ? ' is-active' : ''}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="equipment-ops-detail-grid">
          {/* 설비 상태 요약 — "지금 이 설비가 어떤 상태인지" 한눈에 */}
          <div className="equipment-ops-detail-card" style={{ gridColumn: '1 / -1' }}>
            <div className="equipment-ops-card-h">
              <span>설비 상태</span>
              <span
                className="equipment-ops-status-chip"
                style={{ background: statusChip.bg, color: statusChip.fg }}
              >
                {statusChip.label}
              </span>
            </div>
            <div className="equipment-ops-list" style={{ marginTop: 4 }}>
              <StatRow
                label="예정 점검"
                value={
                  nextDue?.due_date
                    ? <>{nextDue.due_date.slice(0, 10)} <span style={{ color: 'var(--eq-primary)', fontWeight: 700 }}>({dDayLabel(nextDue.due_date)})</span></>
                    : '예정 점검 없음'
                }
                disabled={!nextDue}
                onClick={onOpenProjectTab ? () => onOpenProjectTab(project.id, 'calendar') : undefined}
              />
              <StatRow
                label="활성 이슈"
                value={`${issues.length}건`}
                variant={issues.length > 0 ? 'issue' : undefined}
                disabled={issues.length === 0}
                onClick={openIssuesModal}
              />
              <StatRow
                label="미완료 체크시트"
                value={<>{incompleteSheetCount} / {sheetSummary.total}</>}
                variant={incompleteChecklistSheets.length > 0 ? 'sheet' : undefined}
                disabled={incompleteChecklistSheets.length === 0}
                onClick={openIncompleteSheetsModal}
              />
              {mappingSheetCount > 0 && (
                <StatRow
                  label="설비-배치 매핑"
                  value={`${mappingSheetCount}개`}
                  onClick={openMappingSheetsModal}
                />
              )}
              <div className="equipment-ops-list-row">
                <span>진행률</span>
                <span className="equipment-ops-list-meta" style={{ color: 'var(--eq-primary-dark)', fontWeight: 700 }}>{sheetSummary.overall}%</span>
              </div>
            </div>
            <div className="equipment-ops-progress-track" style={{ marginTop: 6 }}>
              <div className="equipment-ops-progress-fill" style={{ width: `${sheetSummary.overall}%` }} />
            </div>
          </div>

          {/* 체크시트 현황 — 기본은 미완료만, 요약 + 토글 */}
          <div className="equipment-ops-detail-card">
            <div className="equipment-ops-card-h">
              <span>체크시트 현황</span>
              <button
                type="button"
                className="equipment-ops-btn"
                style={{ padding: '2px 8px', fontSize: 11 }}
                onClick={() => setShowCompletedSheets(v => !v)}
              >
                완료 항목 보기 {showCompletedSheets ? 'ON' : 'OFF'}
              </button>
            </div>
            {sheetSummary.total === 0 ? (
              <div className="equipment-ops-empty">연결된 체크시트가 없습니다.</div>
            ) : (
              <>
                <div style={{ fontSize: 12, color: 'var(--eq-text-secondary)', fontWeight: 600, marginBottom: 2 }}>
                  미완료 {incompleteSheetCount} · 진행중{' '}
                  <span style={{ color: sheetSummary.inProgress > 0 ? '#7c3aed' : undefined, fontWeight: sheetSummary.inProgress > 0 ? 700 : undefined }}>
                    {sheetSummary.inProgress}
                  </span>
                  {' '}· 완료 {sheetSummary.completed}
                  {sheetSummary.overdue > 0 && (
                    <span style={{ color: '#d97706', fontWeight: 700 }}> · 지연 {sheetSummary.overdue}</span>
                  )}
                </div>
                <div style={{ fontSize: 11, color: 'var(--eq-primary-dark)', fontWeight: 700, marginBottom: 4 }}>
                  진행률 {sheetSummary.overall}%
                </div>
                {visibleSheets.length === 0 ? (
                  <div className="equipment-ops-empty">미완료 체크시트가 없습니다.</div>
                ) : (
                  <div className="equipment-ops-list">
                    {visibleSheets.slice(0, SHEET_LIST_LIMIT).map(s => (
                      <div
                        key={s.id}
                        className="equipment-ops-list-row"
                        style={{ cursor: onOpenSheet ? 'pointer' : 'default' }}
                        onClick={() => onOpenSheet?.(s.id)}
                      >
                        <span>{s.title || s.template_name || `Sheet #${s.id}`}</span>
                        <span className="equipment-ops-list-meta">{s.progress || 0}% · {sheetStatusText(s)}</span>
                      </div>
                    ))}
                    {visibleSheets.length > SHEET_LIST_LIMIT && (
                      <button
                        type="button"
                        className="equipment-ops-btn"
                        style={{ padding: '2px 8px', fontSize: 11, marginTop: 4, alignSelf: 'flex-start' }}
                        onClick={() => onOpenSheetsPage?.()}
                      >
                        전체 보기 (+{visibleSheets.length - SHEET_LIST_LIMIT})
                      </button>
                    )}
                  </div>
                )}
              </>
            )}
          </div>

          {/* 활성 이슈 — High 또는 미해결 이슈 위주. 이슈가 있으면 카드 전체를 은은한 빨강으로 강조. */}
          <div
            className="equipment-ops-detail-card"
            style={issues.length > 0 ? { background: '#fff5f5', borderColor: '#fecaca', borderLeft: '3px solid #ef4444' } : undefined}
          >
            <div className="equipment-ops-card-h">
              <span>활성 이슈</span>
              <span style={{ fontSize: 11, color: issues.length > 0 ? 'var(--eq-error)' : 'var(--eq-text-secondary)', fontWeight: 700 }}>
                {issues.length}건
              </span>
            </div>
            {issues.length === 0 ? (
              <div className="equipment-ops-empty">활성 이슈가 없습니다.</div>
            ) : (
              <div className="equipment-ops-list">
                {issues.slice(0, 6).map(t => (
                  <div
                    key={t.id}
                    className="equipment-ops-list-row"
                    style={{ cursor: onOpenTask ? 'pointer' : 'default' }}
                    onClick={() => onOpenTask?.(t)}
                  >
                    <span>
                      {t.priority === 'high' && (
                        <span style={{
                          fontSize: 10, fontWeight: 700, color: 'var(--eq-error)',
                          background: 'var(--eq-error-soft-bg)', padding: '1px 6px', borderRadius: 999, marginRight: 6,
                        }}>HIGH</span>
                      )}
                      {t.title}
                    </span>
                    <span className="equipment-ops-list-meta">
                      {t.due_date ? dDayLabel(t.due_date) : t.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 다음 예정 작업 */}
          <div className="equipment-ops-detail-card" style={{ gridColumn: '1 / -1' }}>
            <div className="equipment-ops-card-h">
              <span>다음 예정 작업</span>
              <span style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{nextTasks.length}건</span>
            </div>
            {nextTasks.length === 0 ? (
              <div className="equipment-ops-empty">예정된 작업이 없습니다.</div>
            ) : (
              <div className="equipment-ops-list">
                {nextTasks.map(t => (
                  <div
                    key={t.id}
                    className="equipment-ops-list-row"
                    style={{ cursor: onOpenTask ? 'pointer' : 'default' }}
                    onClick={() => onOpenTask?.(t)}
                  >
                    <span>{t.title}</span>
                    <span className="equipment-ops-list-meta">
                      {t.due_date?.slice(0, 10) || ''}
                      {t.due_date && (
                        <span style={{ color: 'var(--eq-primary)', fontWeight: 700, marginLeft: 6 }}>{dDayLabel(t.due_date)}</span>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'detail' && (
        <EquipmentDetailInfoTab
          project={project}
          projectTasks={projectTasks}
          projectSheets={projectSheets}
          currentUserId={currentUserId}
          onOpenTask={onOpenTask}
          onOpenSheet={onOpenSheet}
          onOpenProjectTab={onOpenProjectTab}
        />
      )}

      {tab === 'history' && (
        <EquipmentHistoryTab
          projectTasks={projectTasks}
          projectSheets={projectSheets}
          onOpenTask={onOpenTask}
          onOpenSheet={onOpenSheet}
        />
      )}

      {tab === 'links' && (
        <EquipmentLinksTab
          project={project}
          projectSheets={projectSheets}
          onOpenSheet={onOpenSheet}
          onOpenSheetsPage={onOpenSheetsPage}
        />
      )}

      {tab === 'files' && (
        <EquipmentFilesTab
          project={project}
          currentUserId={currentUserId}
        />
      )}

      <EquipmentStatModal state={statModal} onClose={() => setStatModal(null)} />
    </div>
  );
};

export default SelectedEquipmentDetail;
