import React, { useState } from 'react';
import {
  DndContext,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  closestCenter,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  arrayMove,
  rectSortingStrategy,
  sortableKeyboardCoordinates,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

import type { Project, Task, SheetExecution } from '../../types';
import {
  isOpen,
  isToday,
  isThisWeek,
  isPeriodicTask,
  categorizeIssueTasks,
  sortByLatestUpdate,
  sortByNearestDue,
  formatRelative,
  dDayLabel,
  type IssueKind,
} from './equipmentDashboardUtils';
import { isEquipmentMappingSheet } from '../sheets/assignmentMappingDetect';
import EquipmentAiSummaryCard from './EquipmentAiSummaryCard';

export type EquipmentWidgetId =
  | 'today_week'
  | 'periodic'
  | 'recent'
  | 'sheets'
  | 'issues'
  | 'ai_summary';

export const DEFAULT_EQUIPMENT_WIDGET_ORDER: EquipmentWidgetId[] = [
  'today_week',
  'periodic',
  'recent',
  'sheets',
  'issues',
  'ai_summary',
];

interface Props {
  project: Project | null;
  projectTasks: Task[];
  projectSheets: SheetExecution[];
  currentUserId: number;
  /** 사용자 저장 위젯 순서. 누락 ID 는 자동 폴백, 미지정 ID 는 끝에 자동 추가. */
  widgetOrder?: EquipmentWidgetId[];
  /** 표시할 위젯 ID 집합. undefined 이면 전체 표시. (Widget Settings 토글과 연결) */
  visibleWidgets?: Set<EquipmentWidgetId>;
  /** 사용자가 drag 로 순서를 바꿨을 때 호출. */
  onReorder?: (next: EquipmentWidgetId[]) => void;
  onOpenTask?: (task: Task) => void;
  onOpenSheet?: (executionId: number) => void;
  onOpenReportTab?: (projectId: number) => void;
}

interface WidgetHeaderProps {
  title: string;
  count?: number;
  /** drag handle 의 listeners/attributes (useSortable 가 반환). */
  dragHandleProps?: React.HTMLAttributes<HTMLDivElement>;
  rightSlot?: React.ReactNode;
}

const WidgetHeader: React.FC<WidgetHeaderProps> = ({ title, count, dragHandleProps, rightSlot }) => (
  <div className="equipment-ops-widget-head">
    <div
      className="equipment-ops-widget-title equipment-ops-drag-handle"
      {...(dragHandleProps || {})}
      title="드래그하여 위치 변경"
    >
      <span aria-hidden style={{ cursor: 'grab', fontSize: 12, color: 'var(--eq-text-secondary)' }}>⠿</span>
      {title}
      {typeof count === 'number' && (
        <span className="equipment-ops-widget-count" style={{ marginLeft: 6 }}>{count}</span>
      )}
    </div>
    {rightSlot}
  </div>
);

const Row: React.FC<{ left: React.ReactNode; right?: React.ReactNode; onClick?: () => void }> = ({ left, right, onClick }) => (
  <div
    className="equipment-ops-list-row"
    style={{ cursor: onClick ? 'pointer' : 'default' }}
    onClick={onClick}
  >
    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{left}</span>
    {right && <span className="equipment-ops-list-meta">{right}</span>}
  </div>
);

interface SortableWidgetProps {
  id: EquipmentWidgetId;
  children: (handle: React.HTMLAttributes<HTMLDivElement>) => React.ReactNode;
}

const SortableWidget: React.FC<SortableWidgetProps> = ({ id, children }) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 5 : undefined,
  };
  const handleProps: React.HTMLAttributes<HTMLDivElement> = {
    ...(attributes as React.HTMLAttributes<HTMLDivElement>),
    ...(listeners as unknown as React.HTMLAttributes<HTMLDivElement>),
  };
  return (
    <div ref={setNodeRef} style={style} className="equipment-ops-widget-card">
      {children(handleProps)}
    </div>
  );
};

/** widgetOrder 정규화: 유효 ID 만 남기고 누락된 default ID 는 뒤에 보충. */
function normalizeOrder(order?: EquipmentWidgetId[]): EquipmentWidgetId[] {
  const valid = new Set<EquipmentWidgetId>(DEFAULT_EQUIPMENT_WIDGET_ORDER);
  const cleaned = (order || []).filter((id): id is EquipmentWidgetId => valid.has(id));
  const missing = DEFAULT_EQUIPMENT_WIDGET_ORDER.filter(id => !cleaned.includes(id));
  return [...cleaned, ...missing];
}

const EquipmentOpsWidgets: React.FC<Props> = ({
  project, projectTasks, projectSheets, currentUserId, widgetOrder, visibleWidgets, onReorder,
  onOpenTask, onOpenSheet, onOpenReportTab,
}) => {
  const normalized = normalizeOrder(widgetOrder);
  const order = visibleWidgets
    ? normalized.filter(id => visibleWidgets.has(id))
    : normalized;
  const openTasks = projectTasks.filter(isOpen);
  // 체크시트 현황: 완료 항목 기본 숨김, 토글로만 표시
  const [showCompletedSheets, setShowCompletedSheets] = useState(false);

  // 1. 오늘 / 이번주 일정
  const todayList = openTasks.filter(t => isToday(t.due_date) || isToday(t.start_date));
  const weekList = sortByNearestDue(openTasks.filter(t => isThisWeek(t.due_date)));

  // 2. 주기 점검 / 반복 작업
  const periodicList = sortByNearestDue(openTasks.filter(isPeriodicTask));

  // 3. 최근 변경사항 / 이력
  const recentTasks = sortByLatestUpdate(projectTasks).slice(0, 6);

  // 4. 체크시트 현황 — 점검 수행형(체크리스트)만. 설비-배치 매핑형은 진행률 개념이 없어 제외.
  //    완료(status completed 또는 진행률 100%)는 기본 숨김.
  const isSheetDone = (s: SheetExecution) => s.status === 'completed' || (s.progress || 0) >= 100;
  const sheets = sortByLatestUpdate(
    projectSheets.filter(s => !isEquipmentMappingSheet(s)).map(s => ({
      ...s,
      updated_at: s.completed_at || s.started_at,
    })),
  );
  const visibleSheetList = showCompletedSheets ? sheets : sheets.filter(s => !isSheetDone(s));

  // 6. 이슈 / 장애 / 메모
  const { fault: faultList, issue: issueList, memo: memoList } = categorizeIssueTasks(projectTasks);
  const issueAggregated: { kind: IssueKind; task: Task }[] = [
    ...faultList.map(t => ({ kind: 'fault' as const, task: t })),
    ...issueList.map(t => ({ kind: 'issue' as const, task: t })),
    ...memoList.map(t => ({ kind: 'memo' as const, task: t })),
  ];
  const issueKindLabel: Record<IssueKind, { text: string; bg: string; fg: string }> = {
    fault: { text: '장애', bg: 'var(--eq-fault-bg)', fg: 'var(--eq-fault-fg)' },
    issue: { text: '이슈', bg: 'var(--eq-issue-bg)', fg: 'var(--eq-issue-fg)' },
    memo:  { text: '메모', bg: 'var(--eq-memo-bg)',  fg: 'var(--eq-memo-fg)' },
  };

  const renderWidget = (id: EquipmentWidgetId, handleProps: React.HTMLAttributes<HTMLDivElement>): React.ReactNode => {
    switch (id) {
      case 'today_week': {
        const total = todayList.length + weekList.length;
        return (
          <>
            <WidgetHeader title="오늘 / 이번주 일정" count={total} dragHandleProps={handleProps} />
            {total === 0 ? (
              <div className="equipment-ops-empty">이번주 예정 작업 없음</div>
            ) : (
              <div className="equipment-ops-list">
                {todayList.length > 0 && (
                  <>
                    <div style={{ fontSize: 11, color: 'var(--eq-primary)', fontWeight: 700, marginBottom: 2 }}>오늘</div>
                    {todayList.slice(0, 4).map(t => (
                      <Row key={t.id} left={t.title} right="오늘" onClick={() => onOpenTask?.(t)} />
                    ))}
                  </>
                )}
                {weekList.length > 0 && (
                  <>
                    <div style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 700, marginTop: 6, marginBottom: 2 }}>이번 주</div>
                    {weekList.slice(0, 5).map(t => (
                      <Row
                        key={t.id}
                        left={t.title}
                        right={t.due_date?.slice(5, 10)}
                        onClick={() => onOpenTask?.(t)}
                      />
                    ))}
                  </>
                )}
              </div>
            )}
          </>
        );
      }
      case 'periodic':
        return (
          <>
            <WidgetHeader title="주기 점검 / 반복 작업" count={periodicList.length} dragHandleProps={handleProps} />
            {periodicList.length === 0 ? (
              <div className="equipment-ops-empty">반복 작업으로 식별된 항목이 없습니다.</div>
            ) : (
              <div className="equipment-ops-list">
                {periodicList.slice(0, 6).map(t => (
                  <Row
                    key={t.id}
                    left={t.title}
                    right={t.due_date ? `${t.due_date.slice(5, 10)} · ${dDayLabel(t.due_date)}` : t.status}
                    onClick={() => onOpenTask?.(t)}
                  />
                ))}
              </div>
            )}
          </>
        );
      case 'recent':
        return (
          <>
            <WidgetHeader title="최근 변경사항 / 이력" count={recentTasks.length} dragHandleProps={handleProps} />
            {recentTasks.length === 0 ? (
              <div className="equipment-ops-empty">최근 변경 내역이 없습니다.</div>
            ) : (
              <div className="equipment-ops-list">
                {recentTasks.map(t => (
                  <Row
                    key={t.id}
                    left={t.title}
                    right={formatRelative(t.updated_at || t.created_at)}
                    onClick={() => onOpenTask?.(t)}
                  />
                ))}
              </div>
            )}
          </>
        );
      case 'sheets':
        return (
          <>
            <WidgetHeader
              title="체크시트 현황"
              count={visibleSheetList.length}
              dragHandleProps={handleProps}
              rightSlot={
                <button
                  type="button"
                  className="equipment-ops-btn"
                  style={{ padding: '2px 8px', fontSize: 11 }}
                  onClick={() => setShowCompletedSheets(v => !v)}
                >
                  완료 항목 보기 {showCompletedSheets ? 'ON' : 'OFF'}
                </button>
              }
            />
            {sheets.length === 0 ? (
              <div className="equipment-ops-empty">연결된 체크시트가 없습니다.</div>
            ) : visibleSheetList.length === 0 ? (
              <div className="equipment-ops-empty">미완료 체크시트가 없습니다.</div>
            ) : (
              <div className="equipment-ops-list">
                {visibleSheetList.slice(0, 6).map(s => (
                  <Row
                    key={s.id}
                    left={s.title || s.template_name || `Sheet #${s.id}`}
                    right={`${s.progress || 0}%${s.status === 'in_progress' ? ' · 진행' : s.status === 'completed' ? ' · 완료' : ''}`}
                    onClick={() => onOpenSheet?.(s.id)}
                  />
                ))}
              </div>
            )}
          </>
        );
      case 'issues':
        return (
          <>
            <WidgetHeader title="이슈 / 장애 / 메모" count={issueAggregated.length} dragHandleProps={handleProps} />
            {issueAggregated.length === 0 ? (
              <div className="equipment-ops-empty">이슈가 없습니다.</div>
            ) : (
              <div className="equipment-ops-list">
                {issueAggregated.slice(0, 6).map(({ kind, task: t }) => {
                  const label = issueKindLabel[kind];
                  return (
                    <Row
                      key={`${kind}-${t.id}`}
                      left={
                        <>
                          <span style={{
                            fontSize: 10, fontWeight: 700, color: label.fg,
                            background: label.bg, padding: '1px 6px', borderRadius: 999, marginRight: 6,
                          }}>{label.text}</span>
                          {t.title}
                        </>
                      }
                      right={t.due_date ? dDayLabel(t.due_date) : t.status}
                      onClick={() => onOpenTask?.(t)}
                    />
                  );
                })}
              </div>
            )}
          </>
        );
      case 'ai_summary':
        return (
          <>
            <WidgetHeader title="AI 운영 요약" dragHandleProps={handleProps} />
            {project ? (
              <EquipmentAiSummaryCard
                project={project}
                projectTasks={projectTasks}
                projectSheets={projectSheets}
                userId={currentUserId}
                onOpenReportTab={onOpenReportTab ? () => onOpenReportTab(project.id) : undefined}
              />
            ) : (
              <div className="equipment-ops-empty">
                설비를 선택하면 해당 설비의 AI 운영 요약을 확인할 수 있습니다.
              </div>
            )}
          </>
        );
    }
  };

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const handleDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIdx = order.indexOf(active.id as EquipmentWidgetId);
    const newIdx = order.indexOf(over.id as EquipmentWidgetId);
    if (oldIdx < 0 || newIdx < 0) return;
    const next = arrayMove(order, oldIdx, newIdx);
    onReorder?.(next);
  };

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={order} strategy={rectSortingStrategy}>
        <div className="equipment-ops-widgets">
          {order.map(id => (
            <SortableWidget key={id} id={id}>
              {(handleProps) => renderWidget(id, handleProps)}
            </SortableWidget>
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
};

export default EquipmentOpsWidgets;
