import React from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, Box, Typography, IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

/**
 * 설비 상세(개요/상세 정보)의 요약 통계 row 를 클릭했을 때 뜨는 필터 목록 모달 + 클릭형 통계 row.
 * 숫자만 보여주고 끝나지 않고, 바로 해당 항목 리스트로 연결하기 위한 공통 컴포넌트.
 */

export interface StatModalItem {
  id: string;
  primary: React.ReactNode;
  secondary?: React.ReactNode;
  /** 지정 시 row 클릭 가능 (해당 task/sheet 열기). */
  onClick?: () => void;
}

export interface StatModalState {
  title: string;
  items: StatModalItem[];
  emptyText?: string;
  /** "전체 보기" 등 하단 액션 버튼 라벨/콜백 (옵션). */
  footerLabel?: string;
  onFooter?: () => void;
}

interface ModalProps {
  state: StatModalState | null;
  onClose: () => void;
}

export const EquipmentStatModal: React.FC<ModalProps> = ({ state, onClose }) => (
  <Dialog open={!!state} onClose={onClose} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 3 } }}>
    <DialogTitle sx={{ fontWeight: 700, fontSize: '0.98rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', pr: 1 }}>
      <span>
        {state?.title}
        <span style={{ color: '#6B7280', fontWeight: 600, fontSize: '0.82rem', marginLeft: 6 }}>
          {state?.items.length ?? 0}건
        </span>
      </span>
      <IconButton size="small" onClick={onClose}><CloseIcon sx={{ fontSize: 18 }} /></IconButton>
    </DialogTitle>
    <DialogContent dividers>
      {!state || state.items.length === 0 ? (
        <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
          {state?.emptyText || '해당 항목이 없습니다.'}
        </Typography>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.6 }}>
          {state.items.map(it => (
            <Box
              key={it.id}
              onClick={it.onClick}
              sx={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 1,
                p: 1, borderRadius: 1.5, border: '1px solid #E5E7EB',
                cursor: it.onClick ? 'pointer' : 'default',
                '&:hover': it.onClick ? { bgcolor: '#F8FAFC' } : undefined,
              }}
            >
              <Box sx={{ minWidth: 0, fontSize: '0.8rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {it.primary}
              </Box>
              {it.secondary != null && (
                <Box sx={{ flexShrink: 0, fontSize: '0.72rem', color: '#6B7280', whiteSpace: 'nowrap' }}>
                  {it.secondary}
                </Box>
              )}
            </Box>
          ))}
        </Box>
      )}
    </DialogContent>
    {state?.footerLabel && state.onFooter && (
      <DialogActions sx={{ px: 2, pb: 1.5 }}>
        <Button onClick={state.onFooter} size="small" variant="outlined">{state.footerLabel}</Button>
      </DialogActions>
    )}
  </Dialog>
);

/**
 * 상태 강조 variant — 중요 상태(이슈/진행/지연 등)를 흰색 row 에 묻히지 않게 은은하게 강조.
 * 배경 톤/좌측 accent bar 는 CSS(.eq-stat-*), 숫자 색은 countColor 로 적용한다.
 * count 가 0 인 항목은 호출측에서 variant 를 넘기지 않아 기존 흰색을 유지한다.
 */
export type StatRowVariant = 'issue' | 'progress' | 'sheet' | 'delayed' | 'done';

const STAT_VARIANT_COUNT_COLOR: Record<StatRowVariant, string> = {
  issue: '#dc2626',
  progress: '#2563eb',
  sheet: '#7c3aed',
  delayed: '#d97706',
  done: '#16a34a',
};

/**
 * 클릭 가능한 요약 통계 row. onClick 이 있고 disabled 가 아니면 hover/포인터/chevron 을 표시한다.
 * 0건 등 비활성 항목은 흐리게 처리하고 클릭을 막는다.
 * variant 가 있으면 상태별 은은한 배경/좌측 accent + 숫자 강조 색을 적용한다.
 */
export const StatRow: React.FC<{
  label: React.ReactNode;
  value: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  variant?: StatRowVariant;
}> = ({ label, value, onClick, disabled, variant }) => {
  const clickable = !!onClick && !disabled;
  return (
    <div
      className={`equipment-ops-list-row${variant ? ` eq-stat-${variant}` : ''}`}
      style={{ cursor: clickable ? 'pointer' : 'default', opacity: disabled ? 0.5 : 1 }}
      onClick={clickable ? onClick : undefined}
    >
      <span style={{ color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{label}</span>
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
        <span
          className="equipment-ops-list-meta"
          style={{ color: variant ? STAT_VARIANT_COUNT_COLOR[variant] : 'var(--eq-text)', fontWeight: variant ? 700 : undefined }}
        >
          {value}
        </span>
        {clickable && <span aria-hidden style={{ color: '#9CA3AF', fontSize: 13, fontWeight: 700, lineHeight: 1 }}>›</span>}
      </span>
    </div>
  );
};
