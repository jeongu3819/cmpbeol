import React from 'react';
import {
  EquipmentSummary,
  statusChipColor,
  dDayLabel,
} from './equipmentDashboardUtils';

interface Props {
  equipments: EquipmentSummary[];
  selectedProjectId: number | null;
  onSelect: (projectId: number) => void;
}

const EquipmentStatusStrip: React.FC<Props> = ({ equipments, selectedProjectId, onSelect }) => {
  if (equipments.length === 0) {
    return (
      <div className="equipment-ops-empty" style={{ padding: '16px 0' }}>
        이 공간에 등록된 설비(=프로젝트)가 없습니다. "+ 프로젝트 추가" 로 설비를 만들어 보세요.
      </div>
    );
  }

  return (
    <div className="equipment-ops-strip">
      {equipments.map(eq => {
        const sc = statusChipColor(eq.status);
        const isSelected = selectedProjectId === eq.project.id;
        const nextDue = eq.nextPeriodicTask || eq.nextDueTask;
        const dLabel = nextDue ? dDayLabel(nextDue.due_date) : '';
        return (
          <button
            key={eq.project.id}
            type="button"
            className={`equipment-ops-equipment-card${isSelected ? ' is-selected' : ''}`}
            onClick={() => onSelect(eq.project.id)}
            style={{ textAlign: 'left' }}
          >
            <div className="equipment-ops-card-head">
              <div className="equipment-ops-card-title" title={eq.project.name}>
                {eq.project.name}
              </div>
              <span
                className="equipment-ops-status-chip"
                style={{ background: sc.bg, color: sc.fg }}
              >
                {sc.label}
              </span>
            </div>

            <div className="equipment-ops-card-meta">
              {nextDue ? (
                <span>
                  다음 점검: {nextDue.due_date?.slice(0, 10) || '-'}
                  {dLabel && (
                    <span style={{ marginLeft: 6, color: 'var(--eq-primary)', fontWeight: 700 }}>({dLabel})</span>
                  )}
                </span>
              ) : (
                <span>예정된 점검 없음</span>
              )}
              <span>
                활성 이슈: <strong style={{ color: eq.activeIssueCount > 0 ? 'var(--eq-error)' : 'var(--eq-text)' }}>{eq.activeIssueCount}</strong>
                {' · '}
                체크시트: <strong>{eq.sheet.inProgress}</strong>/{eq.sheet.total}
                {eq.mappingSheetCount > 0 && (
                  <> · 매핑 <strong>{eq.mappingSheetCount}</strong></>
                )}
              </span>
            </div>

            <div>
              <div className="equipment-ops-progress-track">
                <div
                  className="equipment-ops-progress-fill"
                  style={{ width: `${Math.min(100, Math.max(0, eq.averageProgress))}%` }}
                />
              </div>
              <div style={{ fontSize: 11, color: 'var(--eq-text-secondary)', marginTop: 4, fontWeight: 600 }}>
                진행률 {eq.averageProgress}%
              </div>
            </div>
          </button>
        );
      })}
    </div>
  );
};

export default EquipmentStatusStrip;
