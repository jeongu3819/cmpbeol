import React, { useMemo, useRef, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../../../api/client';
import type { Project, ProjectFile, ProjectMember } from '../../../types';
import { useUser } from '../../../context/UserContext';
import { validateGeneralFiles } from '../../../utils/uploadValidation';
import { formatRelative } from '../equipmentDashboardUtils';

interface Props {
  project: Project;
  currentUserId: number;
}

const formatBytes = (b: number): string => {
  if (!b || b <= 0) return '-';
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
  if (b < 1024 * 1024 * 1024) return `${(b / 1024 / 1024).toFixed(1)} MB`;
  return `${(b / 1024 / 1024 / 1024).toFixed(2)} GB`;
};

const EquipmentFilesTab: React.FC<Props> = ({ project, currentUserId }) => {
  const queryClient = useQueryClient();
  const { user } = useUser();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const { data: files = [], isLoading } = useQuery({
    queryKey: ['projectFiles', project.id, currentUserId],
    queryFn: () => api.getProjectFiles(project.id, currentUserId),
    enabled: project.id > 0 && currentUserId > 0,
  });

  const { data: members = [] } = useQuery({
    queryKey: ['projectMembers', project.id],
    queryFn: () => api.getProjectMembers(project.id),
    enabled: project.id > 0,
  });

  const { data: uploadPolicy } = useQuery({
    queryKey: ['uploadPolicy'],
    queryFn: () => api.getUploadPolicy(),
    staleTime: 60 * 60 * 1000,
  });

  // ── 권한 ──
  // admin/super_admin(전역) 또는 viewer 가 아닌 프로젝트 구성원(owner/admin/member=담당자) → 업로드·삭제 가능.
  // viewer → 다운로드만.
  const globalAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  const myRole = members.find((m: ProjectMember) => m.user_id === currentUserId)?.role;
  const canManage = globalAdmin || (!!myRole && myRole !== 'viewer');

  // uploader_id → 표시명 매핑 (구성원 목록 기준)
  const memberNameById = useMemo(() => {
    const map = new Map<number, string>();
    members.forEach((m: ProjectMember) => {
      if (m.username) map.set(m.user_id, m.username);
    });
    return map;
  }, [members]);

  const sorted = useMemo(
    () => [...files].sort((a, b) => (b.created_at || '').localeCompare(a.created_at || '')),
    [files],
  );

  const uploadMutation = useMutation({
    mutationFn: (file: File) => api.uploadProjectFile(project.id, file, currentUserId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projectFiles', project.id] });
      setUploading(false);
    },
    onError: (err: any) => {
      setUploading(false);
      alert(err?.response?.data?.detail || '파일 업로드에 실패했습니다.');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (fileId: number) => api.deleteProjectFile(project.id, fileId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['projectFiles', project.id] }),
  });

  // 선택/드롭된 파일 검증 후 업로드
  const handleFiles = (selected: FileList | File[] | null) => {
    if (!canManage) return;
    const list = selected ? Array.from(selected) : [];
    if (list.length === 0) return;
    const existingBytes = files.reduce((sum, f) => sum + (f.size || 0), 0);
    const { accepted, error } = validateGeneralFiles(uploadPolicy?.general, list, files.length, existingBytes);
    if (error) {
      alert(error);
      return;
    }
    if (accepted.length > 0) {
      setUploading(true);
      accepted.forEach(file => uploadMutation.mutate(file));
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFiles(e.target.files);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handleFiles(e.dataTransfer.files);
  };

  return (
    <div className="equipment-ops-detail-grid" style={{ gridTemplateColumns: '1fr' }}>
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>문서/파일</span>
          <span style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{sorted.length}개</span>
        </div>

        {/* 업로드 영역 — canManage 일 때만 노출 (드래그 앤 드롭 + 버튼) */}
        {canManage ? (
          <div
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => !uploading && fileInputRef.current?.click()}
            style={{
              border: `1.5px dashed ${dragOver ? 'var(--eq-primary)' : 'var(--eq-border, #d1d5db)'}`,
              borderRadius: 8,
              padding: '14px 12px',
              textAlign: 'center',
              cursor: uploading ? 'default' : 'pointer',
              background: dragOver ? 'var(--eq-primary-soft-bg)' : 'var(--eq-surface-subtle, #f9fafb)',
              color: 'var(--eq-text-secondary)',
              fontSize: 12,
              marginBottom: 10,
              transition: 'all 0.15s',
            }}
          >
            {uploading ? (
              '업로드 중...'
            ) : (
              <>
                <div style={{ fontWeight: 600, color: 'var(--eq-text)' }}>
                  파일을 끌어다 놓거나 클릭하여 업로드
                </div>
                {uploadPolicy?.general && (
                  <div style={{ fontSize: 10, marginTop: 4 }}>
                    {uploadPolicy.general.allowed_label} · 1개당 {uploadPolicy.general.max_file_mb}MB · 최대 {uploadPolicy.general.max_file_count}개
                  </div>
                )}
              </>
            )}
            <input
              ref={fileInputRef}
              type="file"
              multiple
              hidden
              accept={uploadPolicy?.general.allowed_extensions.join(',')}
              onChange={handleInputChange}
            />
          </div>
        ) : (
          <div style={{ fontSize: 11, color: 'var(--eq-text-secondary)', marginBottom: 8 }}>
            보기 권한입니다. 파일 다운로드만 가능합니다.
          </div>
        )}

        {isLoading ? (
          <div className="equipment-ops-empty">파일 목록 불러오는 중...</div>
        ) : sorted.length === 0 ? (
          <div className="equipment-ops-empty">업로드된 파일이 없습니다.</div>
        ) : (
          <div className="equipment-ops-list">
            {sorted.map((f: ProjectFile) => (
              <div key={f.id} className="equipment-ops-list-row" style={{ alignItems: 'center', gap: 8 }}>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, minWidth: 0 }}>
                  <a
                    href={api.downloadProjectFile(f.project_id, f.id, currentUserId)}
                    target="_blank"
                    rel="noreferrer"
                    style={{ color: 'var(--eq-primary-dark)', textDecoration: 'none', fontWeight: 600 }}
                  >
                    {f.filename}
                  </a>
                  <span style={{ display: 'block', fontSize: 10, color: 'var(--eq-text-secondary)', marginTop: 2 }}>
                    {memberNameById.get(f.uploader_id) || `User#${f.uploader_id}`} · {formatRelative(f.created_at)} · {formatBytes(f.size)}
                  </span>
                </span>
                <span style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
                  <a
                    href={api.downloadProjectFile(f.project_id, f.id, currentUserId)}
                    target="_blank"
                    rel="noreferrer"
                    className="equipment-ops-btn"
                    style={{ padding: '2px 8px', fontSize: 11, textDecoration: 'none' }}
                  >
                    다운로드
                  </a>
                  {canManage && (
                    <button
                      type="button"
                      className="equipment-ops-btn"
                      style={{ padding: '2px 8px', fontSize: 11, color: 'var(--eq-error)' }}
                      disabled={deleteMutation.isPending}
                      onClick={() => {
                        if (window.confirm(`"${f.filename}" 파일을 삭제하시겠습니까?`)) deleteMutation.mutate(f.id);
                      }}
                    >
                      삭제
                    </button>
                  )}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default EquipmentFilesTab;
