import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '../../../api/client';
import type { Project, SheetExecution, ProjectMember, SubProject } from '../../../types';
import EquipmentChemicalsCard from '../EquipmentChemicalsCard';

interface Props {
  project: Project;
  projectSheets: SheetExecution[];
  onOpenSheet?: (executionId: number) => void;
  onOpenSheetsPage?: () => void;
}

const EquipmentLinksTab: React.FC<Props> = ({
  project, projectSheets, onOpenSheet, onOpenSheetsPage,
}) => {
  const { data: members = [] } = useQuery({
    queryKey: ['projectMembers', project.id],
    queryFn: () => api.getProjectMembers(project.id),
    enabled: project.id > 0,
  });

  const { data: subProjects = [] } = useQuery({
    queryKey: ['subProjects', project.id],
    queryFn: () => api.getSubProjects(project.id),
    enabled: project.id > 0,
  });

  // 시트별 그룹: 템플릿 단위 묶음
  const sheetGroups = new Map<string, SheetExecution[]>();
  projectSheets.forEach(s => {
    const key = s.template_name || `template-${s.template_id}`;
    if (!sheetGroups.has(key)) sheetGroups.set(key, []);
    sheetGroups.get(key)!.push(s);
  });

  return (
    <div className="equipment-ops-detail-grid">
      {/* 담당자/구성원 */}
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>담당자 / 구성원</span>
          <span style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{members.length}명</span>
        </div>
        {members.length === 0 ? (
          <div className="equipment-ops-empty">등록된 구성원이 없습니다.</div>
        ) : (
          <div className="equipment-ops-list">
            {members.slice(0, 12).map((m: ProjectMember) => (
              <div key={`${m.user_id}-${m.role}`} className="equipment-ops-list-row">
                <span>
                  <span style={{
                    display: 'inline-block', width: 8, height: 8, borderRadius: 999,
                    background: m.avatar_color || 'var(--eq-text-secondary)', marginRight: 6,
                  }} />
                  {m.username || `User#${m.user_id}`}
                  {m.mail && <span style={{ color: 'var(--eq-text-secondary)', marginLeft: 6, fontSize: 11 }}>{m.mail}</span>}
                </span>
                <span className="equipment-ops-list-meta">{m.role}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 하위 분류 */}
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>하위 분류 / SubProject</span>
          <span style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{subProjects.length}개</span>
        </div>
        {subProjects.length === 0 ? (
          <div className="equipment-ops-empty">하위 분류가 없습니다.</div>
        ) : (
          <div className="equipment-ops-list">
            {subProjects.map((sp: SubProject) => (
              <div key={sp.id} className="equipment-ops-list-row">
                <span>{sp.name}</span>
                {sp.description && (
                  <span className="equipment-ops-list-meta">{sp.description.slice(0, 40)}</span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 연결된 시트 템플릿 */}
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>연결된 시트 템플릿</span>
          <span style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{sheetGroups.size}종</span>
        </div>
        {sheetGroups.size === 0 ? (
          <div className="equipment-ops-empty">연결된 시트가 없습니다.</div>
        ) : (
          <div className="equipment-ops-list">
            {Array.from(sheetGroups.entries()).slice(0, 10).map(([name, list]) => (
              <div
                key={name}
                className="equipment-ops-list-row"
                style={{ cursor: onOpenSheet ? 'pointer' : 'default' }}
                onClick={() => onOpenSheet?.(list[0].id)}
              >
                <span>{name}</span>
                <span className="equipment-ops-list-meta">{list.length}회 실행</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 연결 약품 — 현재 설비에 직접 매칭되는 약품만 표시 */}
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>연결 약품 ({project.name})</span>
          {onOpenSheetsPage && (
            <button
              type="button"
              className="equipment-ops-btn"
              style={{ padding: '2px 8px', fontSize: 11 }}
              onClick={onOpenSheetsPage}
            >
              약품 관리 →
            </button>
          )}
        </div>
        <EquipmentChemicalsCard
          projectSheets={projectSheets}
          variant="card"
          equipmentName={project.name}
          onOpenSheet={onOpenSheet}
          onOpenSheetsPage={onOpenSheetsPage}
        />
      </div>
    </div>
  );
};

export default EquipmentLinksTab;
