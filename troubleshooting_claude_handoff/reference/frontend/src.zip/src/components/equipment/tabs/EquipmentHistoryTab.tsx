import React, { useMemo } from 'react';
import type { Task, SheetExecution } from '../../../types';
import { sortByLatestUpdate, formatRelative } from '../equipmentDashboardUtils';

interface Props {
  projectTasks: Task[];
  projectSheets: SheetExecution[];
  onOpenTask?: (task: Task) => void;
  onOpenSheet?: (executionId: number) => void;
}

interface HistoryRow {
  id: string;
  ts: string | null | undefined;
  kind: '체크시트' | '작업' | '이슈';
  title: string;
  status: string;
  onClick?: () => void;
}

const kindColor: Record<HistoryRow['kind'], string> = {
  '체크시트': 'var(--eq-primary-dark)',
  '작업': 'var(--eq-primary)',
  '이슈': 'var(--eq-error)',
};

const EquipmentHistoryTab: React.FC<Props> = ({
  projectTasks, projectSheets, onOpenTask, onOpenSheet,
}) => {
  const rows = useMemo(() => {
    const list: HistoryRow[] = [];

    projectSheets.forEach(s => {
      const ts = s.completed_at || s.started_at;
      list.push({
        id: `sheet-${s.id}`,
        ts,
        kind: '체크시트',
        title: s.title || s.template_name || `Sheet #${s.id}`,
        status: s.status === 'completed'
          ? `완료 · ${s.progress || 0}%`
          : s.status === 'in_progress'
            ? `진행 중 · ${s.progress || 0}%`
            : s.status,
        onClick: () => onOpenSheet?.(s.id),
      });
    });

    projectTasks.forEach(t => {
      const isIssue = (t.priority === 'high') || /이슈|장애|문제|불량|오류/.test(t.title);
      list.push({
        id: `task-${t.id}`,
        ts: t.updated_at || t.created_at,
        kind: isIssue ? '이슈' : '작업',
        title: t.title,
        status: t.status,
        onClick: () => onOpenTask?.(t),
      });
    });

    return sortByLatestUpdate(
      list.map(r => ({ ...r, updated_at: r.ts || '' })),
    ) as (HistoryRow & { updated_at: string })[];
  }, [projectTasks, projectSheets, onOpenTask, onOpenSheet]);

  if (rows.length === 0) {
    return (
      <div className="equipment-ops-empty" style={{ padding: '24px 0', textAlign: 'center' }}>
        이력 데이터가 없습니다.
      </div>
    );
  }

  return (
    <div className="equipment-ops-detail-grid" style={{ gridTemplateColumns: '1fr' }}>
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>전체 이력</span>
          <span style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{rows.length}건</span>
        </div>
        <div className="equipment-ops-list">
          {rows.slice(0, 60).map(r => (
            <div
              key={r.id}
              className="equipment-ops-list-row"
              style={{ cursor: r.onClick ? 'pointer' : 'default' }}
              onClick={r.onClick}
            >
              <span>
                <span style={{
                  fontWeight: 700, color: kindColor[r.kind], marginRight: 6, fontSize: 11,
                }}>
                  [{r.kind}]
                </span>
                {r.title}
              </span>
              <span className="equipment-ops-list-meta">
                {r.status} · {formatRelative(r.ts || '')}
              </span>
            </div>
          ))}
          {rows.length > 60 && (
            <div style={{ fontSize: 11, color: 'var(--eq-text-secondary)', textAlign: 'right' }}>
              +{rows.length - 60} more
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EquipmentHistoryTab;
