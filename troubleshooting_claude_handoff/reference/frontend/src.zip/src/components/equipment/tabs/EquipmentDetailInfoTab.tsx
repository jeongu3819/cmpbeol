import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '../../../api/client';
import type { Project, Task, SheetExecution, ProjectMember, SubProject } from '../../../types';
import { isOpen, isIssueTask, dDayLabel } from '../equipmentDashboardUtils';
import { isEquipmentMappingSheet } from '../../sheets/assignmentMappingDetect';
import { EquipmentStatModal, StatRow, type StatModalState } from '../EquipmentStatModal';

interface Props {
  project: Project;
  projectTasks: Task[];
  projectSheets: SheetExecution[];
  currentUserId: number;
  /** 클릭 시 해당 task 의 TaskDrawer 열기 */
  onOpenTask?: (task: Task) => void;
  /** 클릭 시 해당 시트 실행으로 이동 */
  onOpenSheet?: (executionId: number) => void;
  /** "작업 보드 보기" 등 ProjectPage 탭으로 이동 */
  onOpenProjectTab?: (projectId: number, tab: 'board' | 'list' | 'calendar' | 'roadmap' | 'report' | 'settings') => void;
}

const Row: React.FC<{ k: string; v: React.ReactNode }> = ({ k, v }) => (
  <div className="equipment-ops-list-row">
    <span style={{ color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{k}</span>
    <span className="equipment-ops-list-meta" style={{ color: 'var(--eq-text)' }}>{v ?? '-'}</span>
  </div>
);

const EquipmentDetailInfoTab: React.FC<Props> = ({
  project, projectTasks, projectSheets, onOpenTask, onOpenSheet, onOpenProjectTab,
}) => {
  const [statModal, setStatModal] = useState<StatModalState | null>(null);

  const { data: members = [] } = useQuery({
    queryKey: ['projectMembers', project.id],
    queryFn: () => api.getProjectMembers(project.id),
    enabled: project.id > 0,
  });

  const { data: subProjects = [] } = useQuery({
    queryKey: ['subProjects', project.id],
    queryFn: () => api.getSubProjects(project.id),
    enabled: project.id > 0,
  });

  // 시트 통계는 점검 수행형(체크리스트)만. 설비-배치 매핑형은 진행률/완료 개념이 없어 제외.
  const checklistSheets = useMemo(
    () => projectSheets.filter(s => !isEquipmentMappingSheet(s)),
    [projectSheets],
  );

  const lists = useMemo(() => ({
    open: projectTasks.filter(isOpen),
    done: projectTasks.filter(t => t.status === 'done'),
    issues: projectTasks.filter(isIssueTask),
    inProgressSheets: checklistSheets.filter(s => s.status === 'in_progress'),
    completedSheets: checklistSheets.filter(s => s.status === 'completed'),
  }), [projectTasks, checklistSheets]);

  const stats = {
    total: projectTasks.length,
    open: lists.open.length,
    done: lists.done.length,
    issues: lists.issues.length,
    completedSheets: lists.completedSheets.length,
    inProgressSheets: lists.inProgressSheets.length,
  };

  // ── 통계 row 클릭 → 필터 목록 모달 ──
  const taskRow = (t: Task) => ({
    id: `task-${t.id}`,
    primary: (
      <>
        {t.priority === 'high' && (
          <span style={{
            fontSize: 10, fontWeight: 700, color: 'var(--eq-error)',
            background: 'var(--eq-error-soft-bg)', padding: '1px 6px', borderRadius: 999, marginRight: 6,
          }}>HIGH</span>
        )}
        {t.title}
      </>
    ),
    secondary: t.due_date ? dDayLabel(t.due_date) : t.status,
    onClick: onOpenTask ? () => { onOpenTask(t); setStatModal(null); } : undefined,
  });
  const sheetRow = (s: SheetExecution) => ({
    id: `sheet-${s.id}`,
    primary: s.title || s.template_name || `Sheet #${s.id}`,
    secondary: `진행률 ${s.progress || 0}%`,
    onClick: onOpenSheet ? () => { onOpenSheet(s.id); setStatModal(null); } : undefined,
  });
  const boardFooter = onOpenProjectTab
    ? { footerLabel: '작업 보드에서 전체 보기', onFooter: () => { onOpenProjectTab(project.id, 'board'); setStatModal(null); } }
    : {};
  const openTaskModal = (title: string, tasks: Task[], emptyText: string) =>
    setStatModal({ title, items: tasks.map(taskRow), emptyText, ...boardFooter });
  const openSheetModal = (title: string, sheets: SheetExecution[], emptyText: string) =>
    setStatModal({ title, items: sheets.map(sheetRow), emptyText });

  const owner = members.find((m: ProjectMember) => m.role === 'owner');

  return (
    <div className="equipment-ops-detail-grid">
      {/* 기본 정보 */}
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>기본 정보</span>
        </div>
        {/* 설비 ID / 등록일 / 공개 범위 같은 메타데이터는 운영 화면에 노출하지 않는다.
            (필요 시 "설비 편집" 화면에서 확인) */}
        <div className="equipment-ops-list">
          <Row k="설비명" v={project.name} />
          <Row k="설명" v={project.description || '-'} />
          <Row k="담당자" v={owner?.username || '-'} />
        </div>
      </div>

      {/* 작업 통계 */}
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>작업 통계</span>
        </div>
        <div className="equipment-ops-list">
          <StatRow label="전체 작업" value={`${stats.total}건`} disabled={stats.total === 0}
            onClick={() => openTaskModal('전체 작업', projectTasks, '작업이 없습니다.')} />
          <StatRow label="진행/대기" value={`${stats.open}건`}
            variant={stats.open > 0 ? 'progress' : undefined}
            disabled={stats.open === 0}
            onClick={() => openTaskModal('진행/대기 작업', lists.open, '진행/대기 작업이 없습니다.')} />
          <StatRow label="완료" value={`${stats.done}건`} disabled={stats.done === 0}
            onClick={() => openTaskModal('완료 작업', lists.done, '완료된 작업이 없습니다.')} />
          <StatRow
            label="활성 이슈"
            value={`${stats.issues}건`}
            variant={stats.issues > 0 ? 'issue' : undefined}
            disabled={stats.issues === 0}
            onClick={() => openTaskModal('활성 이슈', lists.issues, '활성 이슈가 없습니다.')}
          />
          <StatRow label="시트 진행 중" value={`${stats.inProgressSheets}건`}
            variant={stats.inProgressSheets > 0 ? 'sheet' : undefined}
            disabled={stats.inProgressSheets === 0}
            onClick={() => openSheetModal('진행 중 체크시트', lists.inProgressSheets, '진행 중인 체크시트가 없습니다.')} />
          <StatRow label="시트 완료" value={`${stats.completedSheets}건`} disabled={stats.completedSheets === 0}
            onClick={() => openSheetModal('완료된 체크시트', lists.completedSheets, '완료된 체크시트가 없습니다.')} />
        </div>
      </div>

      {/* 구성원 */}
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>구성원</span>
          <span style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{members.length}명</span>
        </div>
        {members.length === 0 ? (
          <div className="equipment-ops-empty">등록된 구성원이 없습니다.</div>
        ) : (
          <div className="equipment-ops-list">
            {members.slice(0, 8).map((m: ProjectMember) => (
              <div key={`${m.user_id}-${m.role}`} className="equipment-ops-list-row">
                <span>
                  <span style={{
                    display: 'inline-block', width: 8, height: 8, borderRadius: 999,
                    background: m.avatar_color || 'var(--eq-text-secondary)', marginRight: 6,
                  }} />
                  {m.username || `User#${m.user_id}`}
                  {m.deptname && <span style={{ color: 'var(--eq-text-secondary)', marginLeft: 6, fontSize: 11 }}>{m.deptname}</span>}
                </span>
                <span className="equipment-ops-list-meta">{m.role}</span>
              </div>
            ))}
            {members.length > 8 && (
              <div style={{ fontSize: 11, color: 'var(--eq-text-secondary)', textAlign: 'right' }}>
                +{members.length - 8} more
              </div>
            )}
          </div>
        )}
      </div>

      {/* 하위 분류 */}
      <div className="equipment-ops-detail-card">
        <div className="equipment-ops-card-h">
          <span>하위 분류</span>
          <span style={{ fontSize: 11, color: 'var(--eq-text-secondary)', fontWeight: 600 }}>{subProjects.length}개</span>
        </div>
        {subProjects.length === 0 ? (
          <div className="equipment-ops-empty">하위 분류가 없습니다.</div>
        ) : (
          <div className="equipment-ops-list">
            {subProjects.slice(0, 8).map((sp: SubProject) => (
              <div key={sp.id} className="equipment-ops-list-row">
                <span>{sp.name}</span>
                <span className="equipment-ops-list-meta">
                  {projectTasks.filter(t => t.sub_project_id === sp.id).length}건
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <EquipmentStatModal state={statModal} onClose={() => setStatModal(null)} />
    </div>
  );
};

export default EquipmentDetailInfoTab;
