import React, { useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTheme, alpha } from '@mui/material/styles';
import { api } from '../../api/client';
import type { Project, Task, SheetExecution } from '../../types';
import { useAppStore } from '../../stores/useAppStore';
import { useSpaceNav } from '../../hooks/useSpaceNav';

import EquipmentKpiCards from './EquipmentKpiCards';
import EquipmentStatusStrip from './EquipmentStatusStrip';
import SelectedEquipmentDetail from './SelectedEquipmentDetail';
import KpiDetailDialog from './KpiDetailDialog';
import EquipmentOpsWidgets, {
  DEFAULT_EQUIPMENT_WIDGET_ORDER,
  type EquipmentWidgetId,
} from './EquipmentOpsWidgets';
import {
  computeKpis,
  summarizeEquipment,
  filterValidSheets,
  EquipmentSummary,
  type KpiKey,
} from './equipmentDashboardUtils';
import DashboardCalendar from '../DashboardCalendar';
import InternalRecommendationStrip from '../InternalRecommendationStrip';

import './EquipmentOpsDashboard.css';

/**
 * 설비운영 Widget Settings 카탈로그.
 * HomePage 의 Widget Settings Drawer 와 본 컴포넌트가 공유.
 */
export type EquipmentDashboardWidgetId =
  | 'calendar'
  | 'kpi_total_equipment'
  | 'kpi_today_tasks'
  | 'kpi_week_inspections'
  | 'kpi_open_issues'
  | 'kpi_recent_changes'
  | 'kpi_in_progress_sheets'
  | 'equipment_status'
  | EquipmentWidgetId;

/** KPI 카드 ID → KpiKey 매핑. */
export const EQUIPMENT_KPI_WIDGET_MAP: Record<string, KpiKey> = {
  kpi_total_equipment:   'totalEquipment',
  kpi_today_tasks:       'todayTasks',
  kpi_week_inspections:  'weekInspections',
  kpi_open_issues:       'openIssues',
  kpi_recent_changes:    'recentChanges',
  kpi_in_progress_sheets:'inProgressSheets',
};

/** 설비운영 Dashboard 기본 표시 위젯 — 약품관리 현황 제외. */
export const DEFAULT_EQUIPMENT_DASHBOARD_WIDGETS: EquipmentDashboardWidgetId[] = [
  'calendar',
  'kpi_total_equipment',
  'kpi_today_tasks',
  'kpi_week_inspections',
  'kpi_open_issues',
  'kpi_recent_changes',
  'kpi_in_progress_sheets',
  'equipment_status',
  'today_week',
  'periodic',
  'recent',
  'sheets',
  'issues',
  'ai_summary',
];

interface Props {
  /** 현재 공간 ID. HomePage 에서 전달. */
  currentSpaceId: number | null;
  /** 현재 사용자 ID. HomePage 에서 전달. */
  currentUserId: number;
  /** Space 표시명. (선택사항) */
  spaceName?: string;
  /**
   * HomePage Widget Settings 에서 토글한 가시 위젯 ID 집합.
   * undefined → 전체 표시 (기본값 폴백). null/빈 집합 → 전부 숨김.
   */
  visibleWidgets?: Set<EquipmentDashboardWidgetId>;
}

/**
 * 설비운영 공간 (Space.purpose === 'equipment_ops') 전용 Dashboard.
 *
 * 기존 HomePage 의 위젯 그리드/Drawer/레이아웃 저장 흐름은 일절 건드리지 않고,
 * HomePage 가 purpose 분기로 이 컴포넌트를 렌더한다.
 *
 * 데이터:
 *  - api.getProjects(userId, spaceId)              ← 설비 목록(=Project)
 *  - api.getTasks(undefined, userId)               ← 사용자 가시 task 전체 (project_id 로 필터)
 *  - api.getSheetExecutions(spaceId)               ← 공간 시트 인스턴스 전체
 */
const EquipmentOpsDashboard: React.FC<Props> = ({ currentSpaceId, currentUserId, visibleWidgets }) => {
  const openDrawer = useAppStore(s => s.openDrawer);
  const { spaceNav } = useSpaceNav();
  const theme = useTheme();
  const queryClient = useQueryClient();

  // ── Data fetching ──
  const { data: projects = [] } = useQuery({
    queryKey: ['projects', currentUserId, currentSpaceId, 'equipment-ops'],
    queryFn: () => api.getProjects(currentUserId, currentSpaceId),
    enabled: currentUserId > 0 && !!currentSpaceId,
  });

  const { data: allTasks = [] } = useQuery({
    queryKey: ['tasks', currentUserId, 'equipment-ops-space', currentSpaceId],
    queryFn: () => api.getTasks(undefined, currentUserId),
    enabled: currentUserId > 0,
  });

  const { data: sheetData } = useQuery({
    queryKey: ['sheetExecutions', currentSpaceId, 'equipment-ops'],
    queryFn: () => api.getSheetExecutions(currentSpaceId!),
    enabled: !!currentSpaceId,
  });

  // 단순 일정(CalendarEvent) — 캘린더에 표시 (Phase 2)
  const { data: calendarEvents = [] } = useQuery({
    queryKey: ['calendarEvents', currentSpaceId, currentUserId],
    queryFn: () => api.getCalendarEvents(currentSpaceId!, currentUserId),
    enabled: !!currentSpaceId && currentUserId > 0,
  });
  const rawSheets: SheetExecution[] = useMemo(() => {
    const arr = (sheetData?.executions || sheetData || []) as SheetExecution[];
    return Array.isArray(arr) ? arr : [];
  }, [sheetData]);

  // ── Space-scoped task list ──
  const projectIds = useMemo(() => new Set(projects.map((p: Project) => p.id)), [projects]);
  const spaceTasks = useMemo(
    () => allTasks.filter((t: Task) => projectIds.has(t.project_id)),
    [allTasks, projectIds],
  );

  // ── 유효 연결 시트만 추출 (unlinked/cancelled, Space 와 무관한 잔여 데이터 제외) ──
  const spaceTaskIds = useMemo(() => new Set(spaceTasks.map((t: Task) => t.id)), [spaceTasks]);
  const sheets = useMemo(
    () => filterValidSheets(rawSheets, projectIds, spaceTaskIds),
    [rawSheets, projectIds, spaceTaskIds],
  );

  // ── Equipment summaries ──
  const equipments: EquipmentSummary[] = useMemo(
    () => projects.map((p: Project) => summarizeEquipment(p, spaceTasks, sheets)),
    [projects, spaceTasks, sheets],
  );

  // ── Selection state ──
  // Phase C: 최초 진입 시 미선택. 선택은 사용자가 명시적으로 카드를 클릭해야만 발생.
  // 선택된 project 가 삭제·archive 되어 더 이상 존재하지 않으면 자동 해제.
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  // Phase E: KPI 카드 클릭 시 상세 Dialog 열기. null = 닫힘.
  const [selectedKpi, setSelectedKpi] = useState<KpiKey | null>(null);
  if (selectedProjectId != null && !projectIds.has(selectedProjectId)) {
    // 렌더 중 set 은 React 가 즉시 재렌더하므로 안전. (의존 hook 보다 단순)
    setSelectedProjectId(null);
  }

  const selectedProject = useMemo(
    () => projects.find((p: Project) => p.id === selectedProjectId) || null,
    [projects, selectedProjectId],
  );
  const selectedTasks = useMemo(
    () => spaceTasks.filter((t: Task) => t.project_id === selectedProjectId),
    [spaceTasks, selectedProjectId],
  );
  const selectedSheets = useMemo(() => {
    if (selectedProjectId == null) return [];
    const selectedTaskIds = new Set(selectedTasks.map(t => t.id));
    return sheets.filter(s =>
      s.project_id === selectedProjectId
      || (s.task_id != null && selectedTaskIds.has(s.task_id))
    );
  }, [sheets, selectedProjectId, selectedTasks]);

  // ── KPI 계산 ──
  const kpis = useMemo(
    () => computeKpis(projects, spaceTasks, sheets),
    [projects, spaceTasks, sheets],
  );

  // ── Widget 가시성 ──
  // visibleWidgets === undefined → 전체 표시 (기본값 폴백)
  // 그 외 → 명시적 토글 결과를 그대로 사용
  const isVisible = (id: EquipmentDashboardWidgetId): boolean =>
    !visibleWidgets || visibleWidgets.has(id);
  const visibleKpiKeys = useMemo<Set<KpiKey> | undefined>(() => {
    if (!visibleWidgets) return undefined;
    const out = new Set<KpiKey>();
    for (const [wid, kpiKey] of Object.entries(EQUIPMENT_KPI_WIDGET_MAP)) {
      if (visibleWidgets.has(wid as EquipmentDashboardWidgetId)) out.add(kpiKey);
    }
    return out;
  }, [visibleWidgets]);
  const visibleGridWidgets = useMemo<Set<EquipmentWidgetId> | undefined>(() => {
    if (!visibleWidgets) return undefined;
    const out = new Set<EquipmentWidgetId>();
    for (const id of DEFAULT_EQUIPMENT_WIDGET_ORDER) {
      if (visibleWidgets.has(id)) out.add(id);
    }
    return out;
  }, [visibleWidgets]);

  const showKpis = visibleKpiKeys ? visibleKpiKeys.size > 0 : true;
  const showStatusStrip = isVisible('equipment_status');
  const showCalendar = isVisible('calendar');
  const showWidgetsGrid = visibleGridWidgets ? visibleGridWidgets.size > 0 : true;

  // ── 사용자별/공간별 위젯 순서 (HomePage layout 저장 흐름 재사용) ──
  // 저장 위치: savedLayout.bySpace[spaceKey].equipmentOpsWidgetOrder
  // HomePage 의 다른 key (widgetIds, widgetOrder, widgetHeights) 와 충돌하지 않도록 별도 key 사용.
  const spaceKey: string = currentSpaceId != null ? String(currentSpaceId) : '__no_space__';

  const { data: savedLayout } = useQuery({
    queryKey: ['layout', currentUserId],
    queryFn: () => api.getUserLayout(currentUserId),
    enabled: currentUserId > 0,
  });

  const savedWidgetOrder: EquipmentWidgetId[] | undefined = useMemo(() => {
    const bySpace = (savedLayout as any)?.bySpace;
    const entry = (bySpace && typeof bySpace === 'object') ? bySpace[spaceKey] : null;
    const raw = entry?.equipmentOpsWidgetOrder;
    return Array.isArray(raw) ? raw : undefined;
  }, [savedLayout, spaceKey]);

  const saveLayoutMutation = useMutation({
    mutationFn: (nextOrder: EquipmentWidgetId[]) => {
      const prev = (savedLayout as any) || {};
      const prevBySpace = (prev.bySpace && typeof prev.bySpace === 'object') ? prev.bySpace : {};
      const merged = {
        ...prev,
        bySpace: {
          ...prevBySpace,
          [spaceKey]: {
            ...(prevBySpace[spaceKey] || {}),
            equipmentOpsWidgetOrder: nextOrder,
          },
        },
      };
      return api.saveUserLayout(currentUserId, merged);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['layout', currentUserId] });
    },
  });

  const handleReorderWidgets = (next: EquipmentWidgetId[]) => {
    // optimistic cache patch — 새로고침 없이 즉시 반영
    queryClient.setQueryData(['layout', currentUserId], (old: any) => {
      const base = old || {};
      const baseBySpace = (base.bySpace && typeof base.bySpace === 'object') ? base.bySpace : {};
      return {
        ...base,
        bySpace: {
          ...baseBySpace,
          [spaceKey]: {
            ...(baseBySpace[spaceKey] || {}),
            equipmentOpsWidgetOrder: next,
          },
        },
      };
    });
    saveLayoutMutation.mutate(next);
  };

  // ── Theme palette 를 CSS 변수로 주입 (Theme 변경 시 카드/버튼/border 색이 함께 변하도록) ──
  //    - soft-bg / soft-ring 등 파생 색상은 theme.palette.primary.main 으로부터
  //      alpha() 로 계산해 dark/light theme 양쪽에 자연스럽게 적응한다.
  const themeCssVars = useMemo<React.CSSProperties>(() => {
    const primary = theme.palette.primary.main;
    const success = theme.palette.success.main;
    const warning = theme.palette.warning.main;
    const error = theme.palette.error.main;
    return {
      ['--eq-primary' as any]: primary,
      ['--eq-primary-light' as any]: theme.palette.primary.light,
      ['--eq-primary-dark' as any]: theme.palette.primary.dark,
      ['--eq-primary-contrast' as any]: theme.palette.primary.contrastText,
      ['--eq-primary-soft-bg' as any]: alpha(primary, 0.08),
      ['--eq-primary-soft-ring' as any]: alpha(primary, 0.18),
      ['--eq-primary-hover' as any]: alpha(primary, 0.12),
      ['--eq-surface' as any]: theme.palette.background.paper,
      ['--eq-surface-subtle' as any]: theme.palette.background.default,
      ['--eq-border' as any]: theme.palette.divider,
      ['--eq-border-strong' as any]: alpha(theme.palette.text.primary, 0.12),
      ['--eq-text' as any]: theme.palette.text.primary,
      ['--eq-text-secondary' as any]: theme.palette.text.secondary,
      ['--eq-text-muted' as any]: alpha(theme.palette.text.primary, 0.55),
      ['--eq-success' as any]: success,
      ['--eq-success-soft-bg' as any]: alpha(success, 0.12),
      ['--eq-warning' as any]: warning,
      ['--eq-warning-soft-bg' as any]: alpha(warning, 0.12),
      ['--eq-error' as any]: error,
      ['--eq-error-soft-bg' as any]: alpha(error, 0.12),
      ['--eq-accent-purple' as any]: theme.palette.secondary?.main || '#7C3AED',
    };
  }, [theme]);

  // ── Action handlers ──
  const handleOpenTask = (task: Task) => {
    // 전역 TaskDrawer 열기 (App.tsx 의 단일 인스턴스가 받아서 처리)
    openDrawer(task, task.project_id);
  };

  const handleOpenSheet = (executionId: number) => {
    spaceNav(`/sheets/execution/${executionId}`);
  };

  const handleOpenProjectTab = (
    projectId: number,
    tab: 'board' | 'list' | 'calendar' | 'roadmap' | 'report' | 'settings',
  ) => {
    spaceNav(`/project/${projectId}?tab=${tab}`);
  };

  const handleQuickAddTask = (projectId: number) => {
    // pending task 상태로 Drawer 열어 신규 입력. selectedTask 가 없으면 Drawer 가 신규 모드로 동작.
    openDrawer(null, projectId, { project_id: projectId, status: 'todo', progress: 0 });
  };

  const handleOpenSheetsPage = () => {
    spaceNav('/sheets');
  };

  // Phase C: 선택된 설비가 있으면 그 데이터, 없으면 Space 전체 데이터를 위젯에 전달.
  const widgetTasks = selectedProject ? selectedTasks : spaceTasks;
  const widgetSheets = selectedProject ? selectedSheets : sheets;
  const widgetSectionTitle = selectedProject ? '선택된 설비 운영 위젯' : '전체 설비 운영 위젯';

  // 빈 영역(헤더, 섹션 타이틀, 영역 사이 공백) 클릭 시 선택 해제. 카드/상세/위젯 컨테이너는
  // stopPropagation 으로 보호되어 내부 클릭이 의도치 않게 해제되지 않는다.
  const handleDeselect = () => {
    if (selectedProjectId != null) setSelectedProjectId(null);
  };
  const stopBubble = (e: React.MouseEvent) => e.stopPropagation();
  const handleSelectEquipment = (projectId: number) => setSelectedProjectId(projectId);
  const handleSelectKpi = (key: KpiKey) => setSelectedKpi(key);
  const handleCloseKpi = () => setSelectedKpi(null);
  const handleOpenProjectFromKpi = (projectId: number) => {
    setSelectedProjectId(projectId);
  };

  return (
    <div className="equipment-ops-root" style={themeCssVars} onClick={handleDeselect}>
      {/* 공통 상단 Header(PLAN-AI / Dashboard / 날짜 / 바로가기 / 우측 버튼)는 HomePage 에서 렌더링.
          여기서는 설비운영 요약 문구만 본문 영역의 첫 줄로 표시한다. */}
      <div className="equipment-ops-header">
        <div className="equipment-ops-subtitle">
          {projects.length}대의 설비 · {spaceTasks.length}개의 작업 · {sheets.length}개의 시트
        </div>
      </div>

      {showKpis && (
        <div onClick={stopBubble}>
          <EquipmentKpiCards kpis={kpis} onSelect={handleSelectKpi} visibleKeys={visibleKpiKeys} />
        </div>
      )}

      {/* ── 사내 추천 도구 스트립 (KPI 카드 아래 · 월간 작업 캘린더 위) ──
          global flag OFF 또는 추천 데이터 없음 → null 반환(영역 자체 미표시). */}
      <div onClick={stopBubble}>
        <InternalRecommendationStrip
          placement="EQUIPMENT_DASHBOARD_AFTER_KPI"
          currentUserId={currentUserId}
        />
      </div>

      {showCalendar && (
        <>
          <div className="equipment-ops-section-title">주간/월간 작업 Calendar</div>
          <div onClick={stopBubble}>
            <DashboardCalendar tasks={spaceTasks} events={calendarEvents} openDrawer={openDrawer} />
          </div>
        </>
      )}

      {showStatusStrip && (
        <>
          <div className="equipment-ops-section-title">설비 상태</div>
          <div onClick={stopBubble}>
            <EquipmentStatusStrip
              equipments={equipments}
              selectedProjectId={selectedProjectId}
              onSelect={handleSelectEquipment}
            />
          </div>
        </>
      )}

      {selectedProject && (
        <div onClick={stopBubble}>
          <SelectedEquipmentDetail
            project={selectedProject}
            projectTasks={selectedTasks}
            projectSheets={selectedSheets}
            currentUserId={currentUserId}
            onOpenTask={handleOpenTask}
            onOpenSheet={handleOpenSheet}
            onOpenProjectTab={handleOpenProjectTab}
            onQuickAddTask={handleQuickAddTask}
            onOpenSheetsPage={handleOpenSheetsPage}
          />
        </div>
      )}

      {showWidgetsGrid && (
        <>
          <div className="equipment-ops-section-title">{widgetSectionTitle}</div>
          <div onClick={stopBubble}>
            <EquipmentOpsWidgets
              project={selectedProject}
              projectTasks={widgetTasks}
              projectSheets={widgetSheets}
              currentUserId={currentUserId}
              widgetOrder={savedWidgetOrder || DEFAULT_EQUIPMENT_WIDGET_ORDER}
              visibleWidgets={visibleGridWidgets}
              onReorder={handleReorderWidgets}
              onOpenTask={handleOpenTask}
              onOpenSheet={handleOpenSheet}
              onOpenReportTab={(projectId) => handleOpenProjectTab(projectId, 'report')}
            />
          </div>
        </>
      )}

      <KpiDetailDialog
        open={selectedKpi !== null}
        kpiKey={selectedKpi}
        projects={projects}
        spaceTasks={spaceTasks}
        spaceSheets={sheets}
        equipments={equipments}
        onClose={handleCloseKpi}
        onOpenTask={handleOpenTask}
        onOpenSheet={handleOpenSheet}
        onOpenProject={handleOpenProjectFromKpi}
      />
    </div>
  );
};

export default EquipmentOpsDashboard;
