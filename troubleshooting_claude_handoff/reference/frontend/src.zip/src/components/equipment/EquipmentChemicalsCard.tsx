import React, { useMemo } from 'react';
import { useQueries } from '@tanstack/react-query';
import { api } from '../../api/client';
import type { SheetExecution, SheetStructure, SheetExecutionItem } from '../../types';
import { formatRelative } from './equipmentDashboardUtils';
import {
  getEquipmentColumnIndices,
  resolveHeaderRowIdx,
  isEquipmentColumnHeader,
} from '../sheets/assignmentMappingDetect';
import { makeCellRef } from '../sheets/useAssignmentMappingState';

interface Props {
  projectSheets: SheetExecution[];
  variant?: 'card' | 'widget';
  /**
   * 현재 설비(=Project) 식별자(설비명). 지정되면 약품관리 시트의 설비 컬럼(설비 1~5 등)
   * 값 중 하나가 이 설비명과 일치하는 약품 행만 표시한다.
   * (체크시트 전체 약품을 모두 보여주는 오해 방지)
   */
  equipmentName?: string;
  onOpenSheet?: (executionId: number) => void;
  onOpenSheetsPage?: () => void;
}

/** 약품관리 시트로 간주할 조건:
 *   1) sheet_type === 'assignment_mapping' (구조적으로 매핑형이면 무조건)
 *   2) template_category === 'chemical_mgmt' (업로드 시 약품관리로 분류)
 *   3) title / template_name 이 '약품' 을 포함 (메타 누락된 legacy 시트 폴백)
 *  단, 명시적 'unlinked'/'cancelled' 상태는 제외. */
function isChemicalSheet(s: SheetExecution): boolean {
  if (s.status === 'unlinked' || s.status === 'cancelled') return false;
  if (s.sheet_type === 'assignment_mapping') return true;
  if ((s.template_category || '').toLowerCase() === 'chemical_mgmt') return true;
  const text = `${s.title || ''} ${s.template_name || ''}`;
  return text.includes('약품');
}

/** 셀 값이 문자열이 아닌 객체(pill/chip)일 수 있으므로 텍스트를 안전하게 추출. */
function getCellText(cell: unknown): string {
  if (cell === null || cell === undefined) return '';
  if (typeof cell === 'string' || typeof cell === 'number') return String(cell);
  if (typeof cell === 'object') {
    const o = cell as Record<string, unknown>;
    return String(o.label ?? o.value ?? o.text ?? o.name ?? '');
  }
  return String(cell);
}

/** 대소문자/공백 무시 비교용 정규화. */
function normalize(value: unknown): string {
  return getCellText(value).trim().toLowerCase().replace(/\s+/g, '');
}

/** 현재 설비에 연결된 약품 한 행. */
interface LinkedChemical {
  key: string;
  executionId: number;
  code: string;       // 약품코드
  name: string;       // 약품명
  matchedEquipment: string;
  detail: string;     // 용도 · 관리등급 · 보관위치 · 담당팀 · 점검주기 · 비고 (있는 것만)
}

interface ExecutionDetail {
  id: number;
  status?: string;
  template_structure?: SheetStructure;
  items?: SheetExecutionItem[];
  structure_overlay?: {
    added_columns?: { col_idx: number; header: string; kind?: string }[];
    added_rows?: { row_idx: number }[];
    renamed_headers?: Record<string, string>;
  } | null;
}

/**
 * 약품관리 시트 실행본의 "현재 셀 데이터"(base 구조 + 셀 오버라이드 + overlay)를 재구성해서,
 * 설비 컬럼(설비 1~5 등) 값 중 하나가 equipmentName 과 일치하는 약품 행만 추출한다.
 * — 뷰어(AssignmentMappingExcelViewer)와 동일한 재구성 규칙을 사용하므로 화면에 보이는 값과 일치한다.
 * equipmentName 이 비어 있으면 설비 컬럼에 값이 있는 모든 약품 행을 반환.
 */
function extractLinkedChemicals(detail: ExecutionDetail, equipmentName?: string): LinkedChemical[] {
  const structure = detail.template_structure || ({} as SheetStructure);
  const items = detail.items || [];
  const overlay = detail.structure_overlay || {};
  const headerRow = resolveHeaderRowIdx(structure);
  if (headerRow === null) return [];

  // cellRef → 현재 값 (base 구조 셀 위에 item 오버라이드를 덮어씀 — 뷰어와 동일)
  const valueByRef = new Map<string, string>();
  (structure.cells || []).forEach(c => {
    valueByRef.set(makeCellRef(c.row, c.col), getCellText(c.value));
  });
  items.forEach(it => {
    if (it.cell_ref && it.value !== undefined && it.value !== null) {
      valueByRef.set(it.cell_ref, getCellText(it.value));
    }
  });

  // 설비 컬럼: base 자동감지 + overlay 추가 설비 컬럼
  const equipmentCols = new Set<number>(getEquipmentColumnIndices(structure));
  (overlay.added_columns || []).forEach(c => {
    if (c.kind === 'equipment' || isEquipmentColumnHeader(c.header)) equipmentCols.add(c.col_idx);
  });

  // col → 헤더 텍스트 (base 헤더행 + item 오버라이드 + overlay 추가/rename)
  const headerByCol = new Map<number, string>();
  (structure.cells || []).forEach(c => {
    if (c.row === headerRow) headerByCol.set(c.col, getCellText(c.value));
  });
  items.forEach(it => {
    if (it.row_idx === headerRow && it.value !== undefined && it.value !== null) {
      headerByCol.set(it.col_idx, getCellText(it.value));
    }
  });
  (overlay.added_columns || []).forEach(c => headerByCol.set(c.col_idx, getCellText(c.header)));
  const renamed = overlay.renamed_headers || {};
  Object.keys(renamed).forEach(k => headerByCol.set(Number(k), getCellText(renamed[k])));

  // 헤더 텍스트로 컬럼 찾기 — 정확 일치 우선, 없으면 부분 포함.
  const findCol = (exact: string[], contains: string[]): number | null => {
    for (const [col, h] of headerByCol) {
      if (exact.includes(getCellText(h).replace(/\s+/g, ''))) return col;
    }
    for (const [col, h] of headerByCol) {
      const n = getCellText(h).replace(/\s+/g, '');
      if (contains.some(k => n.includes(k))) return col;
    }
    return null;
  };
  const colCode = findCol(['약품코드', '마스터코드', '코드'], ['코드']);
  const colName = findCol(['약품명', '마스터명', '명칭'], ['약품명', '명칭']);
  const colUsage = findCol(['용도'], ['용도']);
  const colGrade = findCol(['관리등급', '등급'], ['등급']);
  const colLocation = findCol(['보관위치'], ['보관']);
  const colTeam = findCol(['담당팀'], ['담당팀', '담당']);
  const colCycle = findCol(['점검주기', '주기'], ['주기']);
  const colRemark = findCol(['비고'], ['비고']);

  // 데이터 행 범위
  let maxRow = headerRow;
  (structure.cells || []).forEach(c => { if (c.row > maxRow) maxRow = c.row; });
  items.forEach(it => { if (it.row_idx > maxRow) maxRow = it.row_idx; });
  (overlay.added_rows || []).forEach(r => { if (r.row_idx > maxRow) maxRow = r.row_idx; });

  const target = equipmentName ? normalize(equipmentName) : '';
  const valAt = (r: number, c: number | null): string =>
    c === null ? '' : (valueByRef.get(makeCellRef(r, c)) ?? '');

  const out: LinkedChemical[] = [];
  for (let r = headerRow + 1; r <= maxRow; r++) {
    const code = valAt(r, colCode);
    const name = valAt(r, colName);
    // 약품코드/명이 모두 비면 빈 행 — 스킵
    if (!code.trim() && !name.trim()) continue;

    // 설비 컬럼 매칭
    let matched = '';
    for (const c of equipmentCols) {
      const cell = valueByRef.get(makeCellRef(r, c)) ?? '';
      if (!cell.trim()) continue;
      if (!target) { matched = cell; break; }            // 필터 없음 → 값 있는 첫 설비
      if (normalize(cell) === target) { matched = cell; break; }
    }
    if (target && !matched) continue;       // 현재 설비와 매칭되는 행이 아님
    if (!target && !matched) continue;       // 설비 값이 전혀 없는 행은 약품 연결로 보지 않음

    const detailParts = [
      valAt(r, colUsage),
      valAt(r, colGrade),
      valAt(r, colLocation),
      valAt(r, colTeam),
      valAt(r, colCycle),
      valAt(r, colRemark),
    ].map(s => s.trim()).filter(Boolean);

    out.push({
      key: `${detail.id}-${r}`,
      executionId: detail.id,
      code: code.trim(),
      name: name.trim(),
      matchedEquipment: matched.trim(),
      detail: detailParts.join(' · '),
    });
  }
  return out;
}

const EquipmentChemicalsCard: React.FC<Props> = ({
  projectSheets, variant = 'card', equipmentName, onOpenSheet, onOpenSheetsPage,
}) => {
  const chemicalSheets = useMemo(
    () => projectSheets.filter(isChemicalSheet),
    [projectSheets],
  );
  // 설비 컬럼 매칭은 매핑형(assignment_mapping) 시트에서만 가능
  const mappingSheets = useMemo(
    () => chemicalSheets.filter(s => s.sheet_type === 'assignment_mapping'),
    [chemicalSheets],
  );
  const nonMappingChemSheets = useMemo(
    () => chemicalSheets.filter(s => s.sheet_type !== 'assignment_mapping'),
    [chemicalSheets],
  );

  // 각 매핑형 시트의 "현재(live) 실행 상세"를 가져온다.
  // queryKey 를 ['sheetExecution', id] 로 맞춰, 시트 저장(useAssignmentMappingState.save)
  // 시 invalidate 되는 키와 공유 → 저장 후 새로고침 없이 자동 갱신된다.
  const detailQueries = useQueries({
    queries: mappingSheets.map(s => ({
      queryKey: ['sheetExecution', s.id],
      queryFn: () => api.getSheetExecution(s.id),
      enabled: !!s.id,
    })),
  });

  const linkedChemicals: LinkedChemical[] = useMemo(() => {
    const out: LinkedChemical[] = [];
    // 연결 해제/취소된 시트는 현재 active 연결이 아니므로 제외 (과거 이력 표시 방지).
    // 같은 약품이 중복 표시되지 않도록 약품코드·약품명·매칭 설비 기준으로 dedup.
    const seen = new Set<string>();
    detailQueries.forEach(q => {
      const detail = q.data as ExecutionDetail | undefined;
      if (!detail) return;
      if (detail.status === 'unlinked' || detail.status === 'cancelled') return;
      for (const row of extractLinkedChemicals(detail, equipmentName)) {
        const dedupKey = `${normalize(row.code)}|${normalize(row.name)}|${normalize(row.matchedEquipment)}`;
        if (seen.has(dedupKey)) continue;
        seen.add(dedupKey);
        out.push(row);
      }
    });
    return out;
  }, [detailQueries, equipmentName]);

  const isLoading = detailQueries.some(q => q.isLoading);

  // ── 아무 약품관리 시트도 없을 때 ──
  if (chemicalSheets.length === 0) {
    return (
      <div className="equipment-ops-empty">
        약품관리 시트가 연결되어 있지 않습니다.
        {onOpenSheetsPage && (
          <>
            {' '}
            <button
              type="button"
              className="equipment-ops-btn"
              style={{ padding: '2px 8px', fontSize: 11, marginLeft: 6 }}
              onClick={onOpenSheetsPage}
            >
              시트 페이지 →
            </button>
          </>
        )}
      </div>
    );
  }

  const limit = variant === 'widget' ? 6 : 8;

  // ── 매핑형 시트가 있는 경우: 설비 컬럼 매칭 결과 표시 ──
  if (mappingSheets.length > 0) {
    if (isLoading && linkedChemicals.length === 0) {
      return <div className="equipment-ops-empty">약품 매핑 불러오는 중...</div>;
    }
    if (linkedChemicals.length === 0) {
      return (
        <div className="equipment-ops-empty">
          {equipmentName ? `이 설비(${equipmentName})에 연결된 약품이 없습니다.` : '연결된 약품이 없습니다.'}
        </div>
      );
    }
    return (
      <div className="equipment-ops-list">
        {linkedChemicals.slice(0, limit).map(row => (
          <div
            key={row.key}
            className="equipment-ops-list-row"
            style={{
              flexDirection: 'column', alignItems: 'stretch', gap: 3,
              cursor: onOpenSheet ? 'pointer' : 'default',
            }}
            onClick={() => onOpenSheet?.(row.executionId)}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
              <span style={{ minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 13 }}>
                {row.code && <strong style={{ fontWeight: 600, color: 'var(--eq-text, #1F2937)' }}>{row.code}</strong>}
                {row.name && (
                  <span style={{ marginLeft: row.code ? 6 : 0 }}>{row.name}</span>
                )}
              </span>
              {row.matchedEquipment && (
                <span
                  style={{
                    flexShrink: 0, whiteSpace: 'nowrap', fontSize: 11, fontWeight: 600,
                    color: 'var(--eq-primary-dark, #1E40AF)',
                    background: 'var(--eq-primary-soft-bg, #EEF2FF)',
                    padding: '1px 8px', borderRadius: 999,
                  }}
                >
                  {row.matchedEquipment}
                </span>
              )}
            </div>
            {row.detail && (
              <div style={{ fontSize: 11.5, color: 'var(--eq-text-secondary, #9CA3AF)', lineHeight: 1.4 }}>
                {row.detail}
              </div>
            )}
          </div>
        ))}
        {linkedChemicals.length > limit && (
          <div style={{ fontSize: 11, color: 'var(--eq-text-secondary, #9CA3AF)', textAlign: 'right', marginTop: 4 }}>
            +{linkedChemicals.length - limit} more
          </div>
        )}
      </div>
    );
  }

  // ── 매핑형 시트는 없고, 비매핑 약품관리 시트만 있는 경우: 시트 카드 형태로 표시 ──
  //    (inspection 구조이지만 category=='chemical_mgmt' 또는 '약품' 포함 시트 — 설비 컬럼 매칭 불가)
  return (
    <div className="equipment-ops-list">
      {nonMappingChemSheets.slice(0, limit).map(s => {
        const stamp = s.completed_at || s.started_at;
        const statusLabel = s.status === 'completed' ? '완료'
          : s.status === 'in_progress' ? '진행'
          : s.status;
        return (
          <div
            key={`sheet-${s.id}`}
            className="equipment-ops-list-row"
            style={{ cursor: onOpenSheet ? 'pointer' : 'default' }}
            onClick={() => onOpenSheet?.(s.id)}
          >
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              <strong style={{ color: 'var(--eq-text, #1F2937)' }}>
                {s.title || s.template_name || `Sheet #${s.id}`}
              </strong>
              {s.equipment_name && (
                <span style={{ color: 'var(--eq-text-secondary, #9CA3AF)', marginLeft: 6, fontSize: 11 }}>
                  {s.equipment_name}
                </span>
              )}
            </span>
            <span className="equipment-ops-list-meta">
              {`${s.progress || 0}% · ${statusLabel}`}
              {stamp && ` · ${formatRelative(stamp)}`}
            </span>
          </div>
        );
      })}
      {nonMappingChemSheets.length > limit && (
        <div style={{ fontSize: 11, color: 'var(--eq-text-secondary, #9CA3AF)', textAlign: 'right', marginTop: 4 }}>
          +{nonMappingChemSheets.length - limit} more
        </div>
      )}
    </div>
  );
};

export default EquipmentChemicalsCard;
