import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '../../api/client';
import type { Project, Task, SheetExecution, ProjectMember } from '../../types';
import {
  summarizeEquipment,
  summarizeSheetStatus,
  statusChipColor,
  sortByLatestUpdate,
  dDayLabel,
  formatRelative,
} from './equipmentDashboardUtils';
import { isEquipmentMappingSheet } from '../sheets/assignmentMappingDetect';

interface Props {
  project: Project;
  projectTasks: Task[];
  projectSheets: SheetExecution[];
  userId: number;
  /** "AI Report에서 상세 분석 보기" → 리포트 탭으로 이동 */
  onOpenReportTab?: () => void;
}

/**
 * Dashboard 용 짧은 "AI 운영 요약".
 *
 * 긴 AI Report 본문 대신, 설비의 현재 상태를 로컬 데이터(Project/Task/SheetExecution)만으로
 * 3~5줄로 요약한다. 상세 분석은 onOpenReportTab(AI Report)으로 분리.
 */
const EquipmentAiSummaryCard: React.FC<Props> = ({
  project, projectTasks, projectSheets, onOpenReportTab,
}) => {
  // 담당자 표기에만 사용 (없어도 요약은 동작)
  const { data: members = [] } = useQuery({
    queryKey: ['projectMembers', project.id],
    queryFn: () => api.getProjectMembers(project.id),
    enabled: project.id > 0,
  });

  const summary = useMemo(() => {
    const eq = summarizeEquipment(project, projectTasks, projectSheets);
    const checklistSheets = projectSheets.filter(s => !isEquipmentMappingSheet(s));
    const taskById = new Map(projectTasks.map(t => [t.id, t]));
    const sheetSummary = summarizeSheetStatus(checklistSheets, taskById);
    const incompleteSheets = sheetSummary.total - sheetSummary.completed;
    const nextTask = eq.nextPeriodicTask || eq.nextDueTask;
    const recentTask = sortByLatestUpdate(projectTasks)[0];
    const recentChangeAt = recentTask?.updated_at || recentTask?.created_at || sheetSummary.lastUpdatedAt;
    const owner = members.find((m: ProjectMember) => m.role === 'owner');

    return {
      statusLabel: statusChipColor(eq.status).label,
      issueCount: eq.activeIssueCount,
      progress: eq.averageProgress,
      nextTask,
      incompleteSheets,
      totalSheets: sheetSummary.total,
      recentChangeRel: recentChangeAt ? formatRelative(recentChangeAt) : null,
      ownerName: owner?.username || null,
    };
  }, [project, projectTasks, projectSheets, members]);

  const { statusLabel, issueCount, progress, nextTask, incompleteSheets, recentChangeRel, ownerName } = summary;

  // 3~5줄 운영 요약 문장 구성
  const lines: string[] = [];
  lines.push(
    `${project.name}은(는) 현재 "${statusLabel}" 상태이며, 활성 이슈 ${issueCount}건이 있습니다.`,
  );
  if (nextTask) {
    const dday = nextTask.due_date ? ` (${dDayLabel(nextTask.due_date)})` : '';
    lines.push(`가장 우선 확인할 항목은 "${nextTask.title}"${dday}입니다.`);
  } else {
    lines.push('예정된 작업은 없습니다.');
  }
  lines.push(
    incompleteSheets > 0
      ? `체크시트 미완료 항목은 ${incompleteSheets}건이며, 진행률은 ${progress}%입니다.`
      : `체크시트 미완료 항목은 없으며, 진행률은 ${progress}%입니다.`,
  );
  if (recentChangeRel) {
    lines.push(`최근 변경은 ${recentChangeRel}에 발생했습니다.`);
  }
  if (ownerName) {
    lines.push(`담당자는 ${ownerName}입니다.`);
  }

  return (
    <div className="equipment-ops-list" style={{ gap: 4 }}>
      <div style={{ fontSize: 12.5, color: 'var(--eq-text)', lineHeight: 1.6 }}>
        {lines.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
      </div>
      {onOpenReportTab && (
        <div style={{ textAlign: 'right', marginTop: 6 }}>
          <button
            type="button"
            className="equipment-ops-btn"
            style={{ padding: '2px 8px', fontSize: 11 }}
            onClick={onOpenReportTab}
          >
            AI Report에서 상세 분석 보기 →
          </button>
        </div>
      )}
    </div>
  );
};

export default EquipmentAiSummaryCard;
