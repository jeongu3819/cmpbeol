/**
 * 설비운영 Dashboard 전용 순수 헬퍼.
 *
 * - 백엔드/프론트 어디에도 새 API를 만들지 않고, 기존 Project/Task/SheetExecution
 *   데이터만 가지고 KPI/필터링 결과를 계산한다.
 * - 모든 함수는 순수(부수효과 없음)로 작성되어 있어야 한다.
 */

import type { Project, Task, SheetExecution } from '../../types';
import { isEquipmentMappingSheet } from '../sheets/assignmentMappingDetect';

// ────────────────────────────────────────────────────────────────────────────
// 키워드 사전
// ────────────────────────────────────────────────────────────────────────────

/** 점검/PM/주기/반복/교체/세정 관련 키워드. 반복작업 위젯과 "이번주 점검" KPI에 사용. */
export const PERIODIC_KEYWORDS = [
  '점검', 'pm', 'PM', '주기', '반복', '정기', '교체', '세정', '청소', '캘리브', '검교정',
  'inspection', 'Inspection', 'INSPECTION', 'periodic', 'periodic', 'preventive',
];

/** 이슈/장애/메모 위젯과 "미해결 이슈" KPI 후보 키워드. */
export const ISSUE_KEYWORDS = [
  '이슈', '장애', '문제', '불량', '누수', '진동', '압력', '오류', '에러', '경고', '결함',
  'issue', 'Issue', 'ISSUE', 'fault', 'error', 'Error', 'ERROR', 'alarm', 'Alarm',
];

/** 장애성(fault) 키워드 — 운영에 직접 영향. */
export const FAULT_KEYWORDS = [
  '장애', '알람', '에러', 'NG', '정지', '불량', '이상',
  'fault', 'Fault', 'FAULT', 'error', 'Error', 'ERROR', 'alarm', 'Alarm', 'down', 'Down',
];

/** 일반 이슈성(issue) 키워드 — 주의·검토 단계. */
export const ISSUE_LIGHT_KEYWORDS = [
  '이슈', '문제', '리스크', '지연', '누수', '진동', '압력', '경고',
  'issue', 'Issue', 'risk', 'Risk', 'warning', 'Warning',
];

// ────────────────────────────────────────────────────────────────────────────
// 시간/날짜
// ────────────────────────────────────────────────────────────────────────────

/** ISO 또는 YYYY-MM-DD → Date. 실패 시 null. */
export function parseDateSafe(v?: string | null): Date | null {
  if (!v) return null;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return null;
  return d;
}

/** 두 날짜의 차이를 일 단위(소수 없는 정수)로. b - a (a 가 과거이면 음수). */
export function diffDays(a: Date, b: Date): number {
  const ms = b.getTime() - a.getTime();
  return Math.floor(ms / (1000 * 60 * 60 * 24));
}

/** 오늘 자정. */
export function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

/** 이번 주의 일요일 자정 ~ 토요일 23:59:59 범위. */
export function getThisWeekRange(): { start: Date; end: Date } {
  const start = startOfToday();
  start.setDate(start.getDate() - start.getDay()); // Sunday
  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  end.setHours(23, 59, 59, 999);
  return { start, end };
}

/** 'YYYY-MM-DD HH:mm' 한국식 짧은 표시. */
export function formatShortDateTime(iso?: string | null): string {
  const d = parseDateSafe(iso);
  if (!d) return '';
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mi = String(d.getMinutes()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd} ${hh}:${mi}`;
}

/** D-day 라벨. due 가 미래면 'D-N', 과거면 'D+N', 오늘이면 'D-Day'. */
export function dDayLabel(due?: string | null): string {
  const d = parseDateSafe(due);
  if (!d) return '';
  const today = startOfToday();
  const target = new Date(d);
  target.setHours(0, 0, 0, 0);
  const n = diffDays(today, target);
  if (n === 0) return 'D-Day';
  if (n > 0) return `D-${n}`;
  return `D+${Math.abs(n)}`;
}

/** ISO → '14분 전' 같은 상대 표시. */
export function formatRelative(iso?: string | null): string {
  const d = parseDateSafe(iso);
  if (!d) return '';
  const diff = Date.now() - d.getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return '방금 전';
  if (m < 60) return `${m}분 전`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}시간 전`;
  const day = Math.floor(h / 24);
  if (day < 7) return `${day}일 전`;
  return d.toISOString().slice(0, 10);
}

// ────────────────────────────────────────────────────────────────────────────
// Task 분류
// ────────────────────────────────────────────────────────────────────────────

const includesAny = (text: string, words: string[]): boolean => {
  const lower = text.toLowerCase();
  return words.some(w => lower.includes(w.toLowerCase()));
};

/** title/description/tags 합본 텍스트. */
export function taskHaystack(t: Task): string {
  const tags = Array.isArray(t.tags) ? t.tags.join(' ') : '';
  return `${t.title || ''} ${t.description || ''} ${tags}`;
}

export function isPeriodicTask(t: Task): boolean {
  return includesAny(taskHaystack(t), PERIODIC_KEYWORDS);
}

export function isOpen(t: Task): boolean {
  return t.status !== 'done' && !t.archived_at;
}

/** 마감일이 오늘보다 과거이고 아직 미완료인 Task. */
export function isOverdue(t: Task): boolean {
  if (!isOpen(t)) return false;
  const d = parseDateSafe(t.due_date);
  if (!d) return false;
  return d.getTime() < startOfToday().getTime();
}

/** 이슈/장애/메모 위젯의 3분류. null 이면 위젯 표시 대상 아님. */
export type IssueKind = 'fault' | 'issue' | 'memo';

/**
 * Task 를 장애 / 이슈 / 메모 중 하나로 분류한다.
 *  - fault : priority high, status hold, 또는 장애성 키워드 매칭
 *  - issue : priority medium + (이슈 키워드 매칭 또는 overdue), 또는 일반 이슈 키워드 매칭
 *  - memo  : remarks 본문이 있거나 description 이 긴 운영 기록성 항목 (점검/PM 등 작업성 키워드 제외)
 * 그 외 일반 작업은 null.
 */
export function classifyIssueKind(t: Task): IssueKind | null {
  if (!isOpen(t)) return null;
  const text = taskHaystack(t);
  const lower = text.toLowerCase();
  const hasFaultKw = FAULT_KEYWORDS.some(w => lower.includes(w.toLowerCase()));
  const hasIssueLightKw = ISSUE_LIGHT_KEYWORDS.some(w => lower.includes(w.toLowerCase()));

  if (t.priority === 'high' || t.status === 'hold' || hasFaultKw) return 'fault';
  if (hasIssueLightKw) return 'issue';
  if (isOverdue(t)) return 'issue';
  if (t.priority === 'medium' && (t.remarks?.trim() || t.description?.trim())) return 'issue';

  const remarksLen = t.remarks?.trim().length || 0;
  const descLen = t.description?.trim().length || 0;
  const isWorkLike = includesAny(text, PERIODIC_KEYWORDS);
  if (!isWorkLike && (remarksLen > 0 || descLen > 80)) return 'memo';
  return null;
}

export function categorizeIssueTasks(tasks: Task[]): { fault: Task[]; issue: Task[]; memo: Task[] } {
  const fault: Task[] = [];
  const issue: Task[] = [];
  const memo: Task[] = [];
  for (const t of tasks) {
    const k = classifyIssueKind(t);
    if (k === 'fault') fault.push(t);
    else if (k === 'issue') issue.push(t);
    else if (k === 'memo') memo.push(t);
  }
  return { fault, issue, memo };
}

/** 위젯·KPI 의 이슈 카운트용. 이전 시그니처 유지. */
export function isIssueTask(t: Task): boolean {
  return classifyIssueKind(t) !== null;
}

export function isToday(due?: string | null): boolean {
  const d = parseDateSafe(due);
  if (!d) return false;
  const today = startOfToday();
  return d.getFullYear() === today.getFullYear()
    && d.getMonth() === today.getMonth()
    && d.getDate() === today.getDate();
}

export function isThisWeek(due?: string | null): boolean {
  const d = parseDateSafe(due);
  if (!d) return false;
  const { start, end } = getThisWeekRange();
  return d.getTime() >= start.getTime() && d.getTime() <= end.getTime();
}

// ────────────────────────────────────────────────────────────────────────────
// SheetExecution 유효성 / 요약
// ────────────────────────────────────────────────────────────────────────────

/**
 * Dashboard 운영 현황에 노출해도 되는 "유효 연결" 시트인지 판단.
 *  - status 가 unlinked / cancelled 면 제외 (연결 해제·취소된 잔여 데이터)
 *  - project_id 가 현재 Space 의 Project 에 속하거나, task_id 가 Space 내 Task 에 속할 때만 유효
 */
export function isValidLinkedSheet(
  s: SheetExecution,
  projectIds: Set<number>,
  taskIds?: Set<number>,
): boolean {
  if (s.status === 'cancelled' || s.status === 'unlinked') return false;
  const hasProject = s.project_id != null && projectIds.has(s.project_id);
  const hasTask = !!taskIds && s.task_id != null && taskIds.has(s.task_id);
  return hasProject || hasTask;
}

export function filterValidSheets(
  sheets: SheetExecution[],
  projectIds: Set<number>,
  taskIds?: Set<number>,
): SheetExecution[] {
  return sheets.filter(s => isValidLinkedSheet(s, projectIds, taskIds));
}

export interface SheetStatusSummary {
  total: number;
  completed: number;
  inProgress: number;
  /** due_date 가 지났는데 progress < 100 또는 status !== completed 인 시트 수. taskByTaskId 가 있을 때만 채워짐. */
  overdue: number;
  /** 이번주 마감인 시트 수 (완료 제외). taskByTaskId 가 있을 때만 채워짐. */
  upcoming: number;
  overall: number;
  /** 마지막 업데이트 ISO. started_at / completed_at 중 가장 최근. */
  lastUpdatedAt: string | null;
}

export function summarizeSheetStatus(
  sheets: SheetExecution[],
  taskByTaskId?: Map<number, Task>,
): SheetStatusSummary {
  let completed = 0;
  let inProgress = 0;
  let overdue = 0;
  let upcoming = 0;
  let progressSum = 0;
  let lastUpdatedAt: string | null = null;
  for (const s of sheets) {
    if (s.status === 'completed') completed += 1;
    if (s.status === 'in_progress') inProgress += 1;
    progressSum += s.progress || 0;
    const stamp = s.completed_at || s.started_at || null;
    if (stamp && (!lastUpdatedAt || stamp > lastUpdatedAt)) lastUpdatedAt = stamp;
    if (taskByTaskId && s.task_id != null) {
      const t = taskByTaskId.get(s.task_id);
      if (t) {
        if (s.status !== 'completed' && isOverdue(t)) overdue += 1;
        else if (s.status !== 'completed' && isThisWeek(t.due_date)) upcoming += 1;
      }
    }
  }
  const overall = sheets.length > 0 ? Math.round(progressSum / sheets.length) : 0;
  return { total: sheets.length, completed, inProgress, overdue, upcoming, overall, lastUpdatedAt };
}

// ────────────────────────────────────────────────────────────────────────────
// 설비(=Project) 단위 요약
// ────────────────────────────────────────────────────────────────────────────

export type EquipmentStatus = 'running' | 'inspecting' | 'issue' | 'idle';

export interface EquipmentSummary {
  project: Project;
  status: EquipmentStatus;
  /** 다음 정기 점검 예정 Task. 없으면 null. */
  nextPeriodicTask: Task | null;
  /** 다음 마감 (정기/일반 무관) — 카드 D-day 표기에 사용. */
  nextDueTask: Task | null;
  activeIssueCount: number;
  /** progress 평균(0~100). 시트가 없으면 task progress 평균. 점검 수행형(체크리스트) 시트만 모수. */
  averageProgress: number;
  /** 진행 중 시트 / 전체 — 점검 수행형(체크리스트) 시트만 집계. 설비-배치 매핑형은 제외. */
  sheet: { inProgress: number; total: number };
  /** 설비-배치 매핑형(관리 테이블) 시트 개수 — 완료율 분모와 분리해 별도 표시용. */
  mappingSheetCount: number;
}

export function summarizeEquipment(
  project: Project,
  tasks: Task[],
  sheets: SheetExecution[],
): EquipmentSummary {
  const projectTasks = tasks.filter(t => t.project_id === project.id);
  const openTasks = projectTasks.filter(isOpen);

  const issueCount = projectTasks.filter(isIssueTask).length;

  // 다음 정기 점검: due_date 가 미래에 가까운 순
  const future = openTasks
    .map(t => ({ t, d: parseDateSafe(t.due_date) }))
    .filter(x => x.d && x.d.getTime() >= startOfToday().getTime())
    .sort((a, b) => (a.d!.getTime() - b.d!.getTime()));

  const nextPeriodicTask = future.find(x => isPeriodicTask(x.t))?.t || null;
  const nextDueTask = future[0]?.t || null;

  // 시트 요약 (project_id 매칭) — 점검 수행형(체크리스트)과 설비-배치 매핑형을 분리.
  // 매핑형은 완료/진행률 개념이 없으므로 완료율 모수에서 제외한다.
  const projectSheets = sheets.filter(s => s.project_id === project.id);
  const checklistSheets = projectSheets.filter(s => !isEquipmentMappingSheet(s));
  const mappingSheetCount = projectSheets.length - checklistSheets.length;
  const sheetInProgress = checklistSheets.filter(s => s.status === 'in_progress').length;

  // 진행률 평균: 체크리스트 시트가 있으면 시트 평균, 없으면 task progress 평균
  let averageProgress = 0;
  if (checklistSheets.length > 0) {
    const total = checklistSheets.reduce((acc, s) => acc + (s.progress || 0), 0);
    averageProgress = Math.round(total / checklistSheets.length);
  } else if (projectTasks.length > 0) {
    const total = projectTasks.reduce((acc, t) => acc + (t.progress || 0), 0);
    averageProgress = Math.round(total / projectTasks.length);
  }

  // 상태 추정: 이슈 우선 > 정기점검 임박(D-3 이내) > running > idle
  let status: EquipmentStatus = 'running';
  if (issueCount > 0) {
    status = 'issue';
  } else if (nextPeriodicTask) {
    const d = parseDateSafe(nextPeriodicTask.due_date);
    if (d) {
      const n = diffDays(startOfToday(), d);
      if (n <= 3) status = 'inspecting';
    }
  }
  if (projectTasks.length === 0 && projectSheets.length === 0) {
    status = 'idle';
  }

  return {
    project,
    status,
    nextPeriodicTask,
    nextDueTask,
    activeIssueCount: issueCount,
    averageProgress,
    sheet: {
      inProgress: sheetInProgress,
      total: checklistSheets.length,
    },
    mappingSheetCount,
  };
}

export function statusChipColor(s: EquipmentStatus): { bg: string; fg: string; label: string } {
  // ※ CSS 변수(`--eq-*-soft-bg`, `--eq-success` 등)는 EquipmentOpsDashboard.tsx 의
  //   themeCssVars 가 theme.palette 로부터 주입한다. (fallback 은 .css 의 :root)
  switch (s) {
    case 'running':    return { bg: 'var(--eq-success-soft-bg)', fg: 'var(--eq-success)', label: '가동 중' };
    case 'inspecting': return { bg: 'var(--eq-warning-soft-bg)', fg: 'var(--eq-warning)', label: '점검 임박' };
    case 'issue':      return { bg: 'var(--eq-error-soft-bg)',   fg: 'var(--eq-error)',   label: '이슈' };
    case 'idle':       return { bg: 'var(--eq-surface-subtle)',  fg: 'var(--eq-text-secondary)', label: '대기' };
  }
}

// ────────────────────────────────────────────────────────────────────────────
// KPI 카드 데이터
// ────────────────────────────────────────────────────────────────────────────

export interface EquipmentKpis {
  totalEquipment: number;
  todayTasks: number;
  weekInspections: number;
  openIssues: number;
  recentChanges: number;
  inProgressSheets: number;
}

export function computeKpis(
  projects: Project[],
  tasks: Task[],
  sheets: SheetExecution[],
): EquipmentKpis {
  const projectIds = new Set(projects.map(p => p.id));
  const spaceTasks = tasks.filter(t => projectIds.has(t.project_id));

  const todayTasks = spaceTasks.filter(t =>
    isOpen(t) && (isToday(t.due_date) || isToday(t.start_date))
  ).length;

  const weekInspections = spaceTasks.filter(t =>
    isOpen(t) && isThisWeek(t.due_date) && isPeriodicTask(t)
  ).length;

  const openIssues = spaceTasks.filter(isIssueTask).length;

  // 체크시트 진행중 = 점검 수행형(체크리스트)만. 설비-배치 매핑형은 진행률 개념이 없어 제외.
  const inProgressSheets = sheets.filter(s =>
    s.status === 'in_progress' && projectIds.has(s.project_id || -1) && !isEquipmentMappingSheet(s)
  ).length;

  // "변경 이력" — 최근 7일 내 updated_at 또는 시트 started_at 이 있는 항목 수
  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const recentTaskChanges = spaceTasks.filter(t => {
    const d = parseDateSafe(t.updated_at);
    return d && d.getTime() >= sevenDaysAgo;
  }).length;
  const recentSheetChanges = sheets.filter(s => {
    const d = parseDateSafe(s.started_at) || parseDateSafe(s.completed_at);
    return d && d.getTime() >= sevenDaysAgo && projectIds.has(s.project_id || -1);
  }).length;

  return {
    totalEquipment: projects.length,
    todayTasks,
    weekInspections,
    openIssues,
    recentChanges: recentTaskChanges + recentSheetChanges,
    inProgressSheets,
  };
}

// ────────────────────────────────────────────────────────────────────────────
// 정렬 유틸
// ────────────────────────────────────────────────────────────────────────────

/** due_date 가 가까운 순 정렬 (없으면 가장 뒤로). 오픈 task 만 권장. */
export function sortByNearestDue(tasks: Task[]): Task[] {
  return [...tasks].sort((a, b) => {
    const da = parseDateSafe(a.due_date);
    const db = parseDateSafe(b.due_date);
    if (da && db) return da.getTime() - db.getTime();
    if (da) return -1;
    if (db) return 1;
    return 0;
  });
}

/** updated_at(없으면 created_at) 최신순. */
export function sortByLatestUpdate<T extends { updated_at?: string; created_at?: string }>(items: T[]): T[] {
  return [...items].sort((a, b) => {
    const da = parseDateSafe(a.updated_at) || parseDateSafe(a.created_at);
    const db = parseDateSafe(b.updated_at) || parseDateSafe(b.created_at);
    return (db?.getTime() || 0) - (da?.getTime() || 0);
  });
}

// ────────────────────────────────────────────────────────────────────────────
// KPI 클릭 상세 — 카드별로 보여줄 항목 리스트 (Dialog 에서 렌더)
// ────────────────────────────────────────────────────────────────────────────

export type KpiKey = keyof EquipmentKpis;

/** Dialog row 의 디스크리미네이티드 유니온. 각 카드별로 적절한 종류 반환. */
export type KpiDetailItem =
  | { kind: 'project';  project: Project; meta?: string }
  | { kind: 'task';     task: Task;       meta?: string }
  | { kind: 'sheet';    sheet: SheetExecution; meta?: string }
  | { kind: 'change';   id: string; title: string; meta: string; at: string; ref: { type: 'task'; task: Task } | { type: 'sheet'; sheet: SheetExecution } };

/**
 * KPI 카드별 상세 항목 빌더.
 * - 카드 클릭 시 Dialog 에 표시할 row 리스트를 생성.
 * - 각 row 는 onOpen* 콜백으로 열 수 있도록 ref 데이터를 들고 있음.
 */
export function getKpiDetailItems(
  key: KpiKey,
  projects: Project[],
  tasks: Task[],
  sheets: SheetExecution[],
  equipments?: EquipmentSummary[],
): KpiDetailItem[] {
  const projectIds = new Set(projects.map(p => p.id));
  const spaceTasks = tasks.filter(t => projectIds.has(t.project_id));
  const projectById = new Map(projects.map(p => [p.id, p]));

  switch (key) {
    case 'totalEquipment': {
      const eqs = equipments && equipments.length > 0
        ? equipments
        : projects.map(p => summarizeEquipment(p, spaceTasks, sheets));
      return eqs.map(eq => ({
        kind: 'project' as const,
        project: eq.project,
        meta: `${statusChipColor(eq.status).label} · 진행률 ${eq.averageProgress}%`,
      }));
    }
    case 'todayTasks': {
      const list = sortByNearestDue(
        spaceTasks.filter(t => isOpen(t) && (isToday(t.due_date) || isToday(t.start_date)))
      );
      return list.map(t => {
        const proj = projectById.get(t.project_id);
        const due = t.due_date ? `마감 ${t.due_date.slice(0, 10)}` : '';
        return {
          kind: 'task' as const,
          task: t,
          meta: [proj?.name, due].filter(Boolean).join(' · '),
        };
      });
    }
    case 'weekInspections': {
      const list = sortByNearestDue(
        spaceTasks.filter(t => isOpen(t) && isThisWeek(t.due_date) && isPeriodicTask(t))
      );
      return list.map(t => {
        const proj = projectById.get(t.project_id);
        const due = t.due_date ? `${t.due_date.slice(0, 10)} (${dDayLabel(t.due_date)})` : '';
        return {
          kind: 'task' as const,
          task: t,
          meta: [proj?.name, due].filter(Boolean).join(' · '),
        };
      });
    }
    case 'openIssues': {
      const cats = categorizeIssueTasks(spaceTasks);
      // 우선순위: fault > issue > memo
      const ordered = [...cats.fault, ...cats.issue, ...cats.memo];
      return ordered.map(t => {
        const proj = projectById.get(t.project_id);
        const kind = classifyIssueKind(t);
        const kindLabel = kind === 'fault' ? '장애' : kind === 'issue' ? '이슈' : '메모';
        return {
          kind: 'task' as const,
          task: t,
          meta: [kindLabel, proj?.name].filter(Boolean).join(' · '),
        };
      });
    }
    case 'inProgressSheets': {
      // 카드 count(computeKpis)와 동일 기준 — 설비-배치 매핑형 제외.
      const list = sheets.filter(s =>
        s.status === 'in_progress' && projectIds.has(s.project_id || -1) && !isEquipmentMappingSheet(s)
      );
      // progress 낮은 순(처리 필요한 것 먼저)
      const sorted = [...list].sort((a, b) => (a.progress || 0) - (b.progress || 0));
      return sorted.map(s => {
        const proj = s.project_id != null ? projectById.get(s.project_id) : undefined;
        return {
          kind: 'sheet' as const,
          sheet: s,
          meta: [proj?.name, `진행률 ${s.progress || 0}%`].filter(Boolean).join(' · '),
        };
      });
    }
    case 'recentChanges': {
      const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
      const rows: KpiDetailItem[] = [];
      for (const t of spaceTasks) {
        const at = t.updated_at;
        const d = parseDateSafe(at);
        if (!d || d.getTime() < sevenDaysAgo) continue;
        const proj = projectById.get(t.project_id);
        rows.push({
          kind: 'change',
          id: `task-${t.id}-${at}`,
          title: t.title || '(제목 없음)',
          meta: [proj?.name, `작업 · ${formatRelative(at)}`].filter(Boolean).join(' · '),
          at: at!,
          ref: { type: 'task', task: t },
        });
      }
      for (const s of sheets) {
        if (!projectIds.has(s.project_id || -1)) continue;
        const at = s.completed_at || s.started_at;
        const d = parseDateSafe(at);
        if (!d || d.getTime() < sevenDaysAgo) continue;
        const proj = s.project_id != null ? projectById.get(s.project_id) : undefined;
        const verb = s.completed_at ? '완료' : '시작';
        rows.push({
          kind: 'change',
          id: `sheet-${s.id}-${at}`,
          title: s.title || s.template_name || `시트 #${s.id}`,
          meta: [proj?.name, `시트 ${verb} · ${formatRelative(at)}`].filter(Boolean).join(' · '),
          at: at!,
          ref: { type: 'sheet', sheet: s },
        });
      }
      rows.sort((a, b) => {
        const ax = (a as any).at as string;
        const bx = (b as any).at as string;
        return bx.localeCompare(ax);
      });
      return rows;
    }
  }
}

/** KPI 카드의 사람이 읽는 라벨 — Dialog 타이틀과 KpiCards 가 공유. */
export const KPI_LABELS: Record<KpiKey, string> = {
  totalEquipment:   '가동 설비',
  todayTasks:       '오늘 할 일',
  weekInspections:  '이번주 점검',
  openIssues:       '미해결 이슈',
  recentChanges:    '변경 이력 (7일)',
  inProgressSheets: '체크시트 진행중',
};
