import React from 'react';
import { Box, Pagination, MenuItem, Select, Typography } from '@mui/material';
import { planAiColors } from '../../theme/tokens';

export interface PaginationMeta {
  page: number;
  page_size: number;
  total: number;
  total_pages: number;
  has_next: boolean;
  has_prev: boolean;
}

interface PaginationBarProps {
  /** 현재 페이지 (1-base) */
  page: number;
  /** 페이지 크기 */
  pageSize: number;
  /** 전체 건수 */
  total: number;
  /** 전체 페이지 수 (없으면 total/pageSize 로 계산) */
  totalPages?: number;
  onPageChange: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  /** 페이지 크기 선택 옵션. 빈 배열이면 선택 UI 숨김 */
  pageSizeOptions?: number[];
  /** "총 N건" 단위 라벨 */
  unitLabel?: string;
  disabled?: boolean;
}

/**
 * 공통 server-side pagination UI.
 * "총 N건 · 현재/전체 페이지" + 페이지 번호(1 2 3 … N) + 페이지 크기 선택.
 */
const PaginationBar: React.FC<PaginationBarProps> = ({
  page,
  pageSize,
  total,
  totalPages,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [20, 50, 100],
  unitLabel = '건',
  disabled = false,
}) => {
  const computedPages =
    totalPages ?? (pageSize > 0 ? Math.max(1, Math.ceil(total / pageSize)) : 1);

  if (total === 0) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}>
        <Typography variant="body2" sx={{ color: planAiColors.text.tertiary }}>
          표시할 항목이 없습니다.
        </Typography>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 1.5,
        mt: 2,
        py: 1,
      }}
    >
      <Typography variant="body2" sx={{ color: planAiColors.text.secondary, fontSize: '0.8rem' }}>
        총 <strong>{total.toLocaleString()}</strong>
        {unitLabel} · {page} / {computedPages} 페이지
      </Typography>

      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
        <Pagination
          count={computedPages}
          page={Math.min(page, computedPages)}
          onChange={(_, p) => onPageChange(p)}
          color="primary"
          shape="rounded"
          siblingCount={1}
          boundaryCount={1}
          disabled={disabled}
          size="small"
        />
        {onPageSizeChange && pageSizeOptions.length > 0 && (
          <Select
            size="small"
            value={pageSize}
            onChange={e => onPageSizeChange(Number(e.target.value))}
            disabled={disabled}
            sx={{
              height: 32,
              fontSize: '0.78rem',
              '& .MuiSelect-select': { py: 0.4, pr: 3, pl: 1 },
            }}
          >
            {pageSizeOptions.map(opt => (
              <MenuItem key={opt} value={opt} sx={{ fontSize: '0.78rem' }}>
                {opt}개씩
              </MenuItem>
            ))}
          </Select>
        )}
      </Box>
    </Box>
  );
};

export default PaginationBar;
