import React, { useState } from 'react';
import { Box, Paper, Typography, IconButton, Popover } from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  getDay,
  isSameDay,
  isToday as isDateToday,
  addMonths,
  subMonths,
} from 'date-fns';
import { Task, CalendarEvent } from '../types';
import { useAppStore } from '../stores/useAppStore';

// ── Korean Public Holidays (2025–2027) ──
const KOREAN_HOLIDAYS: Record<string, string> = {
  '2025-01-01': '신정',
  '2025-01-28': '설날 연휴',
  '2025-01-29': '설날',
  '2025-01-30': '설날 연휴',
  '2025-03-01': '삼일절',
  '2025-05-05': '어린이날',
  '2025-05-06': '대체공휴일',
  '2025-05-15': '부처님오신날',
  '2025-06-06': '현충일',
  '2025-08-15': '광복절',
  '2025-10-03': '개천절',
  '2025-10-05': '추석 연휴',
  '2025-10-06': '추석',
  '2025-10-07': '추석 연휴',
  '2025-10-08': '대체공휴일',
  '2025-10-09': '한글날',
  '2025-12-25': '성탄절',
  '2026-01-01': '신정',
  '2026-02-16': '설날 연휴',
  '2026-02-17': '설날',
  '2026-02-18': '설날 연휴',
  '2026-03-01': '삼일절',
  '2026-03-02': '대체공휴일',
  '2026-05-05': '어린이날',
  '2026-05-24': '부처님오신날',
  '2026-06-06': '현충일',
  '2026-07-17': '제헌절',
  '2026-08-15': '광복절',
  '2026-08-17': '대체공휴일',
  '2026-09-24': '추석 연휴',
  '2026-09-25': '추석',
  '2026-09-26': '추석 연휴',
  '2026-10-03': '개천절',
  '2026-10-05': '대체공휴일',
  '2026-10-09': '한글날',
  '2026-12-25': '성탄절',
  '2027-01-01': '신정',
  '2027-02-06': '설날 연휴',
  '2027-02-07': '설날',
  '2027-02-08': '설날 연휴',
  '2027-02-09': '대체공휴일',
  '2027-03-01': '삼일절',
  '2027-05-05': '어린이날',
  '2027-05-13': '부처님오신날',
  '2027-06-06': '현충일',
  '2027-06-07': '대체공휴일',
  '2027-08-15': '광복절',
  '2027-08-16': '대체공휴일',
  '2027-09-14': '추석 연휴',
  '2027-09-15': '추석',
  '2027-09-16': '추석 연휴',
  '2027-10-03': '개천절',
  '2027-10-04': '대체공휴일',
  '2027-10-09': '한글날',
  '2027-10-11': '대체공휴일',
  '2027-12-25': '성탄절',
  '2027-12-27': '대체공휴일',
};

// Bar style by status / priority
const taskBarStyle = (t: Task): { bg: string; fg: string; border: string } => {
  if (t.priority === 'high' && t.status !== 'done') {
    return { bg: '#FEE2E2', fg: '#B91C1C', border: '#EF4444' };
  }
  switch (t.status) {
    case 'in_progress':
      return { bg: '#DBEAFE', fg: '#1E40AF', border: '#2955FF' };
    case 'done':
      return { bg: '#F3F4F6', fg: '#6B7280', border: '#9CA3AF' };
    case 'hold':
      return { bg: '#FEF3C7', fg: '#92400E', border: '#F59E0B' };
    case 'todo':
    default:
      return { bg: '#E5E7EB', fg: '#374151', border: '#6B7280' };
  }
};

const taskDateRange = (t: Task): { from: Date; to: Date; single: boolean } | null => {
  const sd = (t as any).start_date ? new Date((t as any).start_date) : null;
  const dd = t.due_date ? new Date(t.due_date) : null;
  if (sd && dd) {
    if (sd.getTime() > dd.getTime()) return { from: dd, to: dd, single: true };
    return { from: sd, to: dd, single: isSameDay(sd, dd) };
  }
  if (dd) return { from: dd, to: dd, single: true };
  if (sd) return { from: sd, to: sd, single: true };
  return null;
};

// 단순 일정(CalendarEvent) 의 날짜 범위 — start/end(YYYY-MM-DD) 기준
const eventDateRange = (e: CalendarEvent): { from: Date; to: Date } | null => {
  const sd = e.start_date ? new Date(e.start_date) : null;
  const ed = e.end_date ? new Date(e.end_date) : null;
  if (sd && ed) return sd.getTime() > ed.getTime() ? { from: ed, to: sd } : { from: sd, to: ed };
  if (sd) return { from: sd, to: sd };
  if (ed) return { from: ed, to: ed };
  return null;
};

const eventBarStyle = (e: CalendarEvent): { bg: string; fg: string; border: string } => {
  if (e.status === 'canceled') return { bg: '#F3F4F6', fg: '#9CA3AF', border: '#D1D5DB' };
  if (e.status === 'done') return { bg: '#ECFDF5', fg: '#047857', border: '#10B981' };
  if (e.status === 'in_progress') return { bg: '#FEF3C7', fg: '#B45309', border: '#F59E0B' };
  return { bg: '#EEF2FF', fg: '#4338CA', border: '#6366F1' };
};

interface Props {
  /** 표시할 작업 목록. 중복 ID 는 알아서 제거됨. start_date 가 있는 항목이 우선. */
  tasks: Task[];
  /** 표시할 단순 일정(CalendarEvent) 목록 (Phase 2). */
  events?: CalendarEvent[];
  /** 작업 클릭 / 빈 셀 클릭 시 호출. 빈 셀 클릭은 enableCreate=true 일 때만 동작. */
  openDrawer: (
    task?: Task | null,
    projectId?: number,
    initialData?: Partial<Task> | null,
  ) => void;
  /** 외곽 Paper/padding 제거 — 다른 위젯 카드 내부에 들어갈 때 사용. */
  flat?: boolean;
  /** 빈 셀 클릭으로 신규 작업 생성 활성화 (기본 true — 기존 HomePage 동작 유지). */
  enableCreate?: boolean;
}

/**
 * 월간 작업 캘린더.
 *
 * 기존 HomePage 내부에 정의되어 있던 DashboardCalendar 를 그대로 추출한 것.
 * 설비운영 Dashboard 등 다른 화면에서도 재사용 가능하도록 stats/overviewData 대신
 * 단순 Task[] 를 받는다.
 */
const DashboardCalendar: React.FC<Props> = ({ tasks, events = [], openDrawer, flat, enableCreate = true }) => {
  const openEventDialog = useAppStore(s => s.openEventDialog);
  const [calMonth, setCalMonth] = useState(new Date());
  const [overflowAnchor, setOverflowAnchor] = useState<HTMLElement | null>(null);
  const [overflowDate, setOverflowDate] = useState<Date | null>(null);
  const [overflowTasks, setOverflowTasks] = useState<Task[]>([]);

  const mStart = startOfMonth(calMonth);
  const mEnd = endOfMonth(calMonth);
  const mDays = eachDayOfInterval({ start: mStart, end: mEnd });
  const pad = getDay(mStart);

  // start_date 가 있는 항목을 우선해서 중복 제거
  const taskMap = new Map<number, Task>();
  for (const t of tasks) {
    const existing = taskMap.get(t.id);
    if (!existing || (!(existing as any).start_date && (t as any).start_date)) {
      taskMap.set(t.id, t);
    }
  }
  const uniqueTasks = Array.from(taskMap.values());
  const WDAYS = ['일', '월', '화', '수', '목', '금', '토'];

  const handleOverflowClick = (e: React.MouseEvent<HTMLElement>, day: Date, dayTasks: Task[]) => {
    e.stopPropagation();
    setOverflowDate(day);
    setOverflowTasks(dayTasks);
    setOverflowAnchor(e.currentTarget);
  };

  const Wrapper: React.ElementType = flat ? Box : Paper;
  const wrapperProps = flat ? {} : { variant: 'outlined' as const };
  const wrapperSx = flat
    ? { p: 0, bgcolor: 'transparent' }
    : {
        p: 2,
        borderRadius: 3,
        bgcolor: '#fff',
        border: '1px solid rgba(0,0,0,0.08)',
        boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
      };

  return (
    <Wrapper {...wrapperProps} sx={wrapperSx}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {!flat && <CalendarMonthIcon sx={{ color: '#2955FF', fontSize: '1.4rem' }} />}
          {!flat && (
            <Typography variant="h6" sx={{ fontWeight: 800, color: '#1A1D29' }}>
              월간 작업 캘린더
            </Typography>
          )}
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <IconButton size="small" onClick={() => setCalMonth(subMonths(calMonth, 1))} sx={{ bgcolor: '#F3F4F6', '&:hover': { bgcolor: '#E5E7EB' } }}>
            <ChevronLeftIcon />
          </IconButton>
          <Typography variant="subtitle1" sx={{ fontWeight: 700, minWidth: 100, textAlign: 'center' }}>
            {format(calMonth, 'yyyy년 M월')}
          </Typography>
          <IconButton size="small" onClick={() => setCalMonth(addMonths(calMonth, 1))} sx={{ bgcolor: '#F3F4F6', '&:hover': { bgcolor: '#E5E7EB' } }}>
            <ChevronRightIcon />
          </IconButton>
        </Box>
      </Box>

      {/* Weekday headers */}
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', borderBottom: '1px solid rgba(0,0,0,0.08)' }}>
        {WDAYS.map((d, i) => (
          <Box key={i} sx={{ textAlign: 'center', py: 1, fontSize: '0.8rem', fontWeight: 700, color: i === 0 ? '#EF4444' : i === 6 ? '#3B82F6' : '#6B7280' }}>
            {d}
          </Box>
        ))}
      </Box>

      {/* Day grid */}
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)' }}>
        {Array.from({ length: pad }).map((_, i) => (
          <Box key={`p${i}`} sx={{ minHeight: 110, borderBottom: '1px solid #F3F4F6', borderRight: '1px solid #F3F4F6', bgcolor: '#FAFBFC' }} />
        ))}
        {mDays.map((day, idx) => {
          const dayNum = parseInt(format(day, 'd'));
          const dateKey = format(day, 'yyyy-MM-dd');
          const holiday = KOREAN_HOLIDAYS[dateKey];
          const isSun = getDay(day) === 0;
          const isSat = getDay(day) === 6;
          const isTd = isDateToday(day);
          const isWeekStart = getDay(day) === 0;
          const isWeekEnd = getDay(day) === 6;
          const isMonthStart = isSameDay(day, mStart);
          const isMonthEnd = isSameDay(day, mEnd);
          const dayMs = day.getTime();

          const dayTasks = uniqueTasks.filter(t => {
            const range = taskDateRange(t);
            if (!range) return false;
            const fromMs = new Date(range.from.getFullYear(), range.from.getMonth(), range.from.getDate()).getTime();
            const toMs = new Date(range.to.getFullYear(), range.to.getMonth(), range.to.getDate()).getTime();
            return dayMs >= fromMs && dayMs <= toMs;
          });
          const displayTasks = dayTasks.slice(0, 5);
          const overflowCount = dayTasks.length - 5;

          const dayEvents = events.filter(ev => {
            const range = eventDateRange(ev);
            if (!range) return false;
            const fromMs = new Date(range.from.getFullYear(), range.from.getMonth(), range.from.getDate()).getTime();
            const toMs = new Date(range.to.getFullYear(), range.to.getMonth(), range.to.getDate()).getTime();
            return dayMs >= fromMs && dayMs <= toMs;
          });

          return (
            <Box
              key={day.toISOString()}
              onClick={() => {
                if (!enableCreate) return;
                // Phase 2: 캘린더 빈 셀 클릭 = 단발 일정(CalendarEvent) 추가
                openEventDialog(null, dateKey);
              }}
              sx={{
                minHeight: 110,
                borderBottom: '1px solid #F3F4F6',
                borderRight: '1px solid #F3F4F6',
                p: 0.5,
                bgcolor: isTd ? '#FAFBFF' : holiday ? '#FFF5F5' : '#fff',
                display: 'flex',
                flexDirection: 'column',
                gap: 0.3,
                cursor: enableCreate ? 'pointer' : 'default',
                '&:hover': enableCreate
                  ? { bgcolor: isTd ? '#F0F4FF' : holiday ? '#FEE2E2' : '#F9FAFB' }
                  : {},
                ...(idx % 7 === 6 - pad && { borderRight: 'none' }),
              }}
            >
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 0.5 }}>
                <Box
                  sx={{
                    width: isTd ? 24 : 'auto',
                    height: isTd ? 24 : 'auto',
                    borderRadius: '50%',
                    bgcolor: isTd ? '#2955FF' : 'transparent',
                    color: isTd ? '#fff' : holiday || isSun ? '#EF4444' : isSat ? '#3B82F6' : '#374151',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '0.8rem',
                    fontWeight: isTd ? 700 : 500,
                    px: isTd ? 0 : 0.5,
                  }}
                >
                  {dayNum}
                </Box>
                {holiday && (
                  <Typography sx={{ fontSize: '0.65rem', color: '#EF4444', fontWeight: 600, mt: 0.2 }}>
                    {holiday}
                  </Typography>
                )}
              </Box>

              {dayEvents.map(ev => {
                const range = eventDateRange(ev)!;
                const style = eventBarStyle(ev);
                const fromMs = new Date(range.from.getFullYear(), range.from.getMonth(), range.from.getDate()).getTime();
                const toMs = new Date(range.to.getFullYear(), range.to.getMonth(), range.to.getDate()).getTime();
                const isBarStart = dayMs === fromMs || isMonthStart || isWeekStart;
                const isBarEnd = dayMs === toMs || isMonthEnd || isWeekEnd;
                const isReallyStart = dayMs === fromMs;
                const radiusLeft = isBarStart ? 4 : 0;
                const radiusRight = isBarEnd ? 4 : 0;
                return (
                  <Box
                    key={`ev-${ev.id}`}
                    onClick={(e) => { e.stopPropagation(); openEventDialog(ev); }}
                    sx={{
                      px: 0.5, py: 0.2,
                      bgcolor: style.bg,
                      color: style.fg,
                      borderLeft: isReallyStart ? `3px dashed ${style.border}` : 'none',
                      borderRadius: `${radiusLeft}px ${radiusRight}px ${radiusRight}px ${radiusLeft}px`,
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                      textDecoration: ev.status === 'canceled' ? 'line-through' : 'none',
                      '&:hover': { filter: 'brightness(0.97)' },
                    }}
                  >
                    {isBarStart ? `• ${ev.title}` : ' '}
                  </Box>
                );
              })}

              {displayTasks.map(t => {
                const range = taskDateRange(t)!;
                const style = taskBarStyle(t);
                const fromMs = new Date(range.from.getFullYear(), range.from.getMonth(), range.from.getDate()).getTime();
                const toMs = new Date(range.to.getFullYear(), range.to.getMonth(), range.to.getDate()).getTime();
                const isBarStart = dayMs === fromMs || isMonthStart || isWeekStart;
                const isBarEnd = dayMs === toMs || isMonthEnd || isWeekEnd;
                const isReallyStart = dayMs === fromMs;
                const radiusLeft = isBarStart ? 4 : 0;
                const radiusRight = isBarEnd ? 4 : 0;
                return (
                  <Box
                    key={t.id}
                    onClick={(e) => { e.stopPropagation(); openDrawer(t); }}
                    sx={{
                      px: 0.5, py: 0.2,
                      bgcolor: style.bg,
                      color: style.fg,
                      borderLeft: isReallyStart ? `3px solid ${style.border}` : 'none',
                      borderRadius: `${radiusLeft}px ${radiusRight}px ${radiusRight}px ${radiusLeft}px`,
                      fontSize: '0.7rem',
                      fontWeight: 600,
                      cursor: 'pointer',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                      opacity: t.status === 'done' ? 0.7 : 1,
                      '&:hover': { filter: 'brightness(0.95)' }
                    }}
                  >
                    {isBarStart ? t.title : ' '}
                  </Box>
                );
              })}
              {overflowCount > 0 && (
                <Typography
                  onClick={(e) => handleOverflowClick(e, day, dayTasks)}
                  sx={{
                    fontSize: '0.65rem',
                    color: '#6B7280',
                    fontWeight: 700,
                    cursor: 'pointer',
                    textAlign: 'center',
                    bgcolor: '#F3F4F6',
                    borderRadius: 1,
                    py: 0.2,
                    '&:hover': { bgcolor: '#E5E7EB', color: '#374151' }
                  }}
                >
                  +{overflowCount} more
                </Typography>
              )}
            </Box>
          );
        })}
      </Box>

      <Popover
        open={Boolean(overflowAnchor)}
        anchorEl={overflowAnchor}
        onClose={() => { setOverflowAnchor(null); setOverflowDate(null); }}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        transformOrigin={{ vertical: 'top', horizontal: 'center' }}
        PaperProps={{ sx: { p: 1.5, width: 260, borderRadius: 2, boxShadow: '0 4px 20px rgba(0,0,0,0.1)' } }}
      >
        <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1, color: '#1A1D29' }}>
          {overflowDate ? format(overflowDate, 'M월 d일 일정') : ''}
        </Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, maxHeight: 300, overflowY: 'auto' }}>
          {overflowTasks.map(t => {
            const style = taskBarStyle(t);
            return (
              <Box
                key={t.id}
                onClick={() => { openDrawer(t); setOverflowAnchor(null); }}
                sx={{
                  px: 1, py: 0.5,
                  bgcolor: style.bg,
                  color: style.fg,
                  borderLeft: `3px solid ${style.border}`,
                  borderRadius: '0 4px 4px 0',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  cursor: 'pointer',
                  opacity: t.status === 'done' ? 0.75 : 1,
                  '&:hover': { filter: 'brightness(0.95)' }
                }}
              >
                {t.title}
              </Box>
            );
          })}
        </Box>
      </Popover>
    </Wrapper>
  );
};

export default DashboardCalendar;
