import React, { useState } from 'react';
import {
  Box, Typography, Card, CardActionArea, CardContent, Button,
  alpha,
} from '@mui/material';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import FolderSpecialIcon from '@mui/icons-material/FolderSpecial';
import PrecisionManufacturingIcon from '@mui/icons-material/PrecisionManufacturing';
import TemplatePreviewDialog from './TemplatePreviewDialog';
import { TEMPLATE_PREVIEWS } from './templatePreviewConfig';
// 아래 4개 옵션(공정 변경/이력·SW 개발·통합 운영·직접 구성)은 노출에서 제외함.
// 기존 데이터/백엔드 enum(자유 문자열)은 그대로 보존하며, 필요 시 아래 import/배열을 복원하면 됨.
// import ScienceIcon from '@mui/icons-material/Science';
// import CodeIcon from '@mui/icons-material/Code';
// import HubIcon from '@mui/icons-material/Hub';
// import TuneIcon from '@mui/icons-material/Tune';
import type { SpacePurpose } from '../../types';

interface Props {
  value: SpacePurpose;
  onChange: (purpose: SpacePurpose) => void;
}

const PURPOSE_OPTIONS: {
  key: SpacePurpose;
  label: string;
  desc: string;
  icon: React.ReactNode;
  color: string;
}[] = [
  {
    key: 'project_management',
    label: '프로젝트 관리',
    desc: 'PM 중심의 일정/진행 관리',
    icon: <FolderSpecialIcon />,
    color: '#2955FF',
  },
  {
    key: 'equipment_ops',
    label: '설비 운영',
    desc: '설비 점검/PM/약품 관리',
    icon: <PrecisionManufacturingIcon />,
    color: '#16A34A',
  },
  // 비노출 옵션들 — 필요 시 주석 해제 후 import 복원하면 됨.
  // {
  //   key: 'process_change',
  //   label: '공정 변경/이력',
  //   desc: 'Recipe 변경 이력 관리',
  //   icon: <ScienceIcon />,
  //   color: '#9333EA',
  // },
  // {
  //   key: 'sw_dev',
  //   label: 'SW 개발',
  //   desc: '기능 단위 개발 흐름 관리',
  //   icon: <CodeIcon />,
  //   color: '#EA580C',
  // },
  // {
  //   key: 'integrated_ops',
  //   label: '통합 운영',
  //   desc: '직군 혼합 협업 운영',
  //   icon: <HubIcon />,
  //   color: '#0891B2',
  // },
  // {
  //   key: 'custom',
  //   label: '직접 구성',
  //   desc: '필요한 기능을 직접 선택',
  //   icon: <TuneIcon />,
  //   color: '#64748B',
  // },
];

export default function SpacePurposeSelector({ value, onChange }: Props) {
  // 생성 전 "미리보기" 대상 템플릿 (null 이면 닫힘). 미리보기는 DB 생성 없이 mock 만 렌더링.
  const [previewKey, setPreviewKey] = useState<SpacePurpose | null>(null);

  return (
    <Box>
      <Typography variant="subtitle2" sx={{ mb: 1, color: 'text.secondary' }}>
        공간 운영 목적
      </Typography>
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1 }}>
        {PURPOSE_OPTIONS.map((opt) => {
          const selected = value === opt.key;
          const hasPreview = !!TEMPLATE_PREVIEWS[opt.key];
          return (
            <Card
              key={opt.key}
              variant="outlined"
              sx={{
                borderColor: selected ? opt.color : 'divider',
                borderWidth: selected ? 2 : 1,
                bgcolor: selected ? alpha(opt.color, 0.06) : 'background.paper',
                transition: 'all 0.15s',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              <CardActionArea onClick={() => onChange(opt.key)} sx={{ p: 1.2, flex: 1 }}>
                <CardContent sx={{ p: '0 !important', display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8 }}>
                    <Box sx={{ color: selected ? opt.color : 'text.secondary', display: 'flex' }}>
                      {opt.icon}
                    </Box>
                    <Typography variant="body2" fontWeight={selected ? 700 : 500} sx={{ color: selected ? opt.color : 'text.primary' }}>
                      {opt.label}
                    </Typography>
                  </Box>
                  <Typography variant="caption" color="text.secondary" sx={{ lineHeight: 1.3 }}>
                    {opt.desc}
                  </Typography>
                </CardContent>
              </CardActionArea>
              {hasPreview && (
                <Box sx={{ px: 1.2, pb: 0.8 }}>
                  <Button
                    size="small"
                    startIcon={<VisibilityOutlinedIcon sx={{ fontSize: '1rem !important' }} />}
                    onClick={(e) => { e.stopPropagation(); setPreviewKey(opt.key); }}
                    sx={{
                      textTransform: 'none', fontSize: '0.72rem', py: 0.2,
                      color: opt.color,
                      '&:hover': { bgcolor: alpha(opt.color, 0.08) },
                    }}
                  >
                    미리보기
                  </Button>
                </Box>
              )}
            </Card>
          );
        })}
      </Box>

      <TemplatePreviewDialog
        open={!!previewKey}
        purposeKey={previewKey}
        onClose={() => setPreviewKey(null)}
        onSelect={(key) => { onChange(key); setPreviewKey(null); }}
      />
    </Box>
  );
}
