import type { SpacePurpose } from '../../types';

/**
 * 템플릿(공간 운영 목적) 미리보기용 mock 설정.
 *
 * 중요: 이 데이터는 실제 DB/API 와 무관한 정적 mock 이다. 미리보기 Dialog 에서만 사용하며,
 * "이 템플릿으로 생성하기"를 눌렀을 때 비로소 기존 생성 플로우(onChange)로 연결된다.
 * 미리보기 자체로는 어떤 데이터도 생성되지 않는다.
 */

export interface PreviewStatCard {
  label: string;
  value: string;
  hint?: string;
}

export interface PreviewTaskRow {
  title: string;
  assignee: string;
  status: string;
  statusColor: string;
  due: string;
}

export interface PreviewHistoryRow {
  time: string;
  actor: string;
  text: string;
}

export interface PreviewChecklistRow {
  label: string;
  done: boolean;
}

export interface TemplatePreview {
  key: SpacePurpose;
  title: string;
  accent: string;
  description: string;
  features: string[];
  stats: PreviewStatCard[];
  tasks: PreviewTaskRow[];
  history: PreviewHistoryRow[];
  /** 설비 운영 템플릿 등에서만 사용하는 체크시트 mock (없으면 탭 숨김) */
  checklist?: { title: string; rows: PreviewChecklistRow[] };
  aiSummary: string[];
}

export const TEMPLATE_PREVIEWS: Partial<Record<SpacePurpose, TemplatePreview>> = {
  project_management: {
    key: 'project_management',
    title: '프로젝트 관리 템플릿',
    accent: '#2955FF',
    description:
      '프로젝트, Task, 담당자, 일정, 진척률을 중심으로 업무를 관리합니다. PM 관점에서 진행 상황과 마감을 한눈에 추적할 수 있습니다.',
    features: [
      '프로젝트 / Task 관리',
      '담당자 및 마감일 관리',
      '진척률 대시보드',
      'AI 요약 및 우선순위 추천',
      '변경 이력 관리',
    ],
    stats: [
      { label: '진행중 Task', value: '12건', hint: '담당자 5명' },
      { label: '마감 임박', value: '3건', hint: '3일 이내' },
      { label: '완료율', value: '68%', hint: '지난주 +12%' },
    ],
    tasks: [
      { title: '요구사항 정의서 작성', assignee: '홍길동', status: '진행 중', statusColor: '#F59E0B', due: '06-20' },
      { title: 'API 설계 리뷰', assignee: '이영희', status: '검토', statusColor: '#7C3AED', due: '06-21' },
      { title: '1차 데모 준비', assignee: '김철수', status: '할 일', statusColor: '#64748B', due: '06-24' },
      { title: '킥오프 미팅', assignee: '홍길동', status: '완료', statusColor: '#22C55E', due: '06-12' },
    ],
    history: [
      { time: '2026-06-18 10:20', actor: '홍길동', text: '상태 변경: 진행 중 → 완료' },
      { time: '2026-06-18 11:05', actor: '김철수', text: '담당자 변경: 미지정 → 이영희' },
      { time: '2026-06-18 13:10', actor: '홍길동', text: '설명 수정' },
    ],
    aiSummary: [
      '이번 주 마감 임박 Task 3건 중 2건이 한 담당자에게 집중되어 있습니다.',
      '전체 완료율은 68%로 지난주 대비 12%p 상승했습니다.',
      '"API 설계 리뷰"가 후속 작업의 선행 조건이므로 우선 처리 권장.',
    ],
  },

  equipment_ops: {
    key: 'equipment_ops',
    title: '설비 운영 템플릿',
    accent: '#16A34A',
    description:
      '설비별 작업, 체크시트, 이슈/조치사항, 변경 이력을 중심으로 운영 업무를 관리합니다. 점검·PM·약품 관리에 적합합니다.',
    features: [
      '설비별 작업 관리',
      '체크시트 연결',
      '설비 변경 이력',
      '이슈 / 조치사항 관리',
      'AI 운영 요약',
    ],
    stats: [
      { label: '진행중 작업', value: '7건', hint: '설비 4대' },
      { label: '이슈 설비', value: '2대', hint: '조치 필요' },
      { label: '최근 변경', value: '5건', hint: '24시간 내' },
    ],
    tasks: [
      { title: 'A설비 정기 점검', assignee: '박기술', status: '진행 중', statusColor: '#F59E0B', due: '06-19' },
      { title: 'B설비 약품 교체', assignee: '최운영', status: '할 일', statusColor: '#64748B', due: '06-22' },
      { title: 'C설비 이상 진동 조치', assignee: '박기술', status: '이슈', statusColor: '#DC2626', due: '06-18' },
      { title: 'D설비 PM 완료', assignee: '최운영', status: '완료', statusColor: '#22C55E', due: '06-15' },
    ],
    history: [
      { time: '2026-06-18 09:40', actor: '박기술', text: '상태 변경: 할 일 → 진행 중' },
      { time: '2026-06-18 10:55', actor: '최운영', text: '약품 교체 주기 수정' },
      { time: '2026-06-18 14:02', actor: '박기술', text: 'C설비 이슈 등록' },
    ],
    checklist: {
      title: 'A설비 정기 점검 체크시트',
      rows: [
        { label: '외관 손상 여부 확인', done: true },
        { label: '윤활유 레벨 점검', done: true },
        { label: '진동 / 소음 측정', done: false },
        { label: '안전 커버 체결 확인', done: false },
      ],
    },
    aiSummary: [
      'C설비의 이상 진동 이슈가 미해결 상태로 우선 조치가 필요합니다.',
      '최근 24시간 내 설비 변경 5건 중 3건이 약품 관련 작업입니다.',
      'B설비 약품 교체가 권장 주기에 근접했습니다.',
    ],
  },
};
