/**
 * SpaceEmptyWarningBanner — 빈 공간 경고/보관 안내 배너.
 *
 * 공간 데이터(_space_dict)의 warned_at / archived_at 으로 상태를 판단한다.
 * - archived_at 있음 → 보관됨/보관 예정 안내
 * - warned_at 있음(미보관) → 빈 공간 경고
 * - 둘 다 없음 → 아무것도 렌더링하지 않음 (null)
 */

import React from 'react';
import { Alert, AlertTitle } from '@mui/material';

interface SpaceLike {
  warned_at?: string | null;
  archived_at?: string | null;
  delete_scheduled_at?: string | null;
}

interface Props {
  space: SpaceLike | null | undefined;
  /** 경고/보관을 유지하려면 활동을 추가하라는 행동 유도 문구 노출 여부 */
  showCallToAction?: boolean;
}

const fmt = (iso?: string | null): string => {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleDateString('ko-KR', { year: 'numeric', month: 'long', day: 'numeric' });
  } catch {
    return '';
  }
};

const SpaceEmptyWarningBanner: React.FC<Props> = ({ space, showCallToAction = true }) => {
  if (!space) return null;

  if (space.archived_at) {
    return (
      <Alert severity="info" sx={{ mb: 2, borderRadius: 2 }}>
        <AlertTitle sx={{ fontWeight: 700 }}>보관된 공간입니다</AlertTitle>
        이 공간은 장기간 사용되지 않아 보관 처리되었습니다. 보관되면 일반 목록에서 숨겨지며, 관리자 또는 소유자가 복구할 수 있습니다.
      </Alert>
    );
  }

  if (space.warned_at) {
    return (
      <Alert severity="warning" sx={{ mb: 2, borderRadius: 2 }}>
        <AlertTitle sx={{ fontWeight: 700 }}>활동이 없는 공간입니다</AlertTitle>
        이 공간은 생성 후 일정 기간 동안 프로젝트나 활동이 없습니다. 계속 사용하지 않으면 자동으로 보관 처리될 수 있습니다
        {space.delete_scheduled_at ? ` (보관/정리 예정: ${fmt(space.delete_scheduled_at)})` : ''}.
        {showCallToAction && ' 공간을 유지하려면 프로젝트를 생성하거나 활동을 추가해주세요.'}
      </Alert>
    );
  }

  return null;
};

export default SpaceEmptyWarningBanner;
