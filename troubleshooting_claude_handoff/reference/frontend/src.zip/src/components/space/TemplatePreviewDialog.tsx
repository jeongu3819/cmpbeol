import React, { useState, useEffect } from 'react';
import {
  Dialog, Box, Typography, IconButton, Button, Chip, Tabs, Tab,
  Divider, Stack, useMediaQuery, useTheme, Avatar,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import DashboardIcon from '@mui/icons-material/Dashboard';
import ChecklistIcon from '@mui/icons-material/Checklist';
import HistoryIcon from '@mui/icons-material/History';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import type { SpacePurpose } from '../../types';
import { TEMPLATE_PREVIEWS } from './templatePreviewConfig';
import { planAiColors } from '../../theme/tokens';

interface Props {
  open: boolean;
  purposeKey: SpacePurpose | null;
  onClose: () => void;
  /** "이 템플릿으로 생성하기" — 기존 생성 플로우로 연결 */
  onSelect: (key: SpacePurpose) => void;
}

/**
 * 템플릿(공간 운영 목적) 미리보기 Dialog.
 *
 * mock 데이터만 렌더링하며 실제 API 호출/DB 생성은 일절 하지 않는다.
 * 사용자가 "이 템플릿으로 생성하기"를 눌렀을 때만 onSelect 로 기존 생성 플로우에 연결된다.
 */
const TemplatePreviewDialog: React.FC<Props> = ({ open, purposeKey, onClose, onSelect }) => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
  const preview = purposeKey ? TEMPLATE_PREVIEWS[purposeKey] : undefined;
  const [tab, setTab] = useState(0);

  // 템플릿이 바뀌면 첫 탭으로 초기화
  useEffect(() => { setTab(0); }, [purposeKey, open]);

  if (!preview) return null;
  const accent = preview.accent;

  // 탭 구성 — 체크시트는 설정이 있을 때만
  const tabs: { label: string; icon: React.ReactElement }[] = [
    { label: '대시보드', icon: <DashboardIcon fontSize="small" /> },
    { label: 'Task', icon: <TaskAltIcon fontSize="small" /> },
    ...(preview.checklist ? [{ label: '체크시트', icon: <ChecklistIcon fontSize="small" /> }] : []),
    { label: '이력', icon: <HistoryIcon fontSize="small" /> },
    { label: 'AI 요약', icon: <AutoAwesomeIcon fontSize="small" /> },
  ];
  const currentLabel = tabs[tab]?.label;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="lg"
      fullWidth
      fullScreen={fullScreen}
      PaperProps={{ sx: { borderRadius: fullScreen ? 0 : 3, minHeight: fullScreen ? '100%' : '70vh' } }}
    >
      {/* Header */}
      <Box sx={{ p: 2.5, display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Box sx={{ width: 10, height: 28, borderRadius: 1, bgcolor: accent }} />
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 800, lineHeight: 1.2 }}>{preview.title} 미리보기</Typography>
            <Typography variant="caption" color="text.secondary">
              샘플 화면입니다. 실제 데이터는 생성되지 않습니다.
            </Typography>
          </Box>
        </Box>
        <IconButton size="small" onClick={onClose}><CloseIcon /></IconButton>
      </Box>

      <Box sx={{ p: { xs: 2, md: 3 }, flex: 1, overflowY: 'auto' }}>
        {/* 상단 요약 */}
        <Box sx={{ mb: 2.5 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            {preview.description}
          </Typography>
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
            {preview.features.map((f) => (
              <Chip key={f} label={f} size="small" sx={{ bgcolor: `${accent}14`, color: accent, fontWeight: 600 }} />
            ))}
          </Stack>
        </Box>

        {/* 샘플 통계 카드 */}
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(3, 1fr)' }, gap: 1.5, mb: 3 }}>
          {preview.stats.map((s) => (
            <Box key={s.label} sx={{ p: 2, borderRadius: 2, border: '1px solid', borderColor: 'divider', bgcolor: 'background.paper' }}>
              <Typography variant="caption" color="text.secondary">{s.label}</Typography>
              <Typography variant="h5" sx={{ fontWeight: 800, color: accent, my: 0.3 }}>{s.value}</Typography>
              {s.hint && <Typography variant="caption" color="text.secondary">{s.hint}</Typography>}
            </Box>
          ))}
        </Box>

        {/* 상세 화면 Preview 탭 */}
        <Box sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 2, overflow: 'hidden' }}>
          <Tabs
            value={tab}
            onChange={(_, v) => setTab(v)}
            variant="scrollable"
            scrollButtons="auto"
            sx={{ borderBottom: '1px solid', borderColor: 'divider', minHeight: 44, '& .MuiTab-root': { minHeight: 44, textTransform: 'none', fontWeight: 600 }, '& .Mui-selected': { color: `${accent} !important` }, '& .MuiTabs-indicator': { bgcolor: accent } }}
          >
            {tabs.map((t) => (
              <Tab key={t.label} icon={t.icon} iconPosition="start" label={t.label} />
            ))}
          </Tabs>

          <Box sx={{ p: { xs: 1.5, md: 2.5 }, minHeight: 240 }}>
            {currentLabel === '대시보드' && (
              <Stack spacing={1.5}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>진행 현황 한눈에 보기</Typography>
                {preview.tasks.map((t) => (
                  <Box key={t.title} sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                    <Box sx={{ width: 120, flexShrink: 0 }}>
                      <Chip label={t.status} size="small" sx={{ height: 20, fontSize: 11, fontWeight: 700, color: t.statusColor, bgcolor: `${t.statusColor}1A` }} />
                    </Box>
                    <Typography variant="body2" sx={{ flex: 1, minWidth: 0 }} noWrap>{t.title}</Typography>
                    <Typography variant="caption" color="text.secondary">{t.assignee}</Typography>
                  </Box>
                ))}
              </Stack>
            )}

            {currentLabel === 'Task' && (
              <Box>
                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 90px 90px 70px', gap: 1, px: 1, pb: 0.8, color: 'text.secondary' }}>
                  <Typography variant="caption" fontWeight={700}>제목</Typography>
                  <Typography variant="caption" fontWeight={700}>담당자</Typography>
                  <Typography variant="caption" fontWeight={700}>상태</Typography>
                  <Typography variant="caption" fontWeight={700}>마감</Typography>
                </Box>
                <Divider />
                {preview.tasks.map((t) => (
                  <Box key={t.title} sx={{ display: 'grid', gridTemplateColumns: '1fr 90px 90px 70px', gap: 1, px: 1, py: 1, alignItems: 'center', borderBottom: '1px solid', borderColor: 'divider' }}>
                    <Typography variant="body2" noWrap>{t.title}</Typography>
                    <Typography variant="caption" color="text.secondary">{t.assignee}</Typography>
                    <Chip label={t.status} size="small" sx={{ height: 20, fontSize: 11, fontWeight: 700, color: t.statusColor, bgcolor: `${t.statusColor}1A`, width: 'fit-content' }} />
                    <Typography variant="caption" color="text.secondary">{t.due}</Typography>
                  </Box>
                ))}
              </Box>
            )}

            {currentLabel === '체크시트' && preview.checklist && (
              <Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5 }}>{preview.checklist.title}</Typography>
                <Stack spacing={1}>
                  {preview.checklist.rows.map((r) => (
                    <Box key={r.label} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      {r.done
                        ? <CheckCircleIcon fontSize="small" sx={{ color: planAiColors.status.success }} />
                        : <RadioButtonUncheckedIcon fontSize="small" sx={{ color: 'text.disabled' }} />}
                      <Typography variant="body2" sx={{ textDecoration: r.done ? 'line-through' : 'none', color: r.done ? 'text.secondary' : 'text.primary' }}>
                        {r.label}
                      </Typography>
                    </Box>
                  ))}
                </Stack>
              </Box>
            )}

            {currentLabel === '이력' && (
              <Stack spacing={1.4}>
                {preview.history.map((h, i) => (
                  <Box key={i} sx={{ display: 'flex', gap: 1.2, alignItems: 'flex-start' }}>
                    <Avatar sx={{ width: 26, height: 26, fontSize: 12, bgcolor: accent }}>{h.actor.slice(0, 1)}</Avatar>
                    <Box>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <Typography variant="body2" sx={{ fontWeight: 600 }}>{h.actor}</Typography>
                        <Typography variant="caption" color="text.secondary">{h.time}</Typography>
                      </Stack>
                      <Typography variant="body2" color="text.secondary">{h.text}</Typography>
                    </Box>
                  </Box>
                ))}
              </Stack>
            )}

            {currentLabel === 'AI 요약' && (
              <Box sx={{ p: 2, borderRadius: 2, bgcolor: `${accent}0A`, border: '1px solid', borderColor: `${accent}33` }}>
                <Stack direction="row" spacing={0.8} alignItems="center" sx={{ mb: 1 }}>
                  <AutoAwesomeIcon fontSize="small" sx={{ color: accent }} />
                  <Typography variant="subtitle2" sx={{ fontWeight: 700, color: accent }}>AI 운영 요약 (예시)</Typography>
                </Stack>
                <Stack spacing={0.8} component="ul" sx={{ m: 0, pl: 2.5 }}>
                  {preview.aiSummary.map((line, i) => (
                    <Typography key={i} variant="body2" color="text.secondary" component="li">{line}</Typography>
                  ))}
                </Stack>
              </Box>
            )}
          </Box>
        </Box>
      </Box>

      {/* 하단 CTA */}
      <Box sx={{ p: 2, display: 'flex', gap: 1.5, justifyContent: 'flex-end', borderTop: '1px solid', borderColor: 'divider', bgcolor: 'background.default' }}>
        <Button onClick={onClose} sx={{ color: 'text.secondary' }}>닫기</Button>
        <Button
          variant="contained"
          onClick={() => onSelect(preview.key)}
          sx={{ bgcolor: accent, fontWeight: 700, '&:hover': { bgcolor: accent, filter: 'brightness(0.92)' } }}
        >
          이 템플릿으로 생성하기
        </Button>
      </Box>
    </Dialog>
  );
};

export default TemplatePreviewDialog;
