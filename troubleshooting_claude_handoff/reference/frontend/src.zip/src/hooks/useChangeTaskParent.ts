import { useCallback } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../api/client';
import type { Task } from '../types';

/**
 * 상위 작업(parent_task_id) 변경/해제 공통 mutation + 실행 취소(Undo) helper.
 *
 * Board·Graph·컨텍스트 메뉴가 각각 별도 로직을 두지 않고 이 하나를 재사용한다.
 * - 기존 endpoint(`PATCH /api/tasks/{id}/parent`) 재사용, 새 API 없음.
 * - optimistic 으로 `['tasks', projectId, currentUserId]` 캐시를 즉시 갱신하고 실패 시 롤백.
 * - 성공 시 view 가 넘긴 `notify` 로 스낵바를 띄우며, undo 콜백은 **이전 parent 로 복원**(같은
 *   mutation·endpoint 재사용, 대상 Task 의 parent_task_id 만 되돌리고 children 은 건드리지 않음).
 * - Undo 도 백엔드의 같은 프로젝트/같은 Board 단계/cycle 검증을 다시 통과해야 반영된다.
 */
export interface ParentChangeNotify {
  (opts: { message: string; variant: 'success' | 'error'; undo?: () => void }): void;
}

export interface ChangeParentArgs {
  taskId: number;
  newParentId: number | null;
  previousParentId: number | null;
  activeTitle?: string;
  targetTitle?: string;
  notify: ParentChangeNotify;
}

export function useChangeTaskParent(projectId: number, currentUserId: number | null | undefined) {
  const queryClient = useQueryClient();
  const tasksKey = ['tasks', projectId, currentUserId] as const;

  const mutation = useMutation({
    mutationFn: ({ taskId, parentId }: { taskId: number; parentId: number | null }) =>
      api.updateTaskParent(taskId, parentId),
    onMutate: async ({ taskId, parentId }) => {
      await queryClient.cancelQueries({ queryKey: tasksKey });
      const prev = queryClient.getQueryData<Task[]>(tasksKey);
      queryClient.setQueryData<Task[]>(tasksKey, (old) =>
        (old || []).map((t) => (t.id === taskId ? { ...t, parent_task_id: parentId } : t)),
      );
      return { prev };
    },
    onError: (_e, _vars, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(tasksKey, ctx.prev); // UI 원상 복구
    },
    onSettled: () => {
      // Board/List/Roadmap 은 tasks query, Graph 는 graph query 를 참조 → 함께 최신화.
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['graph', projectId] });
      queryClient.invalidateQueries({ queryKey: ['roadmap', projectId] });
    },
  });

  const changeParent = useCallback(
    (args: ChangeParentArgs) => {
      mutation.mutate(
        { taskId: args.taskId, parentId: args.newParentId },
        {
          onSuccess: () => {
            const message =
              args.newParentId == null
                ? `"${args.activeTitle ?? '작업'}"의 상위 작업 연결이 해제되었습니다.`
                : `"${args.activeTitle ?? '작업'}"이(가) "${args.targetTitle ?? '상위 작업'}"의 하위 작업으로 연결되었습니다.`;
            args.notify({
              message,
              variant: 'success',
              undo: () => {
                // 최근 변경 1건만 되돌린다. 이전 parent 로 복원 — 실패 시(검증/삭제 등) 안내.
                mutation.mutate(
                  { taskId: args.taskId, parentId: args.previousParentId },
                  { onError: () => args.notify({ message: '실행 취소에 실패했습니다.', variant: 'error' }) },
                );
              },
            });
          },
          onError: () =>
            args.notify({ message: '상위 작업 변경에 실패했습니다. 변경을 되돌렸습니다.', variant: 'error' }),
        },
      );
    },
    [mutation],
  );

  return { changeParent };
}
