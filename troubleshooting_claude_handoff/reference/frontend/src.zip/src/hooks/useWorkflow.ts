import { useQuery } from '@tanstack/react-query';
import { api } from '../api/client';
import type { WorkflowConfig } from '../types';

/**
 * 프로젝트별 워크플로우 컬럼 설정을 react-query로 캐싱한다.
 * 프로젝트 진입 시 1회 조회하고 Board/TaskDrawer/설정 Drawer가 공유한다.
 * DEFAULT 모드 프로젝트는 columns가 비어 있고 mode='DEFAULT'로 내려온다.
 */
export const workflowQueryKey = (projectId: number) => ['workflow-columns', projectId];

export function useWorkflow(projectId: number | undefined) {
  return useQuery<WorkflowConfig>({
    queryKey: workflowQueryKey(projectId ?? 0),
    queryFn: () => api.getWorkflowColumns(projectId as number),
    enabled: !!projectId,
    staleTime: 60_000,
  });
}
