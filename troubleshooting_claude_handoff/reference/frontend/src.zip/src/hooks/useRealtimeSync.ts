import { useEffect, useRef } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { api } from '../api/client';

/**
 * useRealtimeSync — 같은 space 사용자 간 변경사항을 새로고침 없이 2~5초 내 반영한다.
 *
 * 동작:
 *  1) 인증된 사용자가 단발성 ticket 을 발급받고 EventSource(`/api/events/stream`)로 접속한다.
 *  2) SSE 이벤트(type)에 따라 React Query 를 invalidate 한다 (debounce 로 묶어서 호출).
 *  3) invalidate 후에는 기존 API 재조회로 화면이 갱신된다 (payload 를 화면 state 에 직접 넣지 않음).
 *
 * 부하 제어:
 *  - 앱/레이아웃 레벨에서 1개만 마운트한다 (페이지마다 여러 개 만들지 않는다).
 *  - space 변경 시 기존 연결 close 후 재연결, spaceId 없으면 연결하지 않는다.
 *  - 이벤트가 연속으로 들어와도 invalidate 는 debounce(기본 600ms)로 1회로 묶는다.
 */

// client.ts 와 동일한 규칙으로 base URL 산출
const API_URL =
  import.meta.env.VITE_API_URL || `http://${window.location.hostname}:8085/api`;

const INVALIDATE_DEBOUNCE_MS = 600;
const RECONNECT_BASE_MS = 2000;
const RECONNECT_MAX_MS = 30000;

// task 이벤트는 목록/대시보드/로드맵/캘린더/그래프 등 파급이 크다.
const TASK_KEYS = [
  'tasks',
  'projects',
  'stats',
  'spaceOverview',
  'globalRoadmap',
  'roadmap',
  'calendarEvents',
  'graph',
  'subprojects',
];
const PROJECT_KEYS = [
  'projects',
  'stats',
  'spaceOverview',
  'globalRoadmap',
  'calendarEvents',
  'roadmap',
];
const CALENDAR_KEYS = ['calendarEvents', 'stats', 'spaceOverview', 'globalRoadmap'];
const VOC_KEYS = ['voc-list', 'voc-stats'];
// 대량 작업(CSV import 등) — task 전체 파급 집합과 동일하게 한 번만 묶어 재조회
const BULK_KEYS = TASK_KEYS;

/**
 * 이벤트 type → invalidate 할 React Query key prefix 목록.
 * 실제 query key 는 [name, userId, spaceId] 형태가 많지만 invalidateQueries 는
 * prefix 매칭이므로 최상위 name 만으로 모든 변형을 무효화한다.
 */
function keysForType(type: string | undefined): string[] {
  if (!type) return [];
  if (type.endsWith('bulk_changed')) return BULK_KEYS;
  if (type.startsWith('task')) return TASK_KEYS;
  if (type.startsWith('project')) return PROJECT_KEYS;
  if (type.startsWith('calendar_event')) return CALENDAR_KEYS;
  if (type.startsWith('voc')) return VOC_KEYS; // voc_created / voc_updated / voc_comment_created
  return [];
}

const REALTIME_EVENT_TYPES = [
  'task_created',
  'task_updated',
  'task_deleted',
  'task_auto_advanced',
  'project_created',
  'project_updated',
  'project_deleted',
  'calendar_event_created',
  'calendar_event_updated',
  'calendar_event_deleted',
  'voc_created',
  'voc_updated',
  'voc_comment_created',
  'task_bulk_changed',
  'project_bulk_changed',
  'space_bulk_changed',
];

export function useRealtimeSync(spaceId?: number | null): void {
  const queryClient = useQueryClient();
  const esRef = useRef<EventSource | null>(null);
  const pendingRef = useRef<Set<string>>(new Set());
  const flushTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const attemptRef = useRef(0);

  useEffect(() => {
    if (!spaceId || spaceId <= 0) return;

    let cancelled = false;

    const flush = () => {
      flushTimerRef.current = null;
      const keys = Array.from(pendingRef.current);
      pendingRef.current.clear();
      for (const k of keys) {
        queryClient.invalidateQueries({ queryKey: [k] });
      }
    };

    const schedule = (keys: string[]) => {
      if (keys.length === 0) return;
      for (const k of keys) pendingRef.current.add(k);
      if (flushTimerRef.current == null) {
        flushTimerRef.current = setTimeout(flush, INVALIDATE_DEBOUNCE_MS);
      }
    };

    const handleData = (raw: string) => {
      let type: string | undefined;
      try {
        type = JSON.parse(raw)?.type;
      } catch {
        return;
      }
      schedule(keysForType(type));
    };

    const closeEs = () => {
      if (esRef.current) {
        esRef.current.close();
        esRef.current = null;
      }
    };

    const scheduleReconnect = () => {
      if (cancelled) return;
      if (reconnectTimerRef.current != null) return;
      const delay = Math.min(
        RECONNECT_BASE_MS * 2 ** attemptRef.current,
        RECONNECT_MAX_MS,
      );
      attemptRef.current += 1;
      reconnectTimerRef.current = setTimeout(() => {
        reconnectTimerRef.current = null;
        connect();
      }, delay);
    };

    const connect = async () => {
      if (cancelled) return;
      let ticket: string;
      try {
        const res = await api.createEventsTicket(spaceId);
        ticket = res.ticket;
      } catch (e: any) {
        const status = e?.response?.status;
        // 권한 없음/미로그인은 재시도하지 않는다 (조용히 비활성).
        if (status === 401 || status === 403 || status === 400) {
          console.warn('[realtime] sync disabled for space', spaceId, '(', status, ')');
          return;
        }
        scheduleReconnect();
        return;
      }
      if (cancelled) return;

      const url = `${API_URL}/events/stream?space_id=${spaceId}&ticket=${encodeURIComponent(
        ticket,
      )}`;
      const es = new EventSource(url);
      esRef.current = es;

      es.onopen = () => {
        attemptRef.current = 0;
      };

      // 기본(이름 없는) 메시지 + 명시적 이벤트 타입 모두 동일 처리
      es.onmessage = ev => handleData(ev.data);
      const onNamed = (ev: MessageEvent) => handleData(ev.data);
      for (const t of REALTIME_EVENT_TYPES) {
        es.addEventListener(t, onNamed as EventListener);
      }

      es.onerror = () => {
        // 과도한 에러 팝업 없이 console.warn 만. 직접 재연결을 관리한다.
        console.warn('[realtime] EventSource error — reconnecting');
        closeEs();
        scheduleReconnect();
      };
    };

    connect();

    return () => {
      cancelled = true;
      closeEs();
      if (flushTimerRef.current) {
        clearTimeout(flushTimerRef.current);
        flushTimerRef.current = null;
      }
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      pendingRef.current.clear();
      attemptRef.current = 0;
    };
  }, [spaceId, queryClient]);
}

export default useRealtimeSync;
