import React, { useMemo } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline } from '@mui/material';
import { createPlanAiTheme } from './theme/planAiTheme';
import { useAppStore } from './stores/useAppStore';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { SnackbarProvider } from 'notistack';

import HomePage from './pages/HomePage';
import ProjectPage from './pages/ProjectPage';
import KanbanBoardPage from './pages/KanbanBoardPage';
import TrashPage from './pages/TrashPage';
import AiSettingsPage from './pages/AiSettingsPage';
import GlobalRoadmapPage from './pages/GlobalRoadmapPage';
import AdminPage from './pages/AdminPage';
import SsoCallback from './pages/SsoCallbackPage';

import { MainLayout } from './layouts/MainLayout';
import TaskDrawer from './components/TaskDrawer';
import CalendarEventDialog from './components/CalendarEventDialog';
import GlobalRequestIndicator from './components/GlobalRequestIndicator';
import { UserProvider } from './context/UserContext';
import MentionsPage from './pages/MentionsPage';
import AccessDeniedPage from './pages/AccessDeniedPage';
import GroupPage from './pages/GroupPage';
import SpaceManagePage from './pages/SpaceManagePage';
import SheetTemplatePage from './pages/SheetTemplatePage';
import SheetExecutionPage from './pages/SheetExecutionPage';
import SheetHistoryPage from './pages/SheetHistoryPage';
import VOCPage from './pages/VOCPage';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 30000,
    },
  },
});

const withMainLayout = (element: React.ReactNode) => <MainLayout>{element}</MainLayout>;

const App: React.FC = () => {
  // 고급 설정(포인트색/둥글기/그림자)을 반영해 MUI 테마를 동적으로 생성.
  const accent = useAppStore(state => state.customTheme.accent);
  const radius = useAppStore(state => state.customTheme.radius);
  const shadow = useAppStore(state => state.customTheme.shadow);
  const theme = useMemo(
    () => createPlanAiTheme({ accent, radius, shadow }),
    [accent, radius, shadow],
  );

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <SnackbarProvider
          maxSnack={3}
          autoHideDuration={3000}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        >
          <UserProvider>
            {/* 전역 요청 진행 상태(현재 브라우저 기준) — 상단 진행바 + 지연 안내 */}
            <GlobalRequestIndicator />
            <Routes>
              {/* SSO 콜백 (레이아웃 없이) */}
              <Route path="/sso-callback" element={<SsoCallback />} />
              <Route path="/access-denied" element={<AccessDeniedPage />} />

              {/* Space 기반 라우팅 — 모든 페이지가 space 컨텍스트 아래 */}
              <Route path="/space/:spaceSlug" element={withMainLayout(<HomePage />)} />
              <Route path="/space/:spaceSlug/project/kanbanboard" element={withMainLayout(<KanbanBoardPage />)} />
              <Route path="/space/:spaceSlug/project/:id" element={withMainLayout(<ProjectPage />)} />
              <Route path="/space/:spaceSlug/trash" element={withMainLayout(<TrashPage />)} />
              <Route path="/space/:spaceSlug/ai-settings" element={withMainLayout(<AiSettingsPage />)} />
              <Route path="/space/:spaceSlug/roadmap" element={withMainLayout(<GlobalRoadmapPage />)} />
              <Route path="/space/:spaceSlug/mentions" element={withMainLayout(<MentionsPage />)} />
              <Route path="/space/:spaceSlug/admin" element={withMainLayout(<AdminPage />)} />
              <Route path="/space/:spaceSlug/groups" element={withMainLayout(<GroupPage />)} />
              <Route path="/space/:spaceSlug/spaces" element={withMainLayout(<SpaceManagePage />)} />
              <Route path="/space/:spaceSlug/sheets" element={withMainLayout(<SheetTemplatePage />)} />
              <Route path="/space/:spaceSlug/sheets/execution/:executionId" element={withMainLayout(<SheetExecutionPage />)} />
              <Route path="/space/:spaceSlug/sheets/history" element={withMainLayout(<SheetHistoryPage />)} />
              <Route path="/space/:spaceSlug/voc" element={withMainLayout(<VOCPage />)} />

              {/* 레거시 루트 — space 없이 접근 시 기본 공간으로 리다이렉트 */}
              <Route path="/" element={withMainLayout(<HomePage />)} />
              <Route path="/project/kanbanboard" element={withMainLayout(<KanbanBoardPage />)} />
              <Route path="/project/:id" element={withMainLayout(<ProjectPage />)} />
              <Route path="/trash" element={withMainLayout(<TrashPage />)} />
              <Route path="/ai-settings" element={withMainLayout(<AiSettingsPage />)} />
              <Route path="/roadmap" element={withMainLayout(<GlobalRoadmapPage />)} />
              <Route path="/mentions" element={withMainLayout(<MentionsPage />)} />
              <Route path="/admin" element={withMainLayout(<AdminPage />)} />
              <Route path="/groups" element={withMainLayout(<GroupPage />)} />
              <Route path="/spaces" element={withMainLayout(<SpaceManagePage />)} />
              <Route path="/voc" element={withMainLayout(<VOCPage />)} />

              {/* fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>

            {/* 전역 Drawer */}
            <TaskDrawer />
            {/* 전역 단발 일정 다이얼로그 (Phase 2) */}
            <CalendarEventDialog />
          </UserProvider>
        </SnackbarProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
};

export default App;
