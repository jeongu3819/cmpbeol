export interface User {
  id: number;
  loginid: string;
  username: string;
  role?: string;
  avatar_color?: string;
  is_active?: boolean;
  group_name?: string;
  deptname?: string;
  mail?: string;
}

// ── VOC / 개선 요청 ──
export type VocCategory = 'bug' | 'improvement' | 'feature' | 'ux' | 'design' | 'etc';
export type VocRelatedScreen =
  | 'dashboard'
  | 'space'
  | 'project'
  | 'settings'
  | 'sheet'
  | 'messenger'
  | 'ai_report'
  | 'etc';
export type VocPriority = 'low' | 'normal' | 'high' | 'urgent';
export type VocStatus = 'received' | 'reviewing' | 'in_progress' | 'completed' | 'on_hold';
export type VocVisibility = 'public' | 'private';

export interface VocAttachment {
  id: number;
  voc_id: number;
  filename: string;
  stored_name: string;
  content_type?: string | null;
  file_size?: number | null;
  width?: number | null;
  height?: number | null;
  url: string;
  created_at?: string | null;
}

export interface VocItem {
  id: number;
  author_id: number;
  author_name?: string | null;
  author_loginid?: string | null;
  author_color?: string | null;
  title: string;
  category: VocCategory;
  content: string;
  related_screen?: VocRelatedScreen | null;
  priority: VocPriority;
  status: VocStatus;
  visibility?: VocVisibility;
  admin_note?: string | null;
  resolved_by?: number | null;
  resolver_name?: string | null;
  edited_by?: number | null;
  editor_name?: string | null;
  edited_at?: string | null;
  change_summary?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  attachments?: VocAttachment[];
  attachment_count?: number;
  vote_count?: number;
  voted_by_me?: boolean;
}

export interface VocStats {
  total: number;
  completed: number;
  completion_rate: number;
  by_status: Record<VocStatus, number>;
}

export interface VocComment {
  id: number;
  voc_id: number;
  author_id: number;
  author_name?: string | null;
  author_color?: string | null;
  is_admin_reply: boolean;
  content: string;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface Project {
  id: number;
  name: string;
  description?: string;
  owner_id?: number;
  visibility?: string;
  created_at?: string;
  require_approval?: boolean;
  space_id?: number;
  workflow_mode?: WorkflowMode;
  auto_progress_from_notes?: boolean;
  permissions?: {
    post_write?: string;
    post_edit?: string;
    post_view?: string;
    comment_write?: string;
    file_view?: string;
    file_download?: string;
  };
}

// 아이템(프로젝트/Task/일정)별 변경 이력 1건
export interface ActivityLogChange {
  field: string;
  label: string;
  before?: unknown;
  after?: unknown;
}

export interface ActivityLogEntry {
  id: number;
  action: string;            // created / updated / deleted / status_changed / assignee_changed / moved / restored
  entity_type: 'project' | 'task' | 'calendar_event';
  entity_id: number;
  user_id: number | null;
  user_name: string | null;
  message: string | null;
  meta?: { changes?: ActivityLogChange[]; [k: string]: unknown } | null;
  created_at: string | null;
}

export type SpacePurpose =
  | 'project_management'
  | 'equipment_ops'
  | 'process_change'
  | 'sw_dev'
  | 'integrated_ops'
  | 'custom';

export interface Space {
  id: number;
  name: string;
  slug: string;
  description?: string;
  created_by?: number;
  is_active: boolean;
  created_at?: string;
  purpose?: SpacePurpose;
  member_count: number;
  members: SpaceMemberInfo[];
}

export interface SpaceMemberInfo {
  user_id: number;
  role: string;
  username: string;
  loginid: string;
  avatar_color?: string;
}

export interface ProjectFile {
  id: number;
  project_id: number;
  filename: string;
  stored_name: string;
  size: number;
  uploader_id: number;
  created_at: string;
}

export interface SubProject {
  id: number;
  project_id: number;
  parent_id?: number | null;
  name: string;
  description?: string;
  created_at?: string;
}

export interface Task {
  id: number;
  project_id: number;
  title: string;
  description?: string;
  status: 'todo' | 'in_progress' | 'done' | 'hold';
  priority?: 'low' | 'medium' | 'high';
  task_type?: 'normal' | 'one_off';
  start_date?: string | null;
  due_date?: string | null;
  // 일정 미정(TBD): 날짜가 단순 누락(null)인 것과, 사용자가 의도적으로 "미정"으로 둔 것을 구분.
  start_date_tbd?: boolean;
  due_date_tbd?: boolean;
  assignee_ids: number[];
  // Board 검색용 표시명 (get_tasks payload enrich — 별도 users/subProjects 로딩 불필요)
  assignee_names?: string[];
  assignee_login_ids?: string[];
  sub_project_name?: string | null;
  tags?: string[];
  sub_project_id?: number | null;
  progress?: number;
  remarks?: string;
  attachment_count?: number;
  // ── Task 상하 관계 (Parent / Child) ──
  parent_task_id?: number | null;   // null = 최상위 Task
  child_task_count?: number;        // get_tasks enrich — Board 부모 카드 "하위 N개" 뱃지용
  // 현재 단계 완료 선언 여부 (사용자 완료 선언 기반 자동 이동)
  current_stage_completed?: boolean;
  archived_at?: string | null;
  created_at?: string;
  updated_at?: string;
  // ── CUSTOM 워크플로우 (Slice 1) ──
  workflow_column_id?: number | null;
  workflow_label?: string | null;          // get_tasks enrich (표시용)
  workflow_mapped_status?: string | null;  // 컬럼의 canonical status
  workflow_color?: string | null;
}

// ── 프로젝트별 커스텀 워크플로우 컬럼 ──
export type WorkflowMode = 'DEFAULT' | 'CUSTOM';

export interface WorkflowColumn {
  id: number;
  project_id?: number;
  key?: string | null;
  label: string;
  description?: string | null;   // 단계 세부 설명 (Board 헤더 제목 아래 표시)
  mapped_status: 'todo' | 'in_progress' | 'done' | 'hold';
  sort_order: number;
  color?: string | null;
  is_final_done: boolean;
  active: boolean;
  // 중간 완료 체크포인트 (보조 지표 — 최종 완료/Completion 계산과 무관)
  is_checkpoint?: boolean;
  checkpoint_label?: string | null;
  checkpoint_description?: string | null;
  // 진행률 기준 자동 이동 (레거시/고급 progress_threshold 규칙용). 기본 OFF.
  auto_advance_enabled?: boolean;
  auto_advance_threshold?: number | null;
  // 단계 완료 조건: all_required_checkpoints(기본) / manual / progress_threshold(레거시)
  completion_rule_type?: CompletionRuleType;
  // 4차: 단계 완료 선언 시 다음 단계로 자동 이동할지 여부 (기본 true, 마지막 단계 제외)
  auto_move_on_complete?: boolean;
}

export type CompletionRuleType = 'all_required_checkpoints' | 'manual' | 'progress_threshold';

// 진행률 기준 자동 이동 발생 시 백엔드가 반환하는 정보 (toast/Board 갱신용)
export interface TaskAutoAdvanceResult {
  task_id: number;
  from_column_id: number;
  to_column_id: number;
  to_column_label: string;
  to_status: string;
  moved_child_task_count: number;
  // progress 규칙일 때
  progress?: number;
  threshold?: number;
  // 체크포인트 규칙일 때
  completed_checkpoint_count?: number;
}

// 중간 완료 체크포인트 진행 지표 (백엔드 _compute_completion_checkpoints 와 동일 형태)
export interface CompletionCheckpoint {
  checkpointColumnId: number;
  checkpointLabel: string;
  checkpointDescription?: string | null;
  targetColumnLabel: string;
  targetSortOrder: number;
  passedTaskCount: number;
  totalTaskCount: number;
  progressPercent: number;
  status: 'completed' | 'in_progress' | 'waiting';
}

export interface WorkflowConfig {
  mode: WorkflowMode;
  auto_progress_from_notes: boolean;
  columns: WorkflowColumn[];
  completion_checkpoints?: CompletionCheckpoint[];
}

export interface WorkflowModePreview {
  target_mode: WorkflowMode;
  columns: { label: string; mapped_status: string; restored?: boolean }[];
  task_buckets: Record<string, number>;
  auto_progress_note: string;
}

export interface CalendarEvent {
  id: number;
  space_id: number;
  title: string;
  description?: string | null;
  start_date?: string | null;
  end_date?: string | null;
  all_day: boolean;
  status: 'planned' | 'in_progress' | 'done' | 'canceled';
  event_type?: string;
  owner_id?: number | null;
  assignee_id?: number | null;
  linked_task_id?: number | null;
  linked_project_id?: number | null;
  created_at?: string;
  updated_at?: string;
}

export interface Note {
  id: number;
  project_id: number;
  author_id: number;
  content: string;
  created_at: string;
  updated_at?: string;
  author_name?: string;
  author_color?: string;
  mentioned_user_ids?: number[];
}

export interface MentionNote extends Note {
  project_name?: string;
  // source 구분: 작업노트(activity) / Task 댓글(task_comment) / 메모(없음)
  source?: 'activity' | 'task_comment';
  source_label?: string;
  task_id?: number;
  task_title?: string;
  comment_id?: number;
  // 딥링크/목록 클릭이 현재 store space가 아니라 멘션의 space로 이동하도록
  space_slug?: string | null;
}

// 딥링크 단건 조회 (GET /api/mentions/{ref})
export interface MentionDetail {
  id: string; // 'comment-{id}' | 'activity-{id}'
  source_type: 'task_comment' | 'task_work_note';
  space_id?: number | null;
  space_slug?: string | null;
  project_id?: number | null;
  task_id?: number | null;
  comment_id?: number | null;
  work_note_id?: number | null;
  content_preview?: string;
  created_at?: string | null;
  author?: { id: number; username?: string; loginid?: string } | null;
}

// 사용자 멘션 메일 알림 설정 (GET/PATCH /api/users/me/notification-preferences)
export interface NotificationPreference {
  user_id: number;
  mention_email_enabled: boolean;
  task_mention_email_enabled: boolean;
  work_note_mention_email_enabled: boolean;
  task_comment_email_enabled: boolean;
}

export interface Attachment {
  id: number;
  task_id: number;
  url: string;
  filename?: string;
  type?: string;
  stored_name?: string;
  size?: number;
  created_at?: string;
}

export interface TaskActivity {
  id: number;
  task_id: number;
  block_type: 'checkbox' | 'text';
  order_index: number;
  content: string;
  checked: boolean;
  checked_at?: string | null;
  style?: { bold?: boolean; color?: string };
  created_at?: string;
  // 단계 완료 체크포인트 메타 (자동 이동 판단 대상)
  is_stage_checkpoint?: boolean;
  checkpoint_stage_id?: number | null;
  checkpoint_required?: boolean;
}

export interface TaskCommentAttachment {
  id: number;
  comment_id: number | null;
  task_id: number;
  filename?: string | null;
  stored_name?: string | null;
  content_type?: string | null;
  file_size?: number | null;
  width?: number | null;
  height?: number | null;
  url: string;
  created_at?: string | null;
}

export interface TaskComment {
  id: number;
  task_id: number;
  author_user_id: number | null;
  author_name?: string | null;
  author_color?: string | null;
  content: string;
  deleted: boolean;
  mentioned_user_ids: number[];
  attachments?: TaskCommentAttachment[];
  created_at?: string | null;
  updated_at?: string | null;
  edited_at?: string | null;
  can_edit: boolean;
  can_delete: boolean;
}

export interface RoadmapItem {
  id: string;
  type: 'project' | 'subproject' | 'task';
  // task 항목 전용 — 다단계 계층(parent_task_id) 트리 구성을 위한 숫자 id/부모 id (백엔드 enrich)
  task_id?: number;
  parent_task_id?: number | null;
  name: string;
  start_date?: string | null;
  due_date?: string | null;
  start_date_tbd?: boolean;
  due_date_tbd?: boolean;
  status: string;
  progress: number;
  overdue: boolean;
  children?: RoadmapItem[];
  assignee_ids?: number[];
  // CUSTOM 워크플로우 (task item 전용, 백엔드 enrich)
  workflow_label?: string | null;
  workflow_color?: string | null;
}

export interface ActivityLog {
  id: number;
  task_id: number;
  user_id: number;
  action: string;
  details: string;
  created_at: string;
}

export interface ProjectMember {
  project_id: number;
  user_id: number;
  role: string;
  username?: string;
  avatar_color?: string;
  loginid?: string;
  deptname?: string;
  mail?: string;
}

export interface GraphNode {
  id: string;
  type: string;
  label: string;
  status?: string;
  attachment_type?: string;
  url?: string;
  // CUSTOM 워크플로우 (task node 전용, 백엔드 enrich)
  workflow_label?: string | null;
  workflow_color?: string | null;
}

export interface GraphEdge {
  source: string;
  target: string;
}

export interface SearchResultProject {
  project: Project;
  tasks: Task[];
  sub_projects: SubProject[];
  notes: Note[];
  files: ProjectFile[];
  progress: number;
  status_counts: { total: number; done: number; in_progress: number; todo: number; hold: number };
  overdue_tasks: Task[];
  upcoming_tasks: Task[];
}

export interface AiProjectSummary {
  project_id: number;
  project_name: string;
  one_liner: string;
  status_text: string;
  key_schedule: string;
  sub_project_summary: string;
  related_materials: string;
  risks: string;
  next_actions: string;
}

export interface SearchSummaryResult {
  id: number;
  query: string;
  overall_summary: string;
  project_summaries: AiProjectSummary[];
  model: string;
  created_at: string;
}

export interface ProjectAiQueryResponse {
  id: number;
  project_id: number;
  user_id: number;
  query: string;
  parsed_response: {
    one_liner: string;
    details: string;
    key_schedule: string;
    next_actions: string;
  };
  raw_response: string;
  model: string;
  created_at: string;
  context?: {
    project_name: string;
    members: string[];
    tasks: {
      id: number;
      title: string;
      status: string;
      priority: string;
      progress: number;
      due_date: string | null;
      assignees: string[];
      sub_project: string;
      description: string;
    }[];
    status_breakdown: {
      total: number;
      done: number;
      in_progress: number;
      todo: number;
      hold: number;
      overall_progress: number;
    };
    filter?: {
      mode: string;
      window_start?: string | null;
      window_end?: string | null;
    };
  };
}

// ========================================
// v3.0 Sheet 운영 타입
// ========================================

export interface ColumnRoleInfo {
  col: number;       // 0-based column index
  header: string;    // detected header text
  confidence: number; // 0~1
  editor_type?: 'text' | 'textarea' | 'select' | 'date'; // 에디터 타입
  virtual?: boolean; // 웹에서 가상 생성된 컬럼 여부
}

export interface ColumnRoleMapping {
  check_status?: ColumnRoleInfo;
  checked_at?: ColumnRoleInfo;
  assignee?: ColumnRoleInfo;
  due_date?: ColumnRoleInfo;
  planned_date?: ColumnRoleInfo;
  progress_date?: ColumnRoleInfo;
  cycle?: ColumnRoleInfo;
  remark?: ColumnRoleInfo;
}

export type SheetType = 'inspection' | 'assignment_mapping';

export interface SheetTemplate {
  id: number;
  name: string;
  description?: string;
  category?: string;
  original_filename?: string;
  sheet_name?: string;
  sheet_type?: SheetType;
  structure?: SheetStructure;
  row_count: number;
  col_count: number;
  checkable_count: number;
  column_role_mapping?: ColumnRoleMapping | null;
  structure_hash?: string;
  created_by?: number;
  created_at?: string;
}

export interface SheetStructure {
  cells: SheetCell[];
  merges: SheetMerge[];
  col_widths?: number[];
  row_heights?: number[];
  total_rows: number;
  total_cols: number;
  checkable_cells: SheetCheckableCell[];
  headers?: { col: number; value: string }[];
  column_roles?: ColumnRoleMapping;
  header_row_idx?: number;
  data_start_row?: number;
  structure_hash?: string;
  suggested_type?: SheetType;
}

export interface SheetCell {
  row: number;
  col: number;
  value: string;
  type?: string;
  bg?: string;
  font?: { bold?: boolean; italic?: boolean; fontSize?: number; fontColor?: string };
  borders?: Record<string, string>;
  align?: string;
  wrapText?: boolean;
  rowSpan?: number;
  colSpan?: number;
}

export interface SheetMerge {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}

export interface SheetCheckableCell {
  ref: string;
  row: number;
  col: number;
  label: string;
  initial_value?: string;
  parsed_status?: string;
  parsed_note?: string;
}

export interface SheetExecution {
  id: number;
  template_id: number;
  project_id?: number;
  task_id?: number;
  title: string;
  equipment_name?: string;
  sheet_type?: SheetType;
  // v3.9: 'unlinked' = Task에서 연결 해제된 시트 (Dashboard 진행 중 카운트에서 제외, Sheets 관리 화면에서 삭제 가능)
  status: 'in_progress' | 'completed' | 'cancelled' | 'unlinked';
  total_items: number;
  checked_items: number;
  progress: number;
  started_by?: number;
  started_at?: string;
  completed_at?: string;
  completed_by?: number;
  template_structure?: SheetStructure;
  template_name?: string;
  /** SheetTemplate.category — Dashboard 위젯이 약품관리/일반/점검 등 카테고리별로 분류할 때 사용. */
  template_category?: string;
  items?: SheetExecutionItem[];
  mappings?: SheetExecutionMapping[];
  hidden_rows?: number[];
  hidden_cols?: number[];
  structure_overlay?: StructureOverlay;
}

export interface AddedColumn {
  col_idx: number;
  header: string;
  /** 'equipment' = 칩/DnD 셀, 'plain' = 일반 텍스트 셀. 미지정은 'equipment' 로 간주(legacy). */
  kind?: 'equipment' | 'plain';
}

export interface AddedRow {
  row_idx: number;
}

export interface StructureOverlay {
  added_columns?: AddedColumn[];
  added_rows?: AddedRow[];
  renamed_headers?: Record<string, string>;
  /** added_columns 의 표시 순서 (col_idx 배열). 미지정 시 col_idx 오름차순. */
  added_columns_order?: number[];
  /** added_rows 의 표시 순서 (row_idx 배열). 미지정 시 row_idx 오름차순. */
  added_rows_order?: number[];
  /**
   * 전체 컬럼 렌더 순서 (base + added 통합 col_idx 배열). 추가 컬럼을 base 컬럼 사이에 끼워
   * 넣을 때 사용. 미지정 시 base asc + added(=added_columns_order) 폴백.
   */
  column_order?: number[];
  /** 전체 행 렌더 순서 (base + added 통합 row_idx 배열). 미지정 시 base asc + added 폴백. */
  row_order?: number[];
}

export interface SheetExecutionMapping {
  id: number;
  master_name: string;
  master_code?: string;
  assigned_entity: string;
  manager?: string;
  last_checked_at?: string;
  note?: string;
}

export interface SheetExecutionItem {
  id: number;
  cell_ref: string;
  row_idx: number;
  col_idx: number;
  label: string;
  checked: boolean;
  value?: string;
  memo?: string;
  checked_by?: number;
  checked_at?: string;
}

export interface SheetExecutionLog {
  id: number;
  action: string;
  item_id?: number;
  old_value?: string;
  new_value?: string;
  memo?: string;
  user_id?: number;
  created_at?: string;
}

// ── 시스템 이벤트 로그 (운영 확인용 요약 로그) ──
export type SystemLogLevel = 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
export type SystemLogCategory =
  | 'API' | 'DB' | 'S3' | 'KNOX' | 'DSLLM' | 'BACKUP' | 'AUTH' | 'FRONTEND' | 'ADMIN' | 'VISION_AI';

// VISION_AI 로그의 구조화 진단(detail_json). 비민감 지표만 담긴다.
export interface VisionDiagnosticDetails {
  project_id?: number | null;
  canonical_image_id?: string | null;
  image_count?: number | null;
  image_transport?: string | null;
  mime?: string | null;
  width?: number | null;
  height?: number | null;
  original_bytes?: number | null;
  processed_bytes?: number | null;
  base64_chars?: number | null;
  payload_bytes?: number | null;
  max_tokens?: number | null;
  timeout_seconds?: number | null;
  elapsed_ms?: number | null;
  batch_index?: number | null;
  batch_size?: number | null;
}

export interface VisionDiagnostic {
  failure_stage?: string;
  failure_stage_label?: string;
  error_type?: string | null;
  provider?: string | null;
  model?: string | null;
  http_status?: number | null;
  message?: string;
  summary?: string;
  likely_cause?: string;
  recommended_action?: string;
  retry_safe?: boolean;
  recovery_event?: boolean;
  details?: VisionDiagnosticDetails | null;
}

export interface SystemEventLog {
  id: number;
  level: SystemLogLevel;
  category: SystemLogCategory;
  message: string;
  detail?: string | null;
  diagnostic?: VisionDiagnostic | null;
  endpoint?: string | null;
  method?: string | null;
  status_code?: number | null;
  user_id?: number | null;
  login_id?: string | null;
  request_id?: string | null;
  resolved: boolean;
  resolved_at?: string | null;
  resolved_by?: number | null;
  resolution_note?: string | null;
  created_at?: string | null;
}

export interface SystemLogFilters {
  level?: string;
  category?: string;
  date_from?: string;
  date_to?: string;
  resolved?: boolean;
  keyword?: string;
  endpoint?: string;
  status_code?: number;
  limit?: number;
  offset?: number;
  page?: number;
  page_size?: number;
}

/** 공통 server-side pagination 메타 */
export interface PaginationMeta {
  page: number;
  page_size: number;
  total: number;
  total_pages: number;
  has_next: boolean;
  has_prev: boolean;
}

// ── 로그 삭제/일괄 처리 (관리자) ──
export interface SystemLogFilterSpec {
  level?: string;
  category?: string;
  endpoint?: string;
  status_code?: number;
  search?: string;
  date_from?: string;
  date_to?: string;
  resolved?: boolean;
}

export interface SystemLogFilterPreview {
  matched_count: number;
  oldest: string | null;
  newest: string | null;
  sample: {
    id: number;
    created_at: string | null;
    level: string;
    message: string;
    endpoint?: string | null;
    status_code?: number | null;
    request_id?: string | null;
  }[];
}

export interface BackupEventView {
  time: string | null;
  success: boolean;
  message: string;
  s3_key?: string | null;
}

export interface SystemHealth {
  counts_24h: Record<SystemLogLevel, number>;
  counts_7d: Record<SystemLogLevel, number>;
  unresolved_errors: number;
  last_db_backup: BackupEventView | null;
  last_backup_cleanup: BackupEventView | null;
  recent_backup_events: SystemEventLog[];
  server_time: string;
}
